"""Adds the config field adam_eps (PROTOCOL_lrscale_trajectory.md) and passes it to both AdamW constructions. Behaviour-neutral at its
default: 1e-8 is torch's default, and at that value the field stays OUT of the run identifier (as data_fingerprint, max_new_tokens,
subspace_salted and token_weighted_loss do), so no existing run changes id.

    python scripts/patch_adam_eps.py          # patches src/lorasub/config.py and train.py in place; STOPS if any expected line differs
"""
import sys
from pathlib import Path

C, T = Path("src/lorasub/config.py"), Path("src/lorasub/train.py")
c, t = C.read_text(), T.read_text()
if "adam_eps" in c or "adam_eps" in t:
    print("  deja patche : rien a faire"); sys.exit(0)
edits = [
    (C, "    weight_decay: float = 0.0\n", "    weight_decay: float = 0.0\n    adam_eps: float = 1e-8  # Adam's epsilon; torch's default. Out of the id at this value (id_dict).\n"),
    (C, 'float_fields = ("lr", "alpha", "epochs", "warmup_ratio", "weight_decay",', 'float_fields = ("lr", "alpha", "epochs", "warmup_ratio", "weight_decay", "adam_eps",'),
    (C, '        if not d.get("token_weighted_loss"):\n            d.pop("token_weighted_loss", None)\n',
        '        if not d.get("token_weighted_loss"):\n            d.pop("token_weighted_loss", None)\n'
        '        # same principle: Adam\'s epsilon at torch\'s default (the value every existing run used) stays out of the id\n'
        '        if d.get("adam_eps") == 1e-8:\n            d.pop("adam_eps", None)\n'),
    (T, "    return torch.optim.AdamW(params, lr=cfg.lr, betas=(0.9, 0.999), weight_decay=cfg.weight_decay)\n",
        "    return torch.optim.AdamW(params, lr=cfg.lr, betas=(0.9, 0.999), eps=cfg.adam_eps, weight_decay=cfg.weight_decay)\n"),
    (T, "        opt = torch.optim.AdamW(groups, lr=cfg.lr, betas=(0.9, 0.999), weight_decay=cfg.weight_decay)\n",
        "        opt = torch.optim.AdamW(groups, lr=cfg.lr, betas=(0.9, 0.999), eps=cfg.adam_eps, weight_decay=cfg.weight_decay)\n"),
]
texts = {C: c, T: t}
for path, old, new in edits:
    if texts[path].count(old) != 1:
        sys.exit(f"  STOP : ligne attendue absente ou multiple dans {path} : {old.strip()[:70]!r} ; rien n'est modifie")
for path, old, new in edits:
    texts[path] = texts[path].replace(old, new, 1)
C.write_text(texts[C]); T.write_text(texts[T])
print("  config.py : champ adam_eps (hors identifiant a 1e-8) ; train.py : eps passe aux deux AdamW")
