"""Grids of EVAL_base_models.md: the un-adapted model (mode baseline, rank 0), on the base of each campaign. 8 runs.

    python scripts/make_base_grids.py
"""
import sys
from pathlib import Path

import yaml

H = "# EVALUATION DU MODELE DE BASE (EVAL_base_models.md). Genere par scripts/make_base_grids.py. 2 runs.\n"
CELLS = {  # grid: (base file, expected task, expected model, model to set or None)
    "base_fmt_llama": ("configs/grids/sigma_residual_C2.yaml", "format", "meta-llama/Llama-3.2-1B", None),
    "base_fmt_qwen": ("configs/grids/scale_qwen15.yaml", "format", "Qwen/Qwen2.5-1.5B", None),
    "base_obqa_q7": ("configs/grids/obqa_r2_common.yaml", "commonsense", None, "Qwen/Qwen2.5-7B"),
    "base_obqa_m7": ("configs/grids/obqa_r2_common.yaml", "commonsense", None, "mistralai/Mistral-7B-v0.3"),
}
total = 0
for name, (src, task, model, set_model) in CELLS.items():
    p = Path(src)
    if not p.exists():
        sys.exit(f"STOP : {src} introuvable")
    b = dict((yaml.safe_load(open(p)) or {}).get("base") or {})
    if b.get("task") != task or (model and str(b.get("model")) != model):
        sys.exit(f"STOP : {src} n'est pas la base attendue (tache {b.get('task')}, modele {b.get('model')})")
    if task == "commonsense" and str(b.get("data_fingerprint")) != "dc05f4d847f9":
        sys.exit(f"STOP : {src} n'est pas OpenBookQA")
    for k in ("mode", "rank", "lr", "seed", "band_frac", "update_norm_target"):
        b.pop(k, None)
    if set_model:
        b["model"] = set_model
    b.update(rank=0, save_factor_steps=[])
    Path(f"configs/grids/{name}.yaml").write_text(H + yaml.safe_dump({"base": b, "grid": {"mode": ["baseline"], "seed": [150, 151]}}, sort_keys=False))
    total += 2; print(f"  {name:15s} : {b['model']}, {task}, modele non adapte, graines 150 et 151")
print(f"  total : {total} runs")
if total != 8:
    sys.exit("STOP : le total n'est pas 8")
