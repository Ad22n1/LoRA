"""Recompute every number the paper reports, from the runs, and check it is in short_en.tex.

Each check names the population it measures, in the paper's own terms, computes the value, formats it
the way the paper writes it, and looks for that string. Anything that does not match prints DRIFT.
A cell that does not have its seeds prints INCOMPLETE and is not compared: a missing run must never
look like agreement.

    python scripts/audit_paper.py [paper/short_en.tex]
"""
import os
import re
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
from lorasub.aggregate import collect  # noqa: E402

TEX = sys.argv[1] if len(sys.argv) > 1 else "paper/short_en_working.tex"
LLAMA, QWEN, QWEN15 = "meta-llama/Llama-3.2-1B", "Qwen/Qwen2.5-0.5B", "Qwen/Qwen2.5-1.5B"
S26, S28 = list(range(2, 7)), list(range(2, 9))
tex = re.sub(r"\s+", " ", open(TEX).read())
d = collect(os.path.expanduser("~/lora-runs"))
ok = drift = incomplete = 0


def cell(model=LLAMA, mode="top", rank=2, lr=1e-2, seeds=S26, n_modules=7, band=None):
    # alpha = rank everywhere in the paper; a run at another alpha is another configuration, and one
    # such run (alpha = 16, from 12/09) once passed as a divergence. It is excluded by construction.
    """One cell of the reported population: 7 modules, clipping 1.0, no rescaling, 614 items."""
    x = d[(d.task == "format") & (d.model.astype(str) == model) & (d["mode"] == mode) & (d["rank"] == rank)
          & ((d.lr - lr).abs() < 1e-12) & (d.n_modules == n_modules) & (d.max_grad_norm == 1.0)
          & d.update_norm_target.isna() & (d.format_n == 614) & d.seed.isin(seeds)
          & ((d.alpha / d["rank"]).round(2) == 1.0)]
    if band is not None:
        x = x[(x.band_frac - band).abs() < 1e-9]
    if mode in ("random", "random_ortho"):
        x = x[x.subspace_salted == True]
    return x.groupby("seed").format_parsed.mean()


def check(label, value, fmt="{:.4f}"):
    global ok, drift
    s = fmt.format(value)
    if s in tex:
        ok += 1
        print(f"  ok    {label:52s} {s}")
    else:
        drift += 1
        print(f"  DRIFT {label:52s} computed {s}, not in the tex")


def mean_of(label, expect_n=5, **kw):
    global incomplete
    per = cell(**kw)
    if len(per) != expect_n:
        incomplete += 1
        print(f"  INCOMPLETE {label:47s} {len(per)}/{expect_n} seeds")
        return None
    return float(per.mean())


print("=== the free reference, per rank ===")
free = {}
for r, lr in ((1, 1e-3), (2, 2e-3), (4, 2e-3)):
    v = mean_of(f"free r={r}", mode="free", rank=r, lr=lr)
    if v is not None:
        free[r] = v
        check(f"free r={r}", v)

print("\n=== the constrained arms at their reported rate ===")
RANKS = {("random", 1): 1e-2, ("top", 1): 1e-2, ("bottom", 1): 1e-2,
         ("random", 2): 1e-2, ("top", 2): 1e-2, ("bottom", 2): 5e-3,   # selected on seeds 0, 1, 30-32
         ("random", 4): 1e-2, ("top", 4): 2e-3, ("bottom", 4): 2e-3}
vals = {}
for (m, r), lr in sorted(RANKS.items(), key=lambda kv: (kv[0][1], kv[0][0])):
    v = mean_of(f"{m} r={r}", mode=m, rank=r, lr=lr)
    if v is not None:
        vals[(m, r)] = v
        check(f"{m} r={r} at {lr:g}", v)

print("\n=== the cost of freezing, per rank (free of the same rank minus the best arm) ===")
for r in (1, 2, 4):
    arms = [vals[(m, r)] for m in ("random", "top", "bottom") if (m, r) in vals]
    if r in free and len(arms) == 3:
        check(f"freeze at rank {r}", (free[r] - max(arms)) * 100, "{:.1f}")

print("\n=== the common-rate inversion ===")
for label, model, rank, others in (("Llama rank 2", LLAMA, 2, ("top", "random", "random_ortho")),
                                   ("Llama rank 4", LLAMA, 4, ("top", "random")),
                                   ("Qwen rank 2", QWEN, 2, ("top", "random_ortho")),
                                   ("Qwen-1.5B rank 2", QWEN15, 2, ("top", "random_ortho"))):
    lo = {m: mean_of(f"{label} {m} at 2e-3", model=model, mode=m, rank=rank, lr=2e-3) for m in ("bottom",) + others}
    hi = {m: mean_of(f"{label} {m} at 1e-2", model=model, mode=m, rank=rank, lr=1e-2) for m in ("bottom",) + others}
    if any(v is None for v in list(lo.values()) + list(hi.values())):
        continue
    lead = (lo["bottom"] - max(lo[m] for m in others)) * 100
    last = (max(hi[m] for m in others) - hi["bottom"]) * 100
    check(f"{label}: lead at 2e-3", lead, "{:.2f}")
    check(f"{label}: deficit at 1e-2", last, "{:.2f}")
    check(f"{label}: swing", lead + last, "{:.2f}")

print("\n=== the position sweep, seeds 2-8 ===")
band, tab = {}, {0.0: 1e-2, 0.25: 1e-2, 0.5: 1e-2, 0.75: 1e-2, 1.0: 5e-3}
for bf, lr in tab.items():
    v = mean_of(f"beta={bf:g}", expect_n=7, mode="band", rank=2, lr=lr, band=bf, seeds=S28)
    if v is not None:
        band[bf] = v
        check(f"beta={bf:g}", v)
if len(band) == 5:
    check("spread along the spectrum, rank 2", (max(band.values()) - min(band.values())) * 100, "{:.1f}")
    check("beta=0.75 over the top", (band[0.75] - band[0.0]) * 100, "{:.2f}")
    check("beta=0.75 over the bottom", (band[0.75] - band[1.0]) * 100, "{:.2f}")

print("\n=== Qwen ===")
for m, lr in (("random_ortho", 1e-2), ("random", 1e-2), ("top", 1e-2), ("bottom", 2e-3), ("bottom", 5e-3)):
    v = mean_of(f"Qwen {m} at {lr:g}", model=QWEN, mode=m, rank=2, lr=lr)
    if v is not None:
        check(f"Qwen {m} at {lr:g}", v)

print("\n=== the tie-break at rank 2 ===")
# 5e-3 has five clean seeds: the run once counted as a divergence was a 12/09 run at alpha = 16
# (alpha/r = 8), an abandoned configuration, now quarantined. No run is excluded any more.
for lr, n in ((2e-3, 5), (5e-3, 5)):
    x = d[(d.task == "format") & (d.model.astype(str) == LLAMA) & (d["mode"] == "bottom") & (d["rank"] == 2)
          & ((d.lr - lr).abs() < 1e-12) & (d.n_modules == 7) & (d.max_grad_norm == 1.0)
          & d.update_norm_target.isna() & (d.format_n == 614) & d.seed.isin(S26)]
    per = x.groupby("seed").format_parsed.mean()
    if len(per) == n:
        check(f"bottom at {lr:g} ({n} seeds)", float(per.mean()))
    else:
        incomplete += 1
        print(f"  INCOMPLETE bottom at {lr:g}: {len(per)}/{n} seeds")

print("\n=== the five-module control ===")
five = {}
for m, r, lr in (("free", 1, 2e-3), ("random", 2, 1e-2), ("top", 2, 1e-2), ("bottom", 2, 5e-3)):   # bottom at its selected rate
    per = cell(mode=m, rank=r, lr=lr, n_modules=5, seeds=[2, 3, 4, 5, 6])
    if len(per) >= 3:
        five[m] = per
        check(f"5 modules: {m} r={r} ({len(per)} seeds)", float(per.mean()))
    else:
        incomplete += 1
        print(f"  INCOMPLETE 5 modules {m} r={r}: {len(per)} seeds")
if len(five) == 4:
    idx = sorted(set.intersection(*[set(p.index) for p in five.values()]))
    best = lambda i: max(five[m][i] for m in ("random", "top", "bottom"))
    worst = lambda i: min(five[m][i] for m in ("random", "top", "bottom"))
    # the paper's convention everywhere else: a difference of means, not a mean of per-seed differences
    m = {k: float(v.mean()) for k, v in five.items()}
    hi = max(m[k] for k in ("random", "top", "bottom")); lo = min(m[k] for k in ("random", "top", "bottom"))
    check(f"5 modules: freezing ({len(idx)} seeds)", (m["free"] - hi) * 100, "{:.1f}")
    check(f"5 modules: choosing ({len(idx)} seeds)", (hi - lo) * 100, "{:.1f}")

import statistics as _st


def _t(a, b):
    k = sorted(set(a.index) & set(b.index)); dd = [(a[i] - b[i]) * 100 for i in k]
    return _st.mean(dd) / (_st.stdev(dd) / len(dd) ** 0.5)


print("\n=== rank 2 at bottom's selected rate: choosing, and the deficit family ===")
arms = {m: cell(mode=m, rank=2, lr=(5e-3 if m == "bottom" else 1e-2)) for m in ("top", "random", "random_ortho", "bottom")}
if all(len(v) == 5 for v in arms.values()):
    mm = {k: float(v.mean()) for k, v in arms.items()}
    check("rank 2: choosing (main arms)", (max(mm.values()) - min(mm.values())) * 100, "{:.2f}")
    for o in ("top", "random", "random_ortho"):
        check(f"deficit family: {o} - bottom, t", _t(arms[o], arms["bottom"]), "{:.2f}")
else:
    incomplete += 1; print("  INCOMPLETE rank-2 main arms")

print("\n=== knowledge at rank 64, each arm at its selected rate ===")
acc = next((c for c in ("mcq_acc", "facts_mcq_acc", "mcq_accuracy") if c in d.columns), None)
def fcell(mode, lr):
    x = d[(d.task == "facts") & (d.model.astype(str) == LLAMA) & (d["mode"] == mode) & (d["rank"] == 64)
          & ((d.lr - lr).abs() < 1e-12) & d.seed.isin(S26)]
    return x.groupby("seed")[acc].mean()
fk = {"free": fcell("free", 1e-3), "top": fcell("top", 1e-3), "random": fcell("random", 2e-3), "bottom": fcell("bottom", 5e-4)}
for m, v in fk.items():
    if len(v) == 5: check(f"rank 64: {m}", float(v.mean()))
    else: incomplete += 1; print(f"  INCOMPLETE rank 64 {m}: {len(v)} seeds")
for m in ("top", "random", "bottom"):
    if len(fk[m]) == 5 and len(fk["free"]) == 5:
        check(f"rank 64: free - {m}, t", _t(fk["free"], fk[m]), "{:.2f}")

print("\n=== rank 16, OpenBookQA ===")
OB = "dc05f4d847f9"
def ocell(mode, rank, lr):
    x = d[(d.task == "commonsense") & (d.model.astype(str) == QWEN15) & (d["mode"] == mode) & (d["rank"] == rank)
          & ((d.lr - lr).abs() < 1e-12) & d.seed.isin(S26)]
    if "data_fingerprint" in x.columns:
        x = x[x.data_fingerprint.astype(str).isin([OB, "", "nan", "None"])]
    col = "mcq_acc" if "mcq_acc" in x.columns else acc
    return x.groupby("seed")[col].mean()
o = {("bottom", 1e-3): ocell("bottom", 16, 1e-3), ("bottom", 2e-3): ocell("bottom", 16, 2e-3),
     ("top", 1e-3): ocell("top", 16, 1e-3), ("top", 2e-3): ocell("top", 16, 2e-3),
     ("random_ortho", 2e-3): ocell("random_ortho", 16, 2e-3), ("random_ortho", 5e-3): ocell("random_ortho", 16, 5e-3)}
fr16 = ocell("free", 7, 2e-3)
if len(fr16) == 5: check("rank 16: free", float(fr16.mean()), "{:.3f}")
if all(len(v) == 5 for v in o.values()):
    check("rank 16: bottom behind top at 1e-3", (float(o[("top", 1e-3)].mean()) - float(o[("bottom", 1e-3)].mean())) * 100, "{:.2f}")
    best = max(float(o[("top", 2e-3)].mean()), float(o[("random_ortho", 2e-3)].mean()))
    check("rank 16: deficit at 2e-3", (best - float(o[("bottom", 2e-3)].mean())) * 100, "{:.2f}")
    own = [float(o[("top", 2e-3)].mean()), float(o[("bottom", 1e-3)].mean()), float(o[("random_ortho", 5e-3)].mean())]
    if len(fr16) == 5:
        check("rank 16: freezing", (float(fr16.mean()) - max(own)) * 100, "{:.2f}")
    check("rank 16: choosing", (max(own) - min(own)) * 100, "{:.2f}")
else:
    incomplete += 1; print("  INCOMPLETE rank 16:", {f"{k[0]} {k[1]:g}": len(v) for k, v in o.items()})

print(f"\n  {ok} values found in the tex, {drift} DRIFT, {incomplete} incomplete cells")
sys.exit(1 if drift else 0)
