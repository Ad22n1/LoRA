"""PROTOCOL_lrscale_trajectory.md: compare the dW trajectories of top_lrscale and top_scalar, condition by condition. CPU only.

    python scripts/read_traj.py
"""
import glob
import json
import os

import numpy as np
import yaml
from safetensors.numpy import load_file


def runs(root):
    out = {}
    for p in glob.glob(os.path.expanduser(root) + "/*/config.yaml"):
        c = yaml.safe_load(open(p)) or {}; d = os.path.dirname(p)
        if not os.path.exists(d + "/status") or not open(d + "/status").read().startswith("DONE"):
            continue
        key = (float(c.get("max_grad_norm")), float(c.get("adam_eps", 1e-8)), c.get("dtype"))
        out[(key, c.get("mode"))] = d
    return out


def steps(d):
    return {int(os.path.basename(f)[8:-12]): f for f in glob.glob(d + "/factors_*.safetensors") if os.path.basename(f)[8:-12].isdigit()}


def factors(f):
    t = load_file(f); names = sorted({k[:-2] for k in t if k.endswith(".A")})
    return {n: (t[n + ".B"].astype(np.float64), t[n + ".A"].astype(np.float64)) for n in names}


def D(fa, fb):
    """||dW_a - dW_b||_F / ||dW_b||_F over all modules, with dW = B A, computed exactly from r x r products (dW is never formed):
    ||B1A1 - B2A2||^2 = tr(B1'B1 A1A1') + tr(B2'B2 A2A2') - 2 tr(B1'B2 A2A1')."""
    a, b = factors(fa), factors(fb); num = den = 0.0
    for n in b:
        (B1, A1), (B2, A2) = a[n], b[n]
        aa = float(np.trace((B1.T @ B1) @ (A1 @ A1.T))); bb = float(np.trace((B2.T @ B2) @ (A2 @ A2.T))); ab = float(np.trace((B1.T @ B2) @ (A2 @ A1.T)))
        num += max(aa + bb - 2 * ab, 0.0); den += bb
    return (num / den) ** 0.5 if den > 0 else float("nan")


def score(d):
    try:
        return json.load(open(d + "/metrics.json")).get("format_parsed")
    except OSError:
        return None


R = runs("~/lora-runs-traj"); Rc = runs("~/lora-runs-traj-ctrl")
C = {"C0 identite": (1e6, 1e-20, "float32"), "C1 +ecretage": (1.0, 1e-20, "float32"), "C2 +epsilon": (1e6, 1e-8, "float32"),
     "C3 +bf16": (1e6, 1e-20, "bfloat16"), "C4 papier": (1.0, 1e-8, "bfloat16")}
SHOW = [1, 2, 4, 8, 16, 64, 128]
res = {}
c0 = C["C0 identite"]
if (c0, "top_scalar") in R and (c0, "top_scalar") in Rc:
    sa, sb = steps(R[(c0, "top_scalar")]), steps(Rc[(c0, "top_scalar")]); common = sorted(set(sa) & set(sb))
    ctrl = [D(sa[s], sb[s]) for s in common]; floor = max(max(ctrl), 1e-6)   # never below fp32 round-off (protocol)
    print(f"  temoin (top_scalar C0, deux runs) : ecart max {max(ctrl):.2e} ; plancher retenu {floor:.2e} (au moins 1e-6), sur {len(common)} pas")
else:
    floor = None; print("  temoin absent : plancher non calculable")
for lab, key in C.items():
    if (key, "top_scalar") not in R or (key, "top_lrscale") not in R:
        print(f"  {lab:14s} : INCOMPLET"); continue
    a, b = steps(R[(key, "top_lrscale")]), steps(R[(key, "top_scalar")]); common = sorted(set(a) & set(b))
    traj = {s: D(a[s], b[s]) for s in common}; res[lab] = traj[common[-1]]
    sh = "  ".join(f"{s}:{traj[s]:.1e}" for s in SHOW if s in traj) + f"  fin({common[-1]}):{traj[common[-1]]:.1e}"
    sa, sb = score(R[(key, "top_lrscale")]), score(R[(key, "top_scalar")])
    print(f"  {lab:14s} D : {sh}\n  {'':14s} scores : top_lrscale {sa:.4f}, top_scalar {sb:.4f}, ecart {(sa - sb) * 100:+.2f} (une graine, descriptif)")
if floor is not None and "C0 identite" in res:
    ok0 = res["C0 identite"] < 10 * floor
    print(f"\n  identite en C0 : {'TIENT' if ok0 else 'NE TIENT PAS'} (D final {res['C0 identite']:.1e} contre 10 x plancher {10 * floor:.1e})")
    ref = max(floor, res["C0 identite"])
    causes = [lab for lab in ("C1 +ecretage", "C2 +epsilon", "C3 +bf16") if lab in res and res[lab] > 10 * ref]
    print("  causes (D final > 10 x max(plancher, C0)) : " + (", ".join(causes) if causes else "aucune seule"))
    if "C4 papier" in res and res["C4 papier"] > 10 * ref and not causes:
        print("  C4 diverge sans cause seule : INTERACTION entre facteurs")
