#!/bin/bash
# Apres l'etape 1 de PROTOCOL_square_modules.md : genere les grilles du RAPPORT au taux retenu par bras, les committe avant leurs runs, les lance.
set -u
cd "$HOME/repo" || exit 1
PY="/tmp/lora-$USER/venv/bin/python"; [ -x "$PY" ] || PY=python3
echo "=== etape 2, rapport ==="
"$PY" scripts/make_sq_grids.py --stage2 || { echo "  STOP : selection incomplete ; rien n'est lance"; exit 1; }
git add configs/grids/sq_s2_*.yaml && git commit -qm "modules carres : taux retenus sur les graines 130-131 ; grilles du rapport avant leurs runs" && echo "  ok : committe ($(git log -1 --format=%h))"
git push -q 2>/dev/null; bash scripts/launch_sq_s2.sh
