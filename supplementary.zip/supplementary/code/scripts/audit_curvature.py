"""Every check against the curvature measurement, before its numbers go in the paper.

The claim: the minor band is about ten times stiffer than the other arms at initialisation, and the
four arms' unclipped collapse brackets do not intersect, so lambda_max * lr is not what bounds the
usable step size.

This measurement has already been wrong twice. Once with a stopping tolerance larger than the
quantity, once with a single random start that stalled and returned 5e-4 where the answer was 357 —
with the convergence flag set both times. So each number gets checked against the way it failed.
"""
import os
import sys

import pandas as pd

ANA = os.path.expanduser("~/lora-analysis")
LR = {"bottom": 2e-3, "top": 1e-2, "random": 1e-2, "random_ortho": 1e-2, "free": 2e-3}
FAILED = []


def check(name, ok, detail=""):
    print(f"  [{'ok ' if ok else 'FAIL'}] {name}" + (f"\n         {detail}" if detail else ""))
    if not ok:
        FAILED.append(name)


def main():
    p = os.path.join(ANA, "curvature_5seeds_restarts.csv")
    if not os.path.exists(p):
        raise SystemExit(f"not measured yet: {p}")
    d = pd.read_csv(p)
    d["spread"] = (d.curvature_max - d.curvature_min) / d.curvature_median

    print("\n=== A. the measurement is instrumented and the instrument agrees ===")
    for col in ("curvature_min", "curvature_max", "n_batches"):
        check(f"`{col}` is recorded", col in d.columns)
    if "restarts" in d.columns:
        check("several random starts were used", int(d.restarts.min()) >= 5,
              f"restarts = {sorted(d.restarts.unique())}")
    else:
        check("several random starts were used", False, "no `restarts` column: is this the old CSV?")
    check("no batch returns the stall value (order 1e-3) any more",
          float(d.curvature_min.min()) > 1e-2,
          f"smallest per-batch value anywhere: {float(d.curvature_min.min()):.4g}")

    print("\n=== B. five seeds per arm, and they agree ===")
    n = d.groupby("mode").size()
    check("five seeds for every arm", (n == 5).all(), n.to_dict())
    sp = d.groupby("mode").spread.median()
    print("         within-cell spread (max-min)/median, per arm:")
    for m in sp.sort_values().index:
        flag = "   <-- worst" if m == sp.idxmax() else ""
        print(f"           {m:14s} {sp[m]:.2f}{flag}")
    check("no arm's batches disagree by more than the median value itself",
          float(sp.max()) < 2.0,
          f"worst is `{sp.idxmax()}` at {sp.max():.2f}")

    print("\n=== C. the ratio does not rest on one seed ===")
    med = d.groupby("mode").curvature_median.median()
    if {"bottom", "top"} <= set(med.index):
        r = med["bottom"] / med["top"]
        print(f"         ratio bottom/top = {r:.2f}")
        b = d[d["mode"] == "bottom"].curvature_median.values
        t = d[d["mode"] == "top"].curvature_median.values
        ratios = []
        for i in range(len(b)):
            bb = sorted(list(b[:i]) + list(b[i + 1:]))
            for j in range(len(t)):
                tt = sorted(list(t[:j]) + list(t[j + 1:]))
                ratios.append(bb[len(bb) // 2] / tt[len(tt) // 2])
        print(f"         leave-one-out range: {min(ratios):.2f} to {max(ratios):.2f}")
        check("dropping any single seed keeps the ratio above 5",
              min(ratios) > 5.0, f"worst = {min(ratios):.2f}")

    print("\n=== D. lambda * lr, and the claim that no threshold fits ===")
    for m in sorted(med.index):
        print(f"         {m:14s} lambda = {med[m]:7.2f}   lambda*lr = {med[m] * LR[m]:.3f}")
    c = {m: med[m] * LR[m] for m in med.index if m != "free"}
    check("bottom's product is the largest of the constrained arms",
          max(c, key=c.get) == "bottom",
          f"bottom {c.get('bottom', 0):.3f} vs {min(c.values()):.3f}-{sorted(c.values())[-2]:.3f}")

    print("\n" + "=" * 70)
    if FAILED:
        print(f"  {len(FAILED)} CHECK(S) FAILED:")
        for f in FAILED:
            print(f"    - {f}")
    else:
        print("  every check passed.")


if __name__ == "__main__":
    main()
