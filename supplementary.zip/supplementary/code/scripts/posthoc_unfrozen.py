"""POST HOC (not in any protocol): do the two bands score alike once B is unfrozen? No PARTITION.

    python scripts/posthoc_unfrozen.py

Reads the runs of experiment 1 (PROTOCOL_top_unfrozen.md and its addendum) at the rates their protocol selected on seeds 0-1:
top_unfrozen 5e-3 at ranks 1 and 2; bottom_unfrozen 5e-3 at rank 1 and 2e-3 at rank 2; frozen top 1e-2 and bottom 5e-3 at rank 2.
Seeds 2 to 6, paired. Two questions, both post hoc, so reported as such:
  1. bottom_unfrozen - top_unfrozen, at ranks 1 and 2: mean, 95 % interval, and equivalence within +/- 1 point (90 % interval
     inside the margin; the margin is the one C2 fixed in advance for another comparison, reused here, not chosen after seeing);
  2. the interaction: (bottom - top) unfrozen minus (bottom - top) frozen, at rank 2 -- does the gap between the bands shrink
     when B is unfrozen?
GUARD: every cell must have exactly one run per seed; duplicates stop the script.
"""
import glob
import json
import os
import statistics as st

import yaml

R = os.path.expanduser("~/lora-runs")
LLAMA = "meta-llama/Llama-3.2-1B"
S = [2, 3, 4, 5, 6]
T4_95, T4_90 = 2.776, 2.132            # two-sided 95 % and 90 % quantiles of Student's t, 4 d.f.


def tokens(c):
    t = c.get("target_tokens")
    return t.get(c.get("task")) if isinstance(t, dict) else t


def ok(c):
    v = c.get("max_grad_norm", 1.0)
    tm = c.get("target_modules")
    return (c.get("task") == "format" and str(c.get("model")) == LLAMA and tokens(c) == 600000 and v is not None and float(v) == 1.0
            and (tm is None or len(tm) == 7) and c.get("update_norm_target") in (None, ""))


RUNS = []
for p in glob.glob(R + "/*/config.yaml"):
    c = yaml.safe_load(open(p)) or {}
    d = os.path.dirname(p)
    try:
        if ok(c) and open(d + "/status").read().startswith("DONE"):
            RUNS.append((c, json.load(open(d + "/metrics.json"))))
    except OSError:
        continue


def cell(mode, rank, lr):
    by = {}
    for c, m in RUNS:
        if c.get("mode") == mode and c.get("rank") == rank and abs(float(c.get("lr") or 0) - lr) < 1e-12 and c.get("seed") in S and "format_parsed" in m:
            by.setdefault(c["seed"], []).append(m["format_parsed"])
    dup = {s: len(v) for s, v in by.items() if len(v) > 1}
    if dup or len(by) != len(S):
        raise SystemExit(f"  ARRET : {mode} r={rank} lr={lr:g} : {len(by)} graines, doublons {dup or 'aucun'}")
    return {s: v[0] for s, v in by.items()}


def stats(d):
    x = [d[s] * 100 for s in S]; m = st.mean(x); se = st.stdev(x) / len(x) ** 0.5
    return m, m - T4_95 * se, m + T4_95 * se, m - T4_90 * se, m + T4_90 * se, (m / se if se > 0 else float("inf"))


print("POST HOC -- aucun protocole ne prevoyait ce test ; il est rapporte comme tel.\n")
for rank, lt, lb in ((1, 5e-3, 5e-3), (2, 5e-3, 2e-3)):
    tu, bu = cell("top_unfrozen", rank, lt), cell("bottom_unfrozen", rank, lb)
    m, lo, hi, lo90, hi90, t = stats({s: bu[s] - tu[s] for s in S})
    eq = -1 <= lo90 and hi90 <= 1            # equivalence and difference are separate questions: both can hold
    diff = abs(t) > T4_95
    verdict = ("EQUIVALENTS a +/- 1 point" if eq else "equivalence NON etablie") + " ; " + ("difference ETABLIE (petite si equivalents)" if diff else "difference non etablie")
    print(f"  rang {rank} : bottom_unfrozen ({st.mean(bu.values()):.4f}) - top_unfrozen ({st.mean(tu.values()):.4f}) = {m:+.2f} pt, "
          f"IC95 [{lo:+.2f}, {hi:+.2f}], t = {t:+.2f} ; IC90 [{lo90:+.2f}, {hi90:+.2f}] -> {verdict}")
tf, bf = cell("top", 2, 1e-2), cell("bottom", 2, 5e-3)
tu, bu = cell("top_unfrozen", 2, 5e-3), cell("bottom_unfrozen", 2, 2e-3)
mF = stats({s: bf[s] - tf[s] for s in S})[0]; mU = stats({s: bu[s] - tu[s] for s in S})[0]
m, lo, hi, _, _, t = stats({s: (bu[s] - tu[s]) - (bf[s] - tf[s]) for s in S})
change = "l'ecart change de SIGNE" if mF * mU < 0 and abs(mU) >= 1 else ("l'ecart RETRECIT" if abs(mU) < abs(mF) else "l'ecart GRANDIT")
print(f"\n  bottom - top : {mF:+.2f} pt geles, {mU:+.2f} pt degeles ({change})")
print(f"  interaction, rang 2 : difference des deux ecarts = {m:+.2f} pt, IC95 [{lo:+.2f}, {hi:+.2f}], t = {t:+.2f} -> "
      + ("ETABLIE" if (lo > 0 or hi < 0) else "non etablie"))
