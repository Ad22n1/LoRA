#!/usr/bin/env bash
# The night of 26 to 27/09: complete the missing runs of ARC-Challenge at rank 32 (same grid, same protocol), and launch
# the arms that freeze A (PROTOCOL_freeze_A.md). A grid with jobs in the queue is never touched.
#
#     bash scripts/launch_night3.sh --dry     # checks and counts only (any time); logs are never touched
#     bash scripts/launch_night3.sh           # submits; refuses between 09:00 and 17:00
#
# (Point 6 of the previous script was two steps: the 20 trainings (norm6_train_*), then one evaluation task per trained run
# (scripts/norm_rescale_eval.py), built from the training job by scripts/make_eval_array.sh and chained with
# --dependency=afterany, so it starts only once every training task has ended (a failed training is caught
# by the evaluation, which refuses a run that is not DONE).
set -u
cd "$HOME/repo" || exit 1
PY="/tmp/lora-$USER/venv/bin/python"; [ -x "$PY" ] || { echo "  venv introuvable : $PY"; exit 1; }
DRY=0; [ "${1:-}" = "--dry" ] && DRY=1
H=$(date +%H)
if [ $DRY -eq 0 ] && [ "$H" -ge 9 ] && [ "$H" -lt 17 ]; then echo "  REFUS : il est $(date +%H:%M), pas de PARTITION entre 9 h et 17 h"; exit 1; fi

GA="freezeA_all"
GC="arcc32_frozen arcc32_free"
FILES="PROTOCOL_freeze_A.md PROTOCOL_arcc_rank32.md configs/grids/freezeA_all.yaml configs/grids/arcc32_frozen.yaml configs/grids/arcc32_free.yaml scripts/read_night4.py"

echo "=== 1. tout est committe et a jour ==="
bad=0
for f in $FILES; do
    if [ ! -f "$f" ]; then echo "  ABSENT       $f"; bad=1
    elif ! git ls-files --error-unmatch "$f" >/dev/null 2>&1; then echo "  NON COMMITTE $f"; bad=1
    elif ! git diff --quiet HEAD -- "$f"; then echo "  MODIFIE      $f"; bad=1; fi
done
[ $bad -eq 0 ] && echo "  ok" || { echo "  REFUS : envoyer et committer d'abord"; exit 1; }

TMP=$(mktemp -d)
count() {   # "done torun" for grid $1, or ACTIVE if jobs of this grid still run; the grid dir is never deleted
    # A grid is active if a job of the queue runs ITS slurm_array.sh (26/09: launch_grid's own check never fired, and
    # counting regenerated the directory of a running grid). Checked BEFORE launch_grid touches anything.
    if squeue -h -u "$USER" -o "%o" 2>/dev/null | grep -q "/lora-grid/$1/slurm_array.sh"; then echo "ACTIVE"; return; fi
    local dir="$HOME/lora-grid/$1"; [ $DRY -eq 1 ] && dir="$TMP/$1"
    local out; out=$("$PY" -m lorasub.launch_grid "configs/grids/$1.yaml" --grid_dir "$dir" --partition PARTITION \
        --time 01:59:00 --max_par 8 --venv "/tmp/lora-$USER/venv" 2>&1)
    if echo "$out" | grep -q "refusing to generate"; then echo "ACTIVE"; return; fi
    echo "$out" | grep -oE "[0-9]+ already done; [0-9]+ to run" | grep -oE "[0-9]+" | tr '\n' ' '
}
submit() {   # prints the job id on stdout (last line) when it submits
    local g=$1 res done torun
    res="$(count "$g")"
    if [ "$res" = "ACTIVE" ]; then echo "  EN COURS $g : des jobs tournent encore, rien n'est soumis en double" >&2; return; fi
    read -r done torun <<< "$res"
    if [ -z "${done:-}" ]; then echo "  ERREUR  $g : comptage impossible" >&2; return; fi
    if [ "$done" -gt 0 ]; then echo "  SAUTE   $g : $done runs existent deja (collision)" >&2; return; fi
    if [ $DRY -eq 1 ]; then echo "  pret    $g : $torun runs" >&2; return; fi
    local jid; jid=$(sbatch --parsable --exclude=node "$HOME/lora-grid/$g/slurm_array.sh")
    echo "  soumis  $g ($torun runs) : job $jid" >&2; echo "$jid"
}

echo "=== 2. ARC-Challenge au rang 32 : completer les runs manquants (meme grille, meme protocole) ==="
for g in $GC; do
  res="$(count "$g")"
  if [ "$res" = "ACTIVE" ]; then echo "  EN COURS $g : rien n'est touche"; continue; fi
  read -r done torun <<< "$res"
  if [ -z "${done:-}" ]; then echo "  ERREUR  $g : comptage impossible"; continue; fi
  if [ "$torun" -eq 0 ]; then echo "  RIEN    $g : complet ($done)"; continue; fi
  [ $DRY -eq 1 ] && { echo "  pret    $g : $torun runs manquants ($done deja faits)"; continue; }
  echo "  soumis  $g ($torun runs manquants, $done deja faits) : job $(sbatch --parsable --exclude=node "$HOME/lora-grid/$g/slurm_array.sh")"
done
echo "=== 3. geler A plutot que B (PROTOCOL_freeze_A.md) ==="
for g in $GA; do submit "$g" >/dev/null; done
rm -rf "$TMP"
echo "=== file ==="; squeue -u "$USER" | head -6
