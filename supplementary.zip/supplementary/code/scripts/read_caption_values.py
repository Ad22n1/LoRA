"""Every value the caption pass and the new rows of figure 4 will use, printed with its seed count.
No hidden computation: each number the text will cite is printed here first.

    python scripts/read_caption_values.py 2>&1 | grep -vE "FutureWarning|pd.concat"
"""
import glob
import json
import os
import statistics as st
import sys

import yaml

sys.path.insert(0, "src")
from lorasub.aggregate import collect  # noqa: E402

L = "meta-llama/Llama-3.2-1B"
d = collect(os.path.expanduser("~/lora-runs"))
F = d[(d.task == "format") & (d.model.astype(str) == L) & (d.max_grad_norm == 1.0) & d.update_norm_target.isna()
      & d.band_frac.isna() & ((d.alpha / d["rank"]).round(2) == 1.0) & (d.n_modules == 7)]
F = F[~(F["mode"].isin(["random", "random_ortho"]) & (F.subspace_salted != True))]  # noqa: E712


def cell(mode, rank, lr, seeds, key="format_parsed", fn=614):
    x = F[(F["mode"] == mode) & (F["rank"] == rank) & ((F.lr - lr).abs() < 1e-12) & F.seed.isin(seeds)]
    if fn is not None:
        x = x[x.format_n == fn]
    return x.groupby("seed")[key].mean().to_dict()


def show(lab, v):
    print(f"  {lab:44s} " + (f"{st.mean(v.values()):.4f}  ({len(v)} graines : {sorted(v)})" if v else "AUCUN RUN"))
    return st.mean(v.values()) if v else float("nan")


print("=== 1. random au rang 4, graines 2-8 : 5e-3 (controle de sensibilite) contre 1e-2 (rapporte) ===")
S7 = list(range(2, 9))
r5 = show("random r=4 a 5e-3", cell("random", 4, 5e-3, S7))
r10 = show("random r=4 a 1e-2 (taux du papier)", cell("random", 4, 1e-2, S7))
print("  autres bras du rang 4 aux taux du papier, memes graines :")
arms4 = {"top a 2e-3": cell("top", 4, 2e-3, S7), "top a 5e-3": cell("top", 4, 5e-3, S7), "bottom a 2e-3": cell("bottom", 4, 2e-3, S7),
         "top_sigma a 5e-3": cell("top_sigma", 4, 5e-3, S7), "free r=2 a 2e-3": cell("free", 2, 2e-3, S7)}
m4 = {k: show(k, v) for k, v in arms4.items()}
print(f"  -> random gagne {100 * (r5 - r10):+.2f} point a 5e-3 ; le meilleur bras gele au rang 4 change-t-il ? "
      f"avant : {max([r10] + [m4[k] for k in m4 if not k.startswith('free')]):.4f}, avec random a 5e-3 : {max([r5] + [m4[k] for k in m4 if not k.startswith('free')]):.4f}")

print("\n=== 2. bottom au rang 64 (connaissance), selection graines 0-1, validation ===")
x = d[(d.task == "facts") & (d.model.astype(str) == L) & (d["mode"] == "bottom") & (d["rank"] == 64) & d.seed.isin([0, 1])]
for lr, g in x.groupby("lr"):
    col = next((c for c in ("val_mcq_acc", "val_facts_mcq_acc") if c in g.columns), None)
    print(f"  bottom r=64 a {lr:g} : validation {g[col].mean():.4f}  ({g.seed.nunique()} graines)")
print("  -> si 2,5e-4 bat 5e-4, la selection est encore au bord ; sinon, 5e-4 est un maximum interieur")

print("\n=== 3. rang 16, tache de format, graines 2-6, aux taux retenus (pour la figure 4) ===")
S = [2, 3, 4, 5, 6]
own16 = {"top a 2e-3": cell("top", 16, 2e-3, S), "bottom a 5e-4": cell("bottom", 16, 5e-4, S),
         "random a 1e-3": cell("random", 16, 1e-3, S), "random_ortho a 1e-3": cell("random_ortho", 16, 1e-3, S)}
m16 = {k: show(k, v) for k, v in own16.items()}
f16 = show("free r=8 a 2e-3", cell("free", 8, 2e-3, S))
print(f"  -> geler {100 * (f16 - max(m16.values())):.2f}  choisir {100 * (max(m16.values()) - min(m16.values())):.2f}  (moyennes simples)")

print("\n=== 4. rang 8, graines 42-46, aux taux retenus (pour la figure 4) ===")
S8 = [42, 43, 44, 45, 46]
own8 = {"top a 2e-3": cell("top", 8, 2e-3, S8), "bottom a 2e-3": cell("bottom", 8, 2e-3, S8),
        "random a 5e-3": cell("random", 8, 5e-3, S8), "random_ortho a 5e-3": cell("random_ortho", 8, 5e-3, S8)}
m8 = {k: show(k, v) for k, v in own8.items()}
f8 = show("free r=4 a 2e-3", cell("free", 4, 2e-3, S8))
print(f"  -> geler {100 * (f8 - max(m8.values())):.2f}  choisir {100 * (max(m8.values()) - min(m8.values())):.2f}  (moyennes simples)")

print("\n=== 5. ARC-Challenge, rang 16, graines 2-6, aux taux retenus (pour la figure 4) ===")
vals = {}
for p in glob.glob(os.path.expanduser("~/lora-runs/*/config.yaml")):
    c = yaml.safe_load(open(p)) or {}
    if c.get("task") != "commonsense" or str(c.get("data_fingerprint")) != "0755bcdbdce3" or c.get("seed") not in S:
        continue
    f = os.path.dirname(p) + "/metrics.json"
    if os.path.exists(f):
        vals.setdefault((c["mode"], c["rank"], float(c["lr"])), {})[c["seed"]] = json.load(open(f))["mcq_acc"]
arc = {"top a 5e-4": vals.get(("top", 16, 5e-4), {}), "bottom a 1e-3": vals.get(("bottom", 16, 1e-3), {}),
       "random_ortho a 1e-3": vals.get(("random_ortho", 16, 1e-3), {})}
ma = {k: show(k, v) for k, v in arc.items()}
fa = show("free r=7 a 5e-4", vals.get(("free", 7, 5e-4), {}))
print(f"  -> geler {100 * (fa - max(ma.values())):.2f}  choisir {100 * (max(ma.values()) - min(ma.values())):.2f}  (moyennes simples)")
