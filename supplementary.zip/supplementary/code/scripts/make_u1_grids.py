"""Grids of PROTOCOL_7b_unfrozen_r1.md: B trained at rank 1 on Qwen2.5-7B and Mistral-7B, OpenBookQA, exactly as the two 7B campaigns.

    python scripts/make_u1_grids.py --stage1     # selection: 2 models x 2 arms x 5 rates x seeds 0-1 = 40 runs (4 grids)
    python scripts/make_u1_grids.py --stage2     # report: seeds 2-6 at each arm's rate selected on seeds 0-1 = 20 runs (4 grids)
"""
import glob
import json
import os
import statistics as st
import sys
from pathlib import Path

import yaml

SRC = "configs/grids/obqa_r2_common.yaml"
MODELS = {"q7": "Qwen/Qwen2.5-7B", "m7": "mistralai/Mistral-7B-v0.3"}
ARMS = ["top_unfrozen", "bottom_unfrozen"]
LRS = [5e-4, 1e-3, 2e-3, 5e-3, 1e-2]
H = "# PRE-ENREGISTRE (PROTOCOL_7b_unfrozen_r1.md). Genere par scripts/make_u1_grids.py.\n"


def base(model):
    if not Path(SRC).exists():
        sys.exit(f"STOP : {SRC} introuvable")
    b = dict((yaml.safe_load(open(SRC)) or {}).get("base") or {})
    if not (b.get("task") == "commonsense" and str(b.get("data_fingerprint")) == "dc05f4d847f9"):
        sys.exit(f"STOP : {SRC} n'est pas OpenBookQA")
    for k in ("mode", "rank", "lr", "seed", "band_frac", "update_norm_target"):
        b.pop(k, None)
    b.update(model=MODELS[model], save_factor_steps=[], rank=1)
    return b


def write(name, b, grid, note):
    Path(f"configs/grids/{name}.yaml").write_text(H + f"# {note}\n" + yaml.safe_dump({"base": b, "grid": grid}, sort_keys=False))


if "--stage1" in sys.argv:
    total = 0
    for m in MODELS:
        for mode in ARMS:
            write(f"u1_{m}_s1_{mode}", base(m), {"mode": [mode], "lr": LRS, "seed": [0, 1]}, f"SELECTION, {MODELS[m]}, {mode} r=1. 10 runs.")
            total += 10; print(f"  u1_{m}_s1_{mode:16s} : {MODELS[m]}, rang 1, 5 taux x graines 0-1")
    print(f"  total : {total} runs"); total == 40 or sys.exit("STOP : le total n'est pas 40")
elif "--stage2" in sys.argv:
    total = 0
    for m, model in MODELS.items():
        runs = []
        for p in glob.glob(os.path.expanduser("~/lora-runs/*/config.yaml")):
            c = yaml.safe_load(open(p)) or {}; d = os.path.dirname(p)
            if str(c.get("model")) == model and str(c.get("data_fingerprint")) == "dc05f4d847f9" and c.get("rank") == 1 and c.get("seed") in (0, 1):
                try:
                    if open(d + "/status").read().startswith("DONE"):
                        runs.append((c, json.load(open(d + "/metrics.json"))))
                except OSError:
                    pass
        for mode in ARMS:
            means = {}
            for lr in LRS:
                v = [mm["val_mcq_acc"] for c, mm in runs if c.get("mode") == mode and abs(float(c["lr"]) - lr) < 1e-12 and "val_mcq_acc" in mm]
                if len(v) != 2:
                    sys.exit(f"STOP : {model} {mode} a {lr:g} : {len(v)} run(s) de selection au node de 2 ; la selection n'est pas complete")
                means[lr] = st.mean(v)
            best = max(LRS, key=lambda lr: means[lr])       # equal means: the lowest rate, as everywhere in the paper
            write(f"u1_{m}_s2_{mode}", base(m), {"mode": [mode], "lr": [best], "seed": [2, 3, 4, 5, 6]}, f"RAPPORT, {model}, {mode} r=1 au taux retenu. 5 runs.")
            total += 5
            print(f"  u1_{m}_s2_{mode:16s} : " + "  ".join(f"{lr:g}:{means[lr]:.3f}" for lr in LRS) + f"  -> {best:g}" + ("  AU BORD" if best in (LRS[0], LRS[-1]) else ""))
    print(f"  total : {total} runs"); total == 20 or sys.exit("STOP : le total n'est pas 20")
else:
    sys.exit("usage : --stage1 | --stage2")
