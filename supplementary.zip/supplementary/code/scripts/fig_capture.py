"""Run one figure script and record what it plots (01/10), without letting it write anywhere but a work folder.

    python scripts/fig_capture.py OUTDIR DUMP.json SCRIPT [ARGS...]

Every matplotlib export and every PIL save is redirected into OUTDIR (same file name). At each matplotlib export, the data of every
axes is recorded: line coordinates, collection offsets and paths, patch geometry, annotation anchors (the plotted values), the text
of every label (reported separately), and, for checking the layout, how many markers or labels a legend covers and how many pairs of
labels overlap. Nothing is changed in the figure.
"""
import json
import math
import os
import runpy
import sys

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib.text import Annotation  # noqa: E402

OUTDIR, DUMP, SCRIPT = sys.argv[1:4]
ARGS = sys.argv[4:]
os.makedirs(OUTDIR, exist_ok=True)
RECORD = []


def _num(v):
    v = float(v)
    return "nan" if math.isnan(v) else ("inf" if math.isinf(v) else v)


def _arr(a):
    a = np.asarray(a, dtype=float)
    return [[_num(x) for x in row] for row in a.reshape(len(a), -1)] if a.ndim else [_num(a)]


def _layout_checks(ax, r):
    pts = []
    for ln in ax.lines:
        if ln.get_marker() not in (None, "None", "", " ") and len(ln.get_xydata()):
            pts.append(ax.transData.transform(np.asarray(ln.get_xydata(), float)))
    for c in ax.collections:
        off = c.get_offsets()
        if len(off):
            pts.append(c.get_offset_transform().transform(np.asarray(off, float)))
    pts = np.vstack(pts) if pts else np.zeros((0, 2))
    texts = [t for t in ax.texts if t.get_visible() and t.get_text()]
    tb = [t.get_window_extent(r) for t in texts]
    leg = ax.get_legend()
    cov_m = cov_t = 0
    if leg is not None and leg.get_visible():
        bb = leg.get_window_extent(r)
        if len(pts):
            cov_m = int(((pts[:, 0] >= bb.x0) & (pts[:, 0] <= bb.x1) & (pts[:, 1] >= bb.y0) & (pts[:, 1] <= bb.y1)).sum())
        cov_t = int(sum(bool(bb.overlaps(b)) for b in tb))
    ann = [b for t, b in zip(texts, tb) if isinstance(t, Annotation)]
    pairs = sum(bool(ann[i].overlaps(ann[j])) for i in range(len(ann)) for j in range(i + 1, len(ann)))
    close = sum(bool(ann[i].padded(2).overlaps(ann[j].padded(2))) for i in range(len(ann)) for j in range(i + 1, len(ann)))
    return {"legend": leg is not None, "legend_covers_markers": cov_m, "legend_covers_labels": cov_t, "overlapping_label_pairs": int(pairs),
            "label_pairs_within_4px": int(close)}


def _capture(fig):
    fig.canvas.draw(); r = fig.canvas.get_renderer(); axes = []
    for ax in fig.axes:
        data = {"lines": [_arr(l.get_xydata()) for l in ax.lines],
                "collections": [[type(c).__name__, _arr(c.get_offsets()) if len(c.get_offsets()) else [],
                                 [_arr(p.vertices) for p in c.get_paths()[:500]]] for c in ax.collections],
                "patches": [[type(p).__name__, _arr(p.get_path().transformed(p.get_patch_transform()).vertices)] for p in ax.patches],
                "anchors": [[_num(t.xy[0]), _num(t.xy[1])] for t in ax.texts if isinstance(t, Annotation)
                            and isinstance(t.xy[0], (int, float, np.floating)) and t.xycoords == "data"]}
        axes.append({"data": data, "texts": [t.get_text() for t in ax.texts], "title": ax.get_title(loc="left") + "|" + ax.get_title(),
                     "layout": _layout_checks(ax, r)})
    return axes


_orig_save = matplotlib.figure.Figure.savefig


def _save(self, fname, *a, **k):
    if not isinstance(fname, (str, os.PathLike)):          # in-memory exports (e.g. searching an export width) pass through untouched
        return _orig_save(self, fname, *a, **k)
    name = os.path.basename(str(fname))
    RECORD.append({"file": name, "axes": _capture(self)})
    return _orig_save(self, os.path.join(OUTDIR, name), *a, **k)


matplotlib.figure.Figure.savefig = _save
plt.savefig = lambda fname, *a, **k: _save(plt.gcf(), fname, *a, **k)
try:
    from PIL import Image
    _orig_pil = Image.Image.save
    Image.Image.save = lambda self, fp, *a, **k: _orig_pil(self, os.path.join(OUTDIR, os.path.basename(str(fp))), *a, **k) \
        if isinstance(fp, (str, os.PathLike)) else _orig_pil(self, fp, *a, **k)
except ImportError:
    pass
sys.argv = [SCRIPT] + ARGS
try:
    runpy.run_path(SCRIPT, run_name="__main__")
finally:
    json.dump(RECORD, open(DUMP, "w"), default=lambda o: o.item() if hasattr(o, "item") else str(o))   # numpy scalars
