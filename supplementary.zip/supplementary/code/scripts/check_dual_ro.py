"""Why is a dual_random_ortho cell of PROTOCOL_freeze_A.md incomplete? READ ONLY, no PARTITION.

    python scripts/check_dual_ro.py

For the grid freezeA_all: every run of dual_random_ortho (7 rates x seeds 0-6), its state from ~/lora-runs/<run_id>/status
(DONE, FAILED, RUNNING, or no directory = never started), and for the runs that are not DONE, the last lines of their status
file and of their Slurm log. A random run failing is noise; the same error on many runs is a code defect that would also hit
the same arm on OpenBookQA.
"""
import glob
import os
from collections import Counter, defaultdict

import yaml

G = os.path.expanduser("~/lora-grid/freezeA_all")
R = os.path.expanduser("~/lora-runs")
cfgs = {}
for p in glob.glob(G + "/configs/*.yaml"):
    c = yaml.safe_load(open(p)) or {}
    cfgs[os.path.basename(p)[:-5]] = c
listing = [l.strip() for l in open(G + "/listing.txt")] if os.path.exists(G + "/listing.txt") else []
task_of = {os.path.basename(l)[:-5]: i for i, l in enumerate(listing)}

state = defaultdict(dict)
bad = []
for rid, c in cfgs.items():
    if c.get("mode") != "dual_random_ortho":
        continue
    d = os.path.join(R, rid)
    st = "ABSENT"
    if os.path.isdir(d):
        try:
            st = open(d + "/status").read().strip().split("\n")[0][:60] or "VIDE"
        except OSError:
            st = "SANS STATUS"
    state[float(c["lr"])][int(c["seed"])] = st.split()[0] if st else st
    if not st.startswith("DONE"):
        bad.append((rid, c, st))
print(f"  {sum(len(v) for v in state.values())} runs dual_random_ortho dans la grille")
print(f"  {'taux':>8s}  " + "  ".join(f"{'g' + str(s):>4s}" for s in range(7)))
for lr in sorted(state):
    print(f"  {lr:8g}  " + "  ".join(f"{state[lr].get(s, '-')[:4]:>4s}" for s in range(7)))
print("\n  etats :", dict(Counter(v for d in state.values() for v in d.values())))
for rid, c, st in bad[:6]:
    print(f"\n  --- {rid} (lr {c['lr']}, graine {c['seed']}) : {st}")
    t = task_of.get(rid)
    logs = sorted(glob.glob(f"{G}/logs/*_{t}.out")) if t is not None else []
    if logs:
        tail = open(logs[-1], errors="ignore").read().strip().split("\n")[-6:]
        print("      journal " + os.path.basename(logs[-1]) + " :\n        " + "\n        ".join(l[:150] for l in tail))
    else:
        print("      aucun journal retrouve pour cette tache")
if not bad:
    print("\n  aucun run en defaut : la cellule incomplete vient d'ailleurs (selection, doublons ?)")
