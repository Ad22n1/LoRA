"""Forgetting on factors that have ALREADY been trained — no training, one evaluation pass.

WHY THIS MATTERS MORE THAN IT LOOKS. Quercia et al. (arXiv:2602.03493) report that accuracy on the
new task plateaus at the same value whatever the spectral starting point, while FORGETTING forms a
U-shape. Forgetting is their result; the equality of peaks is only their premise. And their design
INITIALISES both factors from a band and subtracts it from the frozen weight — it never freezes a
factor. Nobody has measured forgetting on a frozen subspace.

So this script is the one measurement that puts this project face to face with their contribution,
and it costs no PARTITION training at all: every run under --runs_dir already has its factors on disk.

WHAT IT REPORTS. HellaSwag (acc_norm), TruthfulQA-MC1, WikiText perplexity, via lm_eval, on the
base model once and on each adapted model. The delta against the base is the forgetting.

WHAT IT CANNOT SETTLE. `eval_forgetting: false` in every seed grid means the arms were trained
without this in mind, so the runs are not matched on anything except mode, rank, lr and seed — which
is exactly what we want here, but it also means a missing cell is a missing cell, not a zero. And
the three tasks are English general-knowledge benchmarks: a bottom-band arm that scores worse may be
worse at the task, not at retaining the base model. Report the delta, not a causal claim.
"""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import torch  # noqa: E402
import yaml  # noqa: E402

from lorasub.eval import forgetting  # noqa: E402
from lorasub.lora import inject_lora, load_factors_into  # noqa: E402
from lorasub.modeling import load_model, load_tokenizer  # noqa: E402


def _last_factors(d):
    """The factors of the LAST training step, or None when only the initialisation survives.

    `end` beats any numbered step; among numbers the largest wins, compared as integers. Returning
    None rather than falling back on `factors_0` is the point: a zero adapter measures the base
    model, and that number is indistinguishable from a real one in the CSV.
    """
    best, best_key = None, None
    for f in d.glob("factors_*.safetensors"):
        stem = f.stem[len("factors_"):]
        if stem == "0":
            continue                       # initialisation: A = 0, no update to measure
        if stem == "rescaled":
            continue                       # a different experiment, not a training step
        key = (1, 0) if stem == "end" else ((0, int(stem)) if stem.isdigit() else (-1, 0))
        if key[0] < 0:
            continue
        if best_key is None or key > best_key:
            best, best_key = f, key
    return best


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--runs_dir", default="~/lora-runs")
    ap.add_argument("--svd_cache", required=True)
    ap.add_argument("--model", default="meta-llama/Llama-3.2-1B")
    ap.add_argument("--task", default="format")
    ap.add_argument("--rank", type=int, default=2)
    ap.add_argument("--modes", default="bottom,top,random,random_ortho,free")
    ap.add_argument("--lr_from", default="configs/lr_selected.yaml",
                    help="keep only each arm's selected learning rate; without it the run set "
                         "mixes arms measured off their optimum, which is the confound this "
                         "project exists to remove")
    ap.add_argument("--n_modules", type=int, default=7,
                    help="keep only runs adapting exactly this many modules (7 = main grid, "
                         "5 = module-localisation grid)")
    ap.add_argument("--any_clip", action="store_true",
                    help="also keep runs trained without gradient clipping; off by default because "
                         "they are a different experiment")
    ap.add_argument("--limit", type=int, default=500)
    ap.add_argument("--seeds", default=None,
                    help="comma-separated seeds to keep, THE SAME for every arm. Without it the "
                         "script takes whichever runs come first, and the arms end up measured on "
                         "different seeds: bottom on 2,4,6 and top on 1,2,4 is not a paired "
                         "comparison, and the gap between them mixes the band with the draw.")
    ap.add_argument("--salted", type=lambda x: str(x).lower() not in ("0", "false", "no", "none"),
                    default=None,
                    help="for the drawing arms, keep only the salted (True) or unsalted (False) "
                         "version. They are two different experiments and the main table cites the "
                         "salted one.")
    ap.add_argument("--max_runs_per_cell", type=int, default=3)
    ap.add_argument("--out", default="~/lora-analysis/forgetting.csv")
    a = ap.parse_args()

    runs_dir = Path(a.runs_dir).expanduser()
    table = {}
    if a.lr_from and Path(a.lr_from).exists():
        table = (yaml.safe_load(open(a.lr_from)) or {}).get("selected", {})

    modes = a.modes.split(",")
    cells: dict[tuple, list[Path]] = {}
    for cfg_p in sorted(runs_dir.glob("*/config.yaml")):
        cfg = yaml.safe_load(open(cfg_p)) or {}
        d = cfg_p.parent
        if cfg.get("model") != a.model or cfg.get("task") != a.task:
            continue
        if cfg.get("mode") not in modes:
            continue
        rank = int(float(cfg.get("rank", 0)))
        if cfg.get("mode") != "free" and rank != a.rank:
            continue
        if cfg.get("update_norm_target") is not None:
            continue                                   # rescaled runs measure something else
        # max_grad_norm and target_modules change what a run IS, not how it is read. The noclip
        # grid reruns the same (mode, rank, lr, seed) without clipping, and the module-localisation
        # grid reruns it on five projections instead of seven: without these two lines a forgetting
        # median would silently average three different experiments. Both defaults match the main
        # grid, and --any_clip / --n_modules let an ablation ask for the others explicitly.
        mgn = cfg.get("max_grad_norm")
        if not a.any_clip and mgn is not None and float(mgn) > 1.5:
            continue
        if len(cfg.get("target_modules") or []) != a.n_modules:
            continue
        if table:
            key = f"{cfg['model']}|{cfg['task']}|{cfg['mode']}|{rank}"
            if key in table and abs(float(cfg.get("lr", 0)) - float(table[key])) > 1e-12:
                continue
        if a.seeds is not None:
            want = {int(x) for x in a.seeds.split(",")}
            if int(float(cfg.get("seed", -1))) not in want:
                continue
        if a.salted is not None and cfg.get("mode") in ("random", "random_ortho"):
            if bool(cfg.get("subspace_salted", False)) != a.salted:
                continue
        # `factors_0` alone is not a trained state: it is the initialisation, where A = 0. A run
        # that only has it must be dropped HERE, before the cell is built, and not later when the
        # measurement fails: `--max_runs_per_cell` slices this list, so an unusable run takes the
        # place of a usable replicate. That is how `bottom` seeds 5 and 6 came back empty while
        # 4f95b30be8bb and 1c564bd75ccb sat in the same cells with their factors_274.
        if _last_factors(d) is None:
            continue
        cells.setdefault((cfg["mode"], rank, float(cfg["lr"])), []).append(d)

    if not cells:
        raise SystemExit("no run with saved factors matched — check --model, --rank and --lr_from")

    # ONE RUN PER SEED, and seeds in order. `ds[:max_runs_per_cell]` took whatever the directory
    # listing happened to give: for `bottom` it spent two of its five places on replicates of seed 2
    # and never measured seed 3, which HAS its factors_274. A forgetting comparison across arms is
    # paired on seeds, so a cell that covers {2,2,4,5,6} is not the same measurement as one that
    # covers {2,3,4,5,6} — and the printed table looks identical either way.
    def _seed(dd):
        c = yaml.safe_load(open(dd / "config.yaml")) or {}
        return int(float(c.get("seed", -1)))

    for key, ds in list(cells.items()):
        by_seed = {}
        for dd in sorted(ds, key=lambda x: x.name):     # stable across runs of this script
            by_seed.setdefault(_seed(dd), dd)
        cells[key] = [by_seed[k] for k in sorted(by_seed)]

    # A forgetting comparison across arms is only meaningful if the arms share their seeds. Say so
    # when they do not, because the table that comes out looks exactly the same either way.
    seen = {}
    for (mode, rank, lr), ds in cells.items():
        ss = set()
        for dd in ds[:a.max_runs_per_cell]:
            c = yaml.safe_load(open(dd / "config.yaml")) or {}
            ss.add(int(float(c.get("seed", -1))))
        seen[(mode, rank)] = ss
    common = set.intersection(*seen.values()) if seen else set()
    if len(seen) > 1 and len(common) < min(len(v) for v in seen.values()):
        print("[forgetting] *** the arms do NOT share their seeds:")
        for k, v in sorted(seen.items(), key=lambda x: str(x[0])):
            print(f"      {str(k):24s} {sorted(v)}")
        print(f"      only {sorted(common) or 'none'} in common. This is not a paired comparison; "
              f"pass --seeds to fix it.\n")

    print(f"{sum(min(len(v), a.max_runs_per_cell) for v in cells.values())} evaluations over "
          f"{len(cells)} cells\n")

    rows = []
    tok = load_tokenizer(a.model)
    model = load_model(a.model)
    print("baseline (no adapter)...", flush=True)
    base = forgetting(model, tok, limit=a.limit)
    print("  ", base, "\n", flush=True)
    rows.append({"mode": "baseline", "rank": 0, "lr": 0.0, "seed": -1, "run": "-", **base})
    del model
    torch.cuda.empty_cache()

    for (mode, rank, lr), dirs in sorted(cells.items()):
        for d in dirs[: a.max_runs_per_cell]:
            cfg = yaml.safe_load(open(d / "config.yaml"))
            try:
                model = load_model(a.model)
                inject_lora(model, r=rank, mode=mode, cache_dir=a.svd_cache,
                            model_id=a.model, seed=int(cfg.get("seed", 0)),
                            subspace_salted=bool(cfg.get("subspace_salted", False)))
                # NOT `sorted(...)[-1]`. Two ways that goes wrong, and both did:
                #   * a run whose end-of-training factors were lost keeps `factors_0`, which is the
                #     INITIALISATION where A = 0. Loading it is perfectly valid and silently
                #     evaluates the base model: `bottom` seeds 5 and 6 both came back at exactly
                #     14.085775, the baseline perplexity, with no error anywhere.
                #   * the sort is lexicographic, so `factors_50` sorts after `factors_274`.
                _f = _last_factors(d)
                if _f is None:
                    raise FileNotFoundError(
                        f"{d.name}: only the initialisation was saved, so there is no trained "
                        f"state to measure. Loading it would report the base model as this arm.")
                load_factors_into(model, _f)
                m = forgetting(model, tok, limit=a.limit)
                rows.append({"mode": mode, "rank": rank, "lr": lr,
                             "seed": cfg.get("seed"), "run": d.name, **m})
                # the run id and the file: without them a suspicious number cannot be traced back
                # to what produced it, which is how 14.085775 sat in a log for hours unexplained
                print(f"  {mode:13s} r={rank} lr={lr:<7} seed={cfg.get('seed')} "
                      f"run={d.name} <- {_f.name}  {m}", flush=True)
            except Exception as e:                      # one bad run must not lose the others
                print(f"  {mode:13s} seed={cfg.get('seed')}  FAILED {type(e).__name__}: "
                      f"{str(e)[:80]}", flush=True)
            finally:
                model = None
                torch.cuda.empty_cache()

    out = Path(a.out).expanduser()
    out.parent.mkdir(parents=True, exist_ok=True)
    keys = sorted({k for r in rows for k in r})
    with out.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)
    print(f"\nwrote {len(rows)} rows -> {out}")

    try:
        import pandas as pd
    except ImportError:
        return
    df = pd.DataFrame(rows)
    b = df[df["mode"] == "baseline"]
    metrics = [c for c in ("hellaswag_acc_norm", "truthfulqa_mc1_acc", "wikitext_ppl") if c in df]
    if b.empty or not metrics:
        return
    print("\n=== forgetting: delta against the unadapted base model ===")
    print("    (negative on accuracies = forgot; positive on perplexity = forgot)\n")
    agg = df[df["mode"] != "baseline"].groupby("mode")[metrics].agg(["median", "count"])
    for m in metrics:
        agg[(m, "delta")] = agg[(m, "median")] - float(b[m].iloc[0])
    print(agg.round(4).to_string())
    print(f"\n  baseline: " + ", ".join(f"{m}={float(b[m].iloc[0]):.4f}" for m in metrics))
    print("\n  A U-shape across the spectral position would replicate Quercia et al. on FROZEN")
    print("  subspaces, where they measured it on initialisations. A flat profile would not.")
    print("  Medians, not means: these are small samples on heavy-tailed quantities.")


if __name__ == "__main__":
    main()
