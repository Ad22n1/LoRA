#!/bin/bash
#SBATCH --job-name=lorasub-smoke
#SBATCH --partition=PARTITION            # <- fill in
#SBATCH --gres=PARTITION:1
#SBATCH --cpus-per-task=4
#SBATCH --mem=32G
#SBATCH --time=00:30:00
#SBATCH --output=%x_%j.out
set -euo pipefail
: "${SHARED:?set SHARED}"
export HF_HOME="${HF_HOME:-$SHARED/hf}"
cd "$(dirname "$0")/.."
export PYTHONPATH="$PWD/src:${PYTHONPATH:-}"
python -c "import torch; print(torch.cuda.get_device_name(), 'bf16', torch.cuda.is_bf16_supported())"
python -m lorasub.train configs/smoke.yaml
