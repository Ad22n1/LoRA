"""Put the two toy panels side by side, so the sanity check costs a third of a page instead of two.

WHY A MERGE AND NOT A REDRAW. The two panels were produced on 15/09 and their generating code is
not in the repository; redrawing them would mean re-deriving data we no longer have. Compositing
the existing renders keeps them byte-identical to what was reviewed, and the only thing that
changes is the space they take.

They answer one objection together — "does your instrument see a spectral effect when there is
one?" — and a null result without that control is attackable. One figure, one objection.
"""
import sys

from PIL import Image

LEFT = "paper/figures/toy1_arms_vs_target.png"
RIGHT = "paper/figures/toy1b_free_arm_energy.png"
OUT = sys.argv[1] if len(sys.argv) > 1 else "paper/figures/toy.png"
GAP = 28
PAD = 10

a, b = Image.open(LEFT).convert("RGB"), Image.open(RIGHT).convert("RGB")
# scale to a common height so neither panel dominates by accident
h = max(a.height, b.height)
a = a.resize((round(a.width * h / a.height), h), Image.LANCZOS)
b = b.resize((round(b.width * h / b.height), h), Image.LANCZOS)

out = Image.new("RGB", (a.width + GAP + b.width + 2 * PAD, h + 2 * PAD), "white")
out.paste(a, (PAD, PAD))
out.paste(b, (PAD + a.width + GAP, PAD))

# (01/10) PANEL TITLES. The two renders carry their own "(a)" and "(b)" in the top-left corner, and the right render no letter; panel
# (c) has no white margin wide enough above its legend for a title. So the three titles go in one white band added on top, each
# aligned with its panel's left edge, in DejaVu Sans (the renders' font) at the height of the original letters, and the two original
# letters are blanked so that no letter appears twice. Nothing else in the renders is touched: every other pixel is carried over.
import os  # noqa: E402

import numpy as np  # noqa: E402
from PIL import ImageDraw, ImageFont  # noqa: E402

EXPECT = (2613, 646)
# boxes of the original "(a)" and "(b)", antialiased edge included, measured on the 15/09 composite; each sits above its panel's
# left axis (columns 137 and 938), which starts ten rows lower. The left axis of panel (c) is at column 1823.
LETTERS = [(141, 31, 174, 56), (941, 31, 974, 56)]
TITLES = [(141, "(a) target in the top band"), (941, "(b) target in the bottom band"), (1827, "(c) where the free arm writes")]
if out.size != EXPECT:
    raise SystemExit(f"STOP: composite is {out.size}, expected {EXPECT}; the letter boxes were measured on that size")
arr = np.asarray(out.convert("L"))
for x0, y0, x1, y1 in LETTERS:
    inside = (arr[y0:y1 + 1, x0:x1 + 1] < 128).any()
    ring = np.concatenate([arr[y0 - 6:y0, x0 - 6:x1 + 7].ravel(), arr[y1 + 1:y1 + 7, x0 - 6:x1 + 7].ravel(),
                           arr[y0:y1 + 1, x0 - 6:x0].ravel(), arr[y0:y1 + 1, x1 + 1:x1 + 7].ravel()])
    if not inside or (ring < 255).any():                    # the letter must be surrounded by pure white: blanking it removes nothing else
        raise SystemExit(f"STOP: box {(x0, y0, x1, y1)} does not hold an isolated letter; nothing is blanked")
import matplotlib  # noqa: E402
FONT = os.path.join(matplotlib.get_data_path(), "fonts", "ttf", "DejaVuSans.ttf")
target_h = LETTERS[0][3] - LETTERS[0][1] + 1
size = min(range(10, 80), key=lambda z: abs((lambda bb: bb[3] - bb[1])(ImageFont.truetype(FONT, z).getbbox("(a)")) - target_h))
font = ImageFont.truetype(FONT, size)
band = int(round(1.6 * target_h))
titled = Image.new("RGB", (out.width, out.height + band), "white")
draw_out = ImageDraw.Draw(out)
for x0, y0, x1, y1 in LETTERS:
    draw_out.rectangle((x0, y0, x1, y1), fill="white")
titled.paste(out, (0, band))
d = ImageDraw.Draw(titled)
top = (band - target_h) // 2 + 4
for x, t in TITLES:
    bx = font.getbbox(t)
    d.text((x - bx[0], top - font.getbbox("(a)")[1]), t, font=font, fill="black")   # same baseline for the three titles
out = titled
out.save(OUT)
print(f"  {a.size} + {b.size} -> {out.size} (title band {band} px, font size {size}, letters (a) and (b) moved into the titles)")
print("  ecrit ->", OUT)
