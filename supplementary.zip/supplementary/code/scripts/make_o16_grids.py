"""Grids of PROTOCOL_isolation_obqa16.md, and refs_o16.json (reference values and G, committed before any run). 211 runs.

    python scripts/make_o16_grids.py

The base of every grid is the config.yaml of a REFERENCE RUN itself (OpenBookQA, Qwen2.5-1.5B); only mode, rank (alpha = rank), lr and seed
change. STOPS unless each reference has exactly one run per seed 2-6 at its rate, and unless the free reference at rank 7 has its five seeds at
exactly one rate.
"""
import csv
import glob
import json
import os
import statistics as st
import sys
from pathlib import Path

import yaml


def is_obqa(c):
    """OpenBookQA on Qwen2.5-1.5B: identified by its data directory; the rank-16 campaign predates the data fingerprint (empty)."""
    return (c.get("task") == "commonsense" and str(c.get("model")) == "Qwen/Qwen2.5-1.5B"
            and os.path.basename(str(c.get("data_dir") or "").rstrip("/")) == "openbookqa"
            and str(c.get("data_fingerprint") or "") in ("", "None", "dc05f4d847f9"))

FP, MODEL = "dc05f4d847f9", "Qwen/Qwen2.5-1.5B"
LRS = [1e-4, 2e-4, 5e-4, 1e-3, 2e-3, 5e-3, 1e-2]
H = "# PRE-ENREGISTRE (PROTOCOL_isolation_obqa16.md). Genere par scripts/make_o16_grids.py.\n"
runs = []
for q in glob.glob(os.path.expanduser("~/lora-runs/*/config.yaml")):
    c = yaml.safe_load(open(q)) or {}; d = os.path.dirname(q)
    if not is_obqa(c):
        continue
    try:
        if not open(d + "/status").read().startswith("DONE"):
            continue
        m = json.load(open(d + "/metrics.json"))
    except (OSError, ValueError):
        continue
    if "mcq_acc" in m:
        runs.append((c, m, d))


def PARTITION(d):
    try:
        return (next(csv.DictReader(open(d + "/results.csv"))).get("PARTITION") or "?").replace("NVIDIA ", "").replace(" Generation", "")
    except (OSError, StopIteration):
        return "?"


def ref(mode, rank, lr):
    by = {}
    for c, m, d in runs:
        if c.get("mode") == mode and c.get("rank") == rank and abs(float(c.get("lr") or 0) - lr) < 1e-12 and c.get("seed") in (2, 3, 4, 5, 6) \
                and float(c.get("max_grad_norm", 1.0) or 0) == 1.0 and c.get("update_norm_target") in (None, ""):
            by.setdefault(c["seed"], []).append((m["mcq_acc"], d, c))
    if sorted(by) != [2, 3, 4, 5, 6] or any(len(v) != 1 for v in by.values()):
        sys.exit(f"STOP : reference {mode} r={rank} a {lr:g} : graines {sorted(by)}, doublons {[s for s, v in by.items() if len(v) > 1]} ; rien n'est genere")
    return {s: v[0] for s, v in by.items()}


free_rates = sorted({float(c["lr"]) for c, _, _ in runs if c.get("mode") == "free" and c.get("rank") == 7
                     and len({c2.get("seed") for c2, _, _ in runs if c2.get("mode") == "free" and c2.get("rank") == 7 and abs(float(c2["lr"]) - float(c["lr"])) < 1e-12} & {2, 3, 4, 5, 6}) == 5})
if len(free_rates) != 1:
    sys.exit(f"STOP : le LoRA libre au rang 7 a ses cinq graines de rapport a {len(free_rates)} taux ({free_rates}) au node d'un seul")
REFS = {"top": ("top", 16, 2e-3), "bottom": ("bottom", 16, 1e-3), "free": ("free", 7, free_rates[0])}
R = {k: ref(*v) for k, v in REFS.items()}
out = {"rates": {k: v[2] for k, v in REFS.items()}}
for k, v in R.items():
    out[k] = {str(s): v[s][0] for s in v}
    out[k + "_gpu"] = sorted({PARTITION(v[s][1]) for s in v})
    print(f"  reference {k:6s} (r={REFS[k][1]} a {REFS[k][2]:g}) : {st.mean(x[0] for x in v.values()):.4f} ; cartes {out[k + '_gpu']}")
out["G"] = {X: (st.mean(R["free"][s][0] for s in R["free"]) - st.mean(R[X][s][0] for s in R[X])) * 100 for X in ("top", "bottom")}
print(f"  G (libre r=7 - gele r=16) : top {out['G']['top']:+.2f}, bottom {out['G']['bottom']:+.2f}" + "   (test U : plancher 2 points)")
Path("refs_o16.json").write_text(json.dumps(out, indent=1))


def base_from(c, rank):
    b = dict(c)
    for k in ("mode", "lr", "seed", "band_frac", "update_norm_target"):
        b.pop(k, None)
    b.update(rank=rank, alpha=rank, save_factor_steps=[])
    mods = b.get("target_modules")
    if not is_obqa(b) or not (mods is None or len(mods) == 7):
        sys.exit("STOP : la configuration de reference n'est pas celle attendue")
    return b


total = 0
for rank in (7, 16):
    b = base_from(R["top"][2][2], rank)
    name = f"o16_r{rank}"
    Path(f"configs/grids/{name}.yaml").write_text(H + f"# rang {rank} : top_unfrozen et bottom_unfrozen, 7 taux, graines 0-6. 98 runs.\n"
                                                  + yaml.safe_dump({"base": b, "grid": {"mode": ["top_unfrozen", "bottom_unfrozen"], "lr": LRS, "seed": [0, 1, 2, 3, 4, 5, 6]}}, sort_keys=False))
    total += 98; print(f"  {name:12s} : top_unfrozen et bottom_unfrozen, rang {rank}, 7 taux, graines 0-6")
for k, (mode, rank, lr) in REFS.items():
    b = dict(R[k][2][2]); [b.pop(x, None) for x in ("mode", "lr", "seed")]
    b.update(save_factor_steps=[], out_dir="$HOME/lora-runs-suivi")
    name = f"o16_ref_{k}"
    Path(f"configs/grids/{name}.yaml").write_text(H + f"# CONTROLE A CARTE EGALE : reference {k} reentrainee a l'identique, graines 2-6, ~/lora-runs-suivi. 5 runs.\n"
                                                  + yaml.safe_dump({"base": b, "grid": {"mode": [mode], "lr": [lr], "seed": [2, 3, 4, 5, 6]}}, sort_keys=False))
    total += 5; print(f"  {name:12s} : {mode} r={rank} a {lr:g}, graines 2-6, reentrainee dans ~/lora-runs-suivi")
print(f"  total : {total} runs")
if total != 211:
    sys.exit("STOP : le total n'est pas 211")
