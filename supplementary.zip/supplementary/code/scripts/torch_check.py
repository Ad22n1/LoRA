"""Re-run, under the current torch, the three runs of reported cells that ran under torch 2.5.1.

RULE, FIXED BEFORE ANY RE-RUN: the originals are KEPT in the tables; the re-runs go to a separate
directory (out_dir is not part of run_id, so the configuration is otherwise identical and no replicate
is created), and the paper reports the difference. The question is only whether the library version
moves a score by more than seed-level noise.

    python scripts/torch_check.py             # lists the three runs
    python scripts/torch_check.py --apply     # grid in ~/lora-grid/torch_check
    python scripts/torch_check.py --compare   # after the jobs: original against re-run
"""
import glob
import os
import sys
from pathlib import Path

import pandas as pd
import yaml

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from lorasub.config import load_config  # noqa: E402
from lorasub.launch_grid import write_slurm  # noqa: E402

RUNS = os.path.expanduser("~/lora-runs")
OUT = os.path.expanduser("~/lora-runs-torchcheck")
GRID = Path(os.path.expanduser("~/lora-grid/torch_check"))
CELLS = [  # (mode, rank, band_frac, seed, lr): the three reported cells identified on 21/09
    ("band", 2, 0.25, 4, 0.01), ("bottom", 2, None, 6, 0.002), ("random", 1, None, 2, 0.01)]


def find():
    out = []
    for rdir in sorted(glob.glob(os.path.join(RUNS, "*"))):
        c, r = os.path.join(rdir, "config.yaml"), os.path.join(rdir, "results.csv")
        if not (os.path.exists(c) and os.path.exists(r)):
            continue
        y = yaml.safe_load(open(c)) or {}
        t = pd.read_csv(r, dtype=str)
        if "torch" not in t.columns or not str(t.torch.iloc[0]).startswith("2.5"):
            continue
        if "Llama" not in str(y.get("model")) or y.get("task") != "format" or len(y.get("target_modules") or []) != 7:
            continue
        for mode, rank, bf, seed, lr in CELLS:
            if (y.get("mode") == mode and int(y.get("rank", -1)) == rank and int(y.get("seed", -1)) == seed
                    and abs(float(y.get("lr", 0)) - lr) < 1e-12
                    and (bf is None or abs(float(y.get("band_frac", -1)) - bf) < 1e-9)):
                out.append((rdir, y, float(t.format_parsed.iloc[0])))
    return out


def main():
    runs = find()
    print(f"\n=== {len(runs)} of 3 reported runs under torch 2.5.1 ===")
    for rdir, y, sc in runs:
        print(f"  {os.path.basename(rdir)}  {y['mode']:6s} r={y['rank']} beta={y.get('band_frac')} seed={y['seed']} lr={y['lr']}  score={sc:.4f}")
    if "--compare" in sys.argv:
        print("\n=== original (2.5.1) against re-run (current torch) ===")
        for rdir, y, sc in runs:
            new = os.path.join(OUT, os.path.basename(rdir), "results.csv")
            nv = float(pd.read_csv(new).format_parsed.iloc[0]) if os.path.exists(new) else float("nan")
            print(f"  {os.path.basename(rdir)}  {sc:.4f} -> {nv:.4f}  ({(nv - sc) * 100:+.2f} pt)")
        return
    if "--apply" not in sys.argv:
        print("\n  nothing written. --apply writes the grid; the originals are never touched.")
        return
    (GRID / "configs").mkdir(parents=True, exist_ok=True)
    cfgs = []
    for rdir, y, sc in runs:
        cfg = load_config(os.path.join(rdir, "config.yaml"), overrides=[f"out_dir={OUT}"])
        cfg.to_yaml(GRID / "configs" / f"{cfg.run_id}.yaml")
        cfgs.append(cfg)
    p = write_slurm(GRID, cfgs, partition="PARTITION", time="01:59:00", mem="32G", max_par=3,
                    venv="/tmp/lora-$USER/venv")
    print(f"\n  grid written: {p}\n  submit with:  sbatch --exclude=node {p}")


if __name__ == "__main__":
    main()
