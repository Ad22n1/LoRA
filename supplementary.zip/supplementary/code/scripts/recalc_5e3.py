"""Every number the author checks flag as computed with bottom at 2e-3, recomputed at its selected
rate 5e-3 (seeds 0, 1, 30-32 select it; seeds 2-6 report it), plus the two analyses the TMLR review
asks for. Reads existing runs and forgetting CSVs only: no PARTITION.

    python scripts/recalc_5e3.py 2>&1 | grep -vE "FutureWarning|pd.concat"

Every run is filtered on alpha = rank (the alpha=16 run once pooled into a cell is quarantined, and
this guard keeps any other from passing). Tests are paired over the seeds all compared cells share.
"""
import glob
import math
import os
import random
import statistics as st
import sys

sys.path.insert(0, "src")
from lorasub.aggregate import collect  # noqa: E402

L = "meta-llama/Llama-3.2-1B"
Q05, Q15 = "Qwen/Qwen2.5-0.5B", "Qwen/Qwen2.5-1.5B"
S = [2, 3, 4, 5, 6]
d = collect(os.path.expanduser("~/lora-runs"))


def cell(model, mode, rank, lr, n_modules=7, seeds=S):
    x = d[(d.task == "format") & (d.model.astype(str) == model) & (d["mode"] == mode) & (d["rank"] == rank)
          & ((d.lr - lr).abs() < 1e-12) & (d.n_modules == n_modules) & (d.max_grad_norm == 1.0)
          & d.update_norm_target.isna() & (d.format_n == 614) & d.seed.isin(seeds)
          & ((d.alpha / d["rank"]).round(2) == 1.0)]
    if mode in ("random", "random_ortho"):
        x = x[x.subspace_salted == True]  # noqa: E712
    return x.groupby("seed").format_parsed.mean().to_dict()


def free_cell(model, rank, n_modules=7):
    """free at its selected rate: the best validation score on seeds 0 and 1 (the paper's rule); if
    the population has no selection sweep, the only rate with five reported seeds. Printed."""
    x = d[(d.task == "format") & (d.model.astype(str) == model) & (d["mode"] == "free") & (d["rank"] == rank)
          & (d.n_modules == n_modules) & (d.max_grad_norm == 1.0) & d.update_norm_target.isna()
          & ((d.alpha / d["rank"]).round(2) == 1.0)]
    sel = x[x.seed.isin([0, 1])].groupby("lr").val_format_parsed.agg(["mean", "size"])
    sel = sel[sel["size"] >= 2]
    rep = x[x.seed.isin(S) & (x.format_n == 614)].groupby("lr").seed.nunique()
    if len(sel):
        lr = float(sel["mean"].idxmax()); how = "selection sur les graines 0-1"
    else:
        full = rep[rep >= 5]
        lr = float(full.index[0]) if len(full) == 1 else float("nan"); how = "seul taux a cinq graines rapportees"
    print(f"  free r={rank} ({n_modules} modules) : taux {lr:g} ({how}) ; taux rapportes disponibles {dict(rep)}")
    return cell(model, "free", rank, lr, n_modules) if lr == lr else {}


def paired(a, b, scale=100.0):
    k = sorted(set(a) & set(b))
    dd = [(a[s] - b[s]) * scale for s in k]
    if len(dd) < 2:
        return float("nan"), float("nan"), 0, len(dd)
    sd = st.stdev(dd)
    t = st.mean(dd) / (sd / len(dd) ** 0.5) if sd > 0 else float("inf")
    return st.mean(dd), t, sum(v > 0 for v in dd), len(dd)


def boot(fn, seeds, n=20000):
    rng = random.Random(0)
    v = sorted(fn([seeds[rng.randrange(len(seeds))] for _ in seeds]) for _ in range(n))
    return v[int(0.025 * n)], v[int(0.975 * n)]


def line(lab, m, t, pos, n, thr=None):
    flag = "" if thr is None else ("  PASSE" if abs(t) > thr else "  sous le seuil")
    print(f"  {lab:46s} {m:+7.2f} pt  t = {t:+6.2f}  {pos}/{n}{flag}")


# ---------------------------------------------------------------- 1. rank 2, freezing minus choosing
print("=== 1. rang 2, bras principaux : geler - choisir (bottom a 5e-3) ===")
arms = {"top": cell(L, "top", 2, 1e-2), "bottom": cell(L, "bottom", 2, 5e-3),
        "random": cell(L, "random", 2, 1e-2), "random_ortho": cell(L, "random_ortho", 2, 1e-2)}
free1 = free_cell(L, 1)
for k, v in list(arms.items()) + [("free r=1", free1)]:
    print(f"  {k:13s} {len(v)} graines  {st.mean(v.values()):.4f}")
seeds = sorted(set.intersection(*[set(v) for v in arms.values()], set(free1)))


def fc(ix):
    m = {k: st.mean(v[s] for s in ix) for k, v in arms.items()}
    fr = st.mean(free1[s] for s in ix)
    return (fr - max(m.values())) * 100, (max(m.values()) - min(m.values())) * 100


f, c = fc(seeds)
lo, hi = boot(lambda ix: fc(ix)[0] - fc(ix)[1], seeds)
print(f"  geler {f:.2f}  choisir {c:.2f}  rapport {f / c:.2f}")
print(f"  geler - choisir {f - c:+.2f} pt  IC95 [{lo:+.2f}, {hi:+.2f}]   (ancien : +2.7 [+0.2, +4.3])")

# ---------------------------------------------------------------- 2. the deficit family
print("\n=== 2. famille du deficit, Llama rang 2, bottom a 5e-3 (seuil 3.96, 3 comparaisons) ===")
b = arms["bottom"]
for o in ("top", "random", "random_ortho"):
    line(f"{o} - bottom", *paired(arms[o], b), thr=3.96)
seeds = sorted(set.intersection(*[set(v) for v in arms.values()]))
lo, hi = boot(lambda ix: (max(st.mean(arms[o][s] for s in ix) for o in ("top", "random", "random_ortho"))
                          - st.mean(b[s] for s in ix)) * 100, seeds)
gap = (max(st.mean(arms[o].values()) for o in ("top", "random", "random_ortho")) - st.mean(b.values())) * 100
print(f"  meilleur bras - bottom {gap:+.2f} pt  IC95 [{lo:+.2f}, {hi:+.2f}]")
print(f"  ecart minimal {min((st.mean(arms[o].values()) - st.mean(b.values())) * 100 for o in ('top', 'random', 'random_ortho')):.2f} pt")

# ---------------------------------------------------------------- 3. five modules
print("\n=== 3. cinq modules (bottom a 5e-3) ===")
five = {"free r=1": free_cell(L, 1, 5),
        "top": cell(L, "top", 2, 1e-2, 5), "random": cell(L, "random", 2, 1e-2, 5),
        "random_ortho": cell(L, "random_ortho", 2, 1e-2, 5), "bottom": cell(L, "bottom", 2, 5e-3, 5)}
five = {k: v for k, v in five.items() if v}
for k, v in five.items():
    print(f"  {k:13s} {len(v)} graines  {st.mean(v.values()):.4f}")
con = [k for k in five if k != "free r=1"]
mm = {k: st.mean(five[k].values()) for k in con}
fr5 = st.mean(five["free r=1"].values())
f5, c5 = (fr5 - max(mm.values())) * 100, (max(mm.values()) - min(mm.values())) * 100
print(f"  geler {f5:.2f}  choisir {c5:.2f}  rapport {f5 / c5:.2f}   (ancien : 18.5 / 13.4 / 1.4)")
for o in con:
    if o != "bottom":
        line(f"{o} - bottom (cinq modules)", *paired(five[o], five["bottom"]))

# ---------------------------------------------------------------- 4. forgetting
print("\n=== 4. oubli (perplexite WikiText, arm - bottom ; bottom a 5e-3) ===")
rows = []
for f_ in sorted(glob.glob(os.path.expanduser("~/lora-analysis/forgetting*.csv")), key=os.path.getmtime, reverse=True):
    import pandas as pd
    try:
        t_ = pd.read_csv(f_)
    except Exception:  # noqa: BLE001  -- an empty file left by a cancelled job
        print(f"  (ignore, illisible : {os.path.basename(f_)})")
        continue
    if {"mode", "lr", "seed", "wikitext_ppl"} <= set(t_.columns):
        t_ = t_.copy()
        t_["src"] = os.path.basename(f_) + " (" + __import__("time").strftime("%d/%m", __import__("time").localtime(os.path.getmtime(f_))) + ")"
        if "run" not in t_.columns:          # the 17/09 file predates the run column
            t_["run"] = t_["src"] + ":" + t_["mode"].astype(str) + ":" + t_["lr"].astype(str) + ":" + t_["seed"].astype(str)
        rows.append(t_)
import pandas as pd  # noqa: E402
F = pd.concat(rows).drop_duplicates(subset=["run"]) if rows else pd.DataFrame()
F = F[(F.run != "6da8b49ae6b7") & (F.wikitext_ppl < 1e4) & F.seed.isin(S)] if len(F) else F
print("  cellules disponibles :", sorted({(r.mode, r.lr) for r in F.itertuples()}, key=str))


def ppl(mode, lr, rank=None):
    x = F[(F["mode"] == mode) & ((F.lr - lr).abs() < 1e-12)]
    if rank is not None and "rank" in x.columns:
        x = x[x["rank"] == rank]
    if len(x):
        print(f"    {mode} a {lr:g} : sources {sorted(set(x.src))}, graines {sorted(set(int(v) for v in x.seed))}, moyenne {x.groupby('seed').wikitext_ppl.mean().mean():.2f}")
    return x.groupby("seed").wikitext_ppl.mean().to_dict()


bp = ppl("bottom", 5e-3)
print(f"  bottom a 5e-3 : {len(bp)} graines, moyenne {st.mean(bp.values()):.2f}" if bp else "  bottom a 5e-3 : ABSENT")
print("  (valeurs du papier pour comparaison : bottom 21.25 a 2e-3, top 40.63, random 25.00, random_ortho 26.31, free 24.06)")
ppl("bottom", 2e-3)
for mode, lr in (("random", 1e-2), ("free", 2e-3), ("random_ortho", 1e-2), ("top", 1e-2)):
    ap = ppl(mode, lr, rank=1 if mode == "free" else 2)
    if ap and bp:
        line(f"{mode} - bottom (perplexite)", *paired(ap, bp, 1.0), thr=4.31)
        lg = paired({s: math.log(v) for s, v in ap.items()}, {s: math.log(v) for s, v in bp.items()}, 1.0)
        line(f"{mode} - bottom (log-perplexite)", *lg, thr=4.31)

# ---------------------------------------------------------------- 5. TMLR: fixed competitors, interaction
print("\n=== 5. inversion : concurrents fixes, et interaction variante x taux ===")
CONF = (("Llama r=2", L, 2, ("top", "random", "random_ortho")), ("Llama r=4", L, 4, ("top", "random")),
        ("Qwen-0.5B", Q05, 2, ("top", "random_ortho")), ("Qwen-1.5B", Q15, 2, ("top", "random_ortho")))
for lab, model, rank, others in CONF:
    lo_, hi_ = 2e-3, 1e-2
    print(f"  --- {lab} (taux communs {lo_:g} et {hi_:g}) ---")
    bl, bh = cell(model, "bottom", rank, lo_), cell(model, "bottom", rank, hi_)
    for o in others:
        ol, oh = cell(model, o, rank, lo_), cell(model, o, rank, hi_)
        line(f"avance a {lo_:g}, bottom - {o}", *paired(bl, ol), thr=2.776)
        line(f"retard a {hi_:g}, {o} - bottom", *paired(oh, bh), thr=2.776)
        k = sorted(set(bl) & set(bh) & set(ol) & set(oh))
        inter = {s: (bl[s] - ol[s]) - (bh[s] - oh[s]) for s in k}
        line(f"interaction (bottom - {o}) bas - haut", *paired(inter, {s: 0.0 for s in k}), thr=2.776)
