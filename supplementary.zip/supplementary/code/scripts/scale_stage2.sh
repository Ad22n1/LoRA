#!/bin/bash
# Apres l'etape 1 (selection) : genere les grilles du RAPPORT au taux retenu par bras, les committe avant leurs runs, puis les lance.
set -u
cd "$HOME/repo" || exit 1
PY="/tmp/lora-$USER/venv/bin/python"; [ -x "$PY" ] || PY=python3
M=$(grep -h "^  model:" configs/grids/scale_s1_top.yaml | grep -oE "7B|3B")
[ -n "$M" ] || { echo "  STOP : modele de l'etape 1 introuvable"; exit 1; }
echo "=== etape 2, rapport, modele $M ==="
"$PY" scripts/make_scale_grids.py --stage2 "$M" || { echo "  STOP : selection incomplete ; rien n'est lance"; exit 1; }
git add configs/grids/scale_s2_*.yaml && git commit -qm "echelle : taux retenus sur les graines 0-1 ; grilles du rapport avant leurs runs" && echo "  ok : committe ($(git log -1 --format=%h))"
git push -q 2>/dev/null; bash scripts/launch_scale_s2.sh
