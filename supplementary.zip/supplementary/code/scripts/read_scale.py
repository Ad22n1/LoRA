"""PROTOCOL_scale.md: the central result on Qwen2.5-7B (or Qwen2.5-3B, by the rule), OpenBookQA, rank 2. No PARTITION.

    python scripts/read_scale.py 2>&1 | grep -vE "FutureWarning|pd.concat"

Selection on seeds 0-1 (validation); reported seeds 2-6. (1) X_unfrozen - X, t > 3.495; (2) dual_X - X, t > 3.495; (3) the gap between
bands, (bottom_unfrozen - top_unfrozen) - (bottom - top), t > 2.776. Reported: G = free - X, freezing minus choosing (paired bootstrap),
the rates, the PARTITION models, (no oracle bracket: the reported seeds run at the selected rate only).
"""
import csv
import glob
import json
import math
import os
import random
import re
import statistics as st

import yaml

R = os.path.expanduser("~/lora-runs")
LLAMA, QWEN = "meta-llama/Llama-3.2-1B", "Qwen/Qwen2.5-1.5B"
S_SEL, S_REP = (0, 1), [2, 3, 4, 5, 6]


def tokens(c):
    t = c.get("target_tokens")
    return t.get(c.get("task")) if isinstance(t, dict) else t


RUNS = []
for p in glob.glob(R + "/*/config.yaml"):
    c = yaml.safe_load(open(p)) or {}
    d = os.path.dirname(p)
    try:
        if not open(d + "/status").read().startswith("DONE"):
            continue
        RUNS.append((c, json.load(open(d + "/metrics.json")), d))
    except OSError:
        continue


def clipped(c):
    """Gradient clipping at 1.0, the paper's setting. A noclip grid reran the same cells without clipping (collect()'s
    docstring); mixing both put two runs per seed in the frozen cells and moved G from 12.41 to 13.53 (26/09)."""
    v = c.get("max_grad_norm", 1.0)
    return v is not None and float(v) == 1.0


def seven(c):
    tm = c.get("target_modules")
    return tm is None or len(tm) == 7


def cell(pred, mode, rank, lr, seeds, key):
    """{seed: value}; several runs of one seed are averaged and flagged."""
    by = {}
    for c, m, d in RUNS:
        if (pred(c) and clipped(c) and c.get("mode") == mode and c.get("rank") == rank and abs(float(c.get("lr") or 0) - lr) < 1e-12
                and c.get("seed") in seeds and key in m and c.get("update_norm_target") in (None, "")):
            by.setdefault(c["seed"], []).append((m[key], d))
    dup = {s: len(v) for s, v in by.items() if len(v) > 1}
    if dup:   # say what separates the duplicates, so that the next filter is written from evidence
        s0 = sorted(dup)[0]; cfgs = [yaml.safe_load(open(d + "/config.yaml")) or {} for _, d in by[s0]]
        keys = sorted(k for k in set().union(*cfgs) if k not in ("run_id", "out_dir") and len({str(c_.get(k)) for c_ in cfgs}) > 1)
        dup["differ"] = {k: [c_.get(k) for c_ in cfgs] for k in keys} or "configs identiques"
    return {s: st.mean(x for x, _ in v) for s, v in by.items()}, dup, {s: [d for _, d in v] for s, v in by.items()}


def select(pred, mode, rank, lrs, key):
    full = {}
    for lr in lrs:
        v, _, _ = cell(pred, mode, rank, lr, S_SEL, key)
        if len(v) == 2: full[lr] = st.mean(v.values())
    if len(full) < len(lrs):
        return None, f"INCOMPLET ({len(full)}/{len(lrs)} taux avec leurs deux graines)"
    best = max(full, key=full.get)
    edge = best in (lrs[0], lrs[-1])
    return best, "  ".join(f"{lr:g}:{full[lr]:.3f}" for lr in lrs) + f"  -> {best:g}" + ("  AU BORD" if edge else "")



T4, BONF2 = 2.776, 3.495
LRS = [5e-4, 1e-3, 2e-3, 5e-3, 1e-2]
MODEL = next((m for m in ("Qwen/Qwen2.5-7B", "Qwen/Qwen2.5-3B") if any(str(c.get("model")) == m and c.get("mode") == "dual_top" for c, _, _ in RUNS)), None)
pred = lambda c: c.get("task") == "commonsense" and str(c.get("data_fingerprint")) == "dc05f4d847f9" and str(c.get("model")) == MODEL  # noqa: E731


def gpu_of(d):
    try:
        with open(d + "/results.csv", newline="") as f:
            return (next(csv.DictReader(f)).get("PARTITION") or "?").replace("NVIDIA ", "").replace(" Generation", "")
    except (OSError, StopIteration):
        return "?"


def pt(a, b):
    d = [(a[s] - b[s]) * 100 for s in S_REP]; m = st.mean(d); se = st.stdev(d) / 5 ** 0.5
    return m, m - T4 * se, m + T4 * se, (m / se if se > 0 else float("inf"))


def col(x, thr):
    return f"{x[0]:+.2f} [{x[1]:+.2f}, {x[2]:+.2f}] t={x[3]:+.2f} " + ("ETABLI" if abs(x[3]) > thr else "non etabli")


print(f"==================== le resultat central a plus grande echelle : {MODEL or 'AUCUN RUN'} (OpenBookQA, rang 2) ====================")
if MODEL:
    ARMS = [("top", 2), ("bottom", 2), ("top_unfrozen", 2), ("bottom_unfrozen", 2), ("dual_top", 2), ("dual_bottom", 2), ("free", 1)]
    V, gpus, bad = {}, {}, []
    for mode, rank in ARMS:
        b, txt = select(pred, mode, rank, LRS, "val_mcq_acc")
        print(f"  selection {mode:16s} : {txt}")
        if b is None:
            bad.append(mode); continue
        v, dup, dirs = cell(pred, mode, rank, b, S_REP, "mcq_acc")
        if len(v) != 5 or dup:
            bad.append(mode); continue
        V[mode] = v
        gpus[mode] = sorted({gpu_of(d[0]) for d in dirs.values()})
        print(f"    {mode} a {b:g} : {st.mean(v.values()):.4f}" + ("  AU BORD" if b in (LRS[0], LRS[-1]) else ""))
    if bad:
        print(f"  ARRET : cellules incompletes ou doublons : {bad}")
    else:
        for X in ("top", "bottom"):
            print(f"\n  --- {X} : G = free - {X} = {pt(V['free'], V[X])[0]:+.2f} (rapporte)")
            for lab, a, thr in ((f"(1) gel seul, {X}_unfrozen - {X}", f"{X}_unfrozen", BONF2), (f"(2) geler A, dual_{X} - {X}", f"dual_{X}", BONF2)):
                print(f"    {lab:34s} {col(pt(V[a], V[X]), thr)}")
        shrink = lambda W: {s: (W["bottom_unfrozen"][s] - W["top_unfrozen"][s]) - (W["bottom"][s] - W["top"][s]) for s in S_REP}  # noqa: E731
        zero = {s: 0.0 for s in S_REP}
        print(f"\n  (3) PRE-ENREGISTRE  ecart bottom - top : {pt(V['bottom'], V['top'])[0]:+.2f} geles, {pt(V['bottom_unfrozen'], V['top_unfrozen'])[0]:+.2f} degeles")
        print(f"      reduction : {col(pt(shrink(V), zero), T4)}")
        def fc(ix):
            m = {k: st.mean(V[k][s] for s in ix) for k in ("top", "bottom")}; ff = st.mean(V["free"][s] for s in ix)
            return (ff - max(m.values())) * 100, (max(m.values()) - min(m.values())) * 100
        g, c = fc(S_REP); rng = random.Random(0); B = sorted(a - b for a, b in (fc([S_REP[rng.randrange(5)] for _ in S_REP]) for _ in range(20000)))
        print(f"  rapporte : geler {g:.2f}, choisir {c:.2f}, geler - choisir {g - c:+.2f} [{B[500]:+.2f}, {B[19499]:+.2f}]")
        print("  cartes : " + " | ".join(f"{k} {','.join(v)}" for k, v in gpus.items()))
