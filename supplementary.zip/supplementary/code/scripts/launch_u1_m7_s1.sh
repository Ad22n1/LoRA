#!/bin/bash
# Lance l'etape 1 de PROTOCOL_7b_unfrozen_r1.md pour Mistral-7B, uniquement sur les machines ou un run de ce modele s'est deja termine.
set -u
DRY=0; FA=0; PARTITION="RTX 4000 Ada"; for a in "$@"; do [ "$a" = "--dry" ] && DRY=1; [ "$a" = "--avec-freezeA" ] && FA=1; done
cd "$HOME/repo" || { echo "STOP : ~/repo introuvable"; exit 1; }
PY="/tmp/lora-$USER/venv/bin/python"; [ -x "$PY" ] || { echo "STOP : environnement /tmp/lora-$USER/venv absent"; exit 1; }
GRIDS="u1_m7_s1_top_unfrozen u1_m7_s1_bottom_unfrozen"
FILES="PROTOCOL_7b_unfrozen_r1.md scripts/make_u1_grids.py scripts/read_u1.py configs/grids/u1_m7_s1_top_unfrozen.yaml configs/grids/u1_m7_s1_bottom_unfrozen.yaml scripts/nodes_for_mistral.py"
echo "=== 1. tout est committe et a jour ==="
bad=0
for f in $FILES; do
  git ls-files --error-unmatch "$f" >/dev/null 2>&1 && git diff --quiet HEAD -- "$f" || { echo "  NON COMMITTE OU MODIFIE : $f"; bad=1; }
done
[ $bad -eq 0 ] && echo "  ok" || { echo "  REFUS : committer d'abord ; rien n'est lance"; exit 1; }
echo "=== 2. place disque (aucun facteur sauvegarde) ==="
du -sh "$HOME" 2>/dev/null | sed 's/^/  dossier personnel : /'
echo "=== 2 bis. epinglage sur un seul modele de carte : $PARTITION ==="
EXCL=$("$PY" scripts/nodes_for_mistral.py 2>&1 | tail -1)
case "$EXCL" in STOP*|"") echo "  $EXCL"; echo "  REFUS : epinglage impossible ; rien n'est lance"; exit 1;; esac
"$PY" scripts/nodes_for_mistral.py --report 2>&1 | head -2
echo "=== 3. lancement ==="
for g in $GRIDS; do
  if squeue -h -u "$USER" -o "%o" 2>/dev/null | grep -q "/lora-grid/$g/slurm_array.sh"; then echo "  EN COURS $g : rien n'est touche"; continue; fi
  dir="$HOME/lora-grid/$g"; [ $DRY -eq 1 ] && dir="$(mktemp -d)/$g"
  out=$("$PY" -m lorasub.launch_grid "configs/grids/$g.yaml" --grid_dir "$dir" --partition PARTITION --time 01:59:00 --max_par 8 --venv "/tmp/lora-$USER/venv" 2>&1)
  n=$(echo "$out" | grep -oE "[0-9]+ already done; [0-9]+ to run")
  [ -n "$n" ] || { echo "  ERREUR $g :"; echo "$out" | tail -3 | sed 's/^/    /'; continue; }
  done_=$(echo "$n" | grep -oE "^[0-9]+"); torun=$(echo "$n" | grep -oE "[0-9]+ to run" | grep -oE "[0-9]+")
  if [ "$torun" -eq 0 ]; then echo "  RIEN    $g : complet ($done_)"; continue; fi
  [ "$done_" -gt 0 ] && echo "  REPRISE $g : $done_ runs termines conserves"
  if [ $DRY -eq 1 ]; then echo "  pret    $g : $torun runs"; continue; fi
  { echo "reprise $g, machines eprouvees pour Mistral-7B, le $(date +'%d/%m %H:%M') ; machines exclues :"; echo "node,$EXCL" | tr ',' '\n'; } >> "$HOME/lora-grid/$g/machines_reprise.txt"
  echo "  soumis  $g ($torun runs a relancer, machines eprouvees pour Mistral-7B) : job $(sbatch --parsable --exclude="node,$EXCL" "$HOME/lora-grid/$g/slurm_array.sh")"
done
echo "=== file ==="; squeue -u "$USER" | head -6
