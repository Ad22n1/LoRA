#!/bin/bash
# The two forgetting measurements of job 301 and 305 stopped after three runs per cell: the script's
# --max_runs_per_cell defaults to 3, and it took seeds 2, 3 and 4 in that order (for bottom at 5e-3,
# the collapsed run of seed 2 rather than its converged rerun). Same measurements, every run of the
# cell: bottom at 5e-3 has six runs (seed 2 twice), random at 2e-3 five. Overwrites the two files.
#SBATCH --job-name=forgetc
#SBATCH --partition=PARTITION
#SBATCH --cpus-per-task=4
#SBATCH --mem=32G
#SBATCH --time=01:59:00
#SBATCH --exclude=node
#SBATCH --output=~/lora-results/forgetc-%j.out
source /tmp/lora-$USER/venv/bin/activate
export SHARED=$HOME/lora-shared
cd $HOME/repo
python -c "
import yaml
yaml.safe_dump({'selected': {'meta-llama/Llama-3.2-1B|format|bottom|2': 0.005}}, open('configs/lr_bottom_5e-3.yaml', 'w'))
yaml.safe_dump({'selected': {'meta-llama/Llama-3.2-1B|format|random|2': 0.002}}, open('configs/lr_common_2e-3_random.yaml', 'w'))"
python scripts/forgetting_from_factors.py --svd_cache "$SHARED/svd" --lr_from configs/lr_bottom_5e-3.yaml \
  --modes bottom --seeds 2,3,4,5,6 --max_runs_per_cell 20 --out "$HOME/lora-analysis/forgetting_bottom_5e-3.csv"
python scripts/forgetting_from_factors.py --svd_cache "$SHARED/svd" --lr_from configs/lr_common_2e-3_random.yaml \
  --modes random --salted true --seeds 2,3,4,5,6 --max_runs_per_cell 20 --out "$HOME/lora-analysis/forgetting_common_lr_random.csv"
