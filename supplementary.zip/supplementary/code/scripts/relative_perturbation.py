"""Relative perturbation per arm, computed from the saved factors — no run to redo.

    python scripts/relative_perturbation.py --runs_dir ~/lora-runs --svd_cache $SHARED/svd \
        [--task format] [--out ~/lora-analysis/relative_perturbation.csv]

Why this exists. The absolute update norm is not comparable across spectral bands: on a real layer the
top band carries a Frobenius energy thousands of times larger than the bottom one, so the same
||dW|| = 0.71 is a negligible change up there and an enormous one down below. Measured on a toy
spectrum, one update of norm 0.18 is a 1.8 % relative change in the top band and a 180x change in the
bottom one. An anticorrelation between performance and ABSOLUTE norm therefore says nothing about
relative perturbation, and the two must be reported side by side.

Reads ``factors_<step>.safetensors`` written at the end of each run, so it costs no PARTITION time.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd
import yaml
from safetensors.torch import load_file

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from lorasub import expand_path  # noqa: E402
from lorasub.spectral import load_svd, parse_module_name, relative_perturbation  # noqa: E402

BAND_OF_MODE = {"top": "top:{r}", "bottom": "bottom:{r}", "random": "random:{r}:{seed}"}


def band_spec(mode: str, rank: int, seed, salted: bool, name: str) -> str:
    """The band the run actually wrote into.

    THE SALTED RANDOM ARM DRAWS A DIFFERENT BAND PER MODULE. Reconstructing it as
    ``random:{r}:{seed}`` — the unsalted form — compares dW against a band it was never written to,
    so the denominator is wrong and the relative perturbation reported for `random` is meaningless.
    `top` and `bottom` are deterministic and unaffected. This is the same failure shape as the salt
    in the run id and in KEY: a field that changes what is measured, not read where it matters.
    """
    if mode != "random":
        return BAND_OF_MODE[mode].format(r=rank, seed=seed)
    return f"random:{rank}:{seed}:{name}" if salted else f"random:{rank}:{seed}"


def last_factor_file(run_dir: Path) -> Path | None:
    """Last saved factor file, or None when the only checkpoint is step 0.

    A run that never reached the end leaves only ``factors_0.safetensors``, where A = 0 by
    construction and therefore dW = 0. Reading it yields an update norm of exactly zero, which is not
    a measurement — it is the absence of one. One such run made half of a two-seed cell read as "the
    arm writes nothing", which nearly became a claim about inactive arms.
    """
    steps = [(int(p.stem.split("_")[1]), p) for p in run_dir.glob("factors_*.safetensors")
             if p.stem.split("_")[1].isdigit()]
    if not steps:
        return None
    last_step, path = max(steps)
    return None if last_step == 0 else path


def analyse_run(run_dir: Path, svd_cache: str) -> list[dict]:
    # A directory without results.csv is a run that never finished. Its factors, if any, are those of
    # an interrupted training and do not describe a trained adapter.
    if not (run_dir / "results.csv").exists():
        return []
    cfg_path = run_dir / "config.yaml"
    if not cfg_path.exists():
        return []
    with open(cfg_path) as f:
        cfg = yaml.safe_load(f)
    mode, rank = cfg.get("mode"), int(cfg.get("rank") or 0)
    if mode not in BAND_OF_MODE or rank < 1:
        return []          # `free` has no band to compare against; `full` has no factors
    fpath = last_factor_file(run_dir)
    if fpath is None:
        return []
    # The rescaled runs are a different population: rescale_update_ multiplies A after training, so
    # their factors are not the ones the arm converged to. Reading them here would mix two magnitudes
    # in the same median. Same class as the salt, on a field added the same day.
    if cfg.get("update_norm_target") is not None:
        return []
    scaling = float(cfg.get("alpha") or rank) / rank
    seed = cfg.get("subspace_seed") or cfg.get("seed") or 0
    salted = bool(cfg.get("subspace_salted", False))
    t = load_file(str(fpath), device="cpu")
    names = sorted({k.rsplit(".", 1)[0] for k in t if k.endswith(".A")})
    rows = []
    for name in names:
        try:
            svd = load_svd(svd_cache, cfg["model"], name, device="cpu")
        except FileNotFoundError:
            continue
        layer, mtype = parse_module_name(name)
        band = band_spec(mode, rank, seed, salted, name)      # per module: the salt changes the draw
        r = relative_perturbation(t[f"{name}.A"].float(), t[f"{name}.B"].float(), svd, band, scaling)
        rows.append(dict(run_id=run_dir.name, model=cfg["model"], task=cfg.get("task"), mode=mode,
                         rank=rank, lr=cfg.get("lr"), seed=cfg.get("seed"),
                         subspace_salted=salted,
                         # these two make a run a DIFFERENT experiment, and neither was carried:
                         # the noclip grid reruns the same cell without clipping, the localisation
                         # grid reruns it on five projections. Without them in the file there is no
                         # way to tell three populations apart after the fact.
                         max_grad_norm=cfg.get("max_grad_norm"),
                         n_modules=len(cfg.get("target_modules") or []),
                         layer=layer, module_type=mtype, **r))
    return rows


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs_dir", required=True)
    ap.add_argument("--svd_cache", required=True)
    ap.add_argument("--task", default=None)
    ap.add_argument("--model", default=None,
                    help="substring of the model id; keeps only those runs. Two architectures are "
                         "not commensurable here and a median over both describes neither.")
    ap.add_argument("--select_lr", default=None,
                    help="lr_selected.yaml: keep only the runs at each arm's selected rate. Without "
                         "it the averages mix every learning rate, and the norms differ by an order "
                         "of magnitude between 1e-4 and 3e-2 — the comparison is then meaningless")
    ap.add_argument("--n_modules", type=int, default=7,
                    help="keep only runs adapting exactly this many modules (7 = main grid)")
    ap.add_argument("--any_clip", action="store_true",
                    help="also keep runs trained without gradient clipping")
    ap.add_argument("--cond_tol", type=float, default=1e-4,
                    help="drop a (run, module) pair when the adapted band's smallest singular value is "
                         "below this fraction of the module's largest. THE STATED REASON WAS WRONG "
                         "(13/09): the 3e-9 ratio quoted for q_proj and o_proj was never sourced and "
                         "is contradicted by the cache — worst layers give 1.86e-7 and 4.36e-6, and "
                         "the margin over the fp32 noise floor is 1.6 for q_proj (layer 0 only, "
                         "median 51) and 36 for o_proj. o_proj is NOT ill-conditioned. The medians of "
                         "3046 and 3290 are therefore REAL: the bottom band of those modules carries "
                         "almost no energy, so writing an update of norm ~2.8 there is a genuinely "
                         "enormous relative perturbation. Excluding them removes the cases where the "
                         "measured effect is STRONGEST, which is conservative for the claim that the "
                         "minor arm perturbs more. Report both populations, or justify the threshold "
                         "by the noise floor (1.2e-6, i.e. ten times eps) rather than by a figure "
                         "that does not exist")
    ap.add_argument("--salted", type=lambda x: str(x).lower() not in ("0", "false", "no"), default=True,
                    help="which version of the random arm to keep: True = drawn independently per "
                         "module (post 12/09). The two arms measure different things and must never "
                         "be pooled. top/bottom/free are unaffected and always kept.")
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    runs = sorted(Path(expand_path(a.runs_dir)).glob("*/"))
    rows: list[dict] = []
    for d in runs:
        rows.extend(analyse_run(d, expand_path(a.svd_cache)))
    if not rows:
        print("no constrained run with saved factors found")
        return
    df = pd.DataFrame(rows)
    if a.task:
        df = df[df.task == a.task]
    # ONE MODEL AT A TIME. Two architectures have different d_in, different depth and different
    # band energies, so their relative perturbations are not commensurable — and a median over both
    # describes neither. This bit silently mixed Llama and Qwen the day Qwen produced its first
    # runs: `bottom` at 2e-3 showed nine runs for five seeds, and the median moved from 5,13 to
    # 3,78. The default keeps the whole file, so the filter has to be asked for, but the printed
    # summary now names the models it found.
    if a.model:
        keep = df.model.astype(str).str.contains(a.model, regex=False)
        if not keep.all():
            print(f"[rel-pert] {df[~keep].run_id.nunique()} run(s) of another model set aside "
                  f"(kept those matching {a.model!r})")
        df = df[keep]
    if "max_grad_norm" in df and not a.any_clip:
        drop = df.max_grad_norm.notna() & (df.max_grad_norm.astype(float) > 1.5)
        if drop.any():
            print(f"[rel-pert] {df[drop].run_id.nunique()} run(s) trained without gradient clipping "
                  f"set aside (a different experiment; pass --any_clip to keep them)")
            df = df[~drop]
    if "n_modules" in df:
        keep = df.n_modules == a.n_modules
        if not keep.all():
            print(f"[rel-pert] {df[~keep].run_id.nunique()} run(s) adapting "
                  f"{sorted(set(df[~keep].n_modules))} modules set aside (--n_modules={a.n_modules})")
        df = df[keep]
    # AND a pairing check, which this script never had. mcnemar refuses when a seed appears twice;
    # here the same situation just doubled a median silently — `bottom` at 2e-3 showed nine runs for
    # five seeds and the median moved from 5,13 to 3,78, which would have contradicted the paper's
    # own figure.
    for (mo, rk, lr), g in df.groupby(["mode", "rank", "lr"]):
        dup = g.groupby("seed").run_id.nunique()
        if (dup > 1).any():
            bad = dup[dup > 1].to_dict()
            print(f"[WARN] ({mo}, r={rk}, lr={lr}): seed(s) {bad} appear more than once. "
                  f"A median over them counts those seeds twice. Narrow the selection.")
    models = sorted(df.model.astype(str).unique())
    if len(models) > 1:
        print(f"[WARN] {len(models)} models in this file: {models}\n"
              f"       Their relative perturbations are NOT comparable. Pass --model to pick one.")
    # one version of the random arm at a time — the other one measures a different arm
    if "subspace_salted" in df:
        drop = (df["mode"] == "random") & (df["subspace_salted"] != a.salted)
        if drop.any():
            print(f"[rel-pert] {df[drop].run_id.nunique()} run(s) of the other random arm set aside "
                  f"(subspace_salted != {a.salted})")
            df = df[~drop]
    if a.select_lr:
        with open(expand_path(a.select_lr)) as f:
            table = (yaml.safe_load(f) or {}).get("selected", {})

        def _keep(r) -> bool:
            key = f"{r['model']}|{r['task']}|{r['mode']}|{int(float(r['rank']))}"
            return key not in table or float(r["lr"]) == float(table[key])

        before = df.run_id.nunique()
        df = df[[_keep(r) for _, r in df.iterrows()]]
        print(f"kept {df.run_id.nunique()}/{before} runs at each arm's selected learning rate\n")
    # modules whose band carries essentially no energy: the ratio there is a division by numerical
    # zero, not a measurement
    dropped_by_cell: dict = {}
    if "cond" in df and len(df):
        # Filter on CONDITIONING, not on band energy. What makes a band unusable is not that it holds
        # little energy — bottom bands legitimately do — but that its singular vectors are
        # ill-determined, which happens when sigma_min/sigma_max approaches machine precision.
        bad = df["cond"] < a.cond_tol
        if bad.any():
            by_mod = df.loc[bad].groupby("module_type").size().to_dict()
            print(f"[warn] {int(bad.sum())} (run, module) pairs dropped: the adapted band's smallest "
                  f"singular value is below {a.cond_tol:.0e} of the module's largest, so its singular "
                  f"vectors are ill-conditioned. Per module: {by_mod}\n")
            dropped_by_cell = (df.loc[bad].groupby(["task", "mode", "rank"]).size().to_dict())
            df = df[~bad]
    out = Path(expand_path(a.out)) if a.out else Path(expand_path(a.runs_dir)).parent / "relative_perturbation.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out, index=False)

    print(f"{len(df)} (run, module) pairs from {df.run_id.nunique()} runs\n")
    # MEDIAN, not mean: a single module with a near-null band drags the mean by four orders of
    # magnitude, which is a property of the denominator and not of the arm.
    agg = df.groupby(["task", "mode", "rank"]).agg(
        update_norm=("update_norm", "median"),
        band_energy=("band_energy", "median"),
        relative=("relative_perturbation", "median"),
        relative_q1=("relative_perturbation", lambda x: x.quantile(0.25)),
        relative_q3=("relative_perturbation", lambda x: x.quantile(0.75)),
        n_modules=("relative_perturbation", "size")).round(4)
    agg["n_dropped"] = [dropped_by_cell.get(ix, 0) for ix in agg.index]
    print("ABSOLUTE norm vs RELATIVE perturbation, MEDIANS (the two point in opposite directions)")
    print(agg)
    print("\nby module type, relative perturbation (median):")
    piv = df.pivot_table(index="module_type", columns="mode", values="relative_perturbation",
                         aggfunc="median")
    print(piv.round(3))
    # A module whose median is orders of magnitude above the others has not been filtered properly;
    # say so rather than let it silently dominate the aggregate.
    if len(piv) > 2:
        worst = piv.max(axis=1)
        typical = float(worst.median())
        outliers = sorted(worst[worst > 50 * typical].index)
        if outliers:
            print(f"\n[warn] {', '.join(outliers)} sit more than 50x above the typical module: the "
                  f"aggregate above is meaningless while they are in. Re-run with a larger --cond_tol.")
            keep = df[~df.module_type.isin(outliers)]
            print(f"\nSAME TABLE WITHOUT {', '.join(outliers)} ({keep.module_type.nunique()} "
                  f"well-conditioned modules) — this is the number to report:")
            print(keep.groupby(["task", "mode", "rank"]).agg(
                update_norm=("update_norm", "median"),
                relative=("relative_perturbation", "median"),
                relative_q1=("relative_perturbation", lambda x: x.quantile(0.25)),
                relative_q3=("relative_perturbation", lambda x: x.quantile(0.75)),
                n_modules=("relative_perturbation", "size")).round(4).to_string())
    print(f"\nwritten to {out}")


if __name__ == "__main__":
    main()
