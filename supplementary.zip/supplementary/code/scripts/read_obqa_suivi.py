"""Reading of the follow-up (second addendum of PROTOCOL_obqa_unfrozen.md): tests (1)-(3) on the single-PARTITION evaluations. No PARTITION.

    python scripts/read_obqa_suivi.py

Source: ~/lora-analysis/obqa_single_gpu.csv (scripts/eval_single_gpu.py). Same thresholds as the protocol: U against 0.7 G with
the interval rule (G fixed: 8.04, 12.36), unfrozen(r=2) - frozen(r=2) at t > 3.495, the interaction at t > 2.776.
Also reported: the retrained references against the original ones (in the training process), and the single-PARTITION evaluation
against the recorded one, run by run.
"""
import csv
import glob
import json
import os
import statistics as st

import yaml

S = [2, 3, 4, 5, 6]
G = {"top": 8.04, "bottom": 12.36}
T95, T90 = 2.776, 2.132
PATH = os.path.expanduser("~/lora-analysis/obqa_single_gpu.csv")
if not os.path.exists(PATH):
    raise SystemExit(f"  pas encore de resultats ({PATH}) : la reevaluation n'est pas terminee (squeue -u $USER)")
rows = list(csv.DictReader(open(PATH)))
gpus = {r["PARTITION"] for r in rows}
print(f"  {len(rows)} evaluations ; modele(s) de carte : {sorted(gpus)} ; noeud(s) : {sorted({r['node'] for r in rows})}")
if len(gpus) != 1 or len(rows) != 30:
    raise SystemExit("  ARRET : il faut 30 evaluations sur un seul modele de carte")
C, R = {}, {}
for r in rows:
    k = (r["mode"], int(r["rank"])); C.setdefault(k, {})[int(r["seed"])] = float(r["mcq_acc_single"]); R.setdefault(k, {})[int(r["seed"])] = float(r["mcq_acc_recorded"])


def stats(d):
    x = [d[s] * 100 for s in S]; m = st.mean(x); se = st.stdev(x) / 5 ** 0.5
    return m, m - T95 * se, m + T95 * se, m - T90 * se, m + T90 * se, (m / se if se > 0 else float("inf"))


print("\n  --- les tests, evalues sur une seule carte ---")
for arm in ("top", "bottom"):
    fr, u1, u2 = C[(arm, 2)], C[(f"{arm}_unfrozen", 1)], C[(f"{arm}_unfrozen", 2)]
    U, lo, hi, _, _, _ = stats({s: u1[s] - fr[s] for s in S}); g = G[arm]
    v = ("le gel explique l'essentiel" if lo >= 0.7 * g else "partage (chevauche 0,7 G)") if U >= 0.7 * g else \
        (("l'essentiel vient d'ailleurs" if hi <= 0.3 * g else "partage (chevauche 0,3 G)") if U <= 0.3 * g else "partage, sans attribution")
    print(f"  {arm:6s} (1) U = {U:+.2f}, IC95 [{lo:+.2f}, {hi:+.2f}] ; 0,7 G = {0.7 * g:.2f} -> {v}")
    D, lo, hi, _, _, t = stats({s: u2[s] - fr[s] for s in S})
    print(f"  {arm:6s} (2) gel seul, r=2 : {D:+.2f}, IC95 [{lo:+.2f}, {hi:+.2f}], t = {t:+.2f} -> " + ("ETABLI" if abs(t) > 3.495 else "non etabli"))
tf, bf, tu, bu = C[("top", 2)], C[("bottom", 2)], C[("top_unfrozen", 2)], C[("bottom_unfrozen", 2)]
mF, mU = stats({s: bf[s] - tf[s] for s in S})[0], stats({s: bu[s] - tu[s] for s in S})[0]
m, lo, hi, _, _, t = stats({s: (bu[s] - tu[s]) - (bf[s] - tf[s]) for s in S})
print(f"  (3) bottom - top : {mF:+.2f} geles, {mU:+.2f} degeles ; difference = {m:+.2f}, IC95 [{lo:+.2f}, {hi:+.2f}], t = {t:+.2f} -> "
      + ("ETABLI" if abs(t) > 2.776 else "non etabli") + "   (campagne principale : +3,84, t = 4,12, ETABLI)")

print("\n  --- les references reentrainees contre les references d'origine (dans le processus d'entrainement) ---")
orig = {}
for p in glob.glob(os.path.expanduser("~/lora-runs/*/config.yaml")):
    c = yaml.safe_load(open(p)) or {}
    if c.get("task") == "commonsense" and str(c.get("data_fingerprint")) == "dc05f4d847f9" and c.get("rank") == 2 and c.get("seed") in S \
            and ((c.get("mode") == "top" and abs(float(c.get("lr")) - 5e-3) < 1e-12) or (c.get("mode") == "bottom" and abs(float(c.get("lr")) - 2e-3) < 1e-12)):
        try:
            orig.setdefault(c["mode"], {}).setdefault(c["seed"], []).append(json.load(open(os.path.dirname(p) + "/metrics.json"))["mcq_acc"])
        except (OSError, KeyError):
            pass
for arm in ("top", "bottom"):
    o = {s: st.mean(v) for s, v in orig.get(arm, {}).items()}
    if len(o) == 5:
        d = [(R[(arm, 2)][s] - o[s]) * 100 for s in S]
        print(f"  {arm:6s} reentraine - origine : moyenne {st.mean(d):+.2f} pt, par graine " + " ".join(f"{x:+.1f}" for x in d))
    else:
        print(f"  {arm:6s} : origine incomplete ({len(o)} graines)")
print("\n  --- carte unique contre evaluation enregistree, run par run (points) ---")
for k in sorted(C):
    print(f"  {k[0]:16s} r={k[1]} : " + " ".join(f"{(C[k][s] - R[k][s]) * 100:+.1f}" for s in S))
