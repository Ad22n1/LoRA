"""Moteur des trois experiences de la v2 (PROTOCOL_budget_r3r4.md, PROTOCOL_rank_trend_obqa.md, PROTOCOL_7b_rank16.md). OpenBookQA.

    python scripts/v2camp.py <campagne> <etape>
campagnes : budget15, budget7 (le budget, Qwen2.5-1.5B et 7B) ; trend (rangs 4 et 8, 1.5B) ; r16_7b (rang 16, 7B)
(le protocole de l'entrainement long sur OpenBookQA a ete retire avant tout commit : 49 pas y font deja 5,4 epoques)
etapes    : check   references et bases (au deploiement) ; refs : grilles de reentrainement des references si elles ne sont pas sur une carte
            probe   la sonde memoire (r16_7b) ; probe_read : son verdict
            s1      grilles de selection (graines 0-1)
            sel     selection ; cran de prolongement si l'optimum est au bord ; sinon grilles du rapport (s2, ou s2a : geles et libre)
            G       (trend, r16_7b) G = libre - gele, committe, puis grilles de la seconde vague (s2b : degeles et A gele)
            read    la lecture
La derniere ligne « LANCER: <prefixe> » dit au lanceur quelles grilles soumettre.
"""
import csv
import glob
import json
import math
import os
import random
import statistics as st
import sys
from pathlib import Path

import yaml

Q, Q7 = "Qwen/Qwen2.5-1.5B", "Qwen/Qwen2.5-7B"
SEL, REP = [0, 1], [2, 3, 4, 5, 6]
T4, BONF2, FLOOR = 2.776, 3.495, 2.0
ADA = "RTX 4000 Ada"
CAMPS = {
    "budget15": dict(kind="budget", model=Q, ref=("dual_top", 2, 5e-3), rates=[5e-4, 1e-3, 2e-3, 5e-3, 1e-2, 2e-2], nodes="ada", protocol="PROTOCOL_budget_r3r4.md",
                     arms=[("top", 3), ("bottom", 3), ("top", 4), ("bottom", 4)],
                     refs={"top": ("dual_top", 2, 5e-3, 0.5308), "bottom": ("dual_bottom", 2, 1e-2, 0.5248)},
                     budget={"A2": 46080, "B3": 54528, "B4": 72704}),
    "budget7": dict(kind="budget", model=Q7, ref=("dual_top", 2, 2e-3), rates=[2e-4, 5e-4, 1e-3, 2e-3, 5e-3, 1e-2], nodes="7b", protocol="PROTOCOL_budget_r3r4.md",
                    arms=[("top", 3), ("bottom", 3), ("top", 4), ("bottom", 4)],
                    refs={"top": ("dual_top", 2, 2e-3, 0.6364), "bottom": ("dual_bottom", 2, 2e-3, 0.6148)},
                    budget={"A2": 99328, "B3": 121344, "B4": 161792}),
    "trend": dict(kind="iso", model=Q, ref=("dual_top", 2, 5e-3), rates=[5e-4, 1e-3, 2e-3, 5e-3, 1e-2], nodes="ada", protocol="PROTOCOL_rank_trend_obqa.md",
                  ranks={4: 2, 8: 4}, shared={("top", 4): "budget15", ("bottom", 4): "budget15"}, known={2: {"G": (8.04, 12.36), "AB": (6.56, 10.28)}, 16: {"G": (2.08, 6.32), "AB": (1.36, 3.80)}}),
    "p2": dict(kind="p2", model=Q, ref=("free", 1, 2e-3), rates=[1e-3, 2e-3, 5e-3, 1e-2, 2e-2], nodes="ada", protocol="ANALYSE_writes_additif.md",
               arms_iso=[("learned", 2)], basis="~/repo/bases/learned_obqa_r2_s0.safetensors", G=8.04, dir_seed=0, dir_lr=2e-3, dir_step=49,
               label="OpenBookQA, Qwen2.5-1.5B, direction de la graine 0",
               refs={"top": ("top", 2, 5e-3, 0.4652), "bottom": ("bottom", 2, 2e-3, 0.4220), "random_ortho": ("random_ortho", 2, 2e-2, 0.4592),
                     "free": ("free", 1, 2e-3, 0.5456)}),
    "p2a": dict(kind="p2", model=Q, ref=("free", 1, 2e-3), rates=[1e-3, 2e-3, 5e-3, 1e-2, 2e-2], nodes="ada", protocol="PROTOCOL_p2_replication.md",
                arms_iso=[("learned", 2)], basis="~/repo/bases/learned_obqa_r2_s7.safetensors", G=8.04, dir_seed=7, dir_lr=2e-3, dir_step=49,
                label="replique A : OpenBookQA, Qwen2.5-1.5B, direction de la graine 7",
                refs={"top": ("top", 2, 5e-3, 0.4652), "bottom": ("bottom", 2, 2e-3, 0.4220), "random_ortho": ("random_ortho", 2, 2e-2, 0.4592),
                     "free": ("free", 1, 2e-3, 0.5456)}),
    "p2b": dict(kind="p2", model="fmt:meta-llama/Llama-3.2-1B", ref=("free", 1, 1e-3), rates=[1e-3, 2e-3, 5e-3, 1e-2, 2e-2], nodes="ada",
                protocol="PROTOCOL_p2_replication.md", arms_iso=[("learned", 2)], basis="~/repo/bases/learned_format_llama_r2_s0.safetensors",
                G=12.41, dir_seed=0, dir_lr=2e-3, dir_step=274, key="format_parsed", val_key="val_format_parsed",
                label="replique B : tache de format, Llama-3.2-1B, direction de la graine 0",
                refs={"top": ("top", 2, 1e-2, 0.6443), "bottom": ("bottom", 2, 5e-3, 0.5922), "random_ortho": ("random_ortho", 2, 1e-2, 0.6534),
                      "free": ("free", 1, 1e-3, 0.7684)}),
    "g2a": dict(kind="p2", source="grad", model=Q, ref=("free", 1, 2e-3), rates=[1e-3, 2e-3, 5e-3, 1e-2, 2e-2], nodes="ada",
                protocol="PROTOCOL_grad.md", arms_iso=[("learned", 2)], basis="~/repo/bases/learned_grad_obqa_r2.safetensors", G=8.04,
                label="grad : OpenBookQA, Qwen2.5-1.5B, directions du gradient", learned_ref="p2", refs={"top": ("top", 2, 5e-3, 0.4652), "bottom": ("bottom", 2, 2e-3, 0.4220), "random_ortho": ("random_ortho", 2, 2e-2, 0.4592),
                     "free": ("free", 1, 2e-3, 0.5456)}),
    "g2b": dict(kind="p2", source="grad", model="fmt:meta-llama/Llama-3.2-1B", ref=("free", 1, 1e-3), rates=[1e-3, 2e-3, 5e-3, 1e-2, 2e-2],
                nodes="ada", protocol="PROTOCOL_grad.md", arms_iso=[("learned", 2)], basis="~/repo/bases/learned_grad_format_llama_r2.safetensors",
                G=12.41, key="format_parsed", val_key="val_format_parsed", label="grad : tache de format, Llama-3.2-1B, directions du gradient",
                learned_ref="p2b", refs={"top": ("top", 2, 1e-2, 0.6443), "bottom": ("bottom", 2, 5e-3, 0.5922), "random_ortho": ("random_ortho", 2, 1e-2, 0.6534),
                     "free": ("free", 1, 1e-3, 0.7684)}),
    "g3a256": dict(kind="p2", source="grad", model=Q, ref=("free", 1, 2e-3), rates=[5e-4, 1e-3, 2e-3, 5e-3, 1e-2], nodes="ada", protocol="PROTOCOL_grad_acc.md",
                arms_iso=[("learned", 2)], basis="~/repo/bases/learned_grad256_obqa_r2.safetensors", G=8.04, n=256, arm_name="grad256", main=False,
                ref_published=True, label="grad256 : OpenBookQA, Qwen2.5-1.5B, gradient accumule", learned_ref="p2", refs={"top": ("top", 2, 5e-3, 0.4652), "bottom": ("bottom", 2, 2e-3, 0.4220), "random_ortho": ("random_ortho", 2, 2e-2, 0.4592), "free": ("free", 1, 2e-3, 0.5456)}),
    "g3aall": dict(kind="p2", source="grad", model=Q, ref=("free", 1, 2e-3), rates=[5e-4, 1e-3, 2e-3, 5e-3, 1e-2], nodes="ada", protocol="PROTOCOL_grad_acc.md",
                arms_iso=[("learned", 2)], basis="~/repo/bases/learned_gradall_obqa_r2.safetensors", G=8.04, n='all', arm_name="gradall", main=True,
                ref_published=True, label="gradall : OpenBookQA, Qwen2.5-1.5B, gradient accumule", learned_ref="p2", refs={"top": ("top", 2, 5e-3, 0.4652), "bottom": ("bottom", 2, 2e-3, 0.4220), "random_ortho": ("random_ortho", 2, 2e-2, 0.4592), "free": ("free", 1, 2e-3, 0.5456)}),
    "g3b256": dict(kind="p2", source="grad", model="fmt:meta-llama/Llama-3.2-1B", ref=("free", 1, 1e-3), rates=[5e-4, 1e-3, 2e-3, 5e-3, 1e-2], nodes="ada",
                protocol="PROTOCOL_grad_acc.md", arms_iso=[("learned", 2)], basis="~/repo/bases/learned_grad256_format_llama_r2.safetensors", G=12.41,
                key="format_parsed", val_key="val_format_parsed", n=256, arm_name="grad256", main=False, ref_published=True,
                label="grad256 : tache de format, Llama-3.2-1B, gradient accumule", learned_ref="p2b", refs={"top": ("top", 2, 1e-2, 0.6443), "bottom": ("bottom", 2, 5e-3, 0.5922), "random_ortho": ("random_ortho", 2, 1e-2, 0.6534), "free": ("free", 1, 1e-3, 0.7684)}),
    "g3b1024": dict(kind="p2", source="grad", model="fmt:meta-llama/Llama-3.2-1B", ref=("free", 1, 1e-3), rates=[5e-4, 1e-3, 2e-3, 5e-3, 1e-2], nodes="ada",
                protocol="PROTOCOL_grad_acc.md", arms_iso=[("learned", 2)], basis="~/repo/bases/learned_grad1024_format_llama_r2.safetensors", G=12.41,
                key="format_parsed", val_key="val_format_parsed", n=1024, arm_name="grad1024", main=False, ref_published=True,
                label="grad1024 : tache de format, Llama-3.2-1B, gradient accumule", learned_ref="p2b", refs={"top": ("top", 2, 1e-2, 0.6443), "bottom": ("bottom", 2, 5e-3, 0.5922), "random_ortho": ("random_ortho", 2, 1e-2, 0.6534), "free": ("free", 1, 1e-3, 0.7684)}),
    "g3ball": dict(kind="p2", source="grad", model="fmt:meta-llama/Llama-3.2-1B", ref=("free", 1, 1e-3), rates=[5e-4, 1e-3, 2e-3, 5e-3, 1e-2], nodes="ada",
                protocol="PROTOCOL_grad_acc.md", arms_iso=[("learned", 2)], basis="~/repo/bases/learned_gradall_format_llama_r2.safetensors", G=12.41,
                key="format_parsed", val_key="val_format_parsed", n='all', arm_name="gradall", main=True, ref_published=True,
                label="gradall : tache de format, Llama-3.2-1B, gradient accumule", learned_ref="p2b", refs={"top": ("top", 2, 1e-2, 0.6443), "bottom": ("bottom", 2, 5e-3, 0.5922), "random_ortho": ("random_ortho", 2, 1e-2, 0.6534), "free": ("free", 1, 1e-3, 0.7684)}),
    "w2ad": dict(kind="warmdir", model=Q, ref=("free", 1, 2e-3), nodes="ada", protocol="PROTOCOL_warm.md", dir_seed=0, dir_lr=2e-3, total=49,
                 warm={5: 3, 10: 5, 25: 13}, arms={5: "w2a5", 10: "w2a10", 25: "w2a25"}, pair="obqa", phase2="~/repo/bases/learned_obqa_r2_s0.safetensors"),
    "w2bd": dict(kind="warmdir", model="fmt:meta-llama/Llama-3.2-1B", ref=("free", 1, 1e-3), nodes="ada", protocol="PROTOCOL_warm.md", dir_seed=0, dir_lr=2e-3,
                 total=274, warm={5: 14, 10: 28, 25: 69}, arms={5: "w2b5", 10: "w2b10", 25: "w2b25"}, pair="format_llama",
                 phase2="~/repo/bases/learned_format_llama_r2_s0.safetensors"),
    "w2a5": dict(kind="p2", source="warm", model=Q, ref=("free", 1, 2e-3), rates=[5e-4, 1e-3, 2e-3, 5e-3, 1e-2], nodes="ada", protocol="PROTOCOL_warm.md",
                  arms_iso=[("learned", 2)], basis="~/repo/bases/learned_warm5_obqa_r2.safetensors", G=8.04, max_steps=46, arm_name="warm5",
                  main=False, ref_published=True, verdicts=("un prechauffage court suffit a placer B", "un prechauffage court ne suffit pas"), label="warm5 : OpenBookQA, Qwen2.5-1.5B, B place apres 3 pas sur 49",
                  learned_ref="p2", refs={"top": ("top", 2, 5e-3, 0.4652), "bottom": ("bottom", 2, 2e-3, 0.4220), "random_ortho": ("random_ortho", 2, 2e-2, 0.4592), "free": ("free", 1, 2e-3, 0.5456)}),
    "w2a10": dict(kind="p2", source="warm", model=Q, ref=("free", 1, 2e-3), rates=[5e-4, 1e-3, 2e-3, 5e-3, 1e-2], nodes="ada", protocol="PROTOCOL_warm.md",
                  arms_iso=[("learned", 2)], basis="~/repo/bases/learned_warm10_obqa_r2.safetensors", G=8.04, max_steps=44, arm_name="warm10",
                  main=True, ref_published=True, verdicts=("un prechauffage court suffit a placer B", "un prechauffage court ne suffit pas"), label="warm10 : OpenBookQA, Qwen2.5-1.5B, B place apres 5 pas sur 49",
                  learned_ref="p2", refs={"top": ("top", 2, 5e-3, 0.4652), "bottom": ("bottom", 2, 2e-3, 0.4220), "random_ortho": ("random_ortho", 2, 2e-2, 0.4592), "free": ("free", 1, 2e-3, 0.5456)}),
    "w2a25": dict(kind="p2", source="warm", model=Q, ref=("free", 1, 2e-3), rates=[5e-4, 1e-3, 2e-3, 5e-3, 1e-2], nodes="ada", protocol="PROTOCOL_warm.md",
                  arms_iso=[("learned", 2)], basis="~/repo/bases/learned_warm25_obqa_r2.safetensors", G=8.04, max_steps=36, arm_name="warm25",
                  main=False, ref_published=True, verdicts=("un prechauffage court suffit a placer B", "un prechauffage court ne suffit pas"), label="warm25 : OpenBookQA, Qwen2.5-1.5B, B place apres 13 pas sur 49",
                  learned_ref="p2", refs={"top": ("top", 2, 5e-3, 0.4652), "bottom": ("bottom", 2, 2e-3, 0.4220), "random_ortho": ("random_ortho", 2, 2e-2, 0.4592), "free": ("free", 1, 2e-3, 0.5456)}),
    "w2b5": dict(kind="p2", source="warm", model="fmt:meta-llama/Llama-3.2-1B", ref=("free", 1, 1e-3), rates=[5e-4, 1e-3, 2e-3, 5e-3, 1e-2], nodes="ada",
                  protocol="PROTOCOL_warm.md", arms_iso=[("learned", 2)], basis="~/repo/bases/learned_warm5_format_llama_r2.safetensors", G=12.41,
                  key="format_parsed", val_key="val_format_parsed", max_steps=260, arm_name="warm5", main=False, ref_published=True, verdicts=("un prechauffage court suffit a placer B", "un prechauffage court ne suffit pas"),
                  label="warm5 : tache de format, Llama-3.2-1B, B place apres 14 pas sur 274", learned_ref="p2b", refs={"top": ("top", 2, 1e-2, 0.6443), "bottom": ("bottom", 2, 5e-3, 0.5922), "random_ortho": ("random_ortho", 2, 1e-2, 0.6534), "free": ("free", 1, 1e-3, 0.7684)}),
    "w2b10": dict(kind="p2", source="warm", model="fmt:meta-llama/Llama-3.2-1B", ref=("free", 1, 1e-3), rates=[5e-4, 1e-3, 2e-3, 5e-3, 1e-2], nodes="ada",
                  protocol="PROTOCOL_warm.md", arms_iso=[("learned", 2)], basis="~/repo/bases/learned_warm10_format_llama_r2.safetensors", G=12.41,
                  key="format_parsed", val_key="val_format_parsed", max_steps=246, arm_name="warm10", main=True, ref_published=True, verdicts=("un prechauffage court suffit a placer B", "un prechauffage court ne suffit pas"),
                  label="warm10 : tache de format, Llama-3.2-1B, B place apres 28 pas sur 274", learned_ref="p2b", refs={"top": ("top", 2, 1e-2, 0.6443), "bottom": ("bottom", 2, 5e-3, 0.5922), "random_ortho": ("random_ortho", 2, 1e-2, 0.6534), "free": ("free", 1, 1e-3, 0.7684)}),
    "w2b25": dict(kind="p2", source="warm", model="fmt:meta-llama/Llama-3.2-1B", ref=("free", 1, 1e-3), rates=[5e-4, 1e-3, 2e-3, 5e-3, 1e-2], nodes="ada",
                  protocol="PROTOCOL_warm.md", arms_iso=[("learned", 2)], basis="~/repo/bases/learned_warm25_format_llama_r2.safetensors", G=12.41,
                  key="format_parsed", val_key="val_format_parsed", max_steps=205, arm_name="warm25", main=False, ref_published=True, verdicts=("un prechauffage court suffit a placer B", "un prechauffage court ne suffit pas"),
                  label="warm25 : tache de format, Llama-3.2-1B, B place apres 69 pas sur 274", learned_ref="p2b", refs={"top": ("top", 2, 1e-2, 0.6443), "bottom": ("bottom", 2, 5e-3, 0.5922), "random_ortho": ("random_ortho", 2, 1e-2, 0.6534), "free": ("free", 1, 1e-3, 0.7684)}),
    "ao": dict(kind="ao", model="aoq:Qwen/Qwen2.5-1.5B", pop_ref=Q, ref=("free", 1, 2e-3), rates=[5e-4, 1e-3, 2e-3, 5e-3, 1e-2], nodes="ada",
               protocol="PROTOCOL_answer_only.md", arms_iso=[("top", 2), ("bottom", 2), ("dual_top", 2), ("dual_bottom", 2), ("free", 1)],
               answer_only=True, max_steps=49, base=0.422, full={"G": (8.04, 12.36), "AB": (6.56, 10.28)}),
    "r16_7b": dict(kind="iso", model=Q7, ref=("dual_top", 2, 2e-3), rates=[1e-4, 2e-4, 5e-4, 1e-3, 2e-3], nodes="7b", protocol="PROTOCOL_7b_rank16.md",
                   ranks={16: 7}, probe=("top_unfrozen", 16, 2e-3), known={2: {"G": (9.68, 14.44), "AB": (10.48, 13.08)}}),
}
dd = lambda c: os.path.basename(str(c.get("data_dir") or "").rstrip("/"))  # noqa: E731


def clean(c):
    mods = c.get("target_modules")
    return ((mods is None or len(mods) == 7) and float(c.get("max_grad_norm", 1.0) or 0) == 1.0 and c.get("update_norm_target") in (None, "")
            and not c.get("token_weighted_loss"))


def is_pop(c, model):
    if str(model).startswith("fmt:"):
        tt = c.get("target_tokens"); tok = tt.get("format") if isinstance(tt, dict) else tt
        return c.get("task") == "format" and str(c.get("model")) == str(model)[4:] and tok == 600000 and not c.get("answer_only")
    if str(model).startswith("aoq:"):
        return (c.get("task") == "commonsense" and dd(c) == "openbookqa" and str(c.get("model")) == str(model)[4:] and bool(c.get("answer_only"))
                and str(c.get("data_fingerprint") or "") in ("", "None", "dc05f4d847f9"))
    return (c.get("task") == "commonsense" and dd(c) == "openbookqa" and str(c.get("model")) == model and not c.get("answer_only")
            and str(c.get("data_fingerprint") or "") in ("", "None", "dc05f4d847f9"))


def load_runs(root="~/lora-runs"):
    out = []
    for p in glob.glob(os.path.expanduser(root) + "/*/config.yaml"):
        d = os.path.dirname(p)
        try:
            if open(d + "/status").read().startswith("DONE"):
                out.append((yaml.safe_load(open(p)) or {}, json.load(open(d + "/metrics.json")), d))
        except (OSError, ValueError):
            pass
    return out


def gpu_of(d):
    try:
        return (next(csv.DictReader(open(d + "/results.csv"))).get("PARTITION") or "?").replace("NVIDIA ", "").replace(" Generation", "")
    except (OSError, StopIteration):
        return "?"


def since_of(k):
    """Date du deploiement de la campagne : l'heure du fichier de controle ecrit par le deploiement (v2_<campagne>_check.json)."""
    f = f"v2_{k}_check.json"
    return os.path.getmtime(f) if os.path.exists(f) else None


def cell(runs, model, mode, rank, lr, seeds, key, since=None, md5=None):
    """Une cellule : un run termine par graine. En cas de doublon (un run publie et un run de la campagne, de configurations voisines),
    on garde le seul lance apres le deploiement de la campagne (since) ; sinon la cellule reste incomplete."""
    by = {}
    for c, m, d in runs:
        if (is_pop(c, model) and clean(c) and c.get("mode") == mode and c.get("rank") == rank and abs(float(c.get("lr") or 0) - lr) < 1e-12
                and c.get("seed") in seeds and key in m and (md5 is None or c.get("learned_basis_md5") == md5)):
            by.setdefault(c["seed"], []).append((m[key], d))
    if since is not None:
        for sd, v in list(by.items()):
            if len(v) > 1:
                recent = [x for x in v if os.path.getmtime(x[1] + "/config.yaml") >= since]
                if len(recent) == 1:
                    by[sd] = recent
    ok = sorted(by) == list(seeds) and all(len(v) == 1 for v in by.values())
    return ({s: by[s][0][0] for s in seeds} if ok else None), ({s: by[s][0][1] for s in seeds} if ok else {}), by


def arms_of(C):
    if C["kind"] == "budget":
        return list(C["arms"])
    if "arms_iso" in C:
        return list(C["arms_iso"])
    out = []
    for r, rf in C["ranks"].items():
        for a in [("top", r), ("bottom", r), ("free", rf), ("top_unfrozen", rf), ("bottom_unfrozen", rf), ("top_unfrozen", r), ("bottom_unfrozen", r), ("dual_top", r), ("dual_bottom", r)]:
            if a not in out:
                out.append(a)
    return out


WAVE_A = ("top", "bottom", "free")


def own_arms(C):
    """Les bras que la campagne lance elle-meme : ceux qu'elle partage avec une autre (memes configurations, memes runs) en sont exclus."""
    return [a for a in arms_of(C) if a not in C.get("shared", {})]


def wait(msg):
    print(f"ATTENTE : {msg}"); sys.exit(4)
aid = lambda a: f"{a[0]}_r{a[1]}"  # noqa: E731


def base_of(C, runs, mode, rank, lr, seed=2):
    hits = [c for c, m, d in runs if is_pop(c, C.get("pop_ref", C["model"])) and clean(c) and c.get("mode") == mode and c.get("rank") == rank
            and abs(float(c.get("lr") or 0) - lr) < 1e-12 and c.get("seed") == seed]
    if len(hits) != 1:
        sys.exit(f"STOP : run de reference ({C['model']}, {mode} r={rank} a {lr:g}, graine {seed}) trouve {len(hits)} fois au node d'une")
    b = dict(hits[0])
    for k in ("mode", "lr", "seed", "rank", "alpha", "band_frac", "update_norm_target"):
        b.pop(k, None)
    if C.get("tokens"):
        b["target_tokens"] = C["tokens"]
    b["save_factor_steps"] = []    # facteurs NON sauvegardes : quota de 30 Go, 28 deja utilises (decision du 28/09, apres la relecture)
    return b


def grid_base(C, runs):
    b = base_of(C, runs, *C["ref"])
    if C.get("basis"):
        b["learned_basis"] = os.path.expanduser(C["basis"])
    if C.get("max_steps"):
        b["max_steps"] = C["max_steps"]
    if C.get("answer_only"):
        b["answer_only"] = True
    return b


def write_grid(name, base, mode, rank, lrs, seeds, note):
    b = dict(base); b.update(rank=rank, alpha=rank)
    Path(f"configs/grids/{name}.yaml").write_text(f"# PRE-ENREGISTRE (v2). {note}. Genere par scripts/v2camp.py.\n"
                                                  + yaml.safe_dump({"base": b, "grid": {"mode": [mode], "lr": lrs, "seed": seeds}}, sort_keys=False))


def step_rate(x, up):
    """Next rate on the 1-2-5 ladder."""
    e = math.floor(math.log10(x) + 1e-9); m = round(x / 10 ** e)
    lad = [1, 2, 5]; i = lad.index(m) if m in lad else 0
    if up:
        return (lad[i + 1] * 10 ** e) if i < 2 else 10 ** (e + 1)
    return (lad[i - 1] * 10 ** e) if i > 0 else 5 * 10 ** (e - 1)


def stage_check(k, C, runs):
    base_of(C, runs, *C["ref"]); print(f"  {k} : base reprise du run de reference {C['ref'][0]} r={C['ref'][1]} a {C['ref'][2]:g}, graine 2")
    need = []
    if C["kind"] == "budget":
        for band, (mode, r, lr, exp) in C["refs"].items():
            v, dirs, _ = cell(runs, C["model"], mode, r, lr, REP, "mcq_acc")
            if v is None:
                sys.exit(f"STOP : reference {mode} r={r} a {lr:g} incomplete")
            m = st.mean(v.values())
            if abs(m - exp) > 1e-4:
                sys.exit(f"STOP : reference {mode} r={r} a {lr:g} : {m:.4f} au node de {exp:.4f}")
            g = sorted({gpu_of(d) for d in dirs.values()}); ok = g == [ADA]
            print(f"  reference {mode} r={r} a {lr:g} : {m:.4f} (publie {exp:.4f}) ; cartes {g}" + ("" if ok else "  -> REENTRAINEE sur une carte"))
            if not ok:
                need.append((mode, r, lr))
    json.dump({"refs_a_reentrainer": [list(x) for x in need]}, open(f"v2_{k}_check.json", "w"))
    return need


def p2_check(k, C, runs):
    base_of(C, runs, *C["ref"]); need = []
    for X, (mode, r, lr, exp) in C["refs"].items():
        v, dirs, _ = cell(runs, C["model"], mode, r, lr, REP, C.get("key", "mcq_acc"))
        if v is None or abs(st.mean(v.values()) - exp) > 1e-4:
            sys.exit(f"STOP : reference {mode} r={r} a {lr:g} : " + ("incomplete" if v is None else f"{st.mean(v.values()):.4f} au node de {exp:.4f}"))
        g = sorted({gpu_of(d) for d in dirs.values()}); print(f"  reference {mode} r={r} a {lr:g} : {st.mean(v.values()):.4f} ; cartes {g}" + ("" if g == [ADA] else "  -> REENTRAINEE"))
        if g != [ADA]:
            need.append((mode, r, lr))
    json.dump({"refs_a_reentrainer": [list(x) for x in need]}, open(f"v2_{k}_check.json", "w"))


def p2_dir(k, C, runs):
    b = base_of(C, runs, *C["ref"]); b["out_dir"] = os.path.expanduser("~/lora-runs-p2"); b["save_factor_steps"] = [C["dir_step"]]
    write_grid(f"v2_{k}_dir_free_r2", b, "free", 2, [C["dir_lr"]], [C["dir_seed"]], f"run de direction ({C['label']} ; LoRA libre r=2, facteurs au dernier pas)")
    print(f"  run de direction : LoRA libre r=2, graine {C['dir_seed']}, {C['dir_lr']:g}, facteurs sauvegardes au pas {C['dir_step']}, dans ~/lora-runs-p2")
    for mode, r, lr in json.load(open(f"v2_{k}_check.json"))["refs_a_reentrainer"]:
        rb = base_of(C, runs, mode, r, lr); rb["out_dir"] = os.path.expanduser("~/lora-runs-v2refs")
        write_grid(f"v2_{k}_dir_refs_{mode}_r{r}", rb, mode, r, [lr], REP, f"reference {mode} r={r} reentrainee sur une carte")
        print(f"  reference {mode} r={r} a {lr:g} reentrainee, graines 2-6")
    print("LANCER: dir")


def p2_basis(k, C, runs):
    import hashlib
    import torch
    from safetensors.torch import load_file, save_file
    cand = [(c, d) for c, m, d in load_runs("~/lora-runs-p2") if is_pop(c, C["model"]) and c.get("mode") == "free" and c.get("rank") == 2
            and c.get("seed") == C["dir_seed"] and abs(float(c.get("lr") or 0) - C["dir_lr"]) < 1e-12 and glob.glob(d + "/factors_*.safetensors")]
    if len(cand) != 1:
        sys.exit(f"STOP : run de direction incomplet (termine avec ses facteurs : {len(cand)} au node d'un)")   # « incomplet » : le pilote le reprend ou le relance
    c, d = cand[0]; f = sorted(glob.glob(d + "/factors_*.safetensors"), key=lambda x: int(x.rsplit("_", 1)[1].split(".")[0]))[-1]
    fac = load_file(f); bases = {}; worst = 1.0
    for key in sorted(x for x in fac if x.endswith(".B")):
        Bm = fac[key].float()
        if Bm.shape[1] != 2:
            sys.exit(f"STOP : {key} a {Bm.shape[1]} colonnes au node de 2")
        Qm, R = torch.linalg.qr(Bm); dg = R.diagonal().abs()
        worst = min(worst, float(dg.min() / dg.max()))
        if float(dg.min()) <= 1e-6 * float(dg.max()):
            sys.exit(f"STOP : le B appris de {key[:-2]} est de rang < 2 ; pas de base")
        bases[key[:-2]] = Qm.contiguous()
    out = os.path.expanduser(C["basis"]); os.makedirs(os.path.dirname(out), exist_ok=True); save_file(bases, out)
    md5 = hashlib.md5(open(out, "rb").read()).hexdigest()
    json.dump({"source": os.path.basename(d), "facteurs": os.path.basename(f), "modules": len(bases), "md5": md5, "pire_rapport_R": worst},
              open(f"v2_{k}_basis.json", "w"), indent=1)
    print(f"  bases apprises : {len(bases)} modules, depuis {os.path.basename(d)}/{os.path.basename(f)} ; pire |R22|/|R11| = {worst:.3f} ; md5 {md5}")
    print("LANCER: rien")


def _grad_submit(k, C, runs):
    """Soumet le job du gradient : le preambule d'environnement d'un script du lanceur (lu tel quel), puis scripts/grad_bases.py."""
    import subprocess
    jd = os.path.expanduser(f"~/lora-grid/v2_{k}_gdir"); os.makedirs(jd, exist_ok=True)
    tpl = sorted(glob.glob(os.path.expanduser("~/lora-grid/v2_*/slurm_array.sh")), key=os.path.getmtime)
    if not tpl:
        sys.exit("STOP : aucun script du lanceur a reprendre (~/lora-grid/v2_*/slurm_array.sh)")
    lines = open(tpl[-1]).read().splitlines(); body = []
    for ln in lines:
        if ln.startswith("CFG=$(sed"):
            break
        if ln.startswith("#SBATCH --array") or ln.startswith("#SBATCH --output"):
            continue
        body.append(ln.replace('-lt 6000 ]', '-lt 14000 ]'))       # le gradient demande ~12 Go : on exige 14 Go libres
    if not any("-lt 14000 ]" in ln for ln in body) or not any(ln.startswith('PY="$VENV/bin/python"') for ln in body):
        sys.exit("STOP : le script du lanceur n'a pas la forme attendue ; le job du gradient n'est pas soumis")
    cfg = dict(base_of(C, runs, *C["ref"])); cfg.update(mode="free", rank=1, alpha=1, lr=C["ref"][2], seed=2)
    yaml.safe_dump(cfg, open(jd + "/config.yaml", "w"))
    out = os.path.expanduser(C["basis"])
    body += [f'"$PY" scripts/grad_bases.py --config "{jd}/config.yaml" --out "{out}" --n {C.get("n", 64)} --seed 1000 --rank {C.get("grad_rank", 2)}']
    open(jd + "/job.sh", "w").write("\n".join(body) + "\n"); os.chmod(jd + "/job.sh", 0o755)
    excl = subprocess.run([sys.executable, "scripts/nodes_for_gpu.py", "RTX 4000 Ada"], capture_output=True, text=True).stdout.strip().splitlines()
    excl = excl[-1] if excl else ""
    if not excl or excl.startswith("STOP"):
        sys.exit("STOP : epinglage sur RTX 4000 Ada impossible ; le job du gradient n'est pas soumis")
    import datetime
    now = datetime.datetime.now(); d8 = now.replace(hour=8, minute=0, second=0, microsecond=0)
    d8 = d8 if now < d8 else d8 + datetime.timedelta(days=1)
    r = subprocess.run(["sbatch", "--parsable", f"--deadline={d8:%Y-%m-%dT%H:%M:%S}", "--time=00:30:00", f"--exclude=node,{excl}",
                        f"--output={jd}/grad_%j.out", jd + "/job.sh"], capture_output=True, text=True)
    if r.returncode != 0:
        sys.exit(f"STOP : sbatch a refuse le job du gradient : {r.stderr.strip()[:200]}")
    print(f"  job du gradient soumis : {r.stdout.strip()} ({C.get('n', 64)} sequences, graine 1000, rang {C.get('grad_rank', 2)}) -> {out}")


def g2_gdir(k, C, runs):
    for f in glob.glob(os.path.expanduser(f"~/lora-grid/v2_{k}_gdir/essais")):
        os.remove(f)
    _grad_submit(k, C, runs)
    open(os.path.expanduser(f"~/lora-grid/v2_{k}_gdir/essais"), "w").write("1")
    need = json.load(open(f"v2_{k}_check.json"))["refs_a_reentrainer"]
    for mode, r, lr in need:                       # memes configurations que la replique : deja faites, donc reprises sans calcul
        rb = base_of(C, runs, mode, r, lr); rb["out_dir"] = os.path.expanduser("~/lora-runs-v2refs")
        write_grid(f"v2_{k}_gdir_refs_{mode}_r{r}", rb, mode, r, [lr], REP, f"reference {mode} r={r} reentrainee sur une carte")
    print("LANCER: gdir" if need else "LANCER: rien")


def g2_basis(k, C, runs):
    import hashlib
    import torch
    from safetensors.torch import load_file
    out = os.path.expanduser(C["basis"]); jd = os.path.expanduser(f"~/lora-grid/v2_{k}_gdir")
    if not (os.path.exists(out) and os.path.exists(out + ".json")):
        n = int(open(jd + "/essais").read()) if os.path.exists(jd + "/essais") else 1
        if n >= 3:
            sys.exit("STOP : job du gradient incomplet apres 3 essais (carte occupee ou echec) ; voir ~/lora-grid/v2_" + k + "_gdir/grad_*.out")
        _grad_submit(k, C, runs); open(jd + "/essais", "w").write(str(n + 1))
        wait(f"le job du gradient n'a pas produit ses bases (carte occupee ?) ; resoumis, essai {n + 1}/3")
    bases = load_file(out); side = json.load(open(out + ".json"))
    for name, Qm in bases.items():
        Qm = Qm.float()
        if Qm.shape[1] != 2 or float((Qm.T @ Qm - torch.eye(2)).abs().max()) > 1e-4:
            sys.exit(f"STOP : base du gradient de {name} invalide")
    md5 = hashlib.md5(open(out, "rb").read()).hexdigest()
    if md5 != side.get("md5"):
        sys.exit("STOP : l'empreinte du fichier de bases ne correspond pas a son rapport")
    json.dump({"source": "gradient", "modules": len(bases), "md5": md5, "sequences": side["sequences"], "graine": side["graine"],
               "tokens_supervises": side["tokens_supervises"], "concentration_2_premieres": side["part_du_gradient_dans_les_2_premieres_directions"]},
              open(f"v2_{k}_basis.json", "w"), indent=1)
    print(f"  bases du gradient : {len(bases)} modules ; {side['sequences']} sequences, {side['tokens_supervises']} tokens supervises ; "
          f"part mediane du gradient dans les 2 premieres directions {side['part_du_gradient_dans_les_2_premieres_directions']['mediane']:.3f} ; md5 {md5}")
    print("LANCER: rien")


def w_dir(k, C, runs):
    """Run de direction du prechauffage : LoRA libre r=2, graine 0, ordonnancement complet ; facteurs sauvegardes a k % des pas et a la fin."""
    b = base_of(C, runs, *C["ref"]); b["out_dir"] = os.path.expanduser("~/lora-runs-warm")
    b["save_factor_steps"] = sorted(set(C["warm"].values()) | {C["total"]})
    write_grid(f"v2_{k}_dir_free_r2", b, "free", 2, [C["dir_lr"]], [C["dir_seed"]], f"prechauffage : run de direction, facteurs aux pas {b['save_factor_steps']}")
    print(f"  run de direction : LoRA libre r=2, graine {C['dir_seed']}, {C['dir_lr']:g}, facteurs aux pas {b['save_factor_steps']} ({C['total']} pas en tout), dans ~/lora-runs-warm")
    print("LANCER: dir")


def w_basis(k, C, runs):
    """Les trois bases du prechauffage (QR de l'espace des colonnes de B apres k % des pas), une par bras ; controle de reproduction au dernier pas."""
    import hashlib
    import torch
    from safetensors.torch import load_file, save_file
    cand = [d for c, m, d in load_runs("~/lora-runs-warm") if is_pop(c, C["model"]) and c.get("mode") == "free" and c.get("rank") == 2
            and c.get("seed") == C["dir_seed"] and abs(float(c.get("lr") or 0) - C["dir_lr"]) < 1e-12]
    if len(cand) != 1:
        sys.exit(f"STOP : run de direction du prechauffage incomplet (trouve {len(cand)} fois au node d'une)")
    d = cand[0]

    def qr_bases(f):
        fac = load_file(f); out = {}
        for key in sorted(x for x in fac if x.endswith(".B")):
            Qm, R = torch.linalg.qr(fac[key].double()); dg = R.diagonal().abs()
            if float(dg.min()) <= 1e-6 * float(dg.max()):
                sys.exit(f"STOP : le B de {key[:-2]} ({os.path.basename(f)}) est de rang < 2")
            out[key[:-2]] = Qm.float().contiguous()
        return out
    for kk, step in sorted(C["warm"].items()):
        f = f"{d}/factors_{step}.safetensors"
        if not os.path.exists(f):
            sys.exit(f"STOP : run de direction incomplet (facteurs du pas {step} absents)")
        bases = qr_bases(f); arm = C["arms"][kk]; out = os.path.expanduser(CAMPS[arm]["basis"])
        os.makedirs(os.path.dirname(out), exist_ok=True); save_file(bases, out); raw = open(out, "rb").read()
        json.dump({"source": "prechauffage", "k": kk, "pas": step, "sur": C["total"], "run": os.path.basename(d), "modules": len(bases),
                   "md5": hashlib.md5(raw).hexdigest(), "sha256": hashlib.sha256(raw).hexdigest()}, open(f"v2_{arm}_basis.json", "w"), indent=1)
        print(f"  warm{kk} : bases apres {step} pas sur {C['total']}, {len(bases)} modules, md5 {hashlib.md5(raw).hexdigest()} -> {arm}")
    fin = f"{d}/factors_{C['total']}.safetensors"; p2 = os.path.expanduser(C["phase2"])
    if os.path.exists(fin) and os.path.exists(p2):
        a, b2 = qr_bases(fin), load_file(p2); ov = [float((a[n].T @ b2[n].float()).pow(2).sum() / 2) for n in a if n in b2]
        print(f"  controle : au dernier pas, recouvrement moyen avec les bases de la phase 2 (meme configuration) : mediane {st.median(ov):.3f} (1 = identiques)")
    print("LANCER: rien")


def w_wbasis(k, C, runs):
    if not (os.path.exists(f"v2_{k}_basis.json") and os.path.exists(os.path.expanduser(C["basis"]))):
        wait("les bases du prechauffage ne sont pas encore construites (run de direction en cours)")
    print(f"  bases presentes : md5 {json.load(open(f'v2_{k}_basis.json'))['md5']}"); print("LANCER: rien")


def ao_check(k, C, runs):
    base_of(C, runs, *C["ref"])
    json.dump({"answer_only": True, "max_steps": C["max_steps"]}, open(f"v2_{k}_check.json", "w"))
    print(f"  configuration de reference trouvee ; perte sur la reponse seule, {C['max_steps']} pas ; cinq bras : " + ", ".join(aid(a) for a in arms_of(C)))


def read_ao(k, C, runs):
    sel = json.load(open(f"v2_{k}_selection.json")); since = since_of(k); V, D = {}, {}
    for a in arms_of(C):
        v, dirs, _ = cell(runs, C["model"], a[0], a[1], sel[aid(a)], REP, "mcq_acc", since)
        if v is None:
            sys.exit(f"STOP : rapport de {aid(a)} incomplet")
        V[aid(a)], D[aid(a)] = v, dirs
    toks = []
    for dirs in D.values():
        for d in dirs.values():
            try:
                toks.append(int(list(csv.DictReader(open(d + "/log.csv")))[-1]["tokens_seen"]))
            except Exception:
                pass
    print(f"==================== {k} : perte sur la reponse seule (OpenBookQA, Qwen2.5-1.5B, r=2, {C['max_steps']} pas) ====================")
    print(f"  cartes {sorted({gpu_of(d) for dd_ in D.values() for d in dd_.values()})} ; tokens supervises par run : "
          + (f"mediane {st.median(toks):,.0f} (min {min(toks):,}, max {max(toks):,}) ; perte complete : ~602 112" if toks else "non lus"))
    for a in arms_of(C):
        print(f"  {aid(a):14s} a {sel[aid(a)]:<7g} : {st.mean(V[aid(a)].values()):.4f} ; - modele de base ({C['base']}) : {(st.mean(V[aid(a)].values()) - C['base']) * 100:+.2f}")
    est = {}
    for band, (A, B) in (("top", ("dual_top_r2", "top_r2")), ("bottom", ("dual_bottom_r2", "bottom_r2"))):
        m, lo, hi, t = _t([(V[A][s] - V[B][s]) * 100 for s in REP]); est[band] = m > 0 and t > BONF2
        print(f"  A gele - B gele ({band}) = {m:+.2f} [{lo:+.2f}, {hi:+.2f}], t = {t:+.2f} -> {'ETABLI' if est[band] else 'non etabli'} (seuil 3,495) ; "
              f"perte complete : {C['full']['AB'][0 if band == 'top' else 1]:+.2f}")
    v = ("l'asymetrie ne depend pas de la perte sur la question" if all(est.values())
         else "l'asymetrie depend au moins en partie de la perte sur la question")
    print(f"  LECTURE FIXEE : {v}")
    for band, B in (("top", "top_r2"), ("bottom", "bottom_r2")):
        m, lo, hi, t = _t([(V["free_r1"][s] - V[B][s]) * 100 for s in REP])
        print(f"  G ({band}) = libre r=1 - B gele = {m:+.2f} [{lo:+.2f}, {hi:+.2f}] (rapporte sans test) ; perte complete : {C['full']['G'][0 if band == 'top' else 1]:+.2f}")


def read_p2(k, C, runs):
    sel = json.load(open(f"v2_{k}_selection.json")); refruns = load_runs("~/lora-runs-v2refs"); G = C["G"]
    K_ = C.get("key", "mcq_acc")
    L, ld, _ = cell(runs, C["model"], "learned", 2, sel["learned_r2"], REP, K_, since_of(k), basis_md5(C))
    if L is None:
        sys.exit("STOP : rapport du bras learned incomplet")
    R, retr, Rpub = {}, [], {}
    for X, (mode, r, lr, exp) in C["refs"].items():
        v, dirs, _ = cell(runs, C["model"], mode, r, lr, REP, K_)
        Rpub[X] = v
        if sorted({gpu_of(d) for d in dirs.values()}) != [ADA]:
            v, dirs, _ = cell(refruns, C["model"], mode, r, lr, REP, K_)
            if v is None:
                sys.exit(f"STOP : reference {mode} reentrainee incomplete")
            retr.append(X)
        R[X] = v
    bj = json.load(open(f"v2_{k}_basis.json"))
    print(f"==================== {k} : B gele sur {'les directions du gradient' if C.get('source') == 'grad' else 'la direction apprise'}, r=2 ({C['label']}) ====================")
    print(f"  bases : {bj['modules']} modules, md5 {bj['md5']} ; {'grad' if C.get('source') == 'grad' else 'learned'} a {sel['learned_r2']:g} : {st.mean(L.values()):.4f} ; cartes {sorted({gpu_of(d) for d in ld.values()})}")
    TOP = Rpub["top"] if C.get("ref_published") else R["top"]   # gradient accumule : test contre le top PUBLIE (PROTOCOL_grad_acc.md)
    m, lo, hi, t = _t([(L[s] - TOP[s]) * 100 for s in REP])
    est = m > 0 and t > T4
    grad = C.get("source") == "grad"      # le protocole du gradient a ses propres formulations (PROTOCOL_grad.md)
    if C.get("verdicts"):                  # formulations propres au protocole de la campagne
        yes, no = C["verdicts"]
    elif C.get("arm_name"):                # gradient accumule : formulations de PROTOCOL_grad_acc.md
        yes, no = "le gradient accumule suffit a placer B", "le gradient accumule ne suffit pas"
    elif grad:
        yes, no = ("les directions du gradient suffisent a placer B ; l'essentiel du cout se recupere sans oracle",
                   "les directions du gradient ne suffisent pas ; le placement utile demande un entrainement")
    else:
        yes, no = "l'essentiel du cout du gel de B vient de l'endroit ou B est gele", "l'endroit compte peu : l'essentiel du cout vient du gel lui-meme"
    v = yes if lo >= 0.7 * G else (no if hi <= 0.3 * G else "non resolu")
    arm = C.get("arm_name") or ("grad" if grad else "learned")
    print(f"  {arm} - top = {m:+.2f} [{lo:+.2f}, {hi:+.2f}], t = {t:+.2f} -> test {'ETABLI' if est else 'non etabli'} (seuil 2,776)")
    print(f"  P = ({arm} - top) / G = {m / G:.2f} [{lo / G:.2f}, {hi / G:.2f}] ; G = {G} (fixe d'avance) ; seuils 0,7 G = {0.7 * G:.2f}, 0,3 G = {0.3 * G:.2f}")
    print(f"  LECTURE FIXEE : {v}" if C.get("main", True) else f"  (bras rapporte sans test : pas de lecture fixee ; la regle donnerait « {v} »)")
    if C.get("ref_published"):
        print(f"  (test contre le top PUBLIE, {st.mean(TOP.values()):.4f}" + (f" ; contre le top reentraine sur une carte, {st.mean(R['top'].values()):.4f} : "
              + "{:+.2f} [{:+.2f}, {:+.2f}], t = {:+.2f}".format(*_t([(L[s] - R['top'][s]) * 100 for s in REP])) if "top" in retr else "") + ")")
    G_re = (st.mean(R["free"].values()) - st.mean(R["top"].values())) * 100
    print(f"  G recalcule sur les references utilisees : {G_re:.2f} (G fixe d'avance, {G}, sert a la lecture) ; references reentrainees sur une carte : "
          + (", ".join(f"{X} ({st.mean(R[X].values()):.4f}, publie {C['refs'][X][3]:.4f})" for X in retr) if retr else "aucune"))
    if C.get("learned_ref"):
        lk = C["learned_ref"]; lsel = json.load(open(f"v2_{lk}_selection.json"))["learned_r2"]; lmd5 = json.load(open(f"v2_{lk}_basis.json"))["md5"]
        R["learned"], _, _ = cell(runs, C["model"], "learned", 2, lsel, REP, K_, None, lmd5)
        if R["learned"] is None:
            sys.exit(f"STOP : le bras learned de {lk} est introuvable par son empreinte")
    for X in ("bottom", "random_ortho", "free") + (("learned",) if C.get("learned_ref") else ()):
        m2, lo2, hi2, t2 = _t([(L[s] - R[X][s]) * 100 for s in REP])
        print(f"  {arm} - {X:12s} = {m2:+.2f} [{lo2:+.2f}, {hi2:+.2f}], t = {t2:+.2f} (rapporte sans test)")


def stage_refs(k, C, runs):
    need = json.load(open(f"v2_{k}_check.json"))["refs_a_reentrainer"]
    for mode, r, lr in need:
        b = base_of(C, runs, mode, r, lr); b["out_dir"] = os.path.expanduser("~/lora-runs-v2refs")
        write_grid(f"v2_{k}_refs_{mode}_r{r}", b, mode, r, [lr], REP, f"reference {mode} r={r} reentrainee a l'identique sur une carte")
        print(f"  v2_{k}_refs_{mode}_r{r} : {mode} r={r} a {lr:g}, graines 2-6, dans ~/lora-runs-v2refs")
    print("LANCER: refs" if need else "LANCER: rien")


def stage_probe(k, C, runs):
    mode, r, lr = C["probe"]
    write_grid(f"v2_{k}_probe_{mode}_r{r}", base_of(C, runs, *C["ref"]), mode, r, [lr], [0], "SONDE memoire : le bras le plus gourmand, au taux le plus haut")
    print(f"  sonde : {mode} r={r} a {lr:g}, graine 0 (c'est aussi un run de selection)"); print(f"LANCER: probe")


def stage_probe_read(k, C, runs):
    mode, r, lr = C["probe"]
    v, dirs, _ = cell(runs, C["model"], mode, r, lr, [0], "val_mcq_acc")
    if v is None:
        sys.exit("STOP : la sonde n'est pas terminee")
    d = dirs[0]; mem = max(float(x["gpu_mem_gb"]) for x in csv.DictReader(open(d + "/log.csv")))
    try:
        wall = float(next(csv.DictReader(open(d + "/results.csv"))).get("wallclock_s") or 0) / 60
    except (OSError, StopIteration):
        wall = float("inf")
    go = mem <= 18.5 and wall <= 45 and gpu_of(d) == ADA
    json.dump({"pic_memoire_go": mem, "duree_min": wall, "carte": gpu_of(d), "verdict": "GO" if go else "STOP"}, open(f"v2_{k}_probe.json", "w"))
    print(f"  sonde : pic memoire {mem:.2f} Go (regle <= 18,5), duree {wall:.1f} min (regle <= 45), carte {gpu_of(d)} -> " + ("GO" if go else "STOP : la campagne s'arrete, sans repli"))
    print("LANCER: rien")


def stage_s1(k, C, runs):
    if "probe" in C:
        pj = f"v2_{k}_probe.json"
        if not os.path.exists(pj) or json.load(open(pj)).get("verdict") != "GO":
            sys.exit("STOP : pas de verdict GO de la sonde ; la selection ne part pas")
    if C["kind"] == "p2" and not os.path.exists(os.path.expanduser(C["basis"])):
        sys.exit("STOP : les bases apprises n'existent pas encore (etape « basis »)")
    b = grid_base(C, runs); n = 0
    for mode, r in own_arms(C):
        write_grid(f"v2_{k}_s1_{mode}_r{r}", b, mode, r, C["rates"], SEL, f"SELECTION {mode} r={r}"); n += len(C["rates"]) * len(SEL)
    print(f"  {len(arms_of(C))} grilles de selection, {n} runs" + (" (la sonde, un de ces runs, est deja faite et sera reprise)" if "probe" in C else "")); print("LANCER: s1")


def basis_md5(C):
    k = C.get("_k"); f = f"v2_{k}_basis.json"
    return json.load(open(f))["md5"] if C.get("kind") == "p2" and os.path.exists(f) else None


def select_arm(C, runs, mode, r):
    T0 = since_of(C["_k"]); rates = list(C["rates"]); ext = []
    for up in (False, True):
        x = step_rate(rates[-1] if up else rates[0], up)
        if any(is_pop(c, C["model"]) and clean(c) and c.get("mode") == mode and c.get("rank") == r and abs(float(c.get("lr") or 0) - x) < 1e-12
               and c.get("seed") in SEL and (T0 is None or os.path.getmtime(d + "/config.yaml") >= T0) for c, m, d in runs):
            ext.append(x)
    cand = sorted(rates + ext); means = {}
    for lr in cand:
        v, _, by = cell(runs, C["model"], mode, r, lr, SEL, C.get("val_key", "val_mcq_acc"), T0, basis_md5(C) if mode == "learned" else None)
        if v is None:
            return None, f"{mode} r={r} a {lr:g} : selection incomplete ({sorted(by)})", None
        means[lr] = st.mean(v.values())
    best = max(cand, key=lambda lr: (means[lr], -lr))
    need = None
    if best == rates[0] and step_rate(rates[0], False) not in ext:
        need = step_rate(rates[0], False)
    elif best == rates[-1] and step_rate(rates[-1], True) not in ext:
        need = step_rate(rates[-1], True)
    txt = "  ".join(f"{lr:g}:{means[lr]:.3f}" for lr in cand) + f"  -> {best:g}" + ("  AU BORD" if best in (cand[0], cand[-1]) else "")
    return best, txt, need


def stage_sel(k, C, runs):
    b = grid_base(C, runs); chosen, exts = {}, []
    for (mode, r), other in C.get("shared", {}).items():
        f = f"v2_{other}_selection.json"
        if not os.path.exists(f):
            wait(f"{mode}_r{r} est partage avec {other}, dont la selection n'est pas encore faite")
        chosen[f"{mode}_r{r}"] = json.load(open(f))[f"{mode}_r{r}"]; print(f"  {mode}_r{r:<3d} : partage avec {other}, taux {chosen[f'{mode}_r{r}']:g}")
    for mode, r in own_arms(C):
        best, txt, need = select_arm(C, runs, mode, r)
        if best is None:
            sys.exit(f"STOP : {txt} ; rien n'est ecrit")
        print(f"  {mode}_r{r:<3d} : {txt}"); chosen[f"{mode}_r{r}"] = best
        if need is not None:
            write_grid(f"v2_{k}_ext_{mode}_r{r}", b, mode, r, [need], SEL, f"CRAN DE PROLONGEMENT {mode} r={r}"); exts.append(f"{mode}_r{r} -> {need:g}")
    if exts:
        print("  cran de prolongement necessaire : " + ", ".join(exts) + " ; relancer « sel » quand ces runs sont termines"); print("LANCER: ext"); return
    json.dump(chosen, open(f"v2_{k}_selection.json", "w"), indent=1)
    wave = "s2a" if C["kind"] == "iso" else "s2"
    for mode, r in own_arms(C):
        if C["kind"] == "iso" and mode not in WAVE_A:
            continue
        write_grid(f"v2_{k}_{wave}_{mode}_r{r}", b, mode, r, [chosen[f"{mode}_r{r}"]], REP, f"RAPPORT {mode} r={r} au taux retenu")
    print(f"  selection ecrite (v2_{k}_selection.json) ; grilles du rapport ({wave})"); print(f"LANCER: {wave}")


def stage_G(k, C, runs):
    sel = json.load(open(f"v2_{k}_selection.json")); G = {}; B = since_of(k)
    for r, rf in C["ranks"].items():
        fr, _, _ = cell(runs, C["model"], "free", rf, sel[f"free_r{rf}"], REP, "mcq_acc", B)
        for X in ("top", "bottom"):
            fz, _, _ = cell(runs, C["model"], X, r, sel[f"{X}_r{r}"], REP, "mcq_acc", B)
            if fz is None and (X, r) in C.get("shared", {}):
                wait(f"{X}_r{r} est partage avec {C['shared'][(X, r)]}, dont le rapport n'est pas encore termine")
            if fr is None or fz is None:
                sys.exit(f"STOP : premiere vague incomplete (rang {r}) ; G n'est pas calcule")
            G[f"{r}_{X}"] = {"G": (st.mean(fr.values()) - st.mean(fz.values())) * 100, "gele": fz, "libre": fr}
            print(f"  rang {r:2d}, {X:6s} : G = libre (r={rf}) - gele (r={r}) = {G[f'{r}_{X}']['G']:+.2f} points" + ("" if G[f"{r}_{X}"]["G"] >= FLOOR else "  (sous le plancher : test U non applicable)"))
    json.dump({kk: {"G": v["G"], "gele": {str(s): x for s, x in v["gele"].items()}, "libre": {str(s): x for s, x in v["libre"].items()}} for kk, v in G.items()},
              open(f"v2_{k}_G.json", "w"), indent=1)
    b = base_of(C, runs, *C["ref"])
    for mode, r in own_arms(C):
        if mode not in WAVE_A:
            write_grid(f"v2_{k}_s2b_{mode}_r{r}", b, mode, r, [sel[f"{mode}_r{r}"]], REP, f"RAPPORT, seconde vague, {mode} r={r}")
    print(f"  G committe (v2_{k}_G.json) avant la seconde vague"); print("LANCER: s2b")


def _t(d):
    m = st.mean(d); se = st.stdev(d) / len(d) ** 0.5
    return m, m - T4 * se, m + T4 * se, (m / se if se > 0 else float("inf"))


def _boot(f, seeds, n=10000):
    rng = random.Random(0); pts = sorted(f([rng.choice(seeds) for _ in seeds]) for _ in range(n))
    return f(list(seeds)), pts[int(0.025 * n)], pts[int(0.975 * n) - 1]


def read_budget(k, C, runs):
    sel = json.load(open(f"v2_{k}_selection.json")); refruns = load_runs("~/lora-runs-v2refs")
    print(f"==================== le budget, {C['model']} (OpenBookQA) : A gele (r=2) contre B gele (r=3, r=4) ====================")
    bu = C["budget"]; print(f"  budgets par couche : A gele r=2 {bu['A2']:,} ; B gele r=3 {bu['B3']:,} ({100 * (bu['B3'] / bu['A2'] - 1):+.1f} %) ; r=4 {bu['B4']:,} ({100 * (bu['B4'] / bu['A2'] - 1):+.1f} %)")
    verdict = {}
    for X in ("top", "bottom"):
        mode, r, lr, exp = C["refs"][X]
        A2, dirs, _ = cell(runs, C["model"], mode, r, lr, REP, "mcq_acc"); g = sorted({gpu_of(d) for d in dirs.values()})
        if g != [ADA]:
            A2r, dr, _ = cell(refruns, C["model"], mode, r, lr, REP, "mcq_acc")
            if A2r is None:
                sys.exit(f"STOP : {mode} r=2 n'a pas tourne sur une seule carte, et sa version reentrainee est incomplete")
            print(f"  reference {mode} r=2 : origine {st.mean(A2.values()):.4f} ({g}) ; reentrainee {st.mean(A2r.values()):.4f} ({sorted({gpu_of(d) for d in dr.values()})}) -> la reentrainee sert aux tests")
            A2 = A2r
        else:
            print(f"  reference {mode} r=2 : {st.mean(A2.values()):.4f} ({g})")
        for r_ in (3, 4):
            B, bd, _ = cell(runs, C["model"], X, r_, sel[f"{X}_r{r_}"], REP, "mcq_acc", since_of(k))
            if B is None:
                sys.exit(f"STOP : rapport {X} r={r_} incomplet")
            m, lo, hi, t = _t([(A2[s] - B[s]) * 100 for s in REP])
            lab = f"  {X:6s} : A gele r=2 - B gele r={r_} (a {sel[f'{X}_r{r_}']:g}, {st.mean(B.values()):.4f}) = {m:+.2f} [{lo:+.2f}, {hi:+.2f}], t = {t:+.2f}"
            if r_ == 3:
                pos, neg = m > 0 and t > BONF2, m < 0 and -t > BONF2
                verdict[X] = "A" if pos else ("B" if neg else "?")
                print(lab + (" -> ETABLI (A gele devant)" if pos else " -> ETABLI (B gele devant)" if neg else " -> non etabli") + f" ; cartes {sorted({gpu_of(d) for d in bd.values()})}")
            else:
                print(lab + " (rapporte sans test)")
    if all(v == "A" for v in verdict.values()):
        print("  LECTURE FIXEE : A gele (r=2) reste devant B gele (r=3) sur les deux bandes, avec moins de parametres -> le budget n'explique pas l'avantage de geler A")
    else:
        for X, v in verdict.items():
            if v == "B":
                print(f"  LECTURE FIXEE : B gele (r=3) depasse A gele (r=2) sur la bande {X} -> l'avantage de geler A y est attribue au budget")
        print("  LECTURE FIXEE : l'avantage de geler A est rapporte comme en partie lie au budget")


def _band_test(lab, gf, go):
    mf, mo = st.mean(gf.values()) * 100, st.mean(go.values()) * 100
    if abs(mf) < FLOOR:
        return f"  {lab} : ecart gele {mf:+.2f} sous le plancher de {FLOOR:g} points -> non lu"
    sg = 1 if mf > 0 else -1
    m, lo, hi, t = _t([sg * (gf[s] - go[s]) * 100 for s in REP])
    if (mo > 0) != (mf > 0) and abs(mo) >= FLOOR:
        v = "RENVERSEMENT (l'ecart change de signe), pas un retrecissement"
    elif t > T4 and abs(mo) < abs(mf):
        v = "RETRECISSEMENT ETABLI"
    else:
        v = "non etabli"
    return f"  {lab} : ecart {mf:+.2f} -> {mo:+.2f} ; statistique orientee {m:+.2f} [{lo:+.2f}, {hi:+.2f}], t = {t:+.2f} -> {v}"


def read_iso(k, C, runs):
    sel = json.load(open(f"v2_{k}_selection.json")); Gj = json.load(open(f"v2_{k}_G.json")); cards = set()
    print(f"==================== {k} : {C['model']}, OpenBookQA ====================")
    B = since_of(k)
    get = lambda mode, r: cell(runs, C["model"], mode, r, sel[f"{mode}_r{r}"], REP, "mcq_acc", B) if f"{mode}_r{r}" in sel else (None, {}, {})  # noqa: E731
    AB = {}
    for r, rf in C["ranks"].items():
        print(f"  ---- rang {r} (LoRA libre et U au rang {rf}) ----")
        fr, frd, _ = get("free", rf); cards |= {gpu_of(d) for d in frd.values()}
        for X in ("top", "bottom"):
            fz, fzd, _ = get(X, r); u, ud, _ = get(X + "_unfrozen", rf); cards |= {gpu_of(d) for d in list(fzd.values()) + list(ud.values())}
            if None in (fr, fz, u):
                sys.exit(f"STOP : cellules incompletes au rang {r} pour {X}")
            G = (st.mean(fr.values()) - st.mean(fz.values())) * 100
            if abs(G - Gj[f"{r}_{X}"]["G"]) > 1e-9:
                sys.exit(f"STOP : G ({G:.4f}) differe de G committe ({Gj[f'{r}_{X}']['G']:.4f})")
            m, lo, hi, _ = _t([(u[s] - fz[s]) * 100 for s in REP])
            if G < FLOOR:
                v1 = f"G = {G:+.2f} < plancher : non applicable"
            elif lo >= 0.7 * G:
                v1 = "le gel explique l'essentiel"
            elif hi <= 0.3 * G:
                v1 = "l'essentiel vient d'ailleurs"
            else:
                v1 = "non resolu (partage)"
            R = _boot(lambda S: (st.mean(u[s] for s in S) - st.mean(fz[s] for s in S)) / max(1e-9, st.mean(fr[s] for s in S) - st.mean(fz[s] for s in S)), REP)
            I = _boot(lambda S: (st.mean(fr[s] for s in S) - st.mean(u[s] for s in S)) * 100, REP)
            print(f"  {X:6s} : G {G:+.2f} ; (1) U {m:+.2f} [{lo:+.2f}, {hi:+.2f}] contre 0,7 G = {0.7 * G:.2f} -> {v1} ; U/G {R[0]:.2f} [{R[1]:.2f}, {R[2]:.2f}] ; I {I[0]:+.2f} [{I[1]:+.2f}, {I[2]:+.2f}]")
            ur, _, _ = get(X + "_unfrozen", r)
            if ur is None and r != rf and (X + "_unfrozen", r) in arms_of(C):
                sys.exit(f"STOP : cellules incompletes au rang {r} pour {X}_unfrozen (test du gel seul)")
            if ur is not None and r != rf:
                m, lo, hi, t = _t([(ur[s] - fz[s]) * 100 for s in REP])
                print(f"           (2) gel seul, r={r} : {m:+.2f} [{lo:+.2f}, {hi:+.2f}], t = {t:+.2f} -> " + ("ETABLI" if m > 0 and t > BONF2 else "non etabli"))
            da, dad, _ = get("dual_" + X, r)
            if da is None and ("dual_" + X, r) in arms_of(C):
                sys.exit(f"STOP : cellules incompletes au rang {r} pour dual_{X} (test A gele - B gele)")
            if da is not None:
                cards |= {gpu_of(d) for d in dad.values()}
                m, lo, hi, t = _t([(da[s] - fz[s]) * 100 for s in REP]); AB[(r, X)] = m
                print(f"           (3) A gele - B gele, r={r} : {m:+.2f} [{lo:+.2f}, {hi:+.2f}], t = {t:+.2f} -> " + ("ETABLI" if m > 0 and t > BONF2 else "non etabli"))
            if "short" in C:
                print(f"           entrainement court -> long : gele {C['short'][X]:.4f} -> {st.mean(fz.values()):.4f} ; degele r=1 {C['short'][X + '_unfrozen']:.4f} -> {st.mean(u.values()):.4f}")
            Gj[f"{r}_{X}"]["_v1"] = v1; Gj[f"{r}_{X}"]["_lo"] = lo
        ft, _, _ = get("top", r); fb, _, _ = get("bottom", r); gf = {s: fb[s] - ft[s] for s in REP}
        for lab, a, b in (("(4) bandes, B entraine", "top_unfrozen", "bottom_unfrozen"), ("(4) bandes, A gele", "dual_top", "dual_bottom")):
            ta, _, _ = get(a, r); tb, _, _ = get(b, r)
            if ta is not None and tb is not None and not (a == "top_unfrozen" and r == rf):
                print(_band_test(lab, gf, {s: tb[s] - ta[s] for s in REP}))
    print(f"  cartes : {sorted(cards)}")
    if "short" in C:
        fr_s = C["short"]["free"]; print(f"  libre : {fr_s:.4f} (court) -> {st.mean(get('free', 1)[0].values()):.4f} (long)")
        v = [Gj[f"2_{X}"] for X in ("top", "bottom")]
        if all(x["_v1"] == "le gel explique l'essentiel" for x in v):
            print("  LECTURE FIXEE : U reste au-dessus de 0,7 G sur les deux bandes -> le cout du gel de B sur OpenBookQA n'est pas un effet de l'entrainement court")
        elif any(x["G"] < FLOOR for x in v):
            print("  LECTURE FIXEE : G tombe sous le plancher -> le cout du gel de B sur OpenBookQA est rapporte comme dependant de la duree d'entrainement")
        else:
            print("  LECTURE FIXEE : le cout du gel de B sur OpenBookQA est rapporte comme reduit par l'entrainement long, avec sa valeur")
    if "known" in C:
        for X, i in (("top", 0), ("bottom", 1)):
            seq = [(r, C["known"][r]["G"][i], C["known"][r]["AB"][i]) for r in C["known"]] + [(r, Gj[f"{r}_{X}"]["G"], AB.get((r, X))) for r in C["ranks"]]
            seq.sort(); gs = [g for _, g, _ in seq]; abs_ = [a for _, _, a in seq if a is not None]
            mono = lambda v: all(a > b for a, b in zip(v, v[1:]))  # noqa: E731
            print(f"  prediction ({X}) : G par rang " + ", ".join(f"r={r} {g:+.2f}" for r, g, _ in seq) + (" -> decroit" if mono(gs) else " -> ne decroit pas de facon monotone")
                  + " ; A-B " + ", ".join(f"r={r} {a:+.2f}" for r, _, a in seq if a is not None) + (" -> decroit" if mono(abs_) else " -> non monotone"))


def count_failed(k, C, since_ts):
    """Runs de la campagne passes en echec (status FAILED ecrit) depuis since_ts. Un run abandonne faute de memoire libre (« skip »)
    n'ecrit rien : il n'est pas compte."""
    arms = set(arms_of(C)); n = 0
    for p_ in glob.glob(os.path.expanduser("~/lora-runs/*/config.yaml")):
        d = os.path.dirname(p_); st_ = d + "/status"
        if not os.path.exists(st_) or os.path.getmtime(st_) < since_ts:
            continue
        c = yaml.safe_load(open(p_)) or {}
        if is_pop(c, C["model"]) and (c.get("mode"), c.get("rank")) in arms and open(st_).read().startswith("FAILED"):
            n += 1
    print(f"ECHECS {n}")


if __name__ == "__main__":
    if len(sys.argv) == 4 and sys.argv[1] in CAMPS and sys.argv[2] == "failed":
        count_failed(sys.argv[1], CAMPS[sys.argv[1]], float(sys.argv[3])); sys.exit(0)
    if len(sys.argv) != 3 or sys.argv[1] not in CAMPS:
        sys.exit(__doc__)
    k, stage = sys.argv[1], sys.argv[2]; C = CAMPS[k]; C["_k"] = k; runs = load_runs()
    acts = {"check": p2_check if C["kind"] == "p2" else (ao_check if C["kind"] == "ao" else stage_check), "refs": stage_refs, "probe": stage_probe, "probe_read": stage_probe_read,
            "s1": stage_s1, "sel": stage_sel, "G": stage_G, "dir": w_dir if C["kind"] == "warmdir" else p2_dir, "gdir": g2_gdir, "wbasis": w_wbasis,
            "basis": w_basis if C["kind"] == "warmdir" else (g2_basis if C.get("source") == "grad" else p2_basis),
            "read": {"budget": read_budget, "p2": read_p2, "ao": read_ao}.get(C["kind"], read_iso)}
    if stage not in acts:
        sys.exit(__doc__)
    r = acts[stage](k, C, runs)
    if stage == "check":
        print("LANCER: rien")
