#!/bin/bash
# Apres l'etape 1 de PROTOCOL_long_training.md : genere les grilles du RAPPORT au taux retenu par bras, les committe avant leurs runs, les lance.
set -u
cd "$HOME/repo" || exit 1
PY="/tmp/lora-$USER/venv/bin/python"; [ -x "$PY" ] || PY=python3
echo "=== etape 2, rapport ==="
"$PY" scripts/make_long_grids.py --stage2 || { echo "  STOP : selection incomplete ; rien n'est lance"; exit 1; }
git add configs/grids/long_s2_*.yaml && git commit -qm "entrainement long : taux retenus sur les graines 0-1 ; grilles du rapport avant leurs runs" && echo "  ok : committe ($(git log -1 --format=%h))"
git push -q 2>/dev/null; bash scripts/launch_long_s2.sh
