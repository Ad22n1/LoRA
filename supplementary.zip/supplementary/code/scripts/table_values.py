"""Every number of the tables the 15 re-runs touch, computed from the runs, in one go.

    python scripts/table_values.py

Tables 2 (free by rank), 10 (arms by rank), 7 (freeze and choose), 19 (the two tie-breaks), and the
search for `random` at rank 4. Same population as the paper: Llama-3.2-1B, format, seven modules,
clipping at 1.0, no rescaling, 614 items, seeds 2-6, replicates averaged within a seed, salted random
draws, bottom at rank 2 at the reported 2e-3 (the rule's 5e-3 is Table 19's second row).
Changes nothing.
"""
import os
import sys

import yaml

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
from lorasub.aggregate import collect  # noqa: E402

M = "meta-llama/Llama-3.2-1B"
SEL = (yaml.safe_load(open("configs/lr_selected.yaml")) or {})["selected"]
d = collect(os.path.expanduser("~/lora-runs"))
B = d[(d.task == "format") & (d.model.astype(str) == M) & (d.n_modules == 7) & (d.max_grad_norm == 1.0)
      & d.update_norm_target.isna() & (d.format_n == 614) & d.seed.between(2, 6)]
B = B[~B["mode"].isin(["random", "random_ortho"]) | (B.subspace_salted == True)]


def cell(mode, rank, lr, band_frac=None, drop_collapsed=False):
    x = B[(B["mode"] == mode) & (B["rank"] == rank) & ((B.lr - lr).abs() < 1e-12)]
    if band_frac is not None:
        x = x[(x.band_frac - band_frac).abs() < 1e-9]
    per = x.groupby("seed").format_parsed.mean()
    if drop_collapsed:
        per = per[per > 0.1]
    return float(per.mean()) if per.size else float("nan"), int(per.size)


def lr_of(mode, rank):
    """The rate of the TABLE's cell. lr_selected.yaml disagrees for random at rank 4 (it mixed salted
    and unsalted draws) and may elsewhere: when its rate has no five-seed cell in the reported
    population, take the one rate that does, and say so."""
    if (mode, rank) == ("bottom", 2):
        return 2e-3
    lr = SEL.get(f"{M}|format|{mode}|{rank}")
    x = B[(B["mode"] == mode) & (B["rank"] == rank)]
    full = sorted(float(l) for l, g in x.groupby("lr") if g.seed.nunique() == 5)
    if lr is not None and any(abs(lr - f) < 1e-12 for f in full):
        return lr
    if len(full) == 1:
        print(f"  note: {mode} r={rank} is reported at {full[0]:g}, not the lr_selected {lr}")
        return full[0]
    return lr


print("\n=== Table 2 / free by rank ===")
free = {r: cell("free", r, SEL.get(f"{M}|format|free|{r}")) for r in (1, 2, 4)}
for r, (v, n) in free.items():
    per = B[(B["mode"] == "free") & (B["rank"] == r) & ((B.lr - SEL.get(f"{M}|format|free|{r}")).abs() < 1e-12)
            ].groupby("seed").format_parsed.mean()
    print(f"  free r={r}  lr={SEL.get(f'{M}|format|free|{r}')}  {v:.4f} +- {per.std():.4f} (n={n})  seeds {per.round(4).to_dict()}")

print("\n=== Table 10 / arms by rank ===")
arms = {}
for r in (1, 2, 4):
    for m in ("top", "bottom", "random", "random_ortho"):
        lr = lr_of(m, r)
        if lr is None:
            continue
        v, n = cell(m, r, lr)
        if n:
            arms[(m, r)] = v
            print(f"  {m:13s} r={r}  lr={lr}  {v:.4f} (n={n})")
arms[("top@5e-3", 4)] = cell("band", 4, 5e-3, 0.0)[0]
print(f"  top@5e-3 (beta=0) r=4  {arms[('top@5e-3', 4)]:.4f}")

print("\n=== where does random at rank 4 live? ===")
x = d[(d.task == "format") & (d.model.astype(str) == M) & (d["mode"] == "random") & (d["rank"] == 4)]
print(x.groupby(["lr", "format_n", "n_modules", "max_grad_norm", x.subspace_salted.astype(str)]).agg(
    seeds=("seed", lambda s: ",".join(map(str, sorted(s)))), mean=("format_parsed", "mean")).round(4).to_string())
print(f"  lr_selected for random r=4: {SEL.get(f'{M}|format|random|4')}")

print("\n=== Table 7 / freeze and choose ===")
def row(label, ref, rank, extra=None):
    vals = {m: v for (m, r), v in arms.items() if r == rank and not m.startswith("top@")}
    if extra:
        vals.update(extra)
    best, worst = max(vals.values()), min(vals.values())
    fz, ch = (ref - best) * 100, (best - worst) * 100
    print(f"  {label:34s} freeze {fz:5.2f}  choose {ch:5.2f}  ratio {fz / ch:4.2f}   ({len(vals)} arms)")
row("rank 2 (free r=1)", free[1][0], 2)
row("rank 4 (free r=2), top at 2e-3", free[2][0], 4)
row("rank 4 (free r=2), top at 5e-3", free[2][0], 4, {"top": arms[("top@5e-3", 4)]})
row("rank 1 (free r=1, 2.15x budget)", free[1][0], 1)

print("\n=== Table 19 / the two tie-breaks for bottom at rank 2 ===")
b2 = cell("bottom", 2, 2e-3)
b5 = cell("bottom", 2, 5e-3)
x5 = B[(B["mode"] == "bottom") & (B["rank"] == 2) & ((B.lr - 5e-3).abs() < 1e-12)]
norm_col = next((c for c in ("update_norm_mean", "update_norm_max", "update_norm") if c in x5.columns), None)
print("  bottom 5e-3 per seed: " + "  ".join(
    f"s{int(r.seed)}:{r.format_parsed:.4f}(norm {getattr(r, norm_col):.1f})" for r in x5.itertuples()) if norm_col else "")
keep = x5[x5[norm_col] < 10] if norm_col else x5
per5 = keep.groupby("seed").format_parsed.mean()
b5d = (float(per5.mean()), int(per5.size))
print(f"  bottom 2e-3: {b2[0]:.4f} (n={b2[1]})  |  5e-3: {b5[0]:.4f} (n={b5[1]}), without runs of norm > 10: {b5d[0]:.4f} (n={b5d[1]})")
others = [arms[(m, 2)] for m in ("top", "random", "random_ortho")]
for lab, bv in (("2e-3 (reported)", b2[0]), ("5e-3 (rule, collapse dropped)", b5d[0])):
    ch = (max(others + [bv]) - min(others + [bv])) * 100
    fz = (free[1][0] - max(others + [bv])) * 100
    print(f"  {lab:30s} choose {ch:5.2f}  freeze {fz:5.2f}  ratio {fz / ch:4.2f}")
