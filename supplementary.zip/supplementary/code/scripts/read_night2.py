"""The second night, read by the protocols committed before the runs.

    python scripts/read_night2.py 2>&1 | grep -vE "FutureWarning|pd.concat"

1. Ranks 8 and 16, format task, reported seeds (PROTOCOL_rank8_16_format.md and its two addenda):
   rank 16 -- both halves of the inversion (threshold 2.776, against the best competitor recomputed per
   seed AND each fixed competitor), the arm-by-rate interaction (Bonferroni over three: 3.96), freezing
   against choosing at the selected rates; rank 8 -- the inversion is not testable (common rates
   coincide), so only freezing against choosing.
2. C, top_sigma against top_scalar on fresh seeds 50-64 (PROTOCOL_sigma_residual.md).
3. B, bottom_sigma (PROTOCOL_bottom_sigma.md): selected rates, with and without the degenerate modules.
4. D, OpenBookQA at rank 2, SELECTION only (PROTOCOL_obqa_rank2.md): rates, common rates, rate shift.
Every cell prints its number of seeds, so a missing run shows at once.
"""
import glob
import json
import os
import random
import statistics as st
import sys

import yaml

sys.path.insert(0, "src")
from lorasub.aggregate import collect  # noqa: E402

L = "meta-llama/Llama-3.2-1B"
d = collect(os.path.expanduser("~/lora-runs"))
F = d[(d.task == "format") & (d.model.astype(str) == L) & (d.max_grad_norm == 1.0) & d.update_norm_target.isna()
      & d.band_frac.isna() & ((d.alpha / d["rank"]).round(2) == 1.0) & (d.format_n == 614)]
F = F[~(F["mode"].isin(["random", "random_ortho"]) & (F.subspace_salted != True))]  # noqa: E712
T2 = {2: 2.776, 14: 2.145}


def cell(mode, rank, lr, seeds, nmod=7, key="format_parsed"):
    x = F[(F["mode"] == mode) & (F["rank"] == rank) & ((F.lr - lr).abs() < 1e-12) & F.seed.isin(seeds) & (F.n_modules == nmod)]
    return x.groupby("seed")[key].mean().to_dict()


def paired(a, b):
    k = sorted(set(a) & set(b)); dd = [(a[s] - b[s]) * 100 for s in k]
    if len(dd) < 2: return float("nan"), float("nan"), 0, len(dd), dd
    sd = st.stdev(dd); t = st.mean(dd) / (sd / len(dd) ** 0.5) if sd > 0 else float("inf")
    return st.mean(dd), t, sum(v > 0 for v in dd), len(dd), dd


def line(lab, a, b, thr):
    m, t, pos, n, _ = paired(a, b)
    print(f"    {lab:44s} {m:+6.2f} pt  t = {t:+6.2f}  {pos}/{n}  {'ETABLI' if t > thr else 'non etabli'}")


def fc(own, fr, seeds):
    def f(ix):
        m = {k: st.mean(v[s] for s in ix) for k, v in own.items()}; ff = st.mean(fr[s] for s in ix)
        return (ff - max(m.values())) * 100, (max(m.values()) - min(m.values())) * 100
    g, c = f(seeds); rng = random.Random(0)
    B = [f([seeds[rng.randrange(len(seeds))] for _ in seeds]) for _ in range(20000)]
    q = lambda xs: (sorted(xs)[500], sorted(xs)[19499])  # noqa: E731
    lo, hi = q([b[0] - b[1] for b in B])
    print(f"    geler (ecart a free) {g:5.2f} pt [{q([b[0] for b in B])[0]:+.2f}, {q([b[0] for b in B])[1]:+.2f}]"
          f"   choisir {c:5.2f} pt [{q([b[1] for b in B])[0]:+.2f}, {q([b[1] for b in B])[1]:+.2f}]")
    print(f"    geler - choisir {g - c:+.2f} pt  IC95 [{lo:+.2f}, {hi:+.2f}]  {'(exclut zero)' if lo > 0 or hi < 0 else '(contient zero)'}")


# ------------------------------------------------------------------ 1. ranks 8 and 16, reported seeds
print("==================== 1. RANG 16, tache de format, graines rapportees 2-6 ====================")
S = [2, 3, 4, 5, 6]; LO, HI = 5e-4, 2e-3
arms = ("top", "random", "random_ortho")
A = {(m, lr): cell(m, 16, lr, S) for m in ("bottom",) + arms for lr in (LO, HI)}
for (m, lr), v in sorted(A.items(), key=str): print(f"  {m:13s} {lr:g}  {st.mean(v.values()):.4f}  ({len(v)} graines)")
seeds = sorted(set.intersection(*[set(v) for v in A.values()]))
b_lo, b_hi = A[("bottom", LO)], A[("bottom", HI)]
best_lo = {s: max(A[(m, LO)][s] for m in arms) for s in seeds}; best_hi = {s: max(A[(m, HI)][s] for m in arms) for s in seeds}
print("  avance de bottom a 5e-4 (seuil 2.776) :")
line("contre le meilleur concurrent, recalcule", b_lo, best_lo, 2.776)
for m in arms: line(f"contre {m} (fixe)", b_lo, A[(m, LO)], 2.776)
print("  retard de bottom a 2e-3 (seuil 2.776) :")
line("le meilleur concurrent moins bottom", best_hi, b_hi, 2.776)
for m in arms: line(f"{m} (fixe) moins bottom", A[(m, HI)], b_hi, 2.776)
print("  interaction bras x taux, (bottom - concurrent) a 5e-4 moins a 2e-3 (seuil corrige 3.96) :")
for m in arms:
    inter = {s: (b_lo[s] - A[(m, LO)][s]) - (b_hi[s] - A[(m, HI)][s]) for s in seeds}
    line(f"contre {m}", inter, {s: 0.0 for s in seeds}, 3.96)
own16 = {"top": A[("top", HI)], "bottom": b_lo, "random": cell("random", 16, 1e-3, S), "random_ortho": cell("random_ortho", 16, 1e-3, S)}
fr16 = cell("free", 8, 2e-3, S)
print(f"  aux taux propres (random et random_ortho a 1e-3 : {len(own16['random'])} et {len(own16['random_ortho'])} graines ; free r=8 : {len(fr16)}) :")
fc(own16, fr16, sorted(set(fr16).intersection(*[set(v) for v in own16.values()])))

print("\n==================== RANG 8, graines neuves 42-46 (inversion non testable) ====================")
S8 = [42, 43, 44, 45, 46]
own8 = {"top": cell("top", 8, 2e-3, S8), "bottom": cell("bottom", 8, 2e-3, S8), "random": cell("random", 8, 5e-3, S8), "random_ortho": cell("random_ortho", 8, 5e-3, S8)}
fr8 = cell("free", 4, 2e-3, S8)
for m, v in list(own8.items()) + [("free r=4", fr8)]: print(f"  {m:13s} {st.mean(v.values()):.4f}  ({len(v)} graines)" if v else f"  {m:13s} AUCUN RUN")
line("top moins bottom, au meme taux 2e-3 (descriptif)", own8["top"], own8["bottom"], 2.776)
fc(own8, fr8, sorted(set(fr8).intersection(*[set(v) for v in own8.values()])))

# ------------------------------------------------------------------ 2. C
print("\n==================== 2. C : top_sigma contre top_scalar, graines 50-64 ====================")
sg, sc = cell("top_sigma", 2, 5e-3, range(50, 65)), cell("top_scalar", 2, 5e-3, range(50, 65))
m, t, pos, n, dd = paired(sg, sc)
if n > 1:
    se = st.stdev(dd) / n ** 0.5; lo90, hi90 = m - 1.761 * se, m + 1.761 * se
    print(f"  top_sigma {st.mean(sg.values()):.4f} ({len(sg)})   top_scalar {st.mean(sc.values()):.4f} ({len(sc)})")
    print(f"  d = {m:+.2f} pt, t = {t:+.2f} ({n - 1} d.l.), {pos}/{n} positives ; IC90 [{lo90:+.2f}, {hi90:+.2f}]")
    verdict = "ETABLI (le reste existe)" if (t > 2.145 and m > 0) else ("EQUIVALENCE (dans +/- 1 point)" if -1 <= lo90 and hi90 <= 1 else "NON TRANCHE")
    print(f"  -> {verdict}")

# ------------------------------------------------------------------ 3. B
print("\n==================== 3. B : bottom_sigma, selection (graines 0 et 1, validation) ====================")
def sel(mode, nmod):
    x = F[(F["mode"] == mode) & (F["rank"] == 2) & F.seed.isin([0, 1]) & (F.n_modules == nmod)]
    g = x.groupby("lr").agg(v=("val_format_parsed", "mean"), n=("seed", "nunique"))
    if g.empty: print(f"  {mode:13s} {nmod} modules : AUCUN RUN"); return None
    full = g[g.n == g.n.max()]; best = float(full.v.idxmax())
    edge = best in (min(g.index), max(g.index))
    print(f"  {mode:13s} {nmod} modules : " + "  ".join(f"{lr:g}:{r.v:.3f}({int(r.n)})" for lr, r in g.iterrows()) + f"  -> {best:g}{'  AU BORD' if edge else ''}")
    return best, edge
res = {}
for nmod in (7, 5):
    ts, bs = sel("top_sigma", nmod), sel("bottom_sigma", nmod)
    if ts and bs: res[nmod] = (bs[0] > ts[0], ts[1] or bs[1])
for nmod, (higher, edge) in res.items():
    print(f"  {nmod} modules : bottom_sigma {'PLUS ELEVE' if higher else 'PAS plus eleve'} que top_sigma{'  (une selection au bord : prolonger d abord)' if edge else ''}")
if len(res) == 2:
    k = sum(h for h, _ in res.values()); print(f"  -> prediction {'CONFIRMEE' if k == 2 else ('PARTIELLE' if k == 1 else 'REFUTEE')}")

# ------------------------------------------------------------------ 4. D
print("\n==================== 4. D : OpenBookQA au rang 2, selection (graines 0 et 1) ====================")
runs = []
for p in glob.glob(os.path.expanduser("~/lora-runs/*/config.yaml")):
    c = yaml.safe_load(open(p)) or {}
    if c.get("task") != "commonsense" or str(c.get("data_fingerprint")) != "dc05f4d847f9" or c.get("seed") not in (0, 1): continue
    f = os.path.dirname(p) + "/metrics.json"
    if os.path.exists(f) and open(os.path.dirname(p) + "/status").read().startswith("DONE"):
        runs.append((c["mode"], c["rank"], float(c["lr"]), json.load(open(f)).get("val_mcq_acc")))
selD = {}
for mode, r in (("top", 2), ("bottom", 2), ("random", 2), ("random_ortho", 2), ("free", 1)):
    g = {}
    for mo, rk, lr, v in runs:
        if mo == mode and rk == r and v is not None: g.setdefault(lr, []).append(v)
    if not g: print(f"  {mode:13s} AUCUN RUN"); continue
    full = {lr: st.mean(v) for lr, v in g.items() if len(v) == max(len(x) for x in g.values())}
    best = max(full, key=full.get); selD[mode] = (best, full[best])
    edge = best in (min(g), max(g))
    print(f"  {mode:13s} " + "  ".join(f"{lr:g}:{st.mean(g[lr]):.3f}({len(g[lr])})" for lr in sorted(g)) + f"  -> {best:g}{'  AU BORD' if edge else ''}")
if all(m in selD for m in ("top", "bottom", "random", "random_ortho")):
    other = max(("top", "random", "random_ortho"), key=lambda m: selD[m][1])
    pair = sorted({selD["bottom"][0], selD[other][0]})
    print(f"  taux communs : bottom ({selD['bottom'][0]:g}) et {other} ({selD[other][0]:g}) -> " + ("CONFONDUS, inversion non testable" if len(pair) == 1 else f"{pair[0]:g} et {pair[1]:g}"))
    lower = [m for m in ("top", "random", "random_ortho") if selD["bottom"][0] < selD[m][0]]
    print(f"  deplacement du taux : bottom plus bas que {lower or 'aucun bras'} -> {'CONFIRMEE' if len(lower) == 3 else ('REFUTEE' if not lower else 'PARTIELLE')}")
