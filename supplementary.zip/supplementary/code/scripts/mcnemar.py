"""Paired McNemar test between two arms, from the saved generations. No PARTITION.

    python scripts/mcnemar.py --runs_dir ~/lora-runs --task format --rank 2 \
        --a bottom --b top [--lr_from configs/lr_selected.yaml] [--metric parsed]

Why this exists. Comparing arms through a seed-level win matrix throws away the pairing that carries
the statistical power: with five seeds, a clean sweep gives at best p = 1/32 = 0.031, and a single
discordant seed destroys significance. The arms are evaluated on THE SAME test items, so the
comparison can be paired per example — which is what McNemar's test uses. On 400 items, that is
roughly three orders of magnitude more power than pairing at the seed level, and it costs nothing once
the generations are on disk.

Reads ``generations_test.jsonl`` written by train.py.
"""
from __future__ import annotations

import argparse
import json
import sys
from math import comb
from pathlib import Path

import pandas as pd
import yaml

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from lorasub import expand_path  # noqa: E402


def load_run(run_dir: Path, metric: str) -> tuple[dict, dict] | None:
    """(config, {item_id: bool}) for one run, or None if it has no saved generations."""
    gens = run_dir / "generations_test.jsonl"
    cfg_path = run_dir / "config.yaml"
    if not gens.exists() or not cfg_path.exists() or not (run_dir / "results.csv").exists():
        return None
    with open(cfg_path) as f:
        cfg = yaml.safe_load(f)
    out = {}
    with open(gens) as f:
        for i, line in enumerate(f):
            r = json.loads(line)
            out[r.get("id") if r.get("id") is not None else i] = bool(r.get(metric))
    return cfg, out


def mcnemar(a: dict, b: dict) -> dict:
    """Exact two-sided McNemar on the items both runs were scored on.

    Only the DISCORDANT pairs carry information: items where both arms succeed or both fail say
    nothing about which is better. n01 and n10 count them; under the null they split evenly, so the
    p-value is that of a binomial(n01 + n10, 1/2).
    """
    shared = sorted(set(a) & set(b))
    n01 = sum(1 for k in shared if not a[k] and b[k])       # b right, a wrong
    n10 = sum(1 for k in shared if a[k] and not b[k])       # a right, b wrong
    n = n01 + n10
    if n == 0:
        return {"n_items": len(shared), "n01": 0, "n10": 0, "p_value": 1.0, "note": "no discordance"}
    lo = min(n01, n10)
    p = min(1.0, 2 * sum(comb(n, i) for i in range(lo + 1)) / 2 ** n)
    return {"n_items": len(shared), "n01": n01, "n10": n10, "p_value": p,
            "rate_a": sum(a[k] for k in shared) / len(shared),
            "rate_b": sum(b[k] for k in shared) / len(shared)}


def check_population(runs: dict) -> list[str]:
    """Every reason these runs cannot be pooled into one paired test.

    `crossed_table` and `win_matrix` already refuse on incomparable cells; this is the third function
    whose output goes into the paper and it had no such guard. Four things break the test:

    * a seed appearing TWICE inside one arm — the double loop then emits one row per combination and
      the pooled counts double-count that seed, which is what put seeds 2 and 4 twice in the output;
    * two evaluation sizes — McNemar intersects the item ids and silently tests on the overlap, so a
      400-item run paired with a 614-item run yields a valid-looking p-value over a subset nobody
      chose;
    * two dataset versions — the item ids match while the items do not;
    * two learning rates inside one arm, which is the comparison this whole project exists to avoid.
    """
    out: list[str] = []
    for arm, entries in runs.items():
        seeds = [s for s, _, _, _ in entries]
        for sd in sorted({s for s in seeds if seeds.count(s) > 1}):
            # The two fields that caused a refusal in practice are the two that were NOT shown:
            # max_grad_norm (the noclip grid reruns the same cell without clipping) and the number
            # of target modules (the localisation grid reruns it on five projections). Printing the
            # tuple without them told the reader a cell was ambiguous and left them to guess why.
            which = [(name, str(cfg.get("model", "")).split("/")[-1], cfg.get("lr"),
                      bool(cfg.get("subspace_salted", False)), len(sc),
                      cfg.get("max_grad_norm"), len(cfg.get("target_modules") or []))
                     for s2, sc, cfg, name in entries if s2 == sd]
            out.append(f"{arm}: seed {sd} appears {len(which)} times -> {which} "
                       f"(run, model, lr, salted, n_items, clip, n_modules). Pairing is ambiguous and "
                       f"pooling would count "
                       f"this seed more than once.")
        for label, vals in (
                ("evaluation sizes", {len(sc) for _, sc, _, _ in entries}),
                ("learning rates", {float(cfg.get("lr") or 0) for _, _, cfg, _ in entries}),
                ("dataset versions", {str(cfg.get("data_fingerprint") or "legacy")
                                      for _, _, cfg, _ in entries}),
                # ONLY on the arms the salt describes. `top`, `bottom`, `free` and `band` draw
                # deterministic bands; the flag is recorded on their runs but changes nothing for
                # them. Comparing it there fired a false refusal the moment the default flipped to
                # True: three `top` runs produced before carried False, the two produced after
                # carried True, and the test refused to pair five runs that had measured exactly the
                # same thing. Same principle as the run id — on an arm that draws nothing, the salt
                # is not a property of the run.
                ("random-arm versions",
                 {bool(cfg.get("subspace_salted", False)) for _, _, cfg, _ in entries}
                 if arm in ("random", "random_ortho") else {None})):
            if len(vals) > 1:
                out.append(f"{arm}: {len(vals)} {label} in the same arm ({sorted(vals)}).")
    sizes = {len(sc) for entries in runs.values() for _, sc, _, _ in entries}
    if len(sizes) > 1:
        out.append(f"the two arms were evaluated on {len(sizes)} different sizes ({sorted(sizes)}); "
                   f"the test would run on the intersection only.")
    return out


def combine(df: "pd.DataFrame", name_a: str, name_b: str, n_comparisons: int = 1) -> None:
    """Combine the per-seed tests WITHOUT pretending the seeds give independent items.

    What was here before summed n01 and n10 across seeds and ran one exact binomial on the total. That
    is wrong, and wrong in the direction that flatters the result. The same item is scored under every
    seed, and its difficulty is shared: the discordant pairs are correlated across seeds, so the
    effective number of independent observations is far below n01 + n10. The binomial treats them as
    independent coin flips, underestimates the variance, and returns a p-value that is too small --
    exactly where the power is being claimed. (The old note said the pooling assumed exchangeable
    seeds; that was not the issue. Exchangeability of seeds is fine. Dependence between items is not.)

    What is reported instead:

    * the PER-SEED table, which is the primary result. Each row is a valid McNemar test on its own:
      one seed, distinct items, legitimate pairing.
    * a sign test over seeds. Conservative, assumption-free, and the honest floor: with five seeds all
      in one direction it gives p = 1/16 two-sided, which is the most a seed-level argument can buy.
    * Stouffer's method on the per-seed one-sided p-values. More powerful than the sign test, but it
      still assumes the per-seed tests are independent, and they share the same items -- so it is
      reported as indicative, between the two.
    * a Bonferroni threshold, because comparing four arms means several tests on the same data.
    """
    from statistics import NormalDist

    nd = NormalDist()
    rows = []
    for _, r in df.iterrows():
        n10, n = int(r.n10), int(r.n01) + int(r.n10)
        # one-sided p for "a beats b": P(Binom(n, 1/2) >= n10)
        p1 = sum(comb(n, i) for i in range(n10, n + 1)) / 2 ** n if n else 0.5
        p1 = min(max(p1, 1e-16), 1 - 1e-16)
        rows.append((p1, nd.inv_cdf(1 - p1)))
    k = len(rows)
    wins = sum(1 for _, r in df.iterrows() if r.n10 > r.n01)

    print(f"\ncombination over {k} seed(s) -- the per-seed rows above are the primary result")
    # sign test, two-sided, over seeds
    hi = max(wins, k - wins)
    p_sign = min(1.0, 2 * sum(comb(k, i) for i in range(hi, k + 1)) / 2 ** k) if k else 1.0
    print(f"  sign test over seeds : {wins}/{k} favour {name_a}, p = {p_sign:.4g}  "
          f"(conservative, no assumption)")
    z = sum(t[1] for t in rows) / (k ** 0.5)
    # NOT `1 - cdf(|z|)`: cdf(14.22) is 1 - 4e-46, and in float64 the subtraction returns exactly
    # zero — the script printed "two-sided p = 0", which is a numerical artefact and indefensible in
    # a paper. erfc keeps the small tail representable.
    from math import erfc, sqrt

    p_stouffer = min(1.0, erfc(abs(z) / sqrt(2.0)))
    print(f"  Stouffer on per-seed p : z = {z:+.2f}, two-sided p = {p_stouffer:.3g}  "
          f"(indicative: assumes the seeds are independent, but they share the same items)")
    if p_stouffer < 1e-12:
        print("  NB: such a p-value reflects the model's assumptions far more than the data. "
              "Report the sign test, which makes none.")
    if n_comparisons > 1:
        print(f"  Bonferroni at {n_comparisons} comparisons: significance threshold is "
              f"{0.05 / n_comparisons:.4g}, not 0.05")
    print("  NOT reported: a binomial on the summed discordances. Items are scored under every seed, "
          "so they are not independent and that p-value is anti-conservative.")

    # ------------------------------------------------------------------ effect size, not just p
    # THE SIGN TEST CANNOT CROSS OUR OWN THRESHOLD. Two-sided, k seeds, unanimous: k=5 gives 0.0625,
    # k=6 0.031, k=7 0.0156, k=8 0.0078. With Bonferroni at seven comparisons the threshold is
    # 0.00714, so five seeds put the FLOOR nine times above the bar — the test we present as our
    # defensible floor cannot reach it, whatever the data say. Two things follow, and both are free.
    #
    # First, the sign test throws away the magnitude: it returns 0.0625 for a 0.78-point gap and for
    # an 8-point gap alike. A paired t on the k per-seed differences keeps it. Its assumption —
    # normality of k differences — is far weaker than the independence of items that Stouffer needs.
    #
    # Second, and this matters more than any p-value: a difference deserves an INTERVAL. A p without
    # an amplitude, on five seeds, invites exactly the objection one is trying to avoid.
    diffs = [float(r.rate_a) - float(r.rate_b) for _, r in df.iterrows()]
    if k >= 3:
        m = sum(diffs) / k
        var = sum((d - m) ** 2 for d in diffs) / (k - 1)
        sd = var ** 0.5
        se = sd / (k ** 0.5)
        print(f"\n  effect size over seeds (what a p-value does not tell you)")
        print(f"    mean difference {name_a} - {name_b} : {m:+.4f}  (sd {sd:.4f} over {k} seeds)")
        if se > 0:
            t = m / se
            df_ = k - 1
            # Two-sided p from Student's t. Integrated directly rather than via an incomplete
            # beta: df is always small here (k-1 <= 10), the density is smooth, and Simpson on a
            # few thousand points is exact to far more digits than a p-value deserves. A hand-rolled
            # beta series is the kind of code that returns 0.12 where the answer is 0.51 and nobody
            # notices — checked against the textbook critical values instead (t=2.776 at 4 df -> 0.05,
            # t=4.604 -> 0.01).
            import math

            def _t_two_sided(t_abs: float, nu: int, steps: int = 4000) -> float:
                c = math.exp(math.lgamma((nu + 1) / 2) - math.lgamma(nu / 2)) / math.sqrt(nu * math.pi)
                f = lambda u: c * (1.0 + u * u / nu) ** (-(nu + 1) / 2)
                h = t_abs / steps
                tot = f(0.0) + f(t_abs)
                for i_ in range(1, steps):
                    tot += f(i_ * h) * (4 if i_ % 2 else 2)
                return max(0.0, min(1.0, 1.0 - 2.0 * tot * h / 3.0))

            p_t = _t_two_sided(abs(t), df_)
            print(f"    paired t on per-seed means      : t = {t:+.2f} ({df_} df), two-sided p = {p_t:.4g}")
        # hierarchical bootstrap over SEEDS only. Resampling items too would need the per-item
        # vectors; over seeds alone it is already the honest interval, and it makes no normality
        # assumption at all.
        import random as _rnd

        rng = _rnd.Random(0)
        boot = sorted(sum(rng.choice(diffs) for _ in range(k)) / k for _ in range(20000))
        lo, hi_ = boot[int(0.025 * len(boot))], boot[int(0.975 * len(boot))]
        print(f"    bootstrap 95% CI over seeds     : [{lo:+.4f}, {hi_:+.4f}]  "
              f"(20000 resamples of the {k} seeds, no distributional assumption)")
        if lo * hi_ > 0:
            print(f"    -> the interval excludes zero.")
        else:
            print(f"    -> the interval CONTAINS zero: no effect detected at this sample size.")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs_dir", required=True)
    ap.add_argument("--task", default="format")
    ap.add_argument("--rank", type=float, default=2)
    ap.add_argument("--rank_a", type=float, default=None,
                    help="rank of arm A when it differs from arm B. THE BUDGET-MATCHED CONTROL NEEDS "
                         "THIS: a constrained arm trains r*d_in parameters, `free` trains "
                         "r*(d_in+d_out), so `free` at r=1 (704 512 on Llama-3.2-1B) and a constrained "
                         "arm at r=2 (655 360) are matched to 7.5%. Comparing both at the same rank "
                         "compares 2x the budget and confounds `freezing B` with `having half the "
                         "parameters`. Omitted, both arms use --rank.")
    ap.add_argument("--rank_b", type=float, default=None, help="rank of arm B; see --rank_a.")
    ap.add_argument("--a", required=True, help="first arm, e.g. bottom")
    ap.add_argument("--b", required=True, help="second arm, e.g. top")
    ap.add_argument("--metric", default="parsed", choices=["parsed", "exact"])
    ap.add_argument("--lr_from", default=None, help="keep only each arm's selected learning rate")
    ap.add_argument("--salted", type=lambda x: str(x).lower() not in ("0", "false", "no"), default=True,
                    help="which version of the random arm: True = drawn independently per module. "
                         "WITHOUT this filter the test mixes the two arms and the seeds appear twice.")
    ap.add_argument("--norm_target", type=float, default=None,
                    help="which magnitude population to test: omitted = the unconstrained runs (the "
                         "one the paper reports), a value = the norm-matched ablation at that target. "
                         "Never both: the ablation runs at the selected rate, so they collide with "
                         "the unconstrained runs on (mode, lr, seed).")
    ap.add_argument("--model", default=None,
                    help="substring of the model id (e.g. 'Llama' or 'Qwen'). Required as soon as "
                         "two architectures have runs in the same cell: their scores are not "
                         "comparable and the pairing check will refuse without it.")
    ap.add_argument("--n_modules", type=int, default=None,
                    help="keep only runs adapting exactly this many target modules (7 = the main "
                         "grid, 5 = the module-localisation grid without q_proj and o_proj). "
                         "Runs adapting different module sets are different experiments.")
    ap.add_argument("--eval_n", type=int, default=None,
                    help="keep only runs evaluated on this many items (e.g. 614). The sweep runs at "
                         "400 and the seed grid at 614 live in the same runs_dir; without this the "
                         "population had to be moved aside by hand before every comparison.")
    ap.add_argument("--comparisons", type=int, default=1,
                    help="how many arm-vs-arm tests are being run on this data, for the Bonferroni "
                         "threshold. Four arms means three to six comparisons, not one.")
    ap.add_argument("--allow_mixed", action="store_true",
                    help="print the test even when the population is incoherent. For diagnosis only: "
                         "the resulting p-value must NOT be reported.")
    a = ap.parse_args()

    table = {}
    if a.lr_from:
        with open(expand_path(a.lr_from)) as f:
            table = (yaml.safe_load(f) or {}).get("selected", {})

    runs: dict[str, list[tuple[int, dict]]] = {a.a: [], a.b: []}
    for d in sorted(Path(expand_path(a.runs_dir)).glob("*/")):
        got = load_run(d, a.metric)
        if got is None:
            continue
        cfg, scores = got
        want = {a.a: (a.rank_a if a.rank_a is not None else a.rank),
                a.b: (a.rank_b if a.rank_b is not None else a.rank)}.get(cfg.get("mode"), a.rank)
        if cfg.get("task") != a.task or float(cfg.get("rank") or 0) != want:
            continue
        # MODEL. This script produces every p-value and every confidence interval in the paper, and
        # it filtered on task, rank, lr, salt, eval size, modules and clipping — but never on the
        # architecture. The day a second model produced runs at 614 items, every comparison started
        # refusing to pool (each seed appearing twice, once per model), which is the guard working;
        # but it also meant no comparison could be run ON that second model at all. Tenth occurrence
        # of the same pattern in this repository.
        if a.model and a.model not in str(cfg.get("model", "")):
            continue
        arm = cfg.get("mode")
        if arm not in runs:
            continue
        # The same guards as crossed_table and win_matrix. This is the THIRD function whose output
        # goes into the paper, and it had none: it paired the old unsalted random arm with the new
        # one, which is why seeds appeared twice in the output, and it pooled the two into a single
        # p-value.
        if arm in ("random", "random_ortho") and bool(cfg.get("subspace_salted", False)) != a.salted:
            continue
        # THE RESCALED RUNS ARE A DIFFERENT POPULATION. The norm-matched ablation runs at each arm's
        # SELECTED rate, so with --lr_from it lands on the same (mode, lr, seed) as the unconstrained
        # run and the pairing becomes ambiguous — `bottom` seed 5 at 2e-3 appeared three times, once
        # unconstrained and once per target. Same class as the salt: a field that changes what is
        # measured, not read where a measurement is reconstructed. Default keeps the unconstrained
        # population, which is the one the paper reports.
        target = cfg.get("update_norm_target")
        if a.norm_target is None:
            if target is not None:
                continue
        elif target is None or abs(float(target) - a.norm_target) > 1e-9:
            continue
        if a.eval_n is not None and len(scores) != a.eval_n:
            continue                          # one evaluation population per test, chosen explicitly
        # WHICH MODULES WERE ADAPTED is part of the experiment, not a detail. The module-localisation
        # grid reruns `bottom` and `top` on five projections instead of seven, with the same mode,
        # rank, lr and n_items -- so nothing in the filters above tells the two apart, and every seed
        # appeared twice. The pairing check caught it (as it should), but the fix belongs here: a run
        # adapting five modules and one adapting seven did not measure the same thing, and the
        # default must be the seven-module population that the main table reports.
        n_mod = len(cfg.get("target_modules") or [])
        if a.n_modules is not None and n_mod != a.n_modules:
            continue
        if table:
            key = f"{cfg['model']}|{cfg['task']}|{arm}|{int(float(cfg['rank']))}"
            if key in table and float(cfg.get("lr")) != float(table[key]):
                continue
        runs[arm].append((cfg.get("seed"), scores, cfg, d.name))

    _ra_ = int(a.rank_a if a.rank_a is not None else a.rank)
    _rb_ = int(a.rank_b if a.rank_b is not None else a.rank)
    if not runs[a.a] or not runs[a.b]:
        print(f"no runs with saved generations for {a.a} (r={_ra_}, {len(runs[a.a])} found) / "
              f"{a.b} (r={_rb_}, {len(runs[a.b])} found). "
              f"Only runs produced after generations were saved can be tested.")
        return

    problems = check_population(runs)
    if problems:
        print("REFUSING to pool: these runs did not measure the same thing.\n")
        for prob in problems:
            print(f"  - {prob}")
        print("\nFix the population, or pass --allow_mixed to see the numbers anyway, knowing they "
              "are not reportable.")
        if not a.allow_mixed:
            sys.exit(2)
        print("\n--allow_mixed set: continuing. THESE NUMBERS ARE NOT REPORTABLE.\n")

    rows = []
    for sa, scores_a, _, _ in runs[a.a]:
        for sb, scores_b, _, _ in runs[a.b]:
            if sa != sb:
                continue                      # pair seed with seed: same data order
            rows.append(dict(seed=sa, **mcnemar(scores_a, scores_b)))
    if not rows:
        print("no seed present in both arms; cannot pair")
        return
    df = pd.DataFrame(rows)
    _ra = int(a.rank_a if a.rank_a is not None else a.rank)
    _rb = int(a.rank_b if a.rank_b is not None else a.rank)
    _r = f"r={_ra}" if _ra == _rb else f"r={_ra} vs r={_rb}  (BUDGET-MATCHED, ranks differ on purpose)"
    # the model belongs in the header: without it a Qwen result and a Llama result are the same
    # three lines in a log, and the numbers differ by eight points.
    _m = sorted({str(c.get("model", "?")).split("/")[-1]
                 for arm in (a.a, a.b) for _, _, c, _ in runs[arm]})
    print(f"McNemar paired per EXAMPLE, {'/'.join(_m)}, {a.task} {_r}, metric '{a.metric}'")
    print(f"  a = {a.a}   b = {a.b}   (n01 = b right & a wrong, n10 = a right & b wrong)\n")
    print(df.round(4).to_string(index=False))
    combine(df, a.a, a.b, a.comparisons)


if __name__ == "__main__":
    main()
