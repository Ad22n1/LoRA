"""Grids of PROTOCOL_exp1_format_qwen.md, from the server's base (configs/grids/scale_qwen15.yaml, checked). 196 runs.

    python scripts/make_e1q_grids.py
"""
import sys
from pathlib import Path

import yaml

SRC = Path("configs/grids/scale_qwen15.yaml")
if not SRC.exists():
    sys.exit(f"STOP : {SRC} introuvable")
base = dict((yaml.safe_load(open(SRC)) or {}).get("base") or {})
if base.get("task") != "format" or str(base.get("model")) != "Qwen/Qwen2.5-1.5B":
    sys.exit(f"STOP : la base n'est pas la tache de format sur Qwen2.5-1.5B (task={base.get('task')}, model={base.get('model')})")
for k in ("mode", "rank", "lr", "seed", "band_frac", "update_norm_target"):
    base.pop(k, None)
base["save_factor_steps"] = []
SEEDS = [20, 21, 22, 23, 24, 25, 26]
LRS = [1e-4, 5e-4, 1e-3, 2e-3, 5e-3, 1e-2, 2e-2]
GRIDS = {"e1q_top_r1": ("top_unfrozen", 1), "e1q_bot_r1": ("bottom_unfrozen", 1), "e1q_top_r2": ("top_unfrozen", 2), "e1q_bot_r2": ("bottom_unfrozen", 2)}
H = "# PRE-ENREGISTRE (PROTOCOL_exp1_format_qwen.md). Genere par scripts/make_e1q_grids.py. Selection 20-21, rapport 22-26. 49 runs.\n"
total = 0
for name, (mode, rank) in GRIDS.items():
    b = dict(base); b["rank"] = rank
    Path(f"configs/grids/{name}.yaml").write_text(H + yaml.safe_dump({"base": b, "grid": {"mode": [mode], "lr": LRS, "seed": SEEDS}}, sort_keys=False))
    total += len(LRS) * len(SEEDS); print(f"  {name:11s} : {mode} rang {rank}, 7 taux, 7 graines")
print(f"  total : {total} runs")
if total != 196:
    sys.exit("STOP : le total n'est pas 196")
