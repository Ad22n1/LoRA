"""Machines on which a Mistral-7B-v0.3 run has already finished (PROTOCOL_scale_mistral.md, rerun rule): they have shown enough free PARTITION memory,
a working environment and room for the model on their local disk. Prints the exclusion list (all other machines) on the last line.

    python scripts/nodes_for_mistral.py            # --report for the lists
"""
import csv
import glob
import os
import subprocess
import sys

import yaml

good = set()
for root in ("~/lora-runs", "~/lora-runs-probe"):
    for p in glob.glob(os.path.expanduser(root) + "/*/config.yaml"):
        d = os.path.dirname(p)
        try:
            if str((yaml.safe_load(open(p)) or {}).get("model")) != "mistralai/Mistral-7B-v0.3" or not open(d + "/status").read().startswith("DONE"):
                continue
            with open(d + "/results.csv", newline="") as fh:
                r = next(csv.DictReader(fh))
        except (OSError, StopIteration):
            continue
        h, g = (r.get("host") or "").split(".")[0], r.get("PARTITION") or ""
        if h and "RTX 4000 Ada" in g:
            good.add(h)
try:
    out = subprocess.run(["sinfo", "-h", "-p", "PARTITION", "-N", "-o", "%N"], capture_output=True, text=True, timeout=30).stdout
    nodes = sorted({l.strip().split(".")[0] for l in out.split() if l.strip()})
except Exception:  # noqa: BLE001
    nodes = []
if not nodes:
    sys.exit("STOP : liste des machines de la partition indisponible (sinfo)")
good = sorted(good & set(nodes))
if len(good) < 4:
    sys.exit(f"STOP : seulement {len(good)} machine(s) eprouvee(s) pour Mistral ; trop peu pour relancer")
if "--report" in sys.argv:
    print(f"  {len(nodes)} machines dans la partition ; {len(good)} ont deja termine un run de Mistral : {', '.join(good)}")
print(",".join(sorted(set(nodes) - set(good))))
