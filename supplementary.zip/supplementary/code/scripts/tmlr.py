"""Moteur des experiences TMLR (PROTOCOL_boundary.md, _single_gpu.md, _real_mica.md, _module_shape.md, _warmup_seeds.md).

    python scripts/tmlr.py <exp> <etape>        exp : e1 e2 e3 e4 e5 ; etapes : voir STAGES

Chaque etape ecrit ses grilles (configs/grids/v2_<exp>_<etape>_*.yaml), les committe et les pousse AVANT de les soumettre, puis
imprime « ETAPE: <suivante> », « ATTENTE: ... », « FINI » ou « STOP: ... ». Chaque run est retrouve par le run_dir de sa propre
configuration (lorasub.config.RunConfig), jamais par une date. Tout est epingle sur RTX 4000 Ada (scripts/nodes_for_gpu.py).
"""
import csv
import datetime as dt
import getpass
import glob
import json
import math
import os
import statistics as st
import subprocess
import sys

import yaml
from scipy import stats

REPO = os.path.expanduser("~/repo"); os.chdir(REPO); sys.path.insert(0, f"{REPO}/src")
from lorasub.config import RunConfig, _NON_ID_FIELDS  # noqa: E402
from lorasub.lora import SALTED_MODES  # noqa: E402
from lorasub.launch_grid import expand  # noqa: E402

V2 = {"__name__": "v2camp_lib"}
exec(open(f"{REPO}/scripts/v2camp.py").read().split('if __name__ == "__main__":')[0], V2)
load_runs, is_pop, clean, step_rate = V2["load_runs"], V2["is_pop"], V2["clean"], V2["step_rate"]

FMT, Q = "fmt:meta-llama/Llama-3.2-1B", "Qwen/Qwen2.5-1.5B"
GRID = [5e-4, 1e-3, 2e-3, 5e-3, 1e-2, 2e-2]
SEL, TIE, REP5, REP8 = [0, 1], [30, 31, 32], list(range(2, 7)), list(range(2, 10))
STATE = os.path.expanduser("~/.tmlr"); os.makedirs(STATE, exist_ok=True)
key_of = lambda pop: "format_parsed" if pop == FMT else "mcq_acc"  # noqa: E731
vkey_of = lambda pop: "val_" + key_of(pop)  # noqa: E731
lab = lambda r: f"{r:g}"  # noqa: E731


# ============================================================ grilles, runs, lancement
OUT_ROOT = os.path.expanduser("~/lora-runs-tmlr")      # dossiers neufs : un run TMLR n'est jamais confondu avec un run publie de meme identifiant


def write_grid(name, base, mode, rank, lrs, seeds, note, root=None):
    b = dict(base); b.update(rank=rank, alpha=rank, out_dir=root or OUT_ROOT)
    open(f"configs/grids/{name}.yaml", "w").write(f"# PRE-ENREGISTRE (TMLR). {note}. Genere par scripts/tmlr.py.\n"
                                                  + yaml.safe_dump({"base": b, "grid": {"mode": [mode], "lr": [float(x) for x in lrs], "seed": seeds}}, sort_keys=False))
    return name


def grid_runs(name):
    """[(config, run_dir, metrics ou None, PARTITION)] pour chaque combinaison de la grille."""
    out = []
    for c in expand(yaml.safe_load(open(f"configs/grids/{name}.yaml"))):
        d = str(RunConfig(**c).run_dir); m = None; PARTITION = ""
        try:
            if open(d + "/status").read().startswith("DONE"):
                m = json.load(open(d + "/metrics.json"))
                PARTITION = (next(csv.DictReader(open(d + "/results.csv"))).get("PARTITION") or "").replace("NVIDIA ", "").replace(" Generation", "").strip()
        except (OSError, ValueError, StopIteration):
            pass
        out.append((c, d, m, PARTITION))
    return out


def complete(names):
    rs = [r for n in names for r in grid_runs(n)]
    return all(r[2] is not None for r in rs), sum(r[2] is None for r in rs), len(rs)


def scores(names, key):
    """{(mode, rank, lr): {seed: valeur}} sur les runs termines des grilles."""
    out = {}
    for n in names:
        for c, d, m, PARTITION in grid_runs(n):
            if m is not None and key in m:
                out.setdefault((c["mode"], c["rank"], float(c["lr"])), {})[c["seed"]] = m[key]
    return out


def save(k, obj):
    json.dump(obj, open(f"tmlr_{k}.json", "w"), indent=1, default=str)


def load(k):
    return json.load(open(f"tmlr_{k}.json")) if os.path.exists(f"tmlr_{k}.json") else {}


def git_commit(paths, msg):
    import time
    for _ in range(90):                      # le conducteur et un surveillant peuvent committer en meme temps : attendre le depot libre
        if not os.path.exists(".git/index.lock"):
            break
        time.sleep(2)
    subprocess.run(["git", "add", "-f"] + paths, check=True)
    if subprocess.run(["git", "diff", "--cached", "--quiet"]).returncode != 0:
        subprocess.run(["git", "commit", "-qm", msg], check=True)
    if subprocess.run(["git", "push", "-q"]).returncode != 0:
        sys.exit("STOP: push echoue ; rien n'est soumis")
    return subprocess.run(["git", "log", "-1", "--format=%h %ad", "--date=format:%d/%m %H:%M"], capture_output=True, text=True).stdout.strip()


def deadline():
    f = os.path.join(STATE, "arret")
    if os.path.exists(f):
        return open(f).read().strip()
    now = dt.datetime.now(); mon = now + dt.timedelta(days=(7 - now.weekday()) % 7 or 7)
    return mon.replace(hour=7, minute=55, second=0, microsecond=0).strftime("%Y-%m-%dT%H:%M:%S")


def launch(k, names, msg):
    names = sorted(set(names))
    h = git_commit([f"configs/grids/{n}.yaml" for n in names] + glob.glob(f"tmlr_{k}*.json"), f"TMLR {k} : {msg} ({len(names)} grille(s)), committe avant soumission")
    print(f"  grilles committees et poussees : {h}")
    excl = subprocess.run([sys.executable, "scripts/nodes_for_gpu.py", "RTX 4000 Ada"], capture_output=True, text=True).stdout.strip().splitlines()
    excl = excl[-1] if excl else ""
    if not excl or excl.startswith("STOP"):
        sys.exit(f"STOP: epinglage sur RTX 4000 Ada impossible ({excl}) ; rien n'est soumis")
    for n in names:
        gd = os.path.expanduser(f"~/lora-grid/{n}")
        o = subprocess.run([sys.executable, "-m", "lorasub.launch_grid", f"configs/grids/{n}.yaml", "--grid_dir", gd, "--partition", "PARTITION",
                            "--time", "00:45:00", "--max_par", "8", "--venv", f"/tmp/lora-{getpass.getuser()}/venv"], capture_output=True, text=True,
                           env=dict(os.environ, PYTHONPATH=f"{REPO}/src" + os.pathsep + os.environ.get("PYTHONPATH", "")))
        txt = o.stdout + o.stderr
        if " 0 to run" in txt:
            print(f"  RIEN    {n} : deja complete"); continue
        if not os.path.exists(f"{gd}/slurm_array.sh"):
            sys.exit(f"STOP: {n} : le lanceur n'a pas ecrit de job ({txt.strip()[-300:]})")
        j = subprocess.run(["sbatch", "--parsable", f"--deadline={deadline()}", f"--exclude=node,{excl}", f"{gd}/slurm_array.sh"], capture_output=True, text=True)
        if j.returncode != 0:
            sys.exit(f"STOP: sbatch a refuse {n} : {j.stderr.strip()[:200]}")
        print(f"  soumis  {n} : job {j.stdout.strip()}")


# ============================================================ recherche des cellules publiees
def published(pop, mode, rank, value, seeds=REP5):
    """(taux, run de reference a la graine 2) de la cellule publiee : moyenne des graines = valeur publiee a 1e-4 ;
    plusieurs taux : celui que la selection a retenu (meilleure validation sur 0 et 1)."""
    lr, sel = _published(pop, mode, rank, value, seeds)
    return lr, sel[seeds[0]][2]


def published_values(pop, mode, rank, value, seeds=REP5):
    """(taux, {graine: score}) de la cellule publiee, pour les comparaisons appariees."""
    lr, sel = _published(pop, mode, rank, value, seeds)
    return lr, {s_: sel[s_][0] for s_ in seeds}


def _published(pop, mode, rank, value, seeds):
    runs = [r for r in load_runs() if is_pop(r[0], pop) and clean(r[0]) and r[0].get("mode") == mode and r[0].get("rank") == rank]
    by = {}
    for c, m, d in runs:
        if c.get("seed") in seeds and key_of(pop) in m:
            by.setdefault(float(c["lr"]), {}).setdefault(c["seed"], []).append((m[key_of(pop)], d, c))
    hits = []
    for lr, s in by.items():
        if sorted(s) != list(seeds):
            continue
        for pick in (0, -1):
            sel = {sd: sorted(v, key=lambda x: os.path.getmtime(x[1] + "/config.yaml"))[pick] for sd, v in s.items()}
            if abs(st.mean(x[0] for x in sel.values()) - value) <= 1e-4:
                hits.append((lr, sel)); break
    if not hits:
        sys.exit(f"STOP: cellule publiee {mode} r={rank} ({value}) introuvable")
    if len(hits) > 1:
        val = {lr: st.mean(m.get(vkey_of(pop), -1) for c, m, d in runs if float(c["lr"]) == lr and c.get("seed") in SEL) for lr, _ in hits}
        hits = [max(hits, key=lambda h: val[h[0]])]
    return hits[0]


def base_from(cfg):
    b = dict(cfg)
    for x in ("mode", "lr", "seed", "rank", "alpha", "band_frac", "update_norm_target"):
        b.pop(x, None)
    b["save_factor_steps"] = []
    return b


def t_paired(diffs):
    n = len(diffs); m = st.mean(diffs); sd = st.stdev(diffs); se = sd / n ** 0.5
    return m, se, (m / se if se > 0 else float("inf")), n - 1


def tie_or_best(means):
    """(meilleur, egalite?) sur {taux: moyenne}."""
    order = sorted(means, key=lambda r: -means[r])
    return order[0], (len(order) > 1 and means[order[0]] - means[order[1]] <= 0.005), order[:2]


def settle_tie(means5):
    order = sorted(means5, key=lambda r: -means5[r])
    lead = means5[order[0]] - means5[order[1]]
    return order[0], lead > 0.005, lead


# ============================================================ E1 : la borne de la grille a 2e-2
E1_CELLS = [("top", 1, 0.5107), ("bottom", 1, 0.4547), ("random", 1, 0.5288), ("random", 4, 0.7023)]     # valeurs publiees (tab:ranks)
# Meme configuration, au sens du trainer : les champs hors identifiant (lorasub.config._NON_ID_FIELDS : eval_limit, eval_forgetting,
# notes, chemins...) sont ignores ; les champs ajoutes apres coup valent, absents, leur ancienne valeur fixe (max_new_tokens etait code
# en dur a 128, data_fingerprint vide, token_weighted_loss faux) ; subspace_salted n'est compare que pour les modes a tirage sale,
# absent valant faux (runs d'avant le salage).
LEGACY = {"data_fingerprint": "", "max_new_tokens": 128, "token_weighted_loss": False}


def norm_config(c):
    d = {k: v for k, v in c.items() if k not in _NON_ID_FIELDS and k not in ("seed", "lr", "run_id")}
    for k, v in LEGACY.items():
        if d.get(k) is None:
            d[k] = v
    if d.get("mode") in SALTED_MODES:
        d["subspace_salted"] = bool(d.get("subspace_salted"))
    else:
        d.pop("subspace_salted", None)
    return d


def same_config(c, ref):
    """Meme configuration que la cellule rapportee, a la graine et au taux pres."""
    a, b = norm_config(c), norm_config(ref)
    return all(str(a.get(k)) == str(b.get(k)) for k in set(a) | set(b))


def complete_ref(allruns, mode, rank, pub):
    """La configuration COMPLETE (graines 2 a 6, meme taux) dont la moyenne est la plus proche de la valeur publiee. Une graine relancee
    (plusieurs runs de la meme configuration) : toutes les combinaisons d'un run par graine sont essayees. Un run isole d'une autre
    configuration n'est jamais retenu ; un ecart au publie est rapporte."""
    import itertools
    cands, seen = [], []
    for c, m, d in allruns:
        if c.get("mode") == mode and c.get("rank") == rank and c.get("seed") == REP5[0]:
            by = {}
            for c2, m2, d2 in allruns:
                if (c2.get("mode") == mode and c2.get("rank") == rank and same_config(c2, c) and abs(float(c2["lr"]) - float(c["lr"])) < 1e-12
                        and c2.get("seed") in REP5 and "format_parsed" in m2):
                    by.setdefault(c2["seed"], []).append((m2["format_parsed"], c2))
            seen.append(f"{float(c['lr']):g} : graines {sorted(by)} ({sum(len(v) for v in by.values())} runs)")
            if sorted(by) != REP5:
                continue
            combos = itertools.product(*[by[s_] for s_ in REP5]) if math.prod(len(by[s_]) for s_ in REP5) <= 256 else \
                [[sorted(by[s_], key=lambda x: str(x))[0] for s_ in REP5], [sorted(by[s_], key=lambda x: str(x))[-1] for s_ in REP5]]
            for combo in combos:
                mean = st.mean(x[0] for x in combo)
                cands.append((abs(mean - pub), float(c["lr"]), combo[0][1], mean))
    if not cands:
        sys.exit(f"STOP: E1 {mode} r={rank} : aucune configuration complete sur les graines 2 a 6 ; trouve : " + " | ".join(sorted(set(seen))))
    gap, lr, ref, mean = min(cands, key=lambda x: x[0])
    return lr, ref, mean


def e1_sel():
    S = {"cells": {}}; grids = []
    allruns = [r for r in load_runs() if is_pop(r[0], FMT) and clean(r[0])]
    for mode, rank, pub in E1_CELLS:
        lr_pub, ref, ref_mean = complete_ref(allruns, mode, rank, pub)   # configuration complete la plus proche de la valeur publiee
        rr = [(c, m, d) for c, m, d in allruns if c.get("mode") == mode and c.get("rank") == rank and same_config(c, ref)]
        val = {}
        for c, m, d in rr:
            if c.get("seed") in SEL and float(c["lr"]) <= 1e-2 + 1e-12 and "val_format_parsed" in m:
                val.setdefault(float(c["lr"]), {}).setdefault(c["seed"], []).append(m["val_format_parsed"])
        means = {lr: st.mean(st.mean(v[s]) for s in SEL) for lr, v in val.items() if sorted(v) == SEL}
        if not means:
            sys.exit(f"STOP: E1 {mode} r={rank} : aucun run de selection de la configuration rapportee")
        recomputed = max(means, key=means.get); cid = f"{mode}_r{rank}"
        lims = {c.get("eval_limit") for c, m, d in rr if c.get("seed") in SEL and float(c["lr"]) <= 1e-2 + 1e-12}
        if len(lims) != 1:
            sys.exit(f"STOP: E1 {mode} r={rank} : les runs de selection ont plusieurs eval_limit {sorted(map(str, lims))}")
        lim = lims.pop()                                       # la validation porte sur min(eval_limit, 500) exemples : meme valeur que la grille
        base_sel, base_rep = dict(base_from(ref), eval_limit=lim), base_from(ref)
        S["cells"][cid] = {"mode": mode, "rank": rank, "published": pub, "reference_mean": ref_mean, "main_grid": {lab(r): v for r, v in sorted(means.items())},
                           "selected_before": lr_pub, "recomputed_on_these_runs": recomputed, "base": base_sel, "base_rep": base_rep, "sel_eval_limit": lim,
                           "duplicates_at_selection_seeds": {lab(r): {s: len(v[s]) for s in v} for r, v in val.items()}}
        print(f"  {cid} : configuration de reference a {lr_pub:g}, graines 2 a 6 : {ref_mean:.4f} (publie {pub})"
              + ("" if abs(ref_mean - pub) <= 1e-4 else "  (ECART AU PUBLIE : declare)") + f" ; selection relue sur sa configuration : {recomputed:g}"
              + f" ({sum(len(v) for x in val.values() for v in x.values())} runs, eval_limit {lim})"
              + ("" if abs(recomputed - lr_pub) < 1e-12 else "  (DIFFERENT : declare a la lecture)"))
        grids.append(write_grid(f"v2_e1_sel_{cid}", base_sel, mode, rank, [2e-2], SEL, f"E1 : {cid} a 2e-2, graines 0 et 1, eval_limit {lim} comme la grille"))
    save("e1", S); launch("e1", grids, "borne de la grille, 2e-2 sur les graines de selection"); print("ETAPE: selread")


def e1_selread():
    S = load("e1"); grids = []
    for cid, C in S["cells"].items():
        sc = scores([f"v2_e1_sel_{cid}"], "val_format_parsed").get((C["mode"], C["rank"], 2e-2), {})
        if sorted(sc) != SEL:
            print(f"ATTENTE: E1 {cid} : 2e-2 incomplet"); return
        means = {float(r): v for r, v in C["main_grid"].items()}; means[2e-2] = st.mean(sc[s] for s in SEL)
        best, tie, two = tie_or_best(means)
        C.update(with_2e2=means[2e-2], best=best, tie=tie, tied=two)
        if tie:
            grids.append(write_grid(f"v2_e1_tie_{cid}", C["base"], C["mode"], C["rank"], two, TIE, f"E1 : egalite {cid}, graines 30 a 32"))
    save("e1", S)
    if grids:
        launch("e1", grids, "egalites, graines 30 a 32"); print("ETAPE: tieread")
    else:
        print("ETAPE: decide")


def e1_tieread():
    S = load("e1")
    for cid, C in S["cells"].items():
        if not C["tie"]:
            continue
        sc = scores([f"v2_e1_tie_{cid}"], "val_format_parsed")
        m5 = {}
        for r in C["tied"]:
            s30 = sc.get((C["mode"], C["rank"], float(r)), {})
            if sorted(s30) != TIE:
                print(f"ATTENTE: E1 {cid} : graines 30 a 32 incompletes"); return
            s01 = (C["with_2e2"] * 2 if float(r) == 2e-2 else float(C["main_grid"][lab(float(r))]) * 2)
            m5[float(r)] = (s01 + sum(s30.values())) / 5
        w, ok, lead = settle_tie(m5); C.update(best=w, tie_means5={lab(r): v for r, v in m5.items()}, tie_resolved=ok, tie_lead=lead)
    save("e1", S); print("ETAPE: decide")


def e1_decide():
    S = load("e1"); grids = []
    for cid, C in S["cells"].items():
        C["changed"] = abs(float(C["best"]) - float(C["selected_before"])) > 1e-12
        if C["changed"]:
            grids.append(write_grid(f"v2_e1_rep_{cid}", C["base_rep"], C["mode"], C["rank"], [float(C["best"])], REP5, f"E1 : {cid} au nouveau taux, graines 2 a 6"))
    save("e1", S)
    if grids:
        launch("e1", grids, "cellules dont le taux change, graines 2 a 6"); print("ETAPE: read")
    else:
        print("ETAPE: read")


def e1_read():
    S = load("e1"); L = ["==================== E1 : la borne de la grille a 2e-2 (Llama-3.2-1B, tache de format) ===================="]
    for cid, C in S["cells"].items():
        L.append(f"  {cid} : validation (graines 0, 1) " + ", ".join(f"{r} -> {v:.4f}" for r, v in C["main_grid"].items()) + f", 2e-2 -> {C['with_2e2']:.4f}")
        if abs(float(C["recomputed_on_these_runs"]) - float(C["selected_before"])) > 1e-12:
            L.append(f"    NOTE : sur ces runs, la grille principale seule retiendrait {float(C['recomputed_on_these_runs']):g}, le papier rapporte {float(C['selected_before']):g}")
        if C["tie"]:
            L.append(f"    egalite entre {C['tied']} : moyennes sur 5 graines {C['tie_means5']} ; avance {C['tie_lead']:.4f} -> "
                     + ("tranchee" if C["tie_resolved"] else "NON tranchee (meilleure moyenne retenue, declaree)"))
        if abs(C["reference_mean"] - C["published"]) > 1e-4:
            L.append(f"    NOTE : la configuration de reference vaut {C['reference_mean']:.4f} sur les graines 2 a 6, le papier publie {C['published']:.4f}")
        L.append(f"    taux selectionne : avant {C['selected_before']:g}, apres {float(C['best']):g} -> " + ("CHANGE" if C["changed"] else "inchange"))
        if C["changed"]:
            new = scores([f"v2_e1_rep_{cid}"], "format_parsed").get((C["mode"], C["rank"], float(C["best"])), {})
            if sorted(new) != REP5:
                print(f"ATTENTE: E1 {cid} : rapport incomplet"); return
            L.append(f"    score rapporte (graines 2 a 6) : publie {C['published']:.4f}, configuration de reference {C['reference_mean']:.4f}, nouveau taux {st.mean(new.values()):.4f}")
    finish("e1", L, S)


# ============================================================ E2 : rang 2 sur un seul modele de PARTITION
E2_ARMS = [("top", 2, 0.6443), ("bottom", 2, 0.5922), ("dual_top", 2, 0.7739), ("dual_bottom", 2, 0.7818), ("free", 1, 0.7684),
           ("top_unfrozen", 1, 0.7928), ("bottom_unfrozen", 1, 0.7954)]


def e2_rep():
    S = {"arms": {}}; grids = []
    for mode, rank, v in E2_ARMS:
        lr, ref = published(FMT, mode, rank, v); aid = f"{mode}_r{rank}"
        S["arms"][aid] = {"mode": mode, "rank": rank, "rate": lr, "published": v}
        grids.append(write_grid(f"v2_e2_rep_{aid}", base_from(ref), mode, rank, [lr], REP5, f"E2 : {aid} au taux rapporte, graines 2 a 6, un seul modele de PARTITION"))
    save("e2", S); print("  taux rapportes : " + ", ".join(f"{a} {x['rate']:g}" for a, x in S["arms"].items()))
    launch("e2", grids, "rang 2 sur un seul modele de PARTITION"); print("ETAPE: read")


def e2_read():
    S = load("e2"); V = {}; gpus = set()
    for aid, A in S["arms"].items():
        rs = grid_runs(f"v2_e2_rep_{aid}")
        if any(r[2] is None for r in rs):
            print(f"ATTENTE: E2 {aid} incomplet"); return
        V[aid] = {r[0]["seed"]: r[2]["format_parsed"] for r in rs}; gpus |= {r[3] for r in rs}
    if gpus != {"RTX 4000 Ada"}:
        sys.exit(f"STOP: E2 : modeles de PARTITION {sorted(gpus)} ; le protocole exige RTX 4000 Ada seul (runs a relancer, compte a rapporter)")
    pub = {a: x["published"] for a, x in S["arms"].items()}
    L = ["==================== E2 : rang 2 sur un seul modele de PARTITION (RTX 4000 Ada ; Llama-3.2-1B, tache de format ; graines 2 a 6) ===================="]
    for aid in V:
        L.append(f"  {aid:18s} a {S['arms'][aid]['rate']:<7g} : {st.mean(V[aid].values()):.4f} (publie {pub[aid]:.4f}, ecart {(st.mean(V[aid].values()) - pub[aid]) * 100:+.2f})")
    res = {}
    for band, Bf, Af, Bt in (("top", "top_r2", "dual_top_r2", "top_unfrozen_r1"), ("bottom", "bottom_r2", "dual_bottom_r2", "bottom_unfrozen_r1")):
        G = [(V["free_r1"][s] - V[Bf][s]) * 100 for s in REP5]; AB = [(V[Af][s] - V[Bf][s]) * 100 for s in REP5]; R = [(V[Bt][s] - V[Bf][s]) * 100 for s in REP5]
        mG, seG, tG, df = t_paired(G); mA, seA, tA, _ = t_paired(AB); mR, seR, _, _ = t_paired(R)
        q = stats.t.ppf(0.975, df); loR, hiR = mR - q * seR, mR + q * seR
        res[band] = dict(G=(mG, tG, tG > 3.495), AB=(mA, tA, tA > 3.495), R=(mR, loR, hiR, loR > 0.7 * mG))
        pG = (pub["free_r1"] - pub[Bf]) * 100; pA = (pub[Af] - pub[Bf]) * 100; pR = (pub[Bt] - pub[Bf]) * 100
        L.append(f"  {band}: G = {mG:+.2f}, t = {tG:.2f} -> {'ETABLI' if tG > 3.495 else 'non etabli'} (publie {pG:+.2f}, etabli)")
        L.append(f"  {band}: A gele - B gele = {mA:+.2f}, t = {tA:.2f} -> {'ETABLI' if tA > 3.495 else 'non etabli'} (publie {pA:+.2f}, etabli)")
        L.append(f"  {band}: R = {mR:+.2f} [{loR:+.2f}, {hiR:+.2f}] contre 0,7 G = {0.7 * mG:.2f} -> {'l essentiel (etabli)' if loR > 0.7 * mG else 'non concluant'} (publie {pR:+.2f})")
    allok = all(r["G"][2] and r["AB"][2] and r["R"][3] for r in res.values())
    L.append(f"  TOUS LES RESULTATS ETABLIS DU PAPIER LE RESTENT : {'OUI' if allok else 'NON'}")
    finish("e2", L, S)


# ============================================================ E3 : le vrai MiCA au rang 16
MICA = dict(mode="mica_peft", lr=5e-4, epochs=4.0, target_tokens=None, max_steps=None, batch_size=4, grad_accum=1, warmup_ratio=0.1,
            weight_decay=0.01, max_grad_norm=0.3, lora_dropout=0.05)


def e3_rep():
    lrb, refb = published(Q, "bottom", 16, 0.4984); lrf, reff = published(Q, "free", 7, 0.5616)
    bm = base_from(refb)
    for x in ("target_tokens", "max_steps", "epochs", "batch_size", "grad_accum", "warmup_ratio", "weight_decay", "max_grad_norm", "lora_dropout"):
        bm[x] = MICA[x]
    S = {"bottom_r16": lrb, "free_r7": lrf, "mica": MICA}; save("e3", S)
    g = [write_grid("v2_e3_rep_mica_r16", bm, "mica_peft", 16, [MICA["lr"]], REP5, "E3 : MiCA (PEFT 0.21.0), recette du papier MiCA, graines 2 a 6"),
         write_grid("v2_e3_rep_bottom_r16", base_from(refb), "bottom", 16, [lrb], REP5, "E3 : bottom r=16 au taux selectionne, graines 2 a 6"),
         write_grid("v2_e3_rep_free_r7", base_from(reff), "free", 7, [lrf], REP5, "E3 : LoRA libre r=7 (budget egal) au taux selectionne, graines 2 a 6")]
    print(f"  bottom r=16 a {lrb:g} ; libre r=7 a {lrf:g} ; MiCA a {MICA['lr']:g}, {MICA['epochs']:g} epoques, lot {MICA['batch_size']}")
    launch("e3", g, "vrai MiCA au rang 16"); print("ETAPE: read")


def tokens_steps(d):
    try:
        rows = list(csv.DictReader(open(d + "/log.csv"))); return int(float(rows[-1]["tokens_seen"])), int(float(rows[-1]["step"]))
    except Exception:
        return None, None


def e3_read():
    S = load("e3"); V, TS = {}, {}
    for a in ("mica_r16", "bottom_r16", "free_r7"):
        rs = grid_runs(f"v2_e3_rep_{a}")
        if any(r[2] is None for r in rs):
            print(f"ATTENTE: E3 {a} incomplet"); return
        V[a] = {r[0]["seed"]: r[2]["mcq_acc"] for r in rs}; TS[a] = [tokens_steps(r[1]) for r in rs]
    G = [(V["free_r7"][s] - V["mica_r16"][s]) * 100 for s in REP5]; m, se, t, df = t_paired(G)
    D = [(V["mica_r16"][s] - V["bottom_r16"][s]) * 100 for s in REP5]; md, sed, td, _ = t_paired(D); q = stats.t.ppf(0.975, df)
    L = ["==================== E3 : le vrai MiCA au rang 16 (OpenBookQA, Qwen2.5-1.5B ; graines 2 a 6) ===================="]
    for a in V:
        tk = [x[0] for x in TS[a] if x[0] is not None]; sp = [x[1] for x in TS[a] if x[1] is not None]
        L.append(f"  {a:11s} : {st.mean(V[a].values()):.4f} ; tokens supervises {st.median(tk):,.0f} ; pas d'optimisation {st.median(sp):.0f}")
    est = t > 2.776
    L.append(f"  G_MiCA = libre r=7 - MiCA = {m:+.2f} [{m - q * se:+.2f}, {m + q * se:+.2f}], t = {t:.2f} -> {'ETABLI' if est else 'non etabli'} (seuil 2,776)")
    L.append(f"  MiCA - notre bottom r=16 (descriptif) = {md:+.2f} [{md - q * sed:+.2f}, {md + q * sed:+.2f}]")
    L.append("  LECTURE FIXEE (addendum) : " + ("MiCA entraine avec sa propre recette reste derriere le LoRA a budget egal entraine avec la notre ; "
             "le papier le dira en ces termes, sans pretendre que le cout tient a entrainement egal" if est else
             "le papier doit dire que la recette de MiCA y comble l'ecart"))
    finish("e3", L, S)


# ============================================================ E3b : le LoRA libre avec la recette de MiCA (ADDENDUM_real_mica_2.md)
def e3b_rep():
    lrf, reff = published(Q, "free", 7, 0.5616)
    b = base_from(reff)
    for x in ("target_tokens", "max_steps", "epochs", "batch_size", "grad_accum", "warmup_ratio", "weight_decay", "max_grad_norm", "lora_dropout"):
        b[x] = MICA[x]
    save("e3b", {"free_r7_ref_rate": lrf, "recipe": MICA})
    g = [write_grid("v2_e3b_rep_lora_r7", b, "lora_peft", 7, [MICA["lr"]], REP5, "E3b : LoRA standard de PEFT 0.21.0, r=7, recette de MiCA, graines 2 a 6")]
    launch("e3b", g, "LoRA libre avec la recette de MiCA"); print("ETAPE: read")


def e3b_read():
    V, TS = {}, {}
    for a, grid in (("lora_r7_recette_MiCA", "v2_e3b_rep_lora_r7"), ("mica_r16", "v2_e3_rep_mica_r16"), ("free_r7_notre_recette", "v2_e3_rep_free_r7")):
        rs = grid_runs(grid)
        if any(r[2] is None for r in rs):
            print(f"ATTENTE: E3b {a} incomplet"); return
        V[a] = {r[0]["seed"]: r[2]["mcq_acc"] for r in rs}; TS[a] = [tokens_steps(r[1]) for r in rs]
    gpus = {r[3] for r in grid_runs("v2_e3b_rep_lora_r7")}
    G = [(V["lora_r7_recette_MiCA"][s] - V["mica_r16"][s]) * 100 for s in REP5]; m, se, t, df = t_paired(G); q = stats.t.ppf(0.975, df)
    D = [(V["lora_r7_recette_MiCA"][s] - V["free_r7_notre_recette"][s]) * 100 for s in REP5]; md, sed, _, _ = t_paired(D)
    L = [f"==================== E3b : le LoRA libre avec la recette de MiCA (OpenBookQA, Qwen2.5-1.5B ; graines 2 a 6 ; PARTITION {sorted(gpus)}) ===================="]
    for a in V:
        tk = [x[0] for x in TS[a] if x[0] is not None]; sp = [x[1] for x in TS[a] if x[1] is not None]
        L.append(f"  {a:22s} : {st.mean(V[a].values()):.4f} ; tokens supervises {st.median(tk):,.0f} ; pas d'optimisation {st.median(sp):.0f}")
    est = t > 2.776
    L.append(f"  G_egal = LoRA libre (recette de MiCA) - MiCA = {m:+.2f} [{m - q * se:+.2f}, {m + q * se:+.2f}], t = {t:.2f} -> {'ETABLI' if est else 'non etabli'} (seuil 2,776)")
    L.append(f"  (descriptif) LoRA libre : recette de MiCA - notre recette = {md:+.2f} [{md - q * sed:+.2f}, {md + q * sed:+.2f}]")
    L.append("  LECTURE FIXEE (second addendum) : " + ("MiCA reste derriere le LoRA a budget egal, a recette egale et a entrainement egal" if est else
             "le papier garde la phrase du premier addendum (comparaison de recettes) et n'en tire rien de plus"))
    finish("e3b", L, {})


# ============================================================ E6 : A gele sur une base orthonormee aleatoire (PROTOCOL_random_A.md)
E6_ROOT = os.path.expanduser("~/lora-runs-randA")
E6_CELLS = {"fmt_r2": (FMT, 2, ("random_ortho", 2, 0.6534)), "obqa_r2": (Q, 2, ("random_ortho", 2, 0.4592)),
            "obqa_r16": (Q, 16, ("dual_top", 16, 0.5544))}          # reference de configuration : run publie de la paire
E6_PARAMS = {"fmt_r2": 753664, "obqa_r2": 1290240, "obqa_r16": 10321920}
E6_COMP = {"fmt_r2": [("random_ortho", 2, 0.6534), ("dual_top", 2, 0.7739), ("dual_bottom", 2, 0.7818), ("free", 1, 0.7684)],
           "obqa_r2": [("random_ortho", 2, 0.4592), ("dual_top", 2, 0.5308), ("dual_bottom", 2, 0.5248), ("free", 1, 0.5456)],
           "obqa_r16": [("dual_top", 16, 0.5544), ("dual_bottom", 16, 0.5364), ("free", 7, 0.5616)]}


def e6_sel():
    S = {"cells": {}, "published": {}}; grids = []
    for cid, (pop, rank, (rm, rr, rv)) in E6_CELLS.items():
        for m, r, v in E6_COMP[cid]:                          # bras publies identifies AVANT tout run
            lr, vals = published_values(pop, m, r, v)
            S["published"][f"{cid}:{m}_r{r}"] = {"rate": lr, "published": v, "seeds": {str(k): x for k, x in vals.items()}}
        lr0, ref = published(pop, rm, rr, rv)
        b = dict(base_from(ref), subspace_salted=True)
        S["cells"][cid] = {"pop": pop, "rank": rank, "rates": list(GRID), "base": b, "ext": 0, "state": "sel", "ref_salted": ref.get("subspace_salted"),
                           "ref_subspace_seed": ref.get("subspace_seed")}
        grids.append(write_grid(f"v2_e6_sel_{cid}", b, "dual_random_ortho", rank, GRID, SEL, f"E6 : {cid}, selection sur les graines 0 et 1", root=E6_ROOT))
        print(f"  {cid} : reference {rm} r={rr} ({rv}) a {lr0:g}, sale={ref.get('subspace_salted')}, subspace_seed={ref.get('subspace_seed')}")
    save("e6", S); launch("e6", grids, "A gele sur une base orthonormee aleatoire : selection"); print("ETAPE: selread")


def e6_selread():
    S = load("e6"); grids = []; pending = False
    for cid, C in S["cells"].items():
        if C["state"] == "done":
            continue
        vk = vkey_of(C["pop"]); names = [n for n in (f"v2_e6_sel_{cid}", f"v2_e6_ext1_{cid}") if os.path.exists(f"configs/grids/{n}.yaml")]
        sc = scores(names, vk); means = {}
        for r in C["rates"]:
            s_ = sc.get(("dual_random_ortho", C["rank"], float(r)), {})
            if sorted(s_) != SEL:
                pending = True; break
            means[float(r)] = st.mean(s_[x] for x in SEL)
        else:
            if C["state"] == "tie":
                s30 = scores([f"v2_e6_tie_{cid}"], vk); m5 = {}
                for r in C["tied"]:
                    x = s30.get(("dual_random_ortho", C["rank"], float(r)), {})
                    if sorted(x) != TIE:
                        pending = True; break
                    m5[float(r)] = (means[float(r)] * 2 + sum(x.values())) / 5
                else:
                    w, ok, lead = settle_tie(m5); C.update(selected=w, tie_means5={lab(r): v for r, v in m5.items()}, tie_resolved=ok, tie_lead=lead, state="done")
                continue
            best = max(means, key=means.get); lo, hi = min(C["rates"]), max(C["rates"])
            if best in (lo, hi) and C["ext"] < 1:
                nr = step_rate(best, best == hi); C["rates"].append(nr); C["ext"] += 1
                grids.append(write_grid(f"v2_e6_ext1_{cid}", C["base"], "dual_random_ortho", C["rank"], [nr], SEL, f"E6 : {cid}, prolongement d'un cran ({nr:g})", root=E6_ROOT))
                pending = True; continue
            C["means"] = {lab(r): v for r, v in sorted(means.items())}; C["edge_after_extension"] = best in (lo, hi)
            b2, tie, two = tie_or_best(means)
            if tie:
                C.update(state="tie", tied=two); pending = True
                grids.append(write_grid(f"v2_e6_tie_{cid}", C["base"], "dual_random_ortho", C["rank"], two, TIE, f"E6 : egalite {cid}", root=E6_ROOT))
            else:
                C.update(selected=b2, state="done")
    save("e6", S)
    if grids:
        launch("e6", grids, "A gele sur une base orthonormee aleatoire : prolongements et egalites")
    if pending or grids:
        print("ATTENTE: E6 : selection en cours"); return
    bad = [f"{cid} : {trainable_of(f'v2_e6_sel_{cid}')} au node de {E6_PARAMS[cid]}" for cid in S["cells"] if trainable_of(f"v2_e6_sel_{cid}") != E6_PARAMS[cid]]
    if bad:
        sys.exit("STOP: E6 : parametres entraines differents du protocole : " + " ; ".join(bad))
    print("  parametres entraines : conformes au protocole (" + ", ".join(f"{c} {E6_PARAMS[c]:,}" for c in S["cells"]) + ")"); print("ETAPE: rep")


def e6_rep():
    S = load("e6")
    grids = [write_grid(f"v2_e6_rep_{cid}", C["base"], "dual_random_ortho", C["rank"], [float(C["selected"])], REP5, f"E6 : {cid} au taux selectionne, graines 2 a 6", root=E6_ROOT)
             for cid, C in S["cells"].items()]
    launch("e6", grids, "A gele sur une base orthonormee aleatoire : rapport sur les graines 2 a 6"); print("ETAPE: read")


def e6_read():
    S = load("e6"); V = {}
    for cid, C in S["cells"].items():
        rs = grid_runs(f"v2_e6_rep_{cid}")
        if any(r[2] is None for r in rs):
            print(f"ATTENTE: E6 {cid} incomplet"); return
        V[cid] = {r[0]["seed"]: r[2][key_of(C["pop"])] for r in rs}
    gpus = {r[3] for cid in S["cells"] for r in grid_runs(f"v2_e6_rep_{cid}")}
    q = stats.t.ppf(0.975, 4)
    L = [f"==================== E6 : A gele sur une base orthonormee aleatoire (graines 2 a 6 ; PARTITION {sorted(gpus)}) ===================="]
    verdict = {}
    for cid, C in S["cells"].items():
        L.append(f"  {cid} : taux {float(C['selected']):g}" + (" (grille prolongee d'un cran)" if C.get("ext") else "")
                 + (" (AU BORD apres le prolongement, declare)" if C.get("edge_after_extension") else "")
                 + (f" (egalite {'tranchee' if C.get('tie_resolved') else 'NON tranchee, declaree'} : {C['tie_means5']})" if "tie_means5" in C else "")
                 + f" ; validation {C['means']} ; parametres {E6_PARAMS[cid]:,}")
        L.append("    par graine : " + ", ".join(f"{s_}: {V[cid][s_]:.4f}" for s_ in REP5) + f" ; moyenne {st.mean(V[cid].values()):.4f}")
        for m, r, v in E6_COMP[cid]:
            P = S["published"][f"{cid}:{m}_r{r}"]; pv = {int(k): x for k, x in P["seeds"].items()}
            d = [(V[cid][s_] - pv[s_]) * 100 for s_ in REP5]; md, se, t, _ = t_paired(d)
            line = f"    dual_random_ortho - {m} r={r} (publie {v}, a {P['rate']:g}) = {md:+.2f} [{md - q * se:+.2f}, {md + q * se:+.2f}]"
            if m == "random_ortho":
                ok = t > 3.495; verdict[cid] = ok
                line += f", t = {t:.2f} -> P1 {'ETABLI' if ok else 'non etabli'} (seuil 3,495)"
            L.append(line)
    p1 = [verdict.get("fmt_r2"), verdict.get("obqa_r2")]
    if all(p1):
        lect = "l'avantage de geler A sur geler B ne depend pas d'un placement spectral de A"
    elif any(p1):
        lect = "P1 tient sur une paire seulement : " + ", ".join(f"{c} {'oui' if verdict[c] else 'non'}" for c in ("fmt_r2", "obqa_r2"))
    else:
        lect = "l'avantage de geler A depend au moins en partie de son placement spectral"
    L.append(f"  LECTURE FIXEE : {lect}")
    finish("e6", L, S)


# ============================================================ E4 : le facteur gele contre la forme du module
E4_PAIRS = {"fmt": (FMT, ("top", 2, 0.6443), 8), "obqa": (Q, ("top", 2, 0.4652), 12)}
E4_GROUPS = {"G1": ["down_proj"], "G2": ["gate_proj", "up_proj"]}
E4_PARAMS = {("fmt", "G1"): {"top_r2": 262144, "bottom_r2": 262144, "dual_top_r2": 65536, "dual_bottom_r2": 65536, "free_r1": 163840},
             ("fmt", "G2"): {"top_r2": 131072, "bottom_r2": 131072, "dual_top_r2": 524288, "dual_bottom_r2": 524288, "top_r8": 524288, "bottom_r8": 524288,
                             "free_r1": 327680},
             ("obqa", "G1"): {"top_r2": 501760, "bottom_r2": 501760, "dual_top_r2": 86016, "dual_bottom_r2": 86016, "free_r1": 293888},
             ("obqa", "G2"): {"top_r2": 172032, "bottom_r2": 172032, "dual_top_r2": 1003520, "dual_bottom_r2": 1003520, "top_r12": 1032192,
                              "bottom_r12": 1032192, "free_r1": 587776}}


def e4_arms(pair, group):
    out = [("top", 2), ("bottom", 2), ("dual_top", 2), ("dual_bottom", 2)]
    if group == "G2":
        r = E4_PAIRS[pair][2]; out += [("top", r), ("bottom", r)]
    return out + [("free", 1)]


def e4_sel():
    S = {"cells": {}, "base": {}}; grids = []
    for pair, (pop, (m0, r0, v0), _) in E4_PAIRS.items():
        lr0, ref = published(pop, m0, r0, v0); S["base"][pair] = base = base_from(ref)
        grids.append(write_grid(f"v2_e4_base_{pair}", base, "baseline", 1, [1e-3], [0], f"E4 : modele de base, {pair} (aucun entrainement)"))
        for grp, mods in E4_GROUPS.items():
            b = dict(base, target_modules=mods)
            for mode, rank in e4_arms(pair, grp):
                cid = f"{pair}_{grp}_{mode}_r{rank}"
                S["cells"][cid] = {"pair": pair, "group": grp, "mode": mode, "rank": rank, "rates": list(GRID), "base": b, "ext": 0, "state": "sel"}
                grids.append(write_grid(f"v2_e4_sel_{cid}", b, mode, rank, GRID, SEL, f"E4 : {cid}, selection sur les graines 0 et 1"))
    save("e4", S); launch("e4", grids, "forme du module : selection"); print("ETAPE: selread")


def e4_selread():
    S = load("e4"); grids = []; pending = False
    for cid, C in S["cells"].items():
        if C["state"] == "done":
            continue
        pop = E4_PAIRS[C["pair"]][0]; vk = vkey_of(pop)
        names = [n for n in (f"v2_e4_sel_{cid}", f"v2_e4_ext1_{cid}") if os.path.exists(f"configs/grids/{n}.yaml")]
        sc = scores(names, vk)
        means = {}
        for r in C["rates"]:
            s = sc.get((C["mode"], C["rank"], float(r)), {})
            if sorted(s) != SEL:
                pending = True; break
            means[float(r)] = st.mean(s[x] for x in SEL)
        else:
            if C["state"] == "tie":
                s30 = scores([f"v2_e4_tie_{cid}"], vk); m5 = {}
                for r in C["tied"]:
                    x = s30.get((C["mode"], C["rank"], float(r)), {})
                    if sorted(x) != TIE:
                        pending = True; break
                    m5[float(r)] = (means[float(r)] * 2 + sum(x.values())) / 5
                else:
                    w, ok, lead = settle_tie(m5); C.update(selected=w, tie_means5={lab(r): v for r, v in m5.items()}, tie_resolved=ok, tie_lead=lead, state="done")
                continue
            best = max(means, key=means.get); lo, hi = min(C["rates"]), max(C["rates"])
            if best in (lo, hi) and C["ext"] < 1:                 # un seul cran de prolongement, comme le protocole
                nr = step_rate(best, best == hi); C["rates"].append(nr); C["ext"] += 1
                grids.append(write_grid(f"v2_e4_ext{C['ext']}_{cid}", C["base"], C["mode"], C["rank"], [nr], SEL, f"E4 : {cid}, prolongement d'un cran ({nr:g})"))
                pending = True; continue
            C["means"] = {lab(r): v for r, v in sorted(means.items())}
            C["edge_after_extensions"] = best in (lo, hi)        # encore au bord apres le prolongement : retenu, et declare a la lecture
            b2, tie, two = tie_or_best(means)
            if tie:
                C.update(state="tie", tied=two); grids.append(write_grid(f"v2_e4_tie_{cid}", C["base"], C["mode"], C["rank"], two, TIE, f"E4 : egalite {cid}"))
                pending = True
            else:
                C.update(selected=b2, state="done")
    save("e4", S)
    if grids:
        launch("e4", grids, "forme du module : prolongements et egalites")
    if pending or grids:
        print("ATTENTE: E4 : selection en cours"); return
    # controle des parametres entraines, sur les runs de selection, AVANT tout run de rapport
    bad = []
    for cid, C in S["cells"].items():
        want = E4_PARAMS[(C["pair"], C["group"])][f"{C['mode']}_r{C['rank']}"]
        got = trainable_of(f"v2_e4_sel_{cid}")
        if got != want:
            bad.append(f"{cid} : {got} au node de {want}")
    if bad:
        sys.exit("STOP: E4 : parametres entraines differents du protocole : " + " ; ".join(bad))
    print("  parametres entraines : conformes au protocole pour toutes les cellules"); print("ETAPE: rep")


def trainable_of(name):
    for c, d, m, PARTITION in grid_runs(name):
        if m is None:
            continue
        for f in ("results.csv",):
            try:
                row = next(csv.DictReader(open(f"{d}/{f}")))
                for k, v in row.items():
                    if "trainable" in k and v:
                        return int(float(v))
            except (OSError, StopIteration):
                pass
        for f in glob.glob(f"{d}/*.log") + glob.glob(f"{d}/*.txt"):
            for line in open(f, errors="ignore"):
                if "trainable=" in line:
                    return int(line.split("trainable=")[1].split()[0].replace(",", ""))
    return None


def e4_rep():
    S = load("e4"); grids = [write_grid(f"v2_e4_rep_{cid}", C["base"], C["mode"], C["rank"], [float(C["selected"])], REP8, f"E4 : {cid} au taux selectionne, graines 2 a 9")
                              for cid, C in S["cells"].items()]
    launch("e4", grids, "forme du module : rapport sur les graines 2 a 9"); print("ETAPE: read")


def e4_read():
    S = load("e4"); V = {}
    for cid, C in S["cells"].items():
        rs = grid_runs(f"v2_e4_rep_{cid}")
        if any(r[2] is None for r in rs):
            print(f"ATTENTE: E4 {cid} incomplet"); return
        V[cid] = {r[0]["seed"]: r[2][key_of(E4_PAIRS[C["pair"]][0])] for r in rs}
    base = {}
    for pair, (pop, _, _) in E4_PAIRS.items():
        rs = grid_runs(f"v2_e4_base_{pair}")
        if rs[0][2] is None:
            print(f"ATTENTE: E4 modele de base {pair}"); return
        base[pair] = rs[0][2][key_of(pop)]
    crit = stats.t.ppf(1 - 0.05 / 16, 7)
    L = [f"==================== E4 : le facteur gele contre la forme du module (graines 2 a 9 ; 8 tests, Bonferroni, t = {crit:.3f}) ===================="]
    for cid, C in S["cells"].items():
        L.append(f"  {cid:28s} taux {float(C['selected']):<7g} " + (f"(egalite : {'tranchee' if C.get('tie_resolved') else 'non tranchee, declaree'}) " if "tie_means5" in C else "")
                 + ("(grille prolongee d'un cran) " if C.get("ext") else "") + ("(AU BORD apres le prolongement, declare) " if C.get("edge_after_extensions") else "")
                 + f": {st.mean(V[cid].values()):.4f}")
    verdict = {}
    for pair in E4_PAIRS:
        for grp in E4_GROUPS:
            free = st.mean(V[f"{pair}_{grp}_free_r1"].values()); gain = (free - base[pair]) * 100
            testable = gain >= 2
            L.append(f"  {pair} {grp} : libre r=1 - modele de base = {gain:+.2f} -> {'testable' if testable else 'NON TESTABLE (plancher de 2 points)'}")
            req = 2 if grp == "G1" else E4_PAIRS[pair][2]
            for band in ("top", "bottom"):
                A, B = f"{pair}_{grp}_dual_{band}_r2", f"{pair}_{grp}_{band}_r{req}"
                d = [(V[A][s] - V[B][s]) * 100 for s in REP8]; m, se, t, _ = t_paired(d); lo, hi = m - crit * se, m + crit * se
                v = "non testable" if not testable else ("ETABLI" if lo > 0 else ("INVERSE" if hi < 0 else "non concluant"))
                verdict[(pair, grp, band)] = v
                L.append(f"    {band}: dual_{band} - {band} r={req} = {m:+.2f} [{lo:+.2f}, {hi:+.2f}] -> {v}")
                if grp == "G2":
                    d2 = [(V[A][s] - V[f"{pair}_{grp}_{band}_r2"][s]) * 100 for s in REP8]; m2, se2, _, _ = t_paired(d2)
                    L.append(f"      (descriptif) dual_{band} - {band} r=2 = {m2:+.2f}")
    p1 = all(verdict[(p, "G1", b)] == "ETABLI" for p in E4_PAIRS for b in ("top", "bottom"))
    p2 = all(verdict[(p, "G2", b)] == "ETABLI" for p in E4_PAIRS for b in ("top", "bottom"))
    if p1 and p2:
        lect = "le cout de geler B ne vient ni de la forme du module ni du nombre de parametres"
    elif p1 != p2:
        lect = "le papier doit dire que la forme du module explique une partie de l'effet"
    else:
        lect = "autre configuration : rapportee telle quelle, sans lecture"
    L.append(f"  P1 (G1) sur les deux paires : {'oui' if p1 else 'non'} ; P2 (G2) sur les deux paires : {'oui' if p2 else 'non'}")
    L.append(f"  LECTURE FIXEE : {lect}")
    finish("e4", L, S)


# ============================================================ E5 : le prechauffage sur deux graines de direction de plus
E5_PAIRS = {"obqa": dict(pop=Q, ref=("free", 1, 0.5456), total=49, warm={5: 3, 10: 5, 25: 13}, top=0.4652, G=8.04, orig={5: "w2a5", 10: "w2a10", 25: "w2a25"}),
            "fmt": dict(pop=FMT, ref=("free", 1, 0.7684), total=274, warm={5: 14, 10: 28, 25: 69}, top=0.6443, G=12.41, orig={5: "w2b5", 10: "w2b10", 25: "w2b25"})}
DIRS = [301, 302]


def e5_dir():
    S = {"pairs": {}}; grids = []
    for pair, P in E5_PAIRS.items():
        lr, ref = published(P["pop"], *P["ref"]); base = base_from(ref)
        base["out_dir"] = os.path.expanduser("~/lora-runs-warm"); base["save_factor_steps"] = sorted(set(P["warm"].values()) | {P["total"]})
        rates = {}
        for kk, arm in P["orig"].items():
            sel = json.load(open(f"v2_{arm}_selection.json")); rates[str(kk)] = float(next(v for k, v in sel.items() if k.startswith("learned")))
        S["pairs"][pair] = {"base_ref": base_from(ref), "rates": rates}
        grids.append(write_grid(f"v2_e5_dir_{pair}", base, "free", 2, [2e-3], DIRS, f"E5 : runs de direction, graines {DIRS}, facteurs aux pas {base['save_factor_steps']}"))
    save("e5", S); launch("e5", grids, "prechauffage : runs de direction"); print("ETAPE: basis")


def e5_basis():
    import hashlib
    import torch
    from safetensors.torch import load_file, save_file
    S = load("e5"); files = []; os.makedirs("bases", exist_ok=True)
    for pair, P in E5_PAIRS.items():
        rs = {r[0]["seed"]: r for r in grid_runs(f"v2_e5_dir_{pair}")}
        if any(rs[s][2] is None for s in DIRS):
            print(f"ATTENTE: E5 runs de direction {pair}"); return
        for ds in DIRS:
            d = rs[ds][1]
            for kk, step in P["warm"].items():
                fac = load_file(f"{d}/factors_{step}.safetensors"); bases = {}
                for key in sorted(x for x in fac if x.endswith(".B")):
                    Qm, R = torch.linalg.qr(fac[key].double()); dg = R.diagonal().abs()
                    if float(dg.min()) <= 1e-6 * float(dg.max()):
                        sys.exit(f"STOP: E5 {pair} d{ds} warm{kk} : B de rang < 2 ({key})")
                    bases[key[:-2]] = Qm.float().contiguous()
                out = f"bases/learned_warm{kk}_{pair}_d{ds}_r2.safetensors"; save_file(bases, out); raw = open(out, "rb").read()
                S["pairs"][pair].setdefault("bases", {})[f"warm{kk}_d{ds}"] = {"file": out, "md5": hashlib.md5(raw).hexdigest(), "step": step}
                files.append(out); print(f"  {pair} graine {ds} warm{kk} : {len(bases)} modules apres {step} pas, md5 {hashlib.md5(raw).hexdigest()}")
    save("e5", S); h = git_commit(files + ["tmlr_e5.json"], "TMLR e5 : bases du prechauffage (graines de direction 301 et 302), committees avant les bras")
    print(f"  bases committees et poussees : {h}"); print("ETAPE: rep")


def e5_rep():
    S = load("e5"); grids = []
    for pair, P in E5_PAIRS.items():
        for name, B in S["pairs"][pair]["bases"].items():
            kk = int(name.split("_")[0][4:]); b = dict(S["pairs"][pair]["base_ref"], learned_basis=os.path.expanduser(f"~/repo/{B['file']}"),
                                                       max_steps=P["total"] - B["step"])
            grids.append(write_grid(f"v2_e5_rep_{pair}_{name}", b, "learned", 2, [S["pairs"][pair]["rates"][str(kk)]], REP5, f"E5 : {pair} {name}, graines 2 a 6"))
    launch("e5", grids, "prechauffage : bras sur les nouvelles bases"); print("ETAPE: read")


def e5_read():
    S = load("e5"); crit = stats.t.ppf(1 - 0.05 / 8, 4)
    L = [f"==================== E5 : le prechauffage sur deux graines de direction de plus (graines 2 a 6 ; 4 tests, Bonferroni, t = {crit:.3f}) ===================="]
    allruns = load_runs()
    for pair, P in E5_PAIRS.items():
        top = P["top"]
        for kk in (5, 10, 25):
            row = []
            md5o = json.load(open(f"v2_{P['orig'][kk]}_basis.json"))["md5"]
            o = [m[key_of(P["pop"])] for c, m, d in allruns if c.get("learned_basis_md5") == md5o and abs(float(c["lr"]) - S["pairs"][pair]["rates"][str(kk)]) < 1e-12
                 and c.get("seed") in REP5]
            if len(o) == 5:
                row.append(f"graine 0 : P = {(st.mean(o) - top) * 100 / P['G']:.2f}")
            for ds in DIRS:
                rs = grid_runs(f"v2_e5_rep_{pair}_warm{kk}_d{ds}")
                if any(r[2] is None for r in rs):
                    print(f"ATTENTE: E5 {pair} warm{kk} d{ds}"); return
                v = {r[0]["seed"]: r[2][key_of(P["pop"])] for r in rs}
                d = [(v[s] - top) * 100 for s in REP5]; m, se, t, _ = t_paired(d)
                Pv, lo, hi = m / P["G"], (m - crit * se) / P["G"], (m + crit * se) / P["G"]
                row.append(f"graine {ds} : P = {Pv:.2f} [{lo:.2f}, {hi:.2f}]")
                if kk == 10:
                    reading = "suffit" if lo >= 0.7 else ("ne suffit pas" if hi < 0.3 else "non concluant")
                    L.append(f"  {pair} warm10 graine {ds} : warm10 - top = {m:+.2f}, t = {t:.2f} -> {'ETABLI' if t > crit else 'non etabli'} ; "
                             f"P = {Pv:.2f} [{lo:.2f}, {hi:.2f}] -> LECTURE FIXEE : {reading}")
            L.append(f"  {pair} warm{kk} : " + " ; ".join(row))
    finish("e5", L, S)


# ============================================================ fin d'une experience : lecture, calcul, commit
def finish(k, L, S):
    gh = 0.0; n = 0
    for f in glob.glob(f"configs/grids/v2_{k}_*.yaml"):
        for c, d, m, PARTITION in grid_runs(os.path.basename(f)[:-5]):
            try:
                gh += float(next(csv.DictReader(open(d + "/results.csv")))["wallclock_s"]) / 3600; n += 1
            except Exception:
                pass
    L.append(f"  calcul : {n} runs termines, {gh:.1f} PARTITION-heures")
    txt = "\n".join(L); open(os.path.expanduser(f"~/tmlr_lecture_{k}.txt"), "w").write(txt + "\n"); print(txt)
    open(f"tmlr_lecture_{k}.txt", "w").write(txt + "\n")
    print(f"  lecture committee : {git_commit([f'tmlr_lecture_{k}.txt', f'tmlr_{k}.json'], f'TMLR {k} : lecture')}")
    print("FINI")


def relaunch(k):
    """Resoumet toutes les grilles de l'experience : le lanceur ne relance que les runs absents ou en echec."""
    names = [os.path.basename(f)[:-5] for f in glob.glob(f"configs/grids/v2_{k}_*.yaml")]
    launch(k, names, "relance des runs absents ou en echec")


STAGES = {"e1": {"sel": e1_sel, "selread": e1_selread, "tieread": e1_tieread, "decide": e1_decide, "read": e1_read},
          "e2": {"rep": e2_rep, "read": e2_read}, "e3": {"rep": e3_rep, "read": e3_read}, "e3b": {"rep": e3b_rep, "read": e3b_read},
          "e4": {"sel": e4_sel, "selread": e4_selread, "rep": e4_rep, "read": e4_read},
          "e6": {"sel": e6_sel, "selread": e6_selread, "rep": e6_rep, "read": e6_read},
          "e5": {"dir": e5_dir, "basis": e5_basis, "rep": e5_rep, "read": e5_read}}
FIRST = {"e1": "sel", "e2": "rep", "e3": "rep", "e4": "sel", "e5": "dir"}

if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[2] == "relaunch" and sys.argv[1] in STAGES:
        relaunch(sys.argv[1]); sys.exit(0)
    if len(sys.argv) != 3 or sys.argv[1] not in STAGES or sys.argv[2] not in STAGES[sys.argv[1]]:
        sys.exit(__doc__)
    STAGES[sys.argv[1]][sys.argv[2]]()
