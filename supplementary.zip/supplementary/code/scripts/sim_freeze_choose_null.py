"""Is "freezing minus choosing" an artefact of the range statistic?  A null simulation, no PARTITION.

    python scripts/sim_freeze_choose_null.py

The statistic is F - C, with F = free - (best frozen arm) and C = (best frozen arm) - (worst frozen arm), on means over the
reported seeds. Noise inflates the range C, and the maximum inside F, so F - C is biased towards "choosing" when the frozen
arms are close (the external review's objection; it matters most for ARC-Easy, C = 1.78, and rank 8, C = 1.00).

The null keeps the free reference as observed and gives ALL frozen arms the same true mean (the mean of their observed means).
Scores are y[arm, seed] = mu[arm] + e[seed] + eps, with the seed effect e shared by every arm (it cancels in the differences)
and eps ~ N(0, sigma), sigma the pooled residual of the observed two-way table ((A-1)(S-1) degrees of freedom).
For each population it reports, on 20 000 null draws:
  - the null spread C (what choosing "costs" with no true difference) against the observed C;
  - the null distribution of F - C, and where the observed F - C falls in it (two-sided tail probability).
CALIBRATION (checked 26/09 on 400 datasets drawn under a TRUE null, three arms, five seeds): p < 0.05 in 6.5 % of them,
against 5 % nominal. The test is slightly liberal (sigma is estimated on few degrees of freedom): read a p near 0.05 with care.
GUARD: each population carries the F and C the paper reports; if the recomputed values differ by more than 0.02 point, the
population is skipped with a message, so nothing is simulated on the wrong cells.
"""
import glob
import json
import os
import random
import statistics as st

import yaml

R = os.path.expanduser("~/lora-runs")
LLAMA, QWEN = "meta-llama/Llama-3.2-1B", "Qwen/Qwen2.5-1.5B"
N = 20000


def tokens(c):
    t = c.get("target_tokens")
    return t.get(c.get("task")) if isinstance(t, dict) else t


def clipped(c):
    v = c.get("max_grad_norm", 1.0)
    return v is not None and float(v) == 1.0


def seven(c):
    tm = c.get("target_modules")
    return tm is None or len(tm) == 7


RUNS = []
for p in glob.glob(R + "/*/config.yaml"):
    c = yaml.safe_load(open(p)) or {}
    d = os.path.dirname(p)
    try:
        if not open(d + "/status").read().startswith("DONE"):
            continue
        RUNS.append((c, json.load(open(d + "/metrics.json"))))
    except OSError:
        continue

fmt = lambda tok: (lambda c: c.get("task") == "format" and str(c.get("model")) == LLAMA and tokens(c) == tok and seven(c))  # noqa: E731
qa = lambda fp: (lambda c: c.get("task") == "commonsense" and str(c.get("data_fingerprint")) == fp and str(c.get("model")) == QWEN)  # noqa: E731
S = [2, 3, 4, 5, 6]
# name, predicate, metric, seeds, {arm: (rank, rate)}, free (rank, rate), expected (F, C) as the paper reports them
POPS = [
    ("format, rank 2", fmt(600000), "format_parsed", S,
     {"top": (2, 1e-2), "bottom": (2, 5e-3), "random": (2, 1e-2), "random_ortho": (2, 1e-2)}, (1, 1e-3), (11.50, 6.12)),
    ("format, rank 8", fmt(600000), "format_parsed", [42, 43, 44, 45, 46],
     {"top": (8, 2e-3), "bottom": (8, 2e-3), "random": (8, 5e-3), "random_ortho": (8, 5e-3)}, (4, 2e-3), (7.43, 1.00)),
    ("format, rank 16", fmt(600000), "format_parsed", S,
     {"top": (16, 2e-3), "bottom": (16, 5e-4), "random": (16, 1e-3), "random_ortho": (16, 1e-3)}, (8, 2e-3), (4.10, 2.41)),
    ("format, rank 2, twice the budget", fmt(1200000), "format_parsed", S,
     {"top": (2, 1e-2), "bottom": (2, 5e-3), "random": (2, 1e-2), "random_ortho": (2, 1e-2)}, (1, 1e-3), (10.16, 6.55)),
    ("OpenBookQA, rank 2", qa("dc05f4d847f9"), "mcq_acc", S,
     {"top": (2, 5e-3), "bottom": (2, 2e-3), "random": (2, 5e-3), "random_ortho": (2, 2e-2)}, (1, 2e-3), (8.04, 4.32)),
    ("ARC-Easy, rank 16", qa("15890c7671bb"), "mcq_acc", S,
     {"top": (16, 1e-4), "bottom": (16, 5e-4), "random_ortho": (16, 5e-4)}, (7, 1e-4), (-0.30, 1.78)),
    ("ARC-Challenge, rank 16", qa("0755bcdbdce3"), "mcq_acc", S,
     {"top": (16, 5e-4), "bottom": (16, 1e-3), "random_ortho": (16, 1e-3)}, (7, 5e-4), (-0.18, 5.18)),
    # added 26/09: ARC-Challenge at ranks 2 and 32, whose spreads are modest (1.74 and 2.02 points)
    ("ARC-Challenge, rank 2", qa("0755bcdbdce3"), "mcq_acc", S,
     {"top": (2, 5e-3), "bottom": (2, 2e-3), "random_ortho": (2, 5e-3)}, (1, 1e-3), (2.02, 1.74)),
    ("ARC-Challenge, rank 32", qa("0755bcdbdce3"), "mcq_acc", S,
     {"top": (32, 5e-4), "bottom": (32, 2e-4), "random_ortho": (32, 5e-4)}, (14, 5e-4), (-0.72, 2.02)),
]


def cell(pred, mode, rank, lr, seeds, key):
    by = {}
    for c, m in RUNS:
        if (pred(c) and clipped(c) and c.get("mode") == mode and c.get("rank") == rank and abs(float(c.get("lr") or 0) - lr) < 1e-12
                and c.get("seed") in seeds and key in m and c.get("update_norm_target") in (None, "")):
            by.setdefault(c["seed"], []).append(m[key])
    return {s: st.mean(v) for s, v in by.items()}, {s: len(v) for s, v in by.items() if len(v) > 1}


def fc(means, free):
    best, worst = max(means), min(means)
    return (free - best) * 100, (best - worst) * 100


print(f"{'population':34s} {'F':>6s} {'C':>6s} {'F-C':>6s} | {'C nul':>12s} {'P(C nul >= C)':>13s} | {'F-C nul, 95 %':>18s} {'p bilat.':>8s}")
for name, pred, key, seeds, arms, (rf, lf), (F_exp, C_exp) in POPS:
    data, dups = {}, {}
    for a, (rk, lr) in arms.items():
        data[a], dups[a] = cell(pred, a, rk, lr, seeds, key)
    free, dups["free"] = cell(pred, "free", rf, lf, seeds, key)
    common = sorted(set(free).intersection(*[set(v) for v in data.values()]))
    if len(common) != len(seeds):
        print(f"{name:34s} INCOMPLET : {len(common)} graines communes sur {len(seeds)} " + str({a: len(v) for a, v in data.items()} | {"free": len(free)}))
        continue
    A = list(data)
    Y = {a: [data[a][s] for s in common] for a in A}
    mu = {a: st.mean(Y[a]) for a in A}
    F, C = fc([mu[a] for a in A], st.mean(free[s] for s in common))
    if abs(F - F_exp) > 0.02 or abs(C - C_exp) > 0.02:
        print(f"{name:34s} ARRET : F = {F:.2f}, C = {C:.2f} recalcules, contre {F_exp:.2f} et {C_exp:.2f} publies"
              + (f" ; DOUBLONS {({k: v for k, v in dups.items() if v})}" if any(dups.values()) else ""))
        continue
    # pooled residual of the two-way table (arm x seed), frozen arms only
    grand = st.mean(x for a in A for x in Y[a])
    seff = [st.mean(Y[a][j] for a in A) - grand for j in range(len(common))]
    res = [Y[a][j] - mu[a] - seff[j] for a in A for j in range(len(common))]
    dof = (len(A) - 1) * (len(common) - 1)
    sigma = (sum(r * r for r in res) / dof) ** 0.5
    m0, fr_mean = st.mean(mu.values()), st.mean(free[s] for s in common)
    rng = random.Random(0)
    nullC, nullD = [], []
    for _ in range(N):
        means = [m0 + st.mean(rng.gauss(0, sigma) for _ in common) for _ in A]
        f, c = fc(means, fr_mean)
        nullC.append(c); nullD.append(f - c)
    nullC.sort(); nullD.sort()
    pC = sum(c >= C for c in nullC) / N
    D = F - C
    tail = min(sum(d <= D for d in nullD), sum(d >= D for d in nullD)) / N
    print(f"{name:34s} {F:+6.2f} {C:6.2f} {D:+6.2f} | {st.mean(nullC):5.2f} [{nullC[int(.95 * N)]:4.2f}] {pC:13.4f} | "
          f"[{nullD[int(.025 * N)]:+6.2f}, {nullD[int(.975 * N)]:+6.2f}] {min(1.0, 2 * tail):8.4f}")
print("\nLecture : 'C nul' est la moyenne (et le 95e centile) de l'ecart meilleur-pire sous l'hypothese nulle ; P(C nul >= C) dit si")
print("l'ecart observe entre bras depasse le bruit. 'F-C nul' est l'intervalle a 95 % de la statistique si les bras geles etaient")
print("identiques ; un F-C observe hors de cet intervalle n'est pas un artefact de la statistique de l'etendue.")
print("Calibration : sous une hypothese nulle vraie, p < 0,05 dans 6,5 % des cas (5 % attendu) ; un p proche de 0,05 est a lire avec prudence.")
