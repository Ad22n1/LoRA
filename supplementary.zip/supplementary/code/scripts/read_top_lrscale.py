"""PROTOCOL_top_lrscale.md: top_lrscale against top_scalar, paired on C2's 40 seeds (65-104), at 5e-3. No PARTITION.

    python scripts/read_top_lrscale.py

The test of C2: equivalence if the 90 % interval of d = top_lrscale - top_scalar lies within [-1, +1] point; difference if
|t| > 2.023 (two-sided, 39 d.f.). GUARD: both arms must have exactly one run per seed, 40 seeds each.
"""
import csv
import glob
import json
import os
import statistics as st
from collections import Counter

import yaml

R = os.path.expanduser("~/lora-runs")
SEEDS = list(range(65, 105))
T975, T95 = 2.023, 1.685          # Student t, 39 d.f.: two-sided 95 % and 90 %


def ok(c):
    t = c.get("target_tokens"); tok = t.get(c.get("task")) if isinstance(t, dict) else t
    v = c.get("max_grad_norm", 1.0); tm = c.get("target_modules")
    return (c.get("task") == "format" and str(c.get("model")) == "meta-llama/Llama-3.2-1B" and tok == 600000 and c.get("rank") == 2
            and v is not None and float(v) == 1.0 and (tm is None or len(tm) == 7) and abs(float(c.get("lr") or 0) - 5e-3) < 1e-12
            and c.get("update_norm_target") in (None, ""))


cells = {"top_lrscale": {}, "top_scalar": {}}
gpus = {"top_lrscale": Counter(), "top_scalar": Counter()}
clip = {"top_lrscale": [], "top_scalar": []}   # (mean pre-clip norm, max, clip_frac) from results.csv
for p in glob.glob(R + "/*/config.yaml"):
    c = yaml.safe_load(open(p)) or {}
    if c.get("mode") in cells and c.get("seed") in SEEDS and ok(c):
        d = os.path.dirname(p)
        try:
            if not open(d + "/status").read().startswith("DONE"):
                continue
            v = json.load(open(d + "/metrics.json"))["format_parsed"]
        except (OSError, KeyError):
            continue
        cells[c["mode"]].setdefault(c["seed"], []).append(v)
        try:
            with open(d + "/results.csv", newline="") as f:
                row = next(csv.DictReader(f))
            gpus[c["mode"]][(row.get("PARTITION") or "?").replace("NVIDIA ", "").replace(" Generation", "")] += 1
            num = lambda k: float(row[k]) if row.get(k) not in (None, "") else None  # noqa: E731
            clip[c["mode"]].append((num("grad_norm_pre_clip_mean"), num("grad_norm_pre_clip_max"), num("clip_frac")))
        except (OSError, StopIteration):
            gpus[c["mode"]]["?"] += 1
for arm, by in cells.items():
    dup = {s: len(v) for s, v in by.items() if len(v) > 1}
    print(f"  {arm:12s} : {len(by)} graines sur 40" + (f"  DOUBLONS {dup}" if dup else "") + f" ; cartes : {dict(gpus[arm])}")
    if len(by) != 40 or dup:
        raise SystemExit("  ARRET : il faut exactement un run par graine, 40 graines, pour chaque bras")
d = [(cells["top_lrscale"][s][0] - cells["top_scalar"][s][0]) * 100 for s in SEEDS]
m = st.mean(d); se = st.stdev(d) / len(d) ** 0.5; t = m / se if se > 0 else float("inf")
lo90, hi90, lo95, hi95 = m - T95 * se, m + T95 * se, m - T975 * se, m + T975 * se
print(f"\n  top_lrscale {st.mean(v[0] for v in cells['top_lrscale'].values()):.4f} ; top_scalar {st.mean(v[0] for v in cells['top_scalar'].values()):.4f}")
print(f"  d = {m:+.2f} pt ; IC95 [{lo95:+.2f}, {hi95:+.2f}] ; IC90 [{lo90:+.2f}, {hi90:+.2f}] ; t = {t:+.2f} (39 d.l.) ; ecart type de d {st.stdev(d):.2f}")
eq, diff = (-1 <= lo90 and hi90 <= 1), abs(t) > T975
print("\n  l'ecretage (seuil 1,0) :")
for arm, rows in clip.items():
    mean_ = [x[0] for x in rows if x[0] is not None]; mx = [x[1] for x in rows if x[1] is not None]; fr = [x[2] for x in rows if x[2] is not None]
    print(f"    {arm:12s} norme moyenne avant ecretage {st.mean(mean_):.3f}" if mean_ else f"    {arm:12s} norme moyenne : absente", end="")
    print(f" ; max {max(mx):.3f} ; fraction des pas ecretes {st.mean(fr):.3f}" if fr else " ; frequence d'ecretage : non enregistree (runs anterieurs au 26/09)")
print("  -> " + ("EQUIVALENCE ETABLIE a +/- 1 point : la lecture de Sigma comme un taux par module tient, ecretage et eps compris" if eq and not diff
             else "DIFFERENCE ETABLIE : l'ecretage ou eps cassent l'equivalence" if diff and not eq
             else "equivalence ET petite difference etablies" if eq and diff else "NON MONTREE (ni equivalence, ni difference) : ce n'est PAS une rupture de l'identite ; le bruit de relance peut suffire"))
