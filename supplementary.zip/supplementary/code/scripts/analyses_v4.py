"""Analyses post hoc A1 a A5 (PROTOCOL_analyses_A1-A5.md), sans entrainement. Definitions committees avec ce script, AVANT execution.

    python scripts/analyses_v4.py --a1 --a2 --a3 --a4 --a5     # sorties aussi dans analyses_v4.json

Statut : post hoc, descriptif (PH . D). Chaque analyse est rapportee quelle que soit son issue ; une donnee manquante est dite, jamais
remplacee en silence. Les cellules sont retrouvees comme dans analyses_v3.py (valeur publiee, departagee par la validation si besoin).
"""
import glob
import json
import math
import os
import statistics as st
import sys

import numpy as np
import torch
import yaml

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__))))
import analyses_v3 as V3  # noqa: E402  (meme recherche de cellules, memes populations)

REPO = V3.REPO; OUT = {}
sys.path.insert(0, f"{REPO}/src")
V3.POPS.update({
    "format/Qwen1.5B": (lambda c: c.get("task") == "format" and str(c.get("model")).endswith("Qwen2.5-1.5B") and V3._tok(c) == 600000, "format_parsed"),
    "format/Qwen0.5B": (lambda c: c.get("task") == "format" and str(c.get("model")).endswith("Qwen2.5-0.5B") and V3._tok(c) == 600000, "format_parsed")})
MODEL = {"format/Llama": "meta-llama/Llama-3.2-1B", "OBQA/Qwen1.5B": "Qwen/Qwen2.5-1.5B"}
TYPES = ("q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj")
ty = lambda name: name.rsplit(".", 1)[-1]  # noqa: E731
SVDROOT = f"/tmp/lora-{os.environ.get('USER', '')}/svd"


def svd(model, name):
    from lorasub.spectral import load_svd
    return load_svd(SVDROOT, model, name)


def by_type(d):                       # {module: valeur} -> {type: mediane sur les couches}
    out = {}
    for n, v in d.items():
        out.setdefault(ty(n), []).append(v)
    return {t: st.median(v) for t, v in out.items()}


# ======================================================================= A1 : angles principaux
def overlap_angle(Q1, Q2):
    s = torch.linalg.svdvals(Q1.double().T @ Q2.double()).clamp(max=1.0)
    k = min(Q1.shape[1], Q2.shape[1])
    return float((s ** 2).sum() / k), math.degrees(math.acos(float(s.min())))


_NULL = {}


def null_mean(d, k1, k2):             # 100 bases orthonormales aleatoires (graine 2000) contre une base fixe : moyenne nulle du recouvrement
    key = (d, k1, k2)
    if key not in _NULL:
        g = torch.Generator().manual_seed(2000); F = torch.linalg.qr(torch.randn(d, k2, generator=g, dtype=torch.float64))[0]
        _NULL[key] = st.mean(overlap_angle(torch.linalg.qr(torch.randn(d, k1, generator=g, dtype=torch.float64))[0], F)[0] for _ in range(100))
    return _NULL[key]


FREE_LR = {"OBQA/Qwen1.5B": 2e-3, "format/Llama": 1e-3}   # taux de la cellule publiee du LoRA libre au rang 1


def factor_B(pop, seeds):             # les B du LoRA libre au rang 1 (phase 1), s'ils ont ete sauvegardes, AU TAUX PUBLIE
    from safetensors.torch import load_file
    pred, _ = V3.POPS[pop]; out = {}
    for root in ("~/lora-runs-fw", "~/lora-runs"):
        for p in glob.glob(os.path.expanduser(root) + "/*/config.yaml"):
            c = yaml.safe_load(open(p)) or {}; d = os.path.dirname(p)
            if (pred(c) and c.get("mode") == "free" and c.get("rank") == 1 and c.get("seed") in seeds and c["seed"] not in out
                    and abs(float(c.get("lr") or 0) - FREE_LR[pop]) < 1e-12):
                f = sorted(glob.glob(d + "/factors_*.safetensors"), key=lambda x: int(x.rsplit("_", 1)[1].split(".")[0]))
                if f:
                    fac = load_file(f[-1]); out[c["seed"]] = {k[:-2]: v.flatten() / v.norm() for k, v in fac.items() if k.endswith(".B")}
    return out


def do_a1():
    from safetensors.torch import load_file
    print("==================== A1 : angles principaux (moyenne des cos^2 / rapport au hasard / plus grand angle, medianes sur les couches) ====================")
    B = {}
    for key, f in (("grad", "learned_grad_obqa_r2"), ("grad256", "learned_grad256_obqa_r2"), ("gradall", "learned_gradall_obqa_r2"),
                   ("learned s0", "learned_obqa_r2_s0"), ("learned s7", "learned_obqa_r2_s7"), ("grad (fmt)", "learned_grad_format_llama_r2"),
                   ("grad256 (fmt)", "learned_grad256_format_llama_r2"), ("grad1024 (fmt)", "learned_grad1024_format_llama_r2"),
                   ("gradall (fmt)", "learned_gradall_format_llama_r2"), ("learned (fmt)", "learned_format_llama_r2_s0")):
        p = f"{REPO}/bases/{f}.safetensors"
        if os.path.exists(p):
            B[key] = load_file(p)
        else:
            print(f"  base absente : {key} ({f})")
    OUT["A1"] = {}

    def compare(label, model, A, Bb):
        per = {}
        for name, Qa in A.items():
            if isinstance(Bb, str):
                e = svd(model, name); U = e.U; m = e.S.numel()
                Qb = U[:, :2] if Bb == "top" else U[:, m - 2:m]
            else:
                if name not in Bb:
                    continue
                Qb = Bb[name]
            ov, ang = overlap_angle(Qa, Qb); nul = null_mean(Qa.shape[0], Qa.shape[1], Qb.shape[1])
            per.setdefault(ty(name), []).append((ov, ov / nul, ang))
        row = {t: {"recouvrement": st.median(x[0] for x in v), "rapport_hasard": st.median(x[1] for x in v), "plus_grand_angle": st.median(x[2] for x in v)}
               for t, v in per.items()}
        OUT["A1"][label] = row
        print(f"  {label:34s} : " + "  ".join(f"{t.replace('_proj', '')} {r['recouvrement']:.3f}/{r['rapport_hasard']:.0f}x/{r['plus_grand_angle']:.0f}d" for t, r in row.items()))
    for pair, model, grads, learned in (("OBQA", MODEL["OBQA/Qwen1.5B"], ("grad", "grad256", "gradall"), "learned s0"),
                                        ("format", MODEL["format/Llama"], ("grad (fmt)", "grad256 (fmt)", "grad1024 (fmt)", "gradall (fmt)"), "learned (fmt)")):
        for g in grads:
            if g not in B:
                continue
            for band in ("top", "bottom"):
                compare(f"{pair} : {g} / {band}", model, B[g], band)
            if learned in B:
                compare(f"{pair} : {g} / {learned}", model, B[g], B[learned])
    if "learned s0" in B and "learned s7" in B:
        compare("OBQA : learned s0 / learned s7", MODEL["OBQA/Qwen1.5B"], B["learned s0"], B["learned s7"])
    for pop in ("OBQA/Qwen1.5B", "format/Llama"):
        F = factor_B(pop, V3.S26)
        if len(F) < 2:
            print(f"  {pop} : B du LoRA libre au rang 1 sauvegardes pour {len(F)} graine(s) seulement ; comparaison deux a deux non calculee"); continue
        per = {}
        sd = sorted(F)
        for i in range(len(sd)):
            for j in range(i + 1, len(sd)):
                for name, b in F[sd[i]].items():
                    if name in F[sd[j]]:
                        c2 = float((b.double() @ F[sd[j]][name].double()) ** 2); d = b.numel()
                        per.setdefault(ty(name), []).append((c2, c2 * d))
        row = {t: {"cos2": st.median(x[0] for x in v), "rapport_hasard": st.median(x[1] for x in v)} for t, v in per.items()}
        OUT["A1"][f"{pop} : B libre r=1, graines deux a deux"] = dict(row, taux=FREE_LR[pop], graines=sd)
        print(f"  {pop} : B libre r=1 a {FREE_LR[pop]:g}, graines {sd}, deux a deux : " + "  ".join(f"{t.replace('_proj', '')} {r['cos2']:.3f}/{r['rapport_hasard']:.0f}x" for t, r in row.items()))
    for pair, model, g in (("OBQA", MODEL["OBQA/Qwen1.5B"], "grad"), ("format", MODEL["format/Llama"], "grad (fmt)")):
        if g not in B:
            continue
        prof = {}
        for name, Q in B[g].items():
            e = svd(model, name); U = e.U.double(); m = U.shape[1]; Qd = Q.double()
            en = [float((U[:, int(m * a / 10):int(m * (a + 1) / 10)].T @ Qd).pow(2).sum() / Q.shape[1]) for a in range(10)]
            prof.setdefault(ty(name), []).append(en + [max(0.0, 1 - sum(en))])
        OUT["A1"][f"{pair} : profil de {g}"] = {t: [st.median(x[a] for x in v) for a in range(11)] for t, v in prof.items()}
        print(f"  profil de {g} ({pair}) par dixieme du spectre de W0, en % (hors = hors de l'image de W0) :")
        for t, v in prof.items():
            med = [st.median(x[a] for x in v) * 100 for a in range(11)]
            print(f"      {t:9s} : " + " ".join(f"{x:4.1f}" for x in med[:10]) + f" | hors {med[10]:4.1f}")


# ======================================================================= A2 : normes de mise a jour par type de module
ARMS2 = {"format/Llama": {"top": 0.6443, "bottom": 0.5922, "dual_top": 0.7739, "dual_bottom": 0.7818, "free": 0.7684},
         "OBQA/Qwen1.5B": {"top": 0.4652, "bottom": 0.4220, "dual_top": 0.5308, "dual_bottom": 0.5248, "free": 0.5456}}


def run_dirs(pop, mode, rank, value, seeds=V3.S26):
    pred, key = V3.POPS[pop]; v = V3.cell(pop, mode, rank, seeds, value=value); dirs = {}
    for c, m, d, t in V3.RUNS:
        if pred(c) and V3.clean(c) and c.get("mode") == mode and c.get("rank") == rank and c.get("seed") in seeds and abs(m.get(key, -1) - v[c["seed"]]) < 1e-12:
            dirs.setdefault(c["seed"], d)
    return v, dirs


def do_a2():
    print("==================== A2 : normes de mise a jour ||(alpha/r) B A||_F par type de module, rang 2 (graines 2-6) ====================")
    OUT["A2"] = {}
    for pop, arms in ARMS2.items():
        model = MODEL[pop]; norms = {}; dims = {}
        for arm, val in arms.items():
            rank = 1 if arm == "free" else 2
            _, dirs = run_dirs(pop, arm, rank, val)
            per_seed = []
            for s, d in sorted(dirs.items()):
                f = d + "/update_norms.json"
                if os.path.exists(f):
                    per_seed.append(json.load(open(f)))
            if len(per_seed) != len(V3.S26):
                print(f"  {pop} {arm} : normes presentes pour {len(per_seed)} graine(s) sur 5"); continue
            norms[arm] = {t: st.mean(by_type(u)[t] for u in per_seed) for t in TYPES}
            sq = {t: st.mean(sum(v ** 2 for n, v in u.items() if ty(n) == t) for u in per_seed) for t in TYPES}; tot = sum(sq.values())
            norms[arm + " (part des carres)"] = {t: sq[t] / tot for t in TYPES}
            for n in per_seed[0]:
                if ty(n) not in dims:
                    e = svd(model, n); dims[ty(n)] = (e.Vh.shape[1] if e.Vh is not None else None, e.U.shape[0])
        OUT["A2"][pop] = norms
        print(f"  {pop} : norme (mediane sur les couches, moyenne sur les graines)")
        for arm in arms:
            if arm in norms:
                print(f"      {arm:12s} : " + "  ".join(f"{t.replace('_proj', '')} {norms[arm][t]:.3f}" for t in TYPES)
                      + "   | part des carres : " + " ".join(f"{norms[arm + ' (part des carres)'][t]:.2f}" for t in TYPES))
        for band, (A, Bm) in (("dominante", ("dual_top", "top")), ("mineure", ("dual_bottom", "bottom"))):
            if A in norms and Bm in norms:
                print(f"      A gele / B gele, bande {band:9s} : " + "  ".join(f"{t.replace('_proj', '')} {norms[A][t] / norms[Bm][t]:.2f}" for t in TYPES))
        if dims:
            print("      parametres entraines par module (B gele r*d_in ; A gele r*d_out ; libre r=1 d_in+d_out) : "
                  + "  ".join(f"{t.replace('_proj', '')} {2 * di}/{2 * do}/{di + do}" for t, (di, do) in dims.items() if di))


# ======================================================================= A3 : equivalence bandes / base aleatoire
POP3 = {"format/Llama": (0.6443, 0.5922, 0.6534), "OBQA/Qwen1.5B": (0.4652, 0.4220, 0.4592), "format/Qwen1.5B": (0.6257, 0.6391, 0.6238),
        "ARC-C/Qwen1.5B": (0.4842, 0.4668, 0.4692), "format/Qwen0.5B": (0.4798, 0.4932, 0.5081)}
# graines rapportees de chaque population : 2 a 6, sauf la tache de format sur Qwen2.5-1.5B (selection 20-21, rapport 22-26)
SEEDS3 = {"format/Qwen1.5B": (22, 23, 24, 25, 26)}


def do_a3():
    print("==================== A3 : equivalence entre bandes spectrales et random_ortho (B gele, rang 2) ====================")
    print("  marge = plus petite marge symetrique exclue a 90 % : max(|borne basse|, |borne haute|), en points")
    OUT["A3"] = {}; t90 = 2.132
    for pop, (vt, vb, vr) in POP3.items():
        SS = SEEDS3.get(pop, V3.S26)
        try:
            T = V3.cell(pop, "top", 2, SS, value=vt); Bt = V3.cell(pop, "bottom", 2, SS, value=vb); R = V3.cell(pop, "random_ortho", 2, SS, value=vr)
        except SystemExit as e:
            print(f"  {pop} : {e}"); continue
        res = {}
        for band, X in (("top", T), ("bottom", Bt)):
            d = [(X[s] - R[s]) * 100 for s in SS]; m = st.mean(d); h = t90 * st.stdev(d) / 5 ** 0.5
            res[band] = {"ecart": m, "ic90": [m - h, m + h], "marge": max(abs(m - h), abs(m + h))}
        rng = np.random.default_rng(3000); S = np.array(SS); Tv = np.array([T[s] for s in S]); Bv = np.array([Bt[s] for s in S]); Rv = np.array([R[s] for s in S])
        draws = []
        for _ in range(10000):
            i = rng.integers(0, 5, 5); draws.append((max(Tv[i].mean(), Bv[i].mean()) - Rv[i].mean()) * 100)
        lo, hi = np.percentile(draws, [5, 95])
        res["meilleure bande"] = {"ecart": (max(Tv.mean(), Bv.mean()) - Rv.mean()) * 100, "ic90": [float(lo), float(hi)], "marge": float(max(abs(lo), abs(hi)))}
        res["graines"] = list(SS); OUT["A3"][pop] = res
        print(f"  {pop:16s} (graines {SS[0]}-{SS[-1]}) : " + " ; ".join(f"{k} - random_ortho {v['ecart']:+.2f} [{v['ic90'][0]:+.2f}, {v['ic90'][1]:+.2f}], marge {v['marge']:.2f}"
                                                            for k, v in res.items() if k != "graines"))


# ======================================================================= A4 : le bras bottom d'OpenBookQA
def do_a4():
    print("==================== A4 : le bras bottom d'OpenBookQA au rang 2 (0,4220 = le modele de base) ====================")
    OUT["A4"] = {}; model = MODEL["OBQA/Qwen1.5B"]
    has_pred = has_fac = 0
    for arm, val in (("bottom", 0.4220), ("top", 0.4652)):
        _, dirs = run_dirs("OBQA/Qwen1.5B", arm, 2, val); rel = {}; ab = {}
        for s, d in sorted(dirs.items()):
            has_pred += any(os.path.exists(d + f) for f in ("/generations_test.jsonl", "/predictions.jsonl")); has_fac += bool(glob.glob(d + "/factors_*.safetensors"))
            u = json.load(open(d + "/update_norms.json"))
            for n, v in u.items():
                e = svd(model, n); w = float(e.S.double().pow(2).sum().sqrt())
                rel.setdefault(ty(n), []).append(v / w); ab.setdefault(ty(n), []).append(v)
        OUT["A4"][arm] = {t: {"norme": st.median(ab[t]), "perturbation_relative": st.median(rel[t])} for t in rel}
        print(f"  {arm:6s} : norme ||dW|| / perturbation relative ||dW|| / ||W0|| (medianes sur couches et graines) : "
              + "  ".join(f"{t.replace('_proj', '')} {st.median(ab[t]):.2f} / {st.median(rel[t]) * 100:.2f} %" for t in rel))
    print(f"  predictions question par question sauvegardees : {has_pred} run(s) sur 10 ; facteurs : {has_fac} run(s) sur 10"
          + (" -> la comparaison question par question avec le modele de base, et une reevaluation, sont impossibles" if not has_pred and not has_fac else ""))
    OUT["A4"]["donnees"] = {"predictions": has_pred, "facteurs": has_fac}


# ======================================================================= A5 : bootstrap sur les graines et les questions (tache de format)
def check_fn():
    for mod in ("lorasub.data.format", "lorasub.eval", "lorasub.data"):
        try:
            m = __import__(mod, fromlist=["check_alien"])
            if hasattr(m, "check_alien"):
                return m.check_alien
        except Exception:
            pass
    sys.exit("ARRET : fonction check_alien introuvable")


def do_a5():
    print("==================== A5 : bootstrap a deux niveaux (graines puis questions), tache de format, Llama-3.2-1B, rang 2 ====================")
    print("  OpenBookQA : impossible, les predictions question par question n'y ont pas ete sauvegardees (declare)")
    chk = check_fn(); M = {}; pop = "format/Llama"
    for arm in ("top", "bottom", "dual_top", "dual_bottom"):
        v, dirs = run_dirs(pop, arm, 2, ARMS2[pop][arm]); rows = []
        for s in V3.S26:
            f = dirs[s] + "/generations_test.jsonl"
            if not os.path.exists(f):
                sys.exit(f"ARRET : {arm} graine {s} : generations absentes")
            g = [json.loads(x) for x in open(f)]
            ok = [float(chk(x["gen"], x["gold"])["parsed"]) for x in g]
            if abs(st.mean(ok) - v[s]) > 1e-9:
                sys.exit(f"ARRET : {arm} graine {s} : justesse recalculee {st.mean(ok):.4f} != format_parsed enregistre {v[s]:.4f}")
            rows.append(ok)
        if len({len(r) for r in rows}) != 1:
            sys.exit(f"ARRET : {arm} : nombre de questions different selon les graines")
        M[arm] = np.array(rows)
    nq = M["top"].shape[1]
    print(f"  justesse question par question recalculee et verifiee run par run ({nq} questions, 5 graines, 4 bras)")
    rng = np.random.default_rng(4000); stats = {"ecart B gele (bottom - top)": [], "ecart A gele (dual_bottom - dual_top)": [], "interaction": []}
    seeds_only = {k: [] for k in stats}
    for _ in range(10000):
        si = rng.integers(0, 5, 5); qi = rng.integers(0, nq, nq)
        for store, q in ((stats, qi), (seeds_only, None)):
            mean = {a: (M[a][si][:, q] if q is not None else M[a][si]).mean() for a in M}
            gb = (mean["bottom"] - mean["top"]) * 100; ga = (mean["dual_bottom"] - mean["dual_top"]) * 100
            store["ecart B gele (bottom - top)"].append(gb); store["ecart A gele (dual_bottom - dual_top)"].append(ga); store["interaction"].append(ga - gb)
    pt = {"ecart B gele (bottom - top)": (M["bottom"].mean() - M["top"].mean()) * 100, "ecart A gele (dual_bottom - dual_top)": (M["dual_bottom"].mean() - M["dual_top"].mean()) * 100}
    pt["interaction"] = pt["ecart A gele (dual_bottom - dual_top)"] - pt["ecart B gele (bottom - top)"]
    OUT["A5"] = {}
    for k in stats:
        a = np.percentile(stats[k], [2.5, 97.5]); b = np.percentile(seeds_only[k], [2.5, 97.5])
        OUT["A5"][k] = {"estimation": pt[k], "ic95_graines_et_questions": [float(a[0]), float(a[1])], "ic95_graines_seules": [float(b[0]), float(b[1])]}
        flip = (b[0] > 0) != (a[0] > 0) or (b[1] < 0) != (a[1] < 0)
        print(f"  {k:40s} : {pt[k]:+.2f} ; graines et questions [{a[0]:+.2f}, {a[1]:+.2f}] ; graines seules [{b[0]:+.2f}, {b[1]:+.2f}] ; "
              f"elargissement x{(a[1] - a[0]) / max(1e-9, b[1] - b[0]):.2f}" + ("  <- LE SIGNE N'EST PLUS ETABLI" if flip else ""))


if __name__ == "__main__":
    acts = {"--a1": do_a1, "--a2": do_a2, "--a3": do_a3, "--a4": do_a4, "--a5": do_a5}
    todo = [a for a in sys.argv[1:] if a in acts]
    if not todo:
        sys.exit(__doc__)
    for a in todo:
        acts[a](); print()
    json.dump(OUT, open(f"{REPO}/analyses_v4.json", "w"), indent=1, default=float)
    print(f"  sorties enregistrees : {REPO}/analyses_v4.json")
