"""State of the rank-16 A-frozen campaign on this server, for PROTOCOL_freezeA_rank16_addendum.md.
Exit 0: no run of the campaign has started.  Exit 10: runs started, none finished.  Exit 20: results exist (the addendum would come too late)."""
import glob
import os
import sys

import yaml

started = done = 0
for p in glob.glob(os.path.expanduser("~/lora-runs/*/config.yaml")):
    c = yaml.safe_load(open(p)) or {}
    if (c.get("mode") in ("dual_top", "dual_bottom") and c.get("rank") == 16 and str(c.get("model")) == "Qwen/Qwen2.5-1.5B"
            and (str(c.get("data_fingerprint")) == "0755bcdbdce3" or os.path.basename(str(c.get("data_dir") or "").rstrip("/")) == "openbookqa")):
        started += 1
        try:
            done += open(os.path.join(os.path.dirname(p), "status")).read().startswith("DONE")
        except OSError:
            pass
if done:
    print(f"  {done} run(s) de la campagne ont deja un resultat : un additif ecrit maintenant ne serait plus pre-enregistre")
    sys.exit(20)
if started:
    print(f"  {started} run(s) demarre(s), aucun resultat : l'additif precede tout resultat, mais pas tout run")
    sys.exit(10)
print("  aucun run de la campagne n'a demarre : l'additif precede tout run")
sys.exit(0)
