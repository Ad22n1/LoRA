#!/bin/bash
# Forgetting at a COMMON learning rate — the control the paper's forgetting section is missing.
#
# The first pass compares bottom at 2e-3 with top at 1e-2, because each arm was run at its own
# selected rate. The perplexity gap it reports (21.2 against 40.6) can therefore come entirely from
# the rate rather than from the band — the exact confound this paper holds against the literature it
# discusses.
#
# Here every arm is read at 2e-3, using configs/lr_common_2e-3.yaml. `random` is left out: it has no
# run at 2e-3 with saved factors.
#
# No --gres on this cluster: the grids ask for a whole node with --exclusive instead.
#SBATCH --job-name=forgetC
#SBATCH --partition=PARTITION
#SBATCH --cpus-per-task=4
#SBATCH --mem=32G
#SBATCH --exclusive
#SBATCH --time=01:59:00
#SBATCH --output=~/lora-results/forgetC-%j.out

source /tmp/lora-$USER/venv/bin/activate
export SHARED=$HOME/lora-shared
cd $HOME/repo

python scripts/forgetting_from_factors.py \
  --svd_cache "$SHARED/svd" \
  --lr_from configs/lr_common_2e-3.yaml \
  --modes bottom,top,random_ortho,free \
  --seeds 2,3,4,5,6 --max_runs_per_cell 5 \
  --out "$HOME/lora-analysis/forgetting_common_lr.csv"
