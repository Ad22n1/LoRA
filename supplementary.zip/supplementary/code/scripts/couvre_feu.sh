#!/bin/bash
# Filet de securite, independant du pilote : dort jusqu'a 7 h 58, puis annule tous les jobs lorasub de l'utilisateur.
#   nohup bash scripts/couvre_feu.sh > ~/couvre_feu.log 2>&1 & disown
T=$(date -d "07:58" +%s); [ "$(date +%s)" -ge "$T" ] && T=$(date -d "tomorrow 07:58" +%s)
echo "$(date '+%d/%m %H:%M')  couvre-feu programme pour $(date -d "@$T" '+%d/%m %H:%M')"
sleep $(( T - $(date +%s) ))
scancel -u "$USER" -n lorasub 2>/dev/null
sleep 30; echo "$(date '+%d/%m %H:%M')  jobs lorasub annules ; restant dans la file : $(squeue -h -u "$USER" -n lorasub 2>/dev/null | wc -l)"
