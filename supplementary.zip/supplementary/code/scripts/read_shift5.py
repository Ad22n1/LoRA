"""PROTOCOL_shift_5seeds.md: does the rate shift survive a selection on five seeds? VALIDATION ONLY. No PARTITION.

    python scripts/read_shift5.py 2>&1 | grep -vE "FutureWarning|pd.concat"

Five selection seeds: 0, 1 (from each cell's own campaign) and 110-112 (fresh). (1) On the mean over the five seeds, bottom's rate must be
strictly lower than EACH of top, random and random_ortho: confirmed / partial / not reproduced. (2) Seed by seed: on how many of the five
seeds is bottom's best rate strictly lower than each of the three others'? For comparison, the selection on seeds 0-1 alone among the
same five rates. A robustness check of the selection, not a new selection: the paper's tests stay at the rates chosen on seeds 0-1.
"""
import csv
import glob
import json
import math
import os
import random
import re
import statistics as st

import yaml

R = os.path.expanduser("~/lora-runs")
LLAMA, QWEN = "meta-llama/Llama-3.2-1B", "Qwen/Qwen2.5-1.5B"
S_SEL, S_REP = (0, 1), [2, 3, 4, 5, 6]


def tokens(c):
    t = c.get("target_tokens")
    return t.get(c.get("task")) if isinstance(t, dict) else t


RUNS = []
for p in glob.glob(R + "/*/config.yaml"):
    c = yaml.safe_load(open(p)) or {}
    d = os.path.dirname(p)
    try:
        if not open(d + "/status").read().startswith("DONE"):
            continue
        RUNS.append((c, json.load(open(d + "/metrics.json")), d))
    except OSError:
        continue


def clipped(c):
    """Gradient clipping at 1.0, the paper's setting. A noclip grid reran the same cells without clipping (collect()'s
    docstring); mixing both put two runs per seed in the frozen cells and moved G from 12.41 to 13.53 (26/09)."""
    v = c.get("max_grad_norm", 1.0)
    return v is not None and float(v) == 1.0


def seven(c):
    tm = c.get("target_modules")
    return tm is None or len(tm) == 7


def cell(pred, mode, rank, lr, seeds, key):
    """{seed: value}; several runs of one seed are averaged and flagged."""
    by = {}
    for c, m, d in RUNS:
        if (pred(c) and clipped(c) and c.get("mode") == mode and c.get("rank") == rank and abs(float(c.get("lr") or 0) - lr) < 1e-12
                and c.get("seed") in seeds and key in m and c.get("update_norm_target") in (None, "")):
            by.setdefault(c["seed"], []).append((m[key], d))
    dup = {s: len(v) for s, v in by.items() if len(v) > 1}
    if dup:   # say what separates the duplicates, so that the next filter is written from evidence
        s0 = sorted(dup)[0]; cfgs = [yaml.safe_load(open(d + "/config.yaml")) or {} for _, d in by[s0]]
        keys = sorted(k for k in set().union(*cfgs) if k not in ("run_id", "out_dir") and len({str(c_.get(k)) for c_ in cfgs}) > 1)
        dup["differ"] = {k: [c_.get(k) for c_ in cfgs] for k in keys} or "configs identiques"
    return {s: st.mean(x for x, _ in v) for s, v in by.items()}, dup, {s: [d for _, d in v] for s, v in by.items()}


fmt = lambda c: (c.get("task") == "format" and str(c.get("model")) == LLAMA and tokens(c) == 600000 and seven(c)  # noqa: E731
                 and c.get("max_len") == 384 and c.get("batch_size") == 2 and c.get("grad_accum") == 16)
obqa = lambda c: c.get("task") == "commonsense" and str(c.get("data_fingerprint")) == "dc05f4d847f9" and str(c.get("model")) == QWEN and seven(c)  # noqa: E731
ARMS = ["top", "bottom", "random", "random_ortho"]
LRS = [1e-3, 2e-3, 5e-3, 1e-2, 2e-2]
S5 = [0, 1, 110, 111, 112]


def best_set(m):
    """rates whose mean equals the best mean to the fourth decimal (PROTOCOL_shift_5seeds.md, precision 3): a tie is a set"""
    top_ = max(m.values())
    return sorted(lr for lr, v in m.items() if round(v, 4) == round(top_, 4))


def lower(b, o):
    """strictly lower: the highest of bottom's best rates below the lowest of the other arm's best rates"""
    return max(b) < min(o)


def fmt_set(x):
    return "/".join(f"{lr:g}" for lr in x) + (" (EGALITE)" if len(x) > 1 else "")


def read(title, pred, vkey, extra_bottom=None):
    print(f"\n==================== {title} ====================")
    V, dups = {}, []
    for a in ARMS:
        for lr in LRS:
            v, dup, _ = cell(pred, a, 2, lr, S5, vkey)
            V[(a, lr)] = v
            if dup: dups.append(f"{a} {lr:g} {dup}")
    if dups:
        print("  DOUBLONS (moyennes par graine) : " + "; ".join(dups[:4]))
    rates = [lr for lr in LRS if all(len(V[(a, lr)]) == 5 for a in ARMS)]
    excl = [f"{lr:g} (" + ", ".join(f"{a} {len(V[(a, lr)])}/5" for a in ARMS if len(V[(a, lr)]) < 5) + ")" for lr in LRS if lr not in rates]
    print("  taux retenus pour la comparaison (cinq graines pour les quatre bras) : " + ", ".join(f"{lr:g}" for lr in rates)
          + (f" ; EXCLUS : {'; '.join(excl)}" if excl else ""))
    if len(rates) < 2:
        print("  NON CALCULABLE : moins de deux taux complets"); return
    print("  validation, moyenne sur 5 graines :")
    best = {}
    for a in ARMS:
        m = {lr: st.mean(V[(a, lr)].values()) for lr in rates}; best[a] = best_set(m)
        print(f"    {a:13s} " + "  ".join(f"{lr:g}:{m[lr]:.4f}" for lr in rates) + f"  -> {fmt_set(best[a])}"
              + ("  AU BORD" if any(lr in (rates[0], rates[-1]) for lr in best[a]) else ""))
    others = [a for a in ARMS if a != "bottom"]
    low = [a for a in others if lower(best["bottom"], best[a])]
    verdict = "CONFIRME" if len(low) == 3 else ("PARTIEL" if low else "NON REPRODUIT")
    print(f"  (1) PRINCIPAL : bottom {fmt_set(best['bottom'])} ; strictement plus bas que {low or 'aucun'} -> {verdict}")
    per = {s: {a: best_set({lr: V[(a, lr)][s] for lr in rates}) for a in ARMS} for s in S5}
    n_all = sum(all(lower(per[s]["bottom"], per[s][a]) for a in others) for s in S5)
    each = {a: sum(lower(per[s]["bottom"], per[s][a]) for s in S5) for a in others}
    print(f"  (2) graine par graine : bottom strictement plus bas que les trois autres sur {n_all}/5 graines ; contre chacun : "
          + ", ".join(f"{a} {k}/5" for a, k in each.items()))
    for s in S5:
        print(f"      graine {s:3d} : " + ", ".join(f"{a} {fmt_set(per[s][a])}" for a in ARMS))
    two = {a: best_set({lr: st.mean(V[(a, lr)][s] for s in (0, 1)) for lr in rates}) for a in ARMS}
    changed = [a for a in ARMS if two[a] != best[a]]
    print("  rappel, selection sur les graines 0-1 seules (memes taux) : " + ", ".join(f"{a} {fmt_set(two[a])}" for a in ARMS)
          + (f"\n  -> la selection a cinq graines change le taux de {changed} : LIMITE a rapporter (les tests du papier ne sont pas relances)" if changed else "\n  -> memes taux qu'a deux graines"))
    if extra_bottom:
        ex = {lr: cell(pred, "bottom", 2, lr, extra_bottom, vkey)[0] for lr in rates}
        got = [s for s in extra_bottom if all(s in ex[lr] for lr in rates)]
        print(f"  A PART (ne comptent pas) : graines {extra_bottom} de bottom, celles du departage du papier : {len(got)} completes"
              + ("" if not got else " ; meilleur taux par graine : " + ", ".join(f"{s} {fmt_set(best_set({lr: ex[lr][s] for lr in rates}))}" for s in got)))


read("tache de format, rang 2, Llama-3.2-1B", fmt, "val_format_parsed", extra_bottom=[30, 31, 32])
read("OpenBookQA, rang 2, Qwen2.5-1.5B", obqa, "val_mcq_acc")
