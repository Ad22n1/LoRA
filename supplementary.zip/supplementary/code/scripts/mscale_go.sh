#!/bin/bash
# Apres la SONDE (PROTOCOL_scale_mistral.md) : applique la regle ecrite d avance. M7B -> grilles de SELECTION committees, puis lancees ;
# NONE -> pas de campagne (pas de modele de repli). Aucune decision a la main.
set -u
cd "$HOME/repo" || exit 1
PY="/tmp/lora-$USER/venv/bin/python"; [ -x "$PY" ] || PY=python3
out=$("$PY" scripts/probe_report_mistral.py 2>&1); echo "$out" | sed 's/^/  /'
D=$(echo "$out" | grep -oE "^DECISION : (M7B|NONE)$" | awk '{print $3}')
case "$D" in
  M7B)
    echo "=== modele retenu par la regle : $D -> etape 1, selection ==="
    "$PY" scripts/make_mscale_grids.py --stage1 "$D" || { echo "  STOP : generation refusee"; exit 1; }
    git add configs/grids/mscale_s1_*.yaml && git commit -qm "echelle Mistral : modele $D retenu par la regle (sonde lue) ; grilles de selection avant leurs runs" && echo "  ok : committe ($(git log -1 --format=%h))"
    git push -q 2>/dev/null; bash scripts/launch_mscale_s1.sh ;;
  NONE) echo "=== la sonde de Mistral ne passe pas la regle : PAS DE CAMPAGNE ; le papier part sans elle ===" ;;
  *) echo "  STOP : pas de decision lisible"; exit 1 ;;
esac
