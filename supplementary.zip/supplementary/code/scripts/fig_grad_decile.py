"""Gradient energy by decile of the spectrum of W0, before any training.

This figure existed in the paper with no script behind it: it was produced from code typed at a
terminal and never saved, which means nobody could reproduce its plot. The numbers it shows are in
grad_probe's own output; only the drawing was lost.

Reads the probe CSV (5,824 rows: layer x module x band x side) and plots, per decile, the ratio of
gradient energy to the null reference — the share a subspace of that size would capture by chance.
A ratio above 1 means the gradient concentrates there.

Usage:
    python scripts/fig_grad_decile.py [probe.csv] [out.png]
"""
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
# No conclusions inside the images (24/09): every title is dropped, only panel letters such as "(a)"
# are kept where a caption refers to them. What a figure shows is said in its caption, where it can
# be qualified -- a claim written in the image cannot.
import re as _re
import matplotlib.axes as _max
import matplotlib.figure as _mfig
_set_title = _max.Axes.set_title
def _letter_only(self, label="", *a, **k):
    m = _re.match(r"\s*\(([a-z])\)", str(label))
    return _set_title(self, f"({m.group(1)})" if m else "", loc="left", fontsize=10)
_max.Axes.set_title = _letter_only
_mfig.Figure.suptitle = lambda self, *a, **k: None

# Same signature as every other fig_*.py in this directory: OUTPUT first, optional input second.
# It used to be the other way round, and `python scripts/fig_grad_decile.py out.png` then tried to
# READ out.png as the probe CSV and died on a FileNotFoundError that named the output file.
OUT = Path(sys.argv[1] if len(sys.argv) > 1 else "paper/figures/grad_energy_by_decile.png")
CSV = Path(sys.argv[2] if len(sys.argv) > 2 else
           Path.home() / "lora-results/grad_probe_llama/grad_probe_meta-llama__Llama-3.2-1B.csv")
if not CSV.exists():
    sys.exit(f"probe CSV not found: {CSV}\n"
             f"usage: {sys.argv[0]} [out.png] [probe.csv]")

# Excluded: gate_proj and up_proj. They map 2048 -> 8192, so their 2048 singular values do NOT
# partition an 8192-dimensional output space, and a decile of them is not a tenth of the energy.
# This is what the paper means by "the five module types where the deciles partition the energy" —
# it is not the degeneracy criterion, which excludes q_proj and o_proj instead. Getting the two
# confused changes the last decile from 2.198/1.764 to 1.64/1.69 and erases the composition effect
# the caption discusses.
NOT_PARTITIONED = {"gate_proj", "up_proj"}
STYLE = {"facts": ("#4c72b0", "o", "knowledge"), "format": ("#dd8452", "s", "format")}

d = pd.read_csv(CSV)
# Bands are named "frac:0.0-0.1" for the deciles, plus "top:16", "bottom:16" and "_outside" —
# those three answer a different question and must not be averaged in with the deciles.
d = d[(d.side == "left") & d.band.astype(str).str.startswith("frac:")]
d = d[~d.module_type.isin(NOT_PARTITIONED)]
d["band"] = d.band.astype(str).str.replace("frac:", "", regex=False)
if d.empty:
    sys.exit(f"no decile rows in {CSV}")

d["ratio"] = d.energy / d["null"].replace(0, float("nan"))

# Two panels. The left one shows the profile, and at the last decile the two curves visibly
# separate (2.198 against 1.764) — which contradicts the claim that the tasks are indistinguishable.
# The answer to that is the pairing, and it belongs ON the figure rather than in a caption the
# reader reaches after seeing the opposite: paired by (layer, module), the gap straddles zero.
fig, (ax, ax2) = plt.subplots(1, 2, figsize=(9.6, 3.9),
                              gridspec_kw=dict(width_ratios=[1.45, 1]))

bands = sorted(d.band.unique(), key=lambda b: float(str(b).split("-")[0]))
for ds, g in d.groupby("dataset"):
    col, mk, lab = STYLE.get(str(ds), ("0.4", "^", str(ds)))
    med = g.groupby("band")["ratio"].median().reindex(bands)
    ax.plot(range(len(bands)), med.values, marker=mk, color=col, label=lab, lw=1.8, markersize=6)

ax.axhline(1.0, ls="--", color="0.6", lw=1.0)
ax.text(0.02, 1.0, "null reference", transform=ax.get_yaxis_transform(),
        va="bottom", fontsize=7.5, color="0.45")
ax.set_xticks(range(len(bands)))
ax.set_xticklabels([str(b) for b in bands], rotation=45, ha="right", fontsize=7.5)
ax.set_xlabel("decile of the spectrum of $W_0$  (top $\\rightarrow$ bottom)", fontsize=9)
ax.set_ylabel("gradient energy / null reference", fontsize=9)
ax.set_title("(a) the gradient concentrates at the bottom", fontsize=9.5)
ax.legend(fontsize=8.5, frameon=False)
ax.set_ylim(min(0.6, float(d.groupby(["dataset", "band"]).ratio.median().min()) - 0.12), None)
ax.grid(axis="y", color="0.92", lw=0.7)
ax.set_axisbelow(True)

# (b) the pairing, on the last decile: one point per (layer, module)
piv = (d[d.band == bands[-1]]
       .pivot_table(index=["layer", "module_type"], columns="dataset", values="ratio"))
piv = piv.dropna()
diff = (piv["facts"] - piv["format"]).sort_values()
n_pos = int((diff > 0).sum())
# dashed, so it cannot be mistaken for the solid red median line beside it
ax2.axvline(0, ls="--", color="0.55", lw=1.0)
ax2.hist(diff.values, bins=18, color="0.62", edgecolor="white", lw=0.5)
ax2.axvline(float(diff.median()), color="#c44e52", lw=1.6)
ax2.annotate(f"median {diff.median():+.2f} $\\times$ null ref.",
             xy=(float(diff.median()), ax2.get_ylim()[1] * 0.80),
             xytext=(8, 0), textcoords="offset points",
             fontsize=7.5, color="#c44e52", va="center", ha="left")
ax2.set_xlabel("knowledge $-$ format, last decile", fontsize=9)
ax2.set_ylabel("(layer, module) pairs", fontsize=9)
ax2.set_title(f"(b) paired, the gap straddles zero\n"
              f"knowledge leads in {n_pos}/{len(diff)}, sign test $p = 0.15$", fontsize=9.5)
ax2.grid(axis="y", color="0.92", lw=0.7)
ax2.set_axisbelow(True)

for a in (ax, ax2):
    for sp in ("top", "right"):
        a.spines[sp].set_visible(False)

fig.suptitle("The last decile separates in median, but not pair by pair", fontsize=10.5, y=0.99)
fig.text(0.5, 0.015, "median over the five module types whose deciles partition the energy, and "
                     "over sixteen layers; measured before any training",
         ha="center", fontsize=7.5, color="0.45")
fig.tight_layout(rect=(0, 0.06, 1, 0.95))
OUT.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(OUT, dpi=200)
print(f"{len(d)} decile rows, {d.module_type.nunique()} modules, {d.layer.nunique()} layers")
print(f"paired pairs: {len(diff)}, knowledge leads in {n_pos}")
print("ecrit ->", OUT)
