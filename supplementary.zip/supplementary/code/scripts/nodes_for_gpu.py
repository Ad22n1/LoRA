"""Which nodes carry a given PARTITION model? Prints the Slurm --exclude list that pins a campaign to that model. READ ONLY.

    python scripts/nodes_for_gpu.py "RTX 4000 Ada"            # prints the exclusion list on the last line
    python scripts/nodes_for_gpu.py "RTX 4000 Ada" --report   # and the node -> PARTITION map it rests on

Source: the host and PARTITION every run recorded in its results.csv (~/lora-runs and ~/lora-runs-suivi), and the node list of the
partition (sinfo). A job array cannot be pinned with --nodelist (every task would need every listed node), so the campaign is
pinned by EXCLUDING every other node -- including nodes never seen in a run, whose PARTITION is unknown.
"""
import csv
import glob
import os
import subprocess
import sys
from collections import defaultdict

want = sys.argv[1] if len(sys.argv) > 1 else "RTX 4000 Ada"
seen = defaultdict(set)
for root in ("~/lora-runs", "~/lora-runs-suivi"):
    for f in glob.glob(os.path.expanduser(root) + "/*/results.csv"):
        try:
            with open(f, newline="") as fh:
                r = next(csv.DictReader(fh))
        except (OSError, StopIteration):
            continue
        h, g = (r.get("host") or "").split(".")[0], r.get("PARTITION") or ""
        if h and g:
            seen[h].add(g)
try:
    out = subprocess.run(["sinfo", "-h", "-p", "PARTITION", "-N", "-o", "%N"], capture_output=True, text=True, timeout=30).stdout
    nodes = sorted({l.strip().split(".")[0] for l in out.split() if l.strip()})
except Exception:  # noqa: BLE001
    nodes = []
if not nodes:
    sys.exit("STOP : liste des machines de la partition indisponible (sinfo)")
good = sorted(n for n in nodes if seen.get(n) and all(want in g for g in seen[n]))
mixed = sorted(n for n in nodes if seen.get(n) and any(want in g for g in seen[n]) and not all(want in g for g in seen[n]))
if not good:
    sys.exit(f"STOP : aucune machine connue ne porte uniquement « {want} »")
exclude = sorted(set(nodes) - set(good))
if "--report" in sys.argv:
    print(f"  {len(nodes)} machines dans la partition ; {len(good)} portent « {want} » (vu dans les runs) : {', '.join(good)}")
    if mixed:
        print(f"  exclues car vues avec plusieurs modeles : {', '.join(mixed)}")
    print(f"  exclues car jamais vues : {', '.join(n for n in nodes if not seen.get(n)) or 'aucune'}")
print(",".join(exclude))
