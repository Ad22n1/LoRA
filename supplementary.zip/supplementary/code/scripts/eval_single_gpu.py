"""Follow-up of PROTOCOL_obqa_unfrozen.md (second addendum): re-evaluate the thirty compared checkpoints on ONE PARTITION model.

    python scripts/eval_single_gpu.py --dry                          # no PARTITION: lists the 30 runs and their final factors
    python scripts/eval_single_gpu.py --expect "RTX 4000 Ada"        # on the pinned node (the Slurm job does this)

The thirty: the ten frozen references retrained with their factors (~/lora-runs-suivi: top 5e-3, bottom 2e-3, rank 2, seeds 2-6),
and top_unfrozen / bottom_unfrozen at ranks 1 and 2, at their selected rate 2e-3, seeds 2-6 (~/lora-runs). Each is reloaded
from its final factors by the reload path of the point-6 script (load_model, inject_lora, load_factors_into), then evaluated on
the test split. GUARDS: exactly one run per (cell, seed); final factors present; the PARTITION model must contain --expect, else stop.
Output: ~/lora-analysis/obqa_single_gpu.csv, one row per run.
"""
import argparse
import csv
import glob
import json
import os
import socket
import sys
from pathlib import Path

import yaml

# copied VERBATIM from scripts/norm_rescale_eval.py (the reload path of the point-6 script), to avoid importing torch in --dry
def last_factors(d: Path):
    """Final factors, never the initialisation (A = 0 would evaluate the base model)."""
    best, key_best = None, None
    for f in d.glob("factors_*.safetensors"):
        stem = f.stem[len("factors_"):]
        if stem in ("0", "rescaled"):
            continue
        key = (1, 0) if stem == "end" else ((0, int(stem)) if stem.isdigit() else None)
        if key is not None and (key_best is None or key > key_best):
            best, key_best = f, key
    return best



QWEN, FP = "Qwen/Qwen2.5-1.5B", "dc05f4d847f9"
S = [2, 3, 4, 5, 6]
CELLS = [  # (runs directory, mode, rank, lr)
    ("~/lora-runs-suivi", "top", 2, 5e-3), ("~/lora-runs-suivi", "bottom", 2, 2e-3),
    ("~/lora-runs", "top_unfrozen", 1, 2e-3), ("~/lora-runs", "top_unfrozen", 2, 2e-3),
    ("~/lora-runs", "bottom_unfrozen", 1, 2e-3), ("~/lora-runs", "bottom_unfrozen", 2, 2e-3),
]


def run_config(path):
    """The RunConfig of a run, rebuilt as load_config does (paths such as $SHARED/svd expanded); fields a newer code base
    no longer knows are dropped rather than refused, so that old runs reload."""
    from dataclasses import fields
    from lorasub.config import RunConfig, apply_model_defaults
    raw = yaml.safe_load(open(path)) or {}
    known = {f.name for f in fields(RunConfig)}
    return RunConfig(**apply_model_defaults({k: v for k, v in raw.items() if k in known}))


def find_runs():
    out, problems = [], []
    for root, mode, rank, lr in CELLS:
        by = {}
        for p in glob.glob(os.path.expanduser(root) + "/*/config.yaml"):
            c = yaml.safe_load(open(p)) or {}
            v = c.get("max_grad_norm", 1.0)
            if (c.get("task") == "commonsense" and str(c.get("data_fingerprint")) == FP and str(c.get("model")) == QWEN
                    and c.get("mode") == mode and c.get("rank") == rank and abs(float(c.get("lr") or 0) - lr) < 1e-12
                    and c.get("seed") in S and v is not None and float(v) == 1.0 and c.get("update_norm_target") in (None, "")):
                d = Path(p).parent
                if open(d / "status").read().startswith("DONE"):
                    by.setdefault(c["seed"], []).append(d)
        for s in S:
            ds = by.get(s, [])
            if len(ds) != 1:
                problems.append(f"{mode} r={rank} {lr:g} graine {s} : {len(ds)} run(s) dans {root}")
                continue
            f = last_factors(ds[0])
            if f is None:
                problems.append(f"{mode} r={rank} graine {s} : pas de facteurs finaux ({ds[0].name})")
                continue
            out.append((ds[0], f, mode, rank, lr, s))
    return out, problems


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry", action="store_true"); ap.add_argument("--expect", default="RTX 4000 Ada")
    ap.add_argument("--svd_cache", default=os.path.expanduser("~/lora-shared/svd"))
    ap.add_argument("--out", default=os.path.expanduser("~/lora-analysis/obqa_single_gpu.csv"))
    a = ap.parse_args()
    runs, problems = find_runs()
    print(f"  {len(runs)} checkpoints trouves sur 30")
    for p in problems:
        print("  PROBLEME :", p)
    if a.dry:
        for d, f, mode, rank, lr, s in runs:
            print(f"    {mode:16s} r={rank} {lr:g} graine {s} : {d.name} <- {f.name}")
        return
    if problems or len(runs) != 30:
        sys.exit("  STOP : il faut exactement les 30 checkpoints, chacun avec ses facteurs finaux")
    import torch
    from lorasub.eval import run_all
    from lorasub.lora import inject_lora, load_factors_into
    from lorasub.modeling import load_model, load_tokenizer
    from lorasub.train import ensure_svd_cache       # exactly what training does before injecting (26/09: the cache of
    #   Qwen2.5-1.5B is not in ~/lora-shared/svd; training reads cfg.svd_cache, "$SHARED/svd", and computes it if missing)
    PARTITION = torch.cuda.get_device_name(0) if torch.cuda.is_available() else "cpu"
    print(f"  noeud {socket.gethostname()} ; carte {PARTITION}")
    if a.expect not in PARTITION:
        sys.exit(f"  STOP : la carte ({PARTITION}) n'est pas du modele attendu ({a.expect}) ; rien n'est evalue")
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    rows = []
    for d, f, mode, rank, lr, s in runs:
        c = yaml.safe_load(open(d / "config.yaml")); rec = json.load(open(d / "metrics.json"))
        cfg = run_config(d / "config.yaml")                 # the run's own configuration, $SHARED expanded as in training
        tok = load_tokenizer(c["model"]); model = load_model(c["model"])
        ensure_svd_cache(model, cfg)                       # computed once on this node if missing, under the training's lock
        inject_lora(model, r=int(c["rank"]), mode=c["mode"], cache_dir=cfg.svd_cache, model_id=c["model"],
                    seed=int(c.get("seed", 0)), subspace_salted=bool(c.get("subspace_salted", False)))
        model.eval()
        if hasattr(model.config, "use_cache"):
            model.config.use_cache = True
        load_factors_into(model, f)
        data_dir = os.path.expandvars(os.path.expanduser(str(c["data_dir"])))
        m = run_all(model, tok, c["task"], data_dir, limit=int(c.get("eval_limit") or 1000), split="test",
                    max_new_tokens=int(c.get("max_new_tokens") or 128), do_forgetting=False)
        rows.append({"run": d.name, "root": str(d.parent), "mode": mode, "rank": rank, "lr": lr, "seed": s,
                     "mcq_acc_single": m["mcq_acc"], "mcq_acc_recorded": rec.get("mcq_acc"), "PARTITION": PARTITION, "node": socket.gethostname()})
        print(f"    {mode:16s} r={rank} graine {s} : {m['mcq_acc']:.4f} (enregistre {rec.get('mcq_acc')})", flush=True)
        del model
        torch.cuda.empty_cache()
    with open(a.out, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    print(f"  ecrit -> {a.out}")


if __name__ == "__main__":
    main()
