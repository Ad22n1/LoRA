"""Four analyses asked by the external review, all without PARTITION (they only read files).

    python scripts/analyses_sans_gpu.py 2>&1 | grep -vE "FutureWarning|pd.concat"

1. Singular values inside the frozen bands (SVD cache, S in fp32): sigma_1/sigma_2 in the top band and sigma_(m-1)/sigma_m
   in the bottom band at rank 2, and sigma_1/sigma_16 in the top band at rank 16, per module type. If the ratio is close to 1,
   the equivalence of top_scalar and top_sigma says little beyond Adam's scale identity. Also: is sqrt(sigma) above 1 on the
   top band and below 1 on the bottom band, the condition under which Appendix "adam" predicts the direction of the shift?
2. PARTITION models across arms, seed by seed, for the main populations (results.csv of each run): an evaluation that depends on the
   PARTITION (see the point-6 diagnosis) only stays inside the paired intervals if the PARTITION types are balanced across arms.
3. top trained on q and o only: loss low, valid format low. Which sub-rule fails, and what do the generations look like?
4. How much of bottom's deficit at rank 2 comes from the initials signature sub-rule (format_sig_ok)?
"""
import csv
import glob
import json
import os
import statistics as st
from collections import Counter, defaultdict

import yaml

R = os.path.expanduser("~/lora-runs")
SVD = os.path.expanduser("~/lora-shared/svd/meta-llama__Llama-3.2-1B")
LLAMA = "meta-llama/Llama-3.2-1B"
TYPES = ("q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj")


def q(v, p):
    v = sorted(v); return v[min(len(v) - 1, int(p * (len(v) - 1) + 0.5))]


# ================================================================================================ 1. singular values
print("==================== 1. valeurs singulieres dans les bandes (Llama-3.2-1B) ====================")
try:
    from safetensors.numpy import load_file
    files = sorted(glob.glob(SVD + "/*.safetensors"))
    if not files:
        raise FileNotFoundError(SVD)
    by = defaultdict(lambda: defaultdict(list))
    for f in files:
        S = load_file(f)["S"].astype("float64")
        t = next((x for x in TYPES if x in os.path.basename(f)), None)
        if t is None:
            continue
        by[t]["top 1/2"].append(S[0] / S[1]); by[t]["bot (m-1)/m"].append(S[-2] / S[-1]); by[t]["top 1/16"].append(S[0] / S[15])
        by[t]["sqrt top"].append(float((S[0] ** 0.5 + S[1] ** 0.5) / 2)); by[t]["sqrt bot"].append(float((S[-2] ** 0.5 + S[-1] ** 0.5) / 2))
    print(f"  {len(files)} modules lus dans {SVD}")
    print(f"  {'type':10s} {'n':>3s} | {'s1/s2 (top r=2)':>22s} | {'s(m-1)/s(m) (bot r=2)':>22s} | {'s1/s16 (top r=16)':>20s} | {'moy sqrt s top':>14s} {'moy sqrt s bot':>14s}")
    allt, allb = [], []
    for t in TYPES:
        d = by[t]
        if not d["top 1/2"]:
            continue
        allt += d["sqrt top"]; allb += d["sqrt bot"]
        f3 = lambda v: f"{st.median(v):5.2f} [{q(v, .1):4.2f}-{q(v, .9):4.2f}]"  # noqa: E731
        print(f"  {t:10s} {len(d['top 1/2']):3d} | {f3(d['top 1/2']):>22s} | {f3(d['bot (m-1)/m']):>22s} | {f3(d['top 1/16']):>20s} | "
              f"{st.median(d['sqrt top']):14.3f} {st.median(d['sqrt bot']):14.4f}")
    print("  (mediane [10e-90e centile] sur les couches)")
    print(f"  condition de l'annexe « adam » : sqrt(sigma) > 1 sur la bande top dans {sum(v > 1 for v in allt)}/{len(allt)} modules ;"
          f" < 1 sur la bande bottom dans {sum(v < 1 for v in allb)}/{len(allb)} modules")
except Exception as e:  # noqa: BLE001
    print("  impossible :", e)


# ------------------------------------------------------------------------------------------------ run loading
def tokens(c):
    t = c.get("target_tokens")
    return t.get(c.get("task")) if isinstance(t, dict) else t


def clipped(c):
    v = c.get("max_grad_norm", 1.0)
    return v is not None and float(v) == 1.0


RUNS = []
for p in glob.glob(R + "/*/config.yaml"):
    c = yaml.safe_load(open(p)) or {}
    d = os.path.dirname(p)
    try:
        if not open(d + "/status").read().startswith("DONE"):
            continue
        m = json.load(open(d + "/metrics.json"))
    except OSError:
        continue
    env = {}
    try:
        with open(d + "/results.csv", newline="") as f:
            env = next(csv.DictReader(f))
    except (OSError, StopIteration):
        pass
    RUNS.append((c, m, d, env))


def pick(pred, mode, rank, lr, seeds):
    return [(c, m, d, e) for c, m, d, e in RUNS if pred(c) and clipped(c) and c.get("mode") == mode and c.get("rank") == rank
            and abs(float(c.get("lr") or 0) - lr) < 1e-12 and c.get("seed") in seeds and c.get("update_norm_target") in (None, "")]


fmt = lambda c: c.get("task") == "format" and str(c.get("model")) == LLAMA and tokens(c) == 600000 and (c.get("target_modules") is None or len(c.get("target_modules")) == 7)  # noqa: E731
ARMS2 = {"top": (2, 1e-2), "bottom": (2, 5e-3), "random": (2, 1e-2), "random_ortho": (2, 1e-2), "free": (1, 1e-3)}
S = [2, 3, 4, 5, 6]

# ================================================================================================ 2. PARTITION balance
print("\n==================== 2. modeles de PARTITION par bras, graine par graine (format, rang 2, Llama) ====================")
short = lambda g: (g or "?").replace("NVIDIA ", "").replace("GeForce ", "").replace(" Generation", "")[:16]  # noqa: E731
grid = {}
for a, (rk, lr) in ARMS2.items():
    rs = pick(fmt, a, rk, lr, S)
    grid[a] = {c["seed"]: short(e.get("PARTITION")) for c, m, d, e in rs}
print(f"  {'bras':13s} " + " ".join(f"{'graine ' + str(s):>17s}" for s in S))
for a, g in grid.items():
    print(f"  {a:13s} " + " ".join(f"{g.get(s, '-'):>17s}" for s in S))
tot = Counter(v for g in grid.values() for v in g.values())
print("  repartition : " + ", ".join(f"{k} {v}" for k, v in tot.most_common()))
same = sum(len({grid[a].get(s) for a in grid if grid[a].get(s)}) == 1 for s in S)
print(f"  graines ou tous les bras ont tourne sur le meme modele de PARTITION : {same} sur {len(S)}")

# ================================================================================================ 3. top on q and o
print("\n==================== 3. top sur q et o seulement ====================")
qo = [(c, m, d, e) for c, m, d, e in RUNS if c.get("mode") == "top" and sorted(c.get("target_modules") or []) == ["o_proj", "q_proj"]]
if not qo:
    print("  aucun run top avec target_modules = [q_proj, o_proj]")
else:
    keys = ("format_parsed", "format_keys_ok", "format_count_ok", "format_sig_ok", "format_order_ok", "format_truncated", "format_empty")
    print(f"  {len(qo)} runs ; moyennes : " + ", ".join(f"{k.replace('format_', '')} {st.mean(m[k] for _, m, _, _ in qo if k in m):.3f}" for k in keys if any(k in m for _, m, _, _ in qo)))
    losses = []
    for _, _, d, _ in qo:
        try:
            rows = list(csv.DictReader(open(d + "/log.csv")))
            losses.append(float(rows[-1]["loss"]))
        except (OSError, IndexError, KeyError, ValueError):
            pass
    if losses:
        print(f"  perte d'entrainement finale : moyenne {st.mean(losses):.3f} (sur {len(losses)} runs)")
    g = glob.glob(qo[0][2] + "/generations_test.jsonl")
    if g:
        bad = [json.loads(l) for l in open(g[0]) if not json.loads(l)["parsed"]][:3]
        print(f"  trois generations non conformes, run {os.path.basename(qo[0][2])[:12]} :")
        for b in bad:
            print("    ---\n    " + b["gen"][:400].replace("\n", "\n    "))
    else:
        print("  generations_test.jsonl absent pour ces runs")

# ================================================================================================ 4. initials sub-rule
print("\n==================== 4. la sous-regle des initiales dans le deficit de bottom (format, rang 2, graines 2-6) ====================")
sub = ("format_parsed", "format_sig_ok", "format_keys_ok", "format_count_ok", "format_order_ok", "format_truncated")
tab = {}
for a, (rk, lr) in ARMS2.items():
    rs = pick(fmt, a, rk, lr, S)
    tab[a] = {k: st.mean(m[k] for _, m, _, _ in rs if k in m) if any(k in m for _, m, _, _ in rs) else float("nan") for k in sub}
    tab[a]["n"] = len(rs)
print(f"  {'bras':13s} {'n':>3s} " + " ".join(f"{k.replace('format_', ''):>10s}" for k in sub))
for a, v in tab.items():
    print(f"  {a:13s} {v['n']:3d} " + " ".join(f"{v[k]:10.3f}" for k in sub))
others = [a for a in ("top", "random", "random_ortho") if tab[a]["n"]]
if tab["bottom"]["n"] and others:
    for k in ("format_parsed", "format_sig_ok"):
        gap = st.mean(tab[a][k] for a in others) - tab["bottom"][k]
        print(f"  deficit de bottom sur {k.replace('format_', ''):8s} (contre la moyenne des trois autres bras geles) : {100 * gap:+.1f} points")
    print("  lecture : si le deficit en 'sig_ok' approche celui en 'parsed', la signature des initiales porte l'essentiel du deficit")
