"""Does lambda_max * lr bound the usable step size? Bracket each arm's collapse, from the data.

WHAT THIS TESTS. A stability argument says a gradient step diverges once lambda_max * lr crosses a
constant. If that is what limits the rate, every arm should collapse at the SAME value of the
product, and the four brackets should intersect.

WHY IT NEEDS THE UNCLIPPED RUNS. With clipping on, `bottom` loses one seed in five at 5e-3, and
reading that as a divergence puts its bracket at [0.66, 1.65] — which does intersect the others.
Section `noclip` shows that failure is produced by the clipping threshold, not by the band. Without
clipping `bottom` scores 0.566 at 5e-3 and 0.537 at 1e-2, and only dies at 3e-2.

I got this wrong twice by hand before writing it down: once by reading the clipped collapse as real,
once by computing an intersection over three arms while claiming it covered four. Hence this file.
"""
import os
import sys

import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from lorasub.aggregate import collect  # noqa: E402

# Curvature at initialisation, median over five seeds (curvature_5seeds.csv).
LAMBDA = {"bottom": 330.88, "top": 27.48, "random": 26.29, "random_ortho": 24.38}
DEAD = 0.05          # a score at or below this is a collapse, not a bad run
NOCLIP = 100.0       # max_grad_norm above this means clipping was effectively off


def brackets(runs_dir: str, unclipped_only: bool = True) -> pd.DataFrame:
    d = collect(os.path.expanduser(runs_dir))
    x = d[(d.task == "format") & (d["rank"] == 2) & (d.n_modules == 7)
          & d.model.astype(str).str.contains("Llama")
          & d.update_norm_target.isna()
          & d["mode"].isin(LAMBDA)]
    if unclipped_only:
        x = x[x.max_grad_norm > NOCLIP]
    if x.empty:
        raise SystemExit("no unclipped runs: the bracket cannot be built from clipped data, "
                         "see the docstring")
    g = x.groupby(["mode", "lr"])["format_parsed"].agg(["mean", "size"]).reset_index()
    rows = []
    for m, sub in g.groupby("mode"):
        alive = sub[sub["mean"] > DEAD]["lr"]
        dead = sub[sub["mean"] <= DEAD]["lr"]
        rows.append(dict(
            mode=m, lam=LAMBDA[m],
            lr_alive=alive.max() if len(alive) else float("nan"),
            lr_dead=dead.min() if len(dead) else float("nan"),
            n_rates=len(sub)))
    out = pd.DataFrame(rows).set_index("mode")
    out["holds_to"] = out.lam * out.lr_alive
    out["dies_at"] = out.lam * out.lr_dead
    return out


def main() -> None:
    out = brackets(sys.argv[1] if len(sys.argv) > 1 else "~/lora-runs")
    print(out[["n_rates", "lr_alive", "lr_dead", "holds_to", "dies_at"]].round(3).to_string())

    usable = out.dropna(subset=["holds_to", "dies_at"])
    missing = out.index.difference(usable.index).tolist()
    if missing:
        print(f"\n  NOT BRACKETED (no collapse or no survivor measured): {missing}")

    lo, hi = usable.holds_to.max(), usable.dies_at.min()
    print(f"\n  intersection over {len(usable)} arms ({list(usable.index)}): "
          f"({lo:.2f} ; {hi:.2f})")
    if lo < hi:
        print("  NON-EMPTY: a single threshold in lambda*lr is compatible with every arm.")
    else:
        worst = usable.holds_to.idxmax()
        print(f"  EMPTY: no single threshold fits. `{worst}` still trains at "
              f"{usable.holds_to.max():.2f}, where the others are already dead "
              f"({usable.dies_at.min():.2f}).")
        print("  => lambda_max * lr is NOT the quantity that bounds the usable step size.")


if __name__ == "__main__":
    main()
