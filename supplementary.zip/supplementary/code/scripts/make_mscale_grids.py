"""Grids of PROTOCOL_scale_mistral.md (with its precisions), from the server's OpenBookQA base (configs/grids/obqa_r2_common.yaml, checked).

    python scripts/make_mscale_grids.py --probe M7B       # the probe: top_unfrozen r=2, 1 run, in ~/lora-runs-probe (also --probe 3B)
    python scripts/make_mscale_grids.py --stage1 M7B      # selection: 7 arms x 5 rates x seeds 0-1 = 70 runs (7 grids)
    python scripts/make_mscale_grids.py --stage2 M7B      # report: seeds 2-6 at each arm's rate selected on seeds 0-1 = 35 runs (7 grids)
"""
import glob
import json
import os
import statistics as st
import sys
from pathlib import Path

import yaml

SRC = "configs/grids/obqa_r2_common.yaml"
MODELS = {"M7B": "mistralai/Mistral-7B-v0.3"}
ARMS = [("top", 2), ("bottom", 2), ("top_unfrozen", 2), ("bottom_unfrozen", 2), ("dual_top", 2), ("dual_bottom", 2), ("free", 1)]
LRS = [5e-4, 1e-3, 2e-3, 5e-3, 1e-2]
H = "# PRE-ENREGISTRE (PROTOCOL_scale_mistral.md, avec ses precisions). Genere par scripts/make_mscale_grids.py.\n"


def base(model):
    if not Path(SRC).exists():
        sys.exit(f"STOP : {SRC} introuvable")
    b = dict((yaml.safe_load(open(SRC)) or {}).get("base") or {})
    if not (b.get("task") == "commonsense" and str(b.get("data_fingerprint")) == "dc05f4d847f9"):
        sys.exit(f"STOP : {SRC} n'est pas OpenBookQA")
    for k in ("mode", "rank", "lr", "seed", "band_frac", "update_norm_target"):
        b.pop(k, None)
    b.update(model=MODELS[model], save_factor_steps=[])
    return b


def arg(flag):
    k = sys.argv[sys.argv.index(flag) + 1]
    if k not in MODELS:
        sys.exit(f"STOP : modele inconnu {k!r}")
    return k


def write(name, b, grid, note):
    Path(f"configs/grids/{name}.yaml").write_text(H + f"# {note}\n" + yaml.safe_dump({"base": b, "grid": grid}, sort_keys=False))


if "--probe" in sys.argv:
    m = arg("--probe"); b = base(m); b.update(rank=2, out_dir="$HOME/lora-runs-probe")
    write("mscale_probe", b, {"mode": ["top_unfrozen"], "lr": [2e-3], "seed": [99]}, f"SONDE {MODELS[m]} : n'entre dans aucun test. 1 run.")
    print(f"  mscale_probe : {MODELS[m]}, top_unfrozen r=2 a 2e-3, graine 99, dans ~/lora-runs-probe")
elif "--stage1" in sys.argv:
    m = arg("--stage1"); total = 0
    for mode, rank in ARMS:
        b = base(m); b.update(rank=rank); write(f"mscale_s1_{mode}", b, {"mode": [mode], "lr": LRS, "seed": [0, 1]}, f"SELECTION, {mode}. 10 runs.")
        total += 10; print(f"  mscale_s1_{mode:15s} : {MODELS[m]}, rang {rank}, 5 taux x graines 0-1")
    print(f"  total : {total} runs"); total == 70 or sys.exit("STOP : le total n'est pas 70")
elif "--stage2" in sys.argv:
    m = arg("--stage2"); runs = []
    for p in glob.glob(os.path.expanduser("~/lora-runs/*/config.yaml")):
        c = yaml.safe_load(open(p)) or {}
        d = os.path.dirname(p)
        if str(c.get("model")) == MODELS[m] and str(c.get("data_fingerprint")) == "dc05f4d847f9" and c.get("seed") in (0, 1):
            try:
                if open(d + "/status").read().startswith("DONE"):
                    runs.append((c, json.load(open(d + "/metrics.json"))))
            except OSError:
                pass
    chosen, total = {}, 0
    for mode, rank in ARMS:
        means = {}
        for lr in LRS:
            v = [mm["val_mcq_acc"] for c, mm in runs if c.get("mode") == mode and c.get("rank") == rank and abs(float(c["lr"]) - lr) < 1e-12 and "val_mcq_acc" in mm]
            if len(v) != 2:
                sys.exit(f"STOP : {mode} a {lr:g} : {len(v)} run(s) de selection au node de 2 ; la selection n'est pas complete")
            means[lr] = st.mean(v)
        best = max(LRS, key=lambda lr: means[lr])        # equal means: the lowest rate, as in every other selection of the paper
        chosen[mode] = best
        b = base(m); b.update(rank=rank); write(f"mscale_s2_{mode}", b, {"mode": [mode], "lr": [best], "seed": [2, 3, 4, 5, 6]}, f"RAPPORT, {mode} au taux retenu. 5 runs.")
        total += 5
        print(f"  mscale_s2_{mode:15s} : " + "  ".join(f"{lr:g}:{means[lr]:.3f}" for lr in LRS) + f"  -> {best:g}" + ("  AU BORD" if best in (LRS[0], LRS[-1]) else ""))
    print(f"  total : {total} runs"); total == 35 or sys.exit("STOP : le total n'est pas 35")
else:
    sys.exit("usage : --probe M7B|3B  |  --stage1 M7B|3B  |  --stage2 M7B|3B")
