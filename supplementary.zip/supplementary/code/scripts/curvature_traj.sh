#!/bin/bash
# Curvature ALONG the path, not at its two ends.
#
# WHAT IT SETTLES. The mechanism section measures lambda_max at initialisation (ratio 10.2) and at
# step 274 (ratio 4.85), and the paper says neither is the quantity a stability argument needs: a
# usable rate is constrained by the STIFFEST curvature the run meets on the way, and nothing shows
# that either endpoint is that one.
#
# The traj_curvature runs save ten checkpoints instead of two, so lambda can be read at each and
# the maximum over the path taken. Three outcomes, written before launch:
#   - the max is at initialisation -> the objection falls, and the ratio of 10 is the one that
#     bounds the rate, not 4.85;
#   - the max is at the end -> it falls the other way, and 4.85 is the right one;
#   - the max is in between -> that is the lambda to report, and the ratio is recomputed on it.
#
# Seeds 17-21, which belong to no reported population: save_factor_steps is in _NON_ID_FIELDS, so
# reusing seeds 2-6 would have matched the existing two-checkpoint runs and trained nothing.
#
#SBATCH --job-name=curvtraj
#SBATCH --exclude=node
#SBATCH --array=0-19
#SBATCH --partition=PARTITION
#SBATCH --cpus-per-task=4
#SBATCH --mem=32G
#SBATCH --exclusive
#SBATCH --time=01:59:00
#SBATCH --output=~/lora-results/curvtraj-%A_%a.out

source /tmp/lora-$USER/venv/bin/activate
export SHARED=$HOME/lora-shared
cd $HOME/repo

FREE=$(nvidia-smi --query-PARTITION=memory.free --format=csv,noheader,nounits | head -1)
echo "node: $(hostname)  free: ${FREE} MiB"
if [ "$FREE" -lt 13000 ]; then echo "skip: only ${FREE} MiB free"; exit 1; fi

OUT=$HOME/lora-analysis/curvature_traj.csv
# RESUMABLE. The first submission never started (a 4 h request on a partition where every job that
# runs asks for 2 h), and a job cut short would otherwise redo all twenty measurements. Each
# (arm, step) writes its own CSV; one that already exists is skipped.

# the ten points saved by traj_curvature_1b.yaml
# `end` is resolved to the last step number by _save_steps, so the file on disk is
# factors_274, not factors_end. A format run is 274 steps.
# ONE MEASUREMENT PER ARRAY TASK. A single job did four of the twenty in its two hours and was
# killed by the time limit; each task here does one (arm, step), about half an hour.
STEPS=(0 5 10 20 40 70 110 160 220 274)
# bottom at 5e-3: the trajectory runs (seeds 17-21) were trained at 5e-3 and 5e-4, never at
# 2e-3, so a lookup at 2e-3 found nothing and only the ten top points were ever measured.
# 5e-3 is also the rate the selection rule picks. This path therefore compares bottom at 5e-3
# with top at 1e-2, a displacement of two; the step-274 table uses bottom at 2e-3.
SPECS=("bottom 0.005" "top 0.01")
ID=${SLURM_ARRAY_TASK_ID:-0}
STEP=${STEPS[$((ID / 2))]}
set -- ${SPECS[$((ID % 2))]}
F="$HOME/lora-analysis/curvtraj_${1}_${STEP}.csv"
if [ -s "$F" ]; then echo "=== $1 at step $STEP: already measured, skipped ==="; exit 0; fi
echo "=== $1 at step $STEP ==="
python scripts/curvature.py \
  --model meta-llama/Llama-3.2-1B \
  --data_dir "$SHARED/data" --svd_cache "$SHARED/svd" \
  --task format --rank 2 --modes "$1" --seeds 17,18,19,20,21 \
  --from_step "$STEP" --lr "$2" --max_grad_norm 1.0 \
  --runs_dir "$HOME/lora-runs" \
  --n_batches 3 --iters 60 --restarts 5 \
  --out "$F"
N=$(ls $HOME/lora-analysis/curvtraj_*.csv 2>/dev/null | wc -l)
if [ "$N" -lt 20 ]; then echo "  $N/20 measured; the summary runs when the last task finishes"; exit 0; fi

python - <<'PY'
import glob
import os
import re

import pandas as pd

rows = []
for f in glob.glob(os.path.expanduser("~/lora-analysis/curvtraj_*.csv")):
    m = re.search(r"curvtraj_(\w+?)_(\w+)\.csv$", os.path.basename(f))
    if not m:
        continue
    try:
        d = pd.read_csv(f)
    except Exception:
        continue
    d["arm"], d["step"] = m.group(1), m.group(2)
    rows.append(d)
if not rows:
    raise SystemExit("no per-step CSV was written")
d = pd.concat(rows, ignore_index=True)
d.to_csv(os.path.expanduser("~/lora-analysis/curvature_traj.csv"), index=False)

order = {s: i for i, s in enumerate(["0", "5", "10", "20", "40", "70", "110", "160", "220", "274"])}
d["k"] = d.step.map(order)
t = d.pivot_table(index="k", columns="arm", values="curvature_median", aggfunc="median")
t.index = [s for s, _ in sorted(order.items(), key=lambda x: x[1]) if order[s] in t.index]
print("\n=== lambda_max along the path, median over five seeds ===")
print(t.round(2).to_string())
for a in t.columns:
    print(f"\n  {a}: max {t[a].max():.2f} at step {t[a].idxmax()}, "
          f"init {t[a].iloc[0]:.2f}, end {t[a].iloc[-1]:.2f}")
if {"bottom", "top"} <= set(t.columns):
    print(f"\n  ratio at each arm's OWN maximum : {t['bottom'].max() / t['top'].max():.2f}")
    print( "  ratio at initialisation         : 10.2   (reported)")
    print( "  ratio at step 274               : 4.85   (reported)")
    print( "  the rate displacement is 2 to 5.")
PY
