"""Why did the beta table change between the PDF and the .tex? Six checks, in the auditor's order.

Working hypothesis, to be confirmed or broken here: the OLD table was the mean of lists hard-coded
in fig_band.py over seeds 0-6, and seeds 0-1 are the ones the learning rate was SELECTED on; the NEW
table is read from the runs over seeds 2-8. If every old value is reproduced by seeds 0-6 and every
new value by seeds 2-8, the change is explained. If any position fails, the hypothesis is wrong and
the error is somewhere else.
"""
import os
import statistics as st
import sys

import yaml

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from lorasub.aggregate import collect  # noqa: E402

OLD = {0.0: 0.6575, 0.25: 0.6394, 0.5: 0.6559, 0.75: 0.6875, 1.0: 0.5861}   # PDF
NEW = {0.0: 0.6547, 0.25: 0.6368, 0.5: 0.6670, 0.75: 0.6768, 1.0: 0.5928}   # current .tex
BAD = []


def ok(name, cond, detail=""):
    print(f"  [{'ok ' if cond else 'FAIL'}] {name}" + (f"   {detail}" if detail else ""))
    if not cond:
        BAD.append(name)


d = collect(os.path.expanduser("~/lora-runs"))
tab = (yaml.safe_load(open("configs/lr_selected.yaml")) or {})["selected"]
L = d.model.astype(str).str.contains("Llama")
b = d[(d["mode"] == "band") & L & (d["rank"] == 2) & (d.task == "format") & (d.n_modules == 7)
      & d.update_norm_target.isna() & (d.max_grad_norm == 1.0)]
key = lambda bf: f"meta-llama/Llama-3.2-1B|format|band|2|b{bf:g}"

print("\n=== 1. the seeds behind each version ===")
for bf in sorted(OLD):
    lr = tab.get(key(bf))
    x = b[(abs(b.band_frac - bf) < 1e-9) & (abs(b.lr - lr) < 1e-12) & (b.format_n == 614)]
    g = x.groupby("seed").format_parsed.mean()
    s06 = [g[k] for k in range(0, 7) if k in g.index]
    s28 = [g[k] for k in range(2, 9) if k in g.index]
    m06 = st.mean(s06) if len(s06) == 7 else None
    m28 = st.mean(s28) if len(s28) == 7 else None
    print(f"    beta={bf:<5g} lr={lr}  seeds present {sorted(g.index.tolist())}")
    ok(f"beta={bf:g}: OLD {OLD[bf]} = mean of seeds 0-6", m06 is not None and abs(m06 - OLD[bf]) < 6e-5,
       f"seeds 0-6 give {m06:.4f}" if m06 else "seeds 0-6 incomplete")
    ok(f"beta={bf:g}: NEW {NEW[bf]} = mean of seeds 2-8", m28 is not None and abs(m28 - NEW[bf]) < 6e-5,
       f"seeds 2-8 give {m28:.4f}" if m28 else "seeds 2-8 incomplete")

print("\n=== 2. the selected rate per position: interior, and not a tie ===")
sel = b[b.seed.isin([0, 1])]
for bf in sorted(OLD):
    v = (sel[abs(sel.band_frac - bf) < 1e-9].groupby("lr").val_format_parsed.mean().sort_index())
    lr = tab.get(key(bf))
    print(f"    beta={bf:<5g} " + "  ".join(f"{k:g}:{val:.4f}" for k, val in v.items()) + f"   selected {lr}")
    rates = list(v.index)
    interior = lr in rates and 0 < rates.index(lr) < len(rates) - 1
    ok(f"beta={bf:g}: selected rate is interior to the swept grid", interior)
    if len(v) >= 2:
        top2 = v.sort_values(ascending=False)
        gap = top2.iloc[0] - top2.iloc[1]
        ok(f"beta={bf:g}: winner leads the runner-up by more than 0.005", gap > 0.005,
           f"gap {gap:.4f} ({top2.index[1]:g} second)")

print("\n=== 3. replicates in the reported cells ===")
rep = b[(b.format_n == 614) & b.seed.between(0, 8)]
rep = rep[rep.apply(lambda r: abs(r.lr - tab.get(key(float(r.band_frac)), -1)) < 1e-12, axis=1)]
n_runs = rep.groupby(["band_frac", "seed"]).size()
ok("one run per (position, seed), seeds 0-8", bool((n_runs == 1).all()),
   f"{int((n_runs > 1).sum())} cells with replicates")

print("\n=== 4. sigma follows the seed change ===")
for bf in sorted(OLD):
    x = rep[abs(rep.band_frac - bf) < 1e-9].groupby("seed").format_parsed.mean()
    a = [x[k] for k in range(0, 7) if k in x.index]; c = [x[k] for k in range(2, 9) if k in x.index]
    if len(a) == 7 and len(c) == 7:
        print(f"    beta={bf:<5g} sd seeds 0-6 {st.stdev(a):.3f} | sd seeds 2-8 {st.stdev(c):.3f}")

print("\n=== 5. where the OLD table came from ===")
print("    the old values are means of lists hard-coded in scripts/fig_band.py, not of the aggregator;")
print("    check the git history of that file:  git log --oneline -- scripts/fig_band.py")

print("\n=== 6. verifier hash and data fingerprint across seeds 0-8 ===")
for col in ("_metric_version", "data_fingerprint"):
    if col in rep.columns:
        vals = rep[col].astype(str).unique()
        ok(f"{col} identical across all reported runs", len(vals) == 1, f"{len(vals)} distinct")

print("\n" + "=" * 70)
print(f"  {len(BAD)} failed" + (":" if BAD else " -- the change is explained by the seed sets."))
for x in BAD:
    print(f"    - {x}")
