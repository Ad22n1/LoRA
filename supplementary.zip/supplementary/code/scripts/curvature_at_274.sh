#!/bin/bash
# Curvature at the END of training, not at initialisation.
#
# WHAT IT SETTLES. The unclipped runs bracket where each arm diverges: `bottom` still trains at
# lambda*lr = 3.31 while `top` is already dead at 0.82, so no single threshold in lambda*lr fits
# both. But lambda there is measured at step 0, and the divergence happens after ~274 steps — the
# curvature may have drifted differently per arm, and curvature.py's own docstring says the honest
# claim is about the initial landscape only.
#
# This measures lambda_max on the factors saved at step 274 of real runs, at each arm's own rate.
# Same batches, same power iteration, same convergence filter: only the point on the trajectory
# changes, and it lands in a separate CSV with a `from_step` column so the two can never be averaged.
#
# WHAT TO READ. If the ratio bottom/top is still about twelve at step 274, the curvature did not
# drift and the refutation holds at the point where the runs actually diverge. If it collapses, the
# initial measurement was the wrong quantity and the mechanism section needs rewriting.
#
#SBATCH --job-name=curv274
#SBATCH --partition=PARTITION
#SBATCH --cpus-per-task=4
#SBATCH --mem=32G
#SBATCH --exclusive
#SBATCH --time=01:59:00
#SBATCH --output=~/lora-results/curv274-%j.out

source /tmp/lora-$USER/venv/bin/activate
export SHARED=$HOME/lora-shared
cd $HOME/repo

# same guard as curvature_5seeds.sh: Hessian-vector products need a free card,
# and --exclusive reserves cores, not PARTITION memory.
FREE=$(nvidia-smi --query-PARTITION=memory.free --format=csv,noheader,nounits | head -1)
echo "node: $(hostname)  free: ${FREE} MiB"
if [ "$FREE" -lt 13000 ]; then echo "skip: only ${FREE} MiB free"; exit 1; fi

OUT=$HOME/lora-analysis/curvature_step274.csv
: > "$OUT.parts"

# each arm at ITS OWN selected rate, the one whose factors we are reading
for spec in "bottom 0.002" "top 0.01"; do
  set -- $spec
  echo "=== $1 at lr=$2, step 274 ==="
  python scripts/curvature.py \
    --model meta-llama/Llama-3.2-1B \
    --data_dir "$SHARED/data" --svd_cache "$SHARED/svd" \
    --task format --rank 2 --modes "$1" --seeds 2,3,4,5,6 \
    --from_step 274 --lr "$2" --max_grad_norm 1.0 \
    --runs_dir "$HOME/lora-runs" \
    --n_batches 3 --iters 60 --restarts 5 \
    --out "$HOME/lora-analysis/curv274_$1.csv"
done

python - <<'PY'
import glob, os
import pandas as pd
fs = sorted(glob.glob(os.path.expanduser("~/lora-analysis/curv274_*.csv")))
if not fs:
    raise SystemExit("no per-arm CSV was written")
d = pd.concat([pd.read_csv(f) for f in fs], ignore_index=True)
d.to_csv(os.path.expanduser("~/lora-analysis/curvature_step274.csv"), index=False)
g = d.groupby("mode").curvature_median.median()
print("\n=== lambda_max at step 274, median over seeds ===")
print(g.round(2).to_string())
if {"bottom", "top"} <= set(g.index):
    print(f"\n  ratio bottom/top at step 274 : {g['bottom']/g['top']:.2f}")
    print( "  ratio at initialisation      : 12.04")
if "n_batches_dropped" in d:
    print(f"\n  batches dropped for non-convergence: {int(d.n_batches_dropped.sum())}")
PY
