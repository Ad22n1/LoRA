"""Grids of PROTOCOL_freezeA_rank16.md. 196 runs. ARC-Challenge: from configs/grids/arcc_own_top.yaml (checked). OpenBookQA: from the
config.yaml of a REFERENCE RUN itself (top, rank 16, rate 2e-3, seed 2, data_dir .../openbookqa, DONE), so the new arms carry exactly the
configuration of the frozen arms they are compared with (its grid base does not carry the data fingerprint, which is set when data load).

    python scripts/make_ra_grids.py
"""
import glob
import os
import sys
from pathlib import Path

import yaml


def is_obqa(c):
    """OpenBookQA on Qwen2.5-1.5B: identified by its data directory; the rank-16 campaign predates the data fingerprint (empty)."""
    return (c.get("task") == "commonsense" and str(c.get("model")) == "Qwen/Qwen2.5-1.5B"
            and os.path.basename(str(c.get("data_dir") or "").rstrip("/")) == "openbookqa"
            and str(c.get("data_fingerprint") or "") in ("", "None", "dc05f4d847f9"))

TASKS = {"arc": ("configs/grids/arcc_own_top.yaml", "0755bcdbdce3", [5e-5, 1e-4, 2e-4, 5e-4, 1e-3, 2e-3, 5e-3]),
         "obqa": ("(run de reference)", "dc05f4d847f9", [1e-4, 2e-4, 5e-4, 1e-3, 2e-3, 5e-3, 1e-2])}
SEEDS = [0, 1, 2, 3, 4, 5, 6]
H = "# PRE-ENREGISTRE (PROTOCOL_freezeA_rank16.md). Genere par scripts/make_ra_grids.py. 49 runs.\n"
total = 0
def reference_config():
    hits = []
    for q in glob.glob(os.path.expanduser("~/lora-runs/*/config.yaml")):
        c = yaml.safe_load(open(q)) or {}
        if (is_obqa(c)
                and c.get("mode") == "top" and c.get("rank") == 16 and abs(float(c.get("lr", 0)) - 2e-3) < 1e-12 and c.get("seed") == 2):
            try:
                if open(os.path.join(os.path.dirname(q), "status")).read().startswith("DONE"):
                    hits.append(c)
            except OSError:
                pass
    if len(hits) != 1:
        sys.exit(f"STOP : run de reference OpenBookQA (top, r=16, 2e-3, graine 2) trouve {len(hits)} fois au node d'une")
    return dict(hits[0])


for task, (src, fp, lrs) in TASKS.items():
    if task == "obqa":
        b = reference_config(); print("  OpenBookQA : base prise sur le run de reference (top, r=16, 2e-3, graine 2)")
    else:
        p = Path(src)
        if not p.exists():
            sys.exit(f"STOP : {src} introuvable")
        b = dict((yaml.safe_load(open(p)) or {}).get("base") or {})
    ok = is_obqa(b) if task == "obqa" else (b.get("task") == "commonsense" and str(b.get("data_fingerprint")) == fp and str(b.get("model")) == "Qwen/Qwen2.5-1.5B")
    mods = b.get("target_modules")
    if not ok or not (mods is None or len(mods) == 7) or float(b.get("max_grad_norm", 1.0) or 0) != 1.0:
        sys.exit(f"STOP : {src} n'est pas la base attendue (tache, empreinte {fp}, Qwen2.5-1.5B, sept modules, ecretage 1,0)")
    for k in ("mode", "rank", "lr", "seed", "band_frac", "update_norm_target"):
        b.pop(k, None)
    b.update(rank=16, save_factor_steps=[])
    if b.get("alpha") is not None:
        b["alpha"] = 16
    for mode in ("dual_top", "dual_bottom"):
        name = f"ra_{task}_{mode}"
        Path(f"configs/grids/{name}.yaml").write_text(H + yaml.safe_dump({"base": b, "grid": {"mode": [mode], "lr": lrs, "seed": SEEDS}}, sort_keys=False))
        total += len(lrs) * len(SEEDS); print(f"  {name:20s} : {mode} rang 16, taux {lrs[0]:g} a {lrs[-1]:g}, graines 0-6")
print(f"  total : {total} runs")
if total != 196:
    sys.exit("STOP : le total n'est pas 196")
