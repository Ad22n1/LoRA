"""Grids of PROTOCOL_long_training.md, from configs/grids/sigma_residual_C2.yaml (checked), with 2 400 000 training tokens on the format task.

    python scripts/make_long_grids.py --stage1     # selection: 5 arms x 4 rates x seeds 0-1 = 40 runs (5 grids)
    python scripts/make_long_grids.py --stage2     # report: seeds 2-6 at each arm's rate selected on seeds 0-1 = 25 runs (5 grids)
"""
import glob
import json
import os
import statistics as st
import sys
from pathlib import Path

import yaml

SRC = Path("configs/grids/sigma_residual_C2.yaml")
LONG = 2_400_000
ARMS = {"top": (2, [2e-3, 5e-3, 1e-2, 2e-2]), "bottom": (2, [1e-3, 2e-3, 5e-3, 1e-2]), "top_unfrozen": (2, [1e-3, 2e-3, 5e-3, 1e-2]),
        "bottom_unfrozen": (2, [5e-4, 1e-3, 2e-3, 5e-3]), "free": (1, [2e-4, 5e-4, 1e-3, 2e-3])}
H = "# PRE-ENREGISTRE (PROTOCOL_long_training.md). Genere par scripts/make_long_grids.py.\n"


def base():
    if not SRC.exists():
        sys.exit(f"STOP : {SRC} introuvable")
    b = dict((yaml.safe_load(open(SRC)) or {}).get("base") or {})
    tt = b.get("target_tokens"); tok = tt.get("format") if isinstance(tt, dict) else tt; mods = b.get("target_modules")
    checks = {"tache format": b.get("task") == "format", "Llama-3.2-1B": str(b.get("model")) == "meta-llama/Llama-3.2-1B", "600 000 tokens a l'origine": tok == 600000,
              "longueur 384": b.get("max_len") == 384, "lot 2": b.get("batch_size") == 2, "accumulation 16": b.get("grad_accum") == 16,
              "ecretage 1,0": b.get("max_grad_norm", 1.0) is not None and float(b.get("max_grad_norm", 1.0)) == 1.0, "sept modules": mods is None or len(mods) == 7}
    bad = [k for k, ok in checks.items() if not ok]
    if bad:
        sys.exit(f"STOP : la base differe de la campagne d'origine sur : {', '.join(bad)}")
    for k in ("mode", "rank", "lr", "seed", "band_frac", "update_norm_target"):
        b.pop(k, None)
    b["target_tokens"] = ({**tt, "format": LONG} if isinstance(tt, dict) else LONG)
    b["save_factor_steps"] = []
    return b


def write(name, rank, grid, note):
    b = base(); b["rank"] = rank
    Path(f"configs/grids/{name}.yaml").write_text(H + f"# {note}\n" + yaml.safe_dump({"base": b, "grid": grid}, sort_keys=False))


if "--stage1" in sys.argv:
    for mode, (rank, lrs) in ARMS.items():
        write(f"long_s1_{mode}", rank, {"mode": [mode], "lr": lrs, "seed": [0, 1]}, f"SELECTION, {mode}. 8 runs.")
        print(f"  long_s1_{mode:16s} : rang {rank}, taux {lrs[0]:g} a {lrs[-1]:g}, graines 0-1, 2 400 000 tokens")
    print("  total : 40 runs")
elif "--stage2" in sys.argv:
    vals = {}
    for p in glob.glob(os.path.expanduser("~/lora-runs/*/config.yaml")):
        c = yaml.safe_load(open(p)) or {}; d = os.path.dirname(p)
        tt = c.get("target_tokens"); tok = tt.get("format") if isinstance(tt, dict) else tt
        if c.get("task") != "format" or str(c.get("model")) != "meta-llama/Llama-3.2-1B" or tok != LONG or c.get("seed") not in (0, 1):
            continue
        try:
            if open(d + "/status").read().startswith("DONE"):
                vals.setdefault((c.get("mode"), c.get("rank"), float(c.get("lr"))), []).append(json.load(open(d + "/metrics.json"))["val_format_parsed"])
        except (OSError, KeyError):
            pass
    total = 0
    for mode, (rank, lrs) in ARMS.items():
        means = {}
        for lr in lrs:
            v = vals.get((mode, rank, lr), [])
            if len(v) != 2:
                sys.exit(f"STOP : {mode} a {lr:g} : {len(v)} run(s) de selection au node de 2 ; rien n'est genere")
            means[lr] = st.mean(v)
        best = max(lrs, key=lambda lr: means[lr])
        write(f"long_s2_{mode}", rank, {"mode": [mode], "lr": [best], "seed": [2, 3, 4, 5, 6]}, f"RAPPORT, {mode} au taux retenu. 5 runs.")
        total += 5
        print(f"  long_s2_{mode:16s} : " + "  ".join(f"{lr:g}:{means[lr]:.3f}" for lr in lrs) + f"  -> {best:g}" + ("  AU BORD" if best in (lrs[0], lrs[-1]) else ""))
    print(f"  total : {total} runs")
else:
    sys.exit("usage : --stage1 | --stage2")
