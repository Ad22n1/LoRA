"""Analyses sans entrainement (PROTOCOL_free_writes.md et etape 2 de la relecture). Committe AVANT d'etre execute.

    python scripts/analyses_v2.py --budget      # 2. A gele (r=2) contre le meilleur B gele (r=4), format, Llama
    python scripts/analyses_v2.py --decomp      # 3. decomposition facteur x bande, intervalles par bootstrap apparie
    python scripts/analyses_v2.py --I           # 4. I = G - U sur les cinq paires, avec intervalle
    python scripts/analyses_v2.py --loss        # 5. courbes de perte des bras geles et entraines
    python scripts/analyses_v2.py --steps       # 6. pas, exemples et epoques (OpenBookQA, ARC-Challenge, format)
    python scripts/analyses_v2.py --selftest    # 1. autotest des mesures sur une matrice synthetique (a lancer d'abord)
    python scripts/analyses_v2.py --writes      # 1. ou ecrit le LoRA libre au rang 1

Chaque cellule est retrouvee par sa valeur publiee (moyenne des graines, a 1e-4 pres) ; le script s'arrete si elle ne l'est pas, ou s'il y
trouve un doublon. Intervalles : bootstrap apparie sur les graines, 10 000 tirages, graine du tirage fixee (0).
"""
import csv
import glob
import json
import os
import random
import statistics as st
import sys

import yaml

L, Q, Q7, M7 = "meta-llama/Llama-3.2-1B", "Qwen/Qwen2.5-1.5B", "Qwen/Qwen2.5-7B", "mistralai/Mistral-7B-v0.3"
S26, S120, S22 = (2, 3, 4, 5, 6), (120, 121, 122, 123, 124), (22, 23, 24, 25, 26)
dd = lambda c: os.path.basename(str(c.get("data_dir") or "").rstrip("/"))  # noqa: E731


def _tok(c):
    tt = c.get("target_tokens")
    return tt.get("format") if isinstance(tt, dict) else tt


def clean(c):
    mods = c.get("target_modules")
    return ((mods is None or len(mods) == 7) and float(c.get("max_grad_norm", 1.0) or 0) == 1.0 and c.get("update_norm_target") in (None, "")
            and not c.get("token_weighted_loss"))


POPS = {"format/Llama": (lambda c: c.get("task") == "format" and str(c.get("model")) == L and _tok(c) == 600000, "format_parsed"),
        "format/Qwen1.5B": (lambda c: c.get("task") == "format" and str(c.get("model")) == Q and _tok(c) == 600000, "format_parsed"),
        "OBQA/Qwen1.5B": (lambda c: dd(c) == "openbookqa" and str(c.get("model")) == Q, "mcq_acc"),
        "OBQA/Qwen7B": (lambda c: dd(c) == "openbookqa" and str(c.get("model")) == Q7, "mcq_acc"),
        "OBQA/Mistral7B": (lambda c: dd(c) == "openbookqa" and str(c.get("model")) == M7, "mcq_acc")}
RUNS = []
for p in glob.glob(os.path.expanduser("~/lora-runs/*/config.yaml")):
    d = os.path.dirname(p)
    try:
        if open(d + "/status").read().startswith("DONE"):
            RUNS.append((yaml.safe_load(open(p)) or {}, json.load(open(d + "/metrics.json")), d))
    except (OSError, ValueError):
        pass


def _cell_at(pop, mode, rank, lr, seeds):
    pred, key = POPS[pop]
    by = {}
    for c, m, d in RUNS:
        if (pred(c) and clean(c) and c.get("mode") == mode and c.get("rank") == rank and abs(float(c.get("lr") or 0) - lr) < 1e-12
                and c.get("seed") in seeds and key in m):
            by.setdefault(c["seed"], []).append((m[key], d))
    ok = sorted(by) == list(seeds) and all(len(v) == 1 for v in by.values())
    return ({s: by[s][0][0] for s in seeds}, {s: by[s][0][1] for s in seeds}) if ok else (None, by)


def cell(pop, mode, rank, lr, seeds, expect=None, tol=1e-4):
    """La cellule au taux indique ; si une valeur publiee est donnee et que ce taux ne la redonne pas, le SEUL autre taux dont les cinq
    graines la redonnent exactement (affiche). Arret si aucun, ou plusieurs, ou en cas de doublon."""
    tag = f"{pop} {mode} r={rank} graines {seeds[0]}-{seeds[-1]}"
    v, x = _cell_at(pop, mode, rank, lr, seeds)
    if v is not None and (expect is None or abs(st.mean(v.values()) - expect) <= tol):
        return v, x
    if expect is None:
        sys.exit(f"ARRET : {tag} a {lr:g} : graines {sorted(x)}, doublons {[s for s, w in x.items() if len(w) > 1]}")
    pred, key = POPS[pop]
    rates = sorted({float(c["lr"]) for c, m, d in RUNS if pred(c) and clean(c) and c.get("mode") == mode and c.get("rank") == rank and c.get("seed") in seeds})
    hits = [r_ for r_ in rates if (lambda w: w[0] is not None and abs(st.mean(w[0].values()) - expect) <= tol)(_cell_at(pop, mode, rank, r_, seeds))]
    if len(hits) != 1:
        got = "" if v is None else f" (a {lr:g} : {st.mean(v.values()):.4f})"
        sys.exit(f"ARRET : {tag} : valeur publiee {expect:.4f} retrouvee a {len(hits)} taux {hits}{got}")
    print(f"    [{tag} : la valeur publiee {expect:.4f} est au taux {hits[0]:g}, pas {lr:g}]")
    return _cell_at(pop, mode, rank, hits[0], seeds)


def boot(stat, cells, seeds, n=10000):
    """Paired bootstrap on seeds: resample the seed list, recompute the statistic on the resampled seeds."""
    rng = random.Random(0); pts = sorted(stat(cells, [rng.choice(seeds) for _ in seeds]) for _ in range(n))
    return stat(cells, list(seeds)), pts[int(0.025 * n)], pts[int(0.975 * n) - 1]


fmt = lambda x: f"{x[0]:+.2f} [{x[1]:+.2f}, {x[2]:+.2f}]"  # noqa: E731
mean_pts = lambda v, S: 100 * st.mean(v[s] for s in S)  # noqa: E731

# (pop, graines) -> cellules publiees : bras -> (mode, rang, taux, valeur publiee)
PAIRS = {
    ("format/Llama", S26): {"top": ("top", 2, 1e-2, 0.6443), "bottom": ("bottom", 2, 5e-3, 0.5922), "dual_top": ("dual_top", 2, 1e-2, 0.7739),
                            "dual_bottom": ("dual_bottom", 2, 1e-2, 0.7818), "free": ("free", 1, 1e-3, 0.7684),
                            "tu1": ("top_unfrozen", 1, 5e-3, 0.7928), "bu1": ("bottom_unfrozen", 1, 5e-3, 0.7954),
                            "tu2": ("top_unfrozen", 2, 5e-3, 0.8000), "bu2": ("bottom_unfrozen", 2, 2e-3, 0.8072)},
    ("format/Llama", S120): {"top": ("top", 2, 1e-2, 0.6593), "bottom": ("bottom", 2, 5e-3, 0.5954), "dual_top": ("dual_top", 2, 1e-2, 0.7772),
                             "dual_bottom": ("dual_bottom", 2, 1e-2, 0.7818), "free": ("free", 1, 1e-3, 0.7664),
                             "tu1": ("top_unfrozen", 1, 5e-3, 0.8078), "bu1": ("bottom_unfrozen", 1, 5e-3, 0.7997)},
    ("format/Qwen1.5B", S22): {"top": ("top", 2, 5e-3, 0.6257), "bottom": ("bottom", 2, 5e-3, 0.6391), "free": ("free", 1, 5e-3, 0.7879),
                               "tu1": ("top_unfrozen", 1, 5e-3, 0.7896), "bu1": ("bottom_unfrozen", 1, 5e-3, 0.7811)},
    ("OBQA/Qwen1.5B", S26): {"top": ("top", 2, 5e-3, 0.4652), "bottom": ("bottom", 2, 2e-3, 0.4220), "dual_top": ("dual_top", 2, 5e-3, 0.5308),
                             "dual_bottom": ("dual_bottom", 2, 1e-2, 0.5248), "free": ("free", 1, 2e-3, 0.5456),
                             "tu1": ("top_unfrozen", 1, 2e-3, 0.5524), "bu1": ("bottom_unfrozen", 1, 2e-3, 0.5496),
                             "tu2": ("top_unfrozen", 2, 2e-3, 0.5576), "bu2": ("bottom_unfrozen", 2, 2e-3, 0.5528)},
    ("OBQA/Qwen7B", S26): {"top": ("top", 2, 5e-3, 0.5316), "bottom": ("bottom", 2, 5e-4, 0.4840), "dual_top": ("dual_top", 2, 2e-3, 0.6364),
                           "dual_bottom": ("dual_bottom", 2, 2e-3, 0.6148), "free": ("free", 1, 2e-3, 0.6284),
                           "tu1": ("top_unfrozen", 1, 2e-3, 0.6232), "bu1": ("bottom_unfrozen", 1, 2e-3, 0.6264)},
    ("OBQA/Mistral7B", S26): {"top": ("top", 2, 1e-3, 0.4764), "bottom": ("bottom", 2, 1e-3, 0.4776), "dual_top": ("dual_top", 2, 5e-4, 0.6076),
                              "dual_bottom": ("dual_bottom", 2, 1e-3, 0.5860), "free": ("free", 1, 1e-3, 0.6012),
                              "tu1": ("top_unfrozen", 1, 2e-3, 0.5924), "bu1": ("bottom_unfrozen", 1, 2e-3, 0.5924)},
}


def load_pair(key, arms):
    pop, S = key
    return {a: cell(pop, *PAIRS[key][a][:3], S, PAIRS[key][a][3])[0] for a in arms}


def do_budget():
    print("==================== 2. A gele (r=2) contre le meilleur B gele (r=4) : format, Llama, graines 2-6 ====================")
    print("  budgets par couche : A gele r=2 : 2 x 23 552 = 47 104 ; B gele r=4 : 4 x 20 480 = 81 920 (+73,9 %)")
    C = load_pair(("format/Llama", S26), ("dual_top", "dual_bottom"))
    pred, key = POPS["format/Llama"]; cands = {}
    for c, m, d in RUNS:
        if pred(c) and clean(c) and c.get("rank") == 4 and c.get("mode") in ("top", "bottom", "random", "random_ortho") and c.get("seed") in S26 and key in m:
            cands.setdefault((c["mode"], float(c["lr"])), {}).setdefault(c["seed"], []).append(m[key])
    full = {k: {s: v[s][0] for s in S26} for k, v in cands.items() if sorted(v) == list(S26) and all(len(x) == 1 for x in v.values())}
    for k in sorted(full, key=lambda k: -st.mean(full[k].values())):
        print(f"    B gele r=4 : {k[0]:13s} lr={k[1]:<7g} {st.mean(full[k].values()):.4f}")
    best = max(full, key=lambda k: st.mean(full[k].values()))
    print(f"  meilleur B gele r=4, a son meilleur taux (choix qui l'avantage) : {best[0]} lr={best[1]:g}")
    for X in ("dual_top", "dual_bottom"):
        cells = {"a": C[X], "b": full[best]}
        est = boot(lambda cc, S: mean_pts(cc["a"], S) - mean_pts(cc["b"], S), cells, S26)
        d = [(C[X][s] - full[best][s]) * 100 for s in S26]; se = st.stdev(d) / 5 ** 0.5
        print(f"    {X} (r=2) - B gele r=4 : {fmt(est)} ; t = {st.mean(d) / se:+.2f} (seuil 3,495, deux bras)")


def do_decomp():
    print("==================== 3. decomposition facteur x bande (rang 2), bootstrap apparie ====================")
    print("  facteur = moyenne(A gele) - moyenne(B gele) ; bande = moyenne(bottom) - moyenne(top) ; interaction = (A:bottom-top) - (B:bottom-top)")
    for key in PAIRS:
        if "dual_top" not in PAIRS[key]:
            continue
        C = load_pair(key, ("top", "bottom", "dual_top", "dual_bottom")); S = list(key[1])
        f = lambda cc, s: (mean_pts(cc["dual_top"], s) + mean_pts(cc["dual_bottom"], s) - mean_pts(cc["top"], s) - mean_pts(cc["bottom"], s)) / 2  # noqa: E731
        b = lambda cc, s: (mean_pts(cc["bottom"], s) + mean_pts(cc["dual_bottom"], s) - mean_pts(cc["top"], s) - mean_pts(cc["dual_top"], s)) / 2  # noqa: E731
        i = lambda cc, s: (mean_pts(cc["dual_bottom"], s) - mean_pts(cc["dual_top"], s)) - (mean_pts(cc["bottom"], s) - mean_pts(cc["top"], s))  # noqa: E731
        print(f"  {key[0]:16s} graines {S[0]}-{S[-1]} : facteur {fmt(boot(f, C, S))} ; bande {fmt(boot(b, C, S))} ; interaction {fmt(boot(i, C, S))}")


def do_I():
    print("==================== 4. I = G - U = libre - degele (r=1), sur les cinq paires, bootstrap apparie ====================")
    for key in (("format/Llama", S26), ("format/Qwen1.5B", S22), ("OBQA/Qwen1.5B", S26), ("OBQA/Qwen7B", S26), ("OBQA/Mistral7B", S26)):
        C = load_pair(key, ("top", "bottom", "free", "tu1", "bu1")); S = list(key[1])
        for X, U in (("top", "tu1"), ("bottom", "bu1")):
            G = boot(lambda cc, s: mean_pts(cc["free"], s) - mean_pts(cc[X], s), C, S)
            Uv = boot(lambda cc, s: mean_pts(cc[U], s) - mean_pts(cc[X], s), C, S)
            I = boot(lambda cc, s: mean_pts(cc["free"], s) - mean_pts(cc[U], s), C, S)
            R = boot(lambda cc, s: (mean_pts(cc[U], s) - mean_pts(cc[X], s)) / (mean_pts(cc["free"], s) - mean_pts(cc[X], s)), C, S)
            print(f"  {key[0]:16s} {X:6s} : G {G[0]:+.2f} ; U {fmt(Uv)} ; I = G - U {fmt(I)} ; U/G {R[0]:.2f} [{R[1]:.2f}, {R[2]:.2f}]")


def do_loss():
    print("==================== 5. courbes de perte : bras geles et entraines (rang 2 ; libre au rang 1) ====================")
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    ARMS = ("top", "bottom", "tu2", "bu2", "dual_top", "dual_bottom", "free")
    LAB = {"top": "B gele, top", "bottom": "B gele, bottom", "tu2": "B entraine, top", "bu2": "B entraine, bottom",
           "dual_top": "A gele, top", "dual_bottom": "A gele, bottom", "free": "libre, r=1"}
    fig, axes = plt.subplots(1, 2, figsize=(11, 4)); out = open("analyses_loss_curves.csv", "w", newline=""); w = csv.writer(out)
    w.writerow(["population", "bras", "pas", "perte_moyenne", "graines"])
    for ax, key in zip(axes, (("format/Llama", S26), ("OBQA/Qwen1.5B", S26))):
        print(f"  --- {key[0]} ---")
        for a in ARMS:
            _, dirs = cell(key[0], *PAIRS[key][a][:3], key[1], PAIRS[key][a][3])
            curves = []
            for s_ in key[1]:
                rows = list(csv.DictReader(open(dirs[s_] + "/log.csv")))
                curves.append({int(r["step"]): float(r["loss"]) for r in rows})
            steps = sorted(set.intersection(*(set(c) for c in curves)))
            mean = [st.mean(c[t] for c in curves) for t in steps]
            for t, v in zip(steps, mean):
                w.writerow([key[0], a, t, f"{v:.5f}", len(curves)])
            ax.plot(steps, mean, label=LAB[a], ls="--" if a in ("top", "bottom") else "-")
            q = lambda f: mean[min(len(mean) - 1, int(round(f * (len(mean) - 1))))]  # noqa: E731
            print(f"    {LAB[a]:18s} perte a 25/50/75/100 % : {q(0.25):.4f} / {q(0.5):.4f} / {q(0.75):.4f} / {q(1.0):.4f} ;"
                  f" baisse sur le dernier quart {100 * (q(0.75) - q(1.0)) / q(0.75):+.1f} %")
        ax.set_title(key[0]); ax.set_xlabel("pas"); ax.set_ylabel("perte d'entrainement"); ax.set_yscale("log"); ax.legend(fontsize=7)
    out.close(); fig.tight_layout(); fig.savefig("analyses_loss_curves.png", dpi=150)
    print("  ecrit -> analyses_loss_curves.csv, analyses_loss_curves.png")
    print("  lecture : un bras gele plus lent descend encore au dernier quart ; un bras plafonne ne descend plus, a une perte plus haute")


def do_steps():
    print("==================== 6. pas, exemples et epoques (budget de 600 000 tokens supervises) ====================")
    import math
    from transformers import AutoTokenizer
    try:
        from lorasub.data import build_dataset
    except ImportError:
        from lorasub.train import build_dataset
    for name, pred in (("OpenBookQA", lambda c: dd(c) == "openbookqa" and str(c.get("model")) == Q), ("ARC-Challenge", lambda c: dd(c) == "arc_challenge" and str(c.get("model")) == Q),
                       ("format", lambda c: c.get("task") == "format" and str(c.get("model")) == L and _tok(c) == 600000)):
        ref = next(((c, d) for c, m, d in RUNS if pred(c) and clean(c) and c.get("rank") == 2 and c.get("seed") == 2 and os.path.exists(d + "/log.csv")), None)
        if ref is None:
            print(f"  {name} : aucun run de reference avec journal"); continue
        c, d = ref
        tok = AutoTokenizer.from_pretrained(c["model"])
        if tok.pad_token is None:
            tok.pad_token = tok.eos_token
        ds = build_dataset(c["task"], c["data_dir"], tok, c["max_len"], split="train", seed=c["seed"])
        n, ntok, bs, ga = len(ds), ds.n_tokens, c["batch_size"], c["grad_accum"]
        tps = ntok / max(1, n) * bs * ga; total = max(1, math.ceil(c["target_tokens"] / tps if not isinstance(c["target_tokens"], dict) else _tok(c) / tps))
        spe = math.ceil(math.ceil(n / bs) / ga); last = list(csv.DictReader(open(d + "/log.csv")))[-1]
        print(f"  {name:13s} : {n:,} exemples d'entrainement ; {ntok / n:.1f} tokens supervises par exemple ; {tps:,.0f} par pas (lot {bs} x accumulation {ga})")
        print(f"                  {total} pas ({last['step']} dans le journal du run) ; {spe} pas par epoque ; {total / spe:.2f} epoque(s) ; {total * bs * ga:,} exemples vus")


def _fracs(Bm, Am, e, k, gen):
    """Parts d'energie de B (colonnes, bandes de U) et de A (lignes, bandes de V), et plus petit angle principal, pour une largeur k."""
    import torch
    m = e.S.numel(); U, V = e.U.float(), e.Vh.float().T
    out = {}
    for band, idx in (("dominante", slice(0, k)), ("mineure", slice(m - k, m))):
        Pu, Pv = U[:, idx], V[:, idx]
        fb = float((Pu.T @ Bm).pow(2).sum() / Bm.pow(2).sum()); fa = float((Am @ Pv).pow(2).sum() / Am.pow(2).sum())
        qb = torch.linalg.qr(Bm)[0]; cb = torch.linalg.svdvals(Pu.T @ qb).clamp(max=1.0)
        out[band] = (fb, fa, float(torch.rad2deg(torch.arccos(cb.max()))))
    rb, ra = [], []
    for _ in range(100):
        Qu = torch.linalg.qr(torch.randn(U.shape[0], k, generator=gen))[0]; Qv = torch.linalg.qr(torch.randn(V.shape[0], k, generator=gen))[0]
        rb.append(float((Qu.T @ Bm).pow(2).sum() / Bm.pow(2).sum())); ra.append(float((Am @ Qv).pow(2).sum() / Am.pow(2).sum()))
    out["aleatoire"] = (st.mean(rb), st.mean(ra), float("nan"))
    return out, k / U.shape[0], k / V.shape[0]


RULE = ("regle : HORS des bandes si la part d'energie reste sous 5 fois la reference nulle k/d dans la bande dominante ET dans la mineure ; "
        "sinon, DANS la bande au plus grand rapport si sa part d'energie y atteint 0,10 ; sinon AU-DESSUS DU HASARD MAIS DIFFUSE "
        "(k = 2, mediane sur les couches, moyenne sur les graines)")
RULE_STATUS = {"format/Llama": "appliquee A POSTERIORI (resultat deja connu)", "OBQA/Qwen1.5B": "PRE-ENREGISTREE (committee avant cette analyse)"}


def _profile(v, basis):
    """Part de l'energie de v (normalise) sur chaque dixieme des vecteurs singuliers (du plus dominant au plus mineur), et hors de leur espace.
    Ecrit avec des operations communes a torch et numpy."""
    v = v / float((v * v).sum()) ** 0.5
    c = (basis.T @ v) ** 2; m = c.shape[0]
    bounds = [round(i * m / 10) for i in range(11)]
    dec = [float(c[bounds[i]:bounds[i + 1]].sum()) for i in range(10)]
    return dec, max(0.0, 1.0 - sum(dec))


def do_selftest():
    print("==================== 1. autotest des mesures (matrice synthetique, puis cache reel) ====================")
    import torch
    from types import SimpleNamespace
    g = torch.Generator().manual_seed(0); W = torch.randn(64, 48, generator=g)
    U, S, Vh = torch.linalg.svd(W, full_matrices=False); e = SimpleNamespace(U=U, S=S, Vh=Vh)
    ok = True
    for lab, Bm, Am, want in (("B = u1, A = v1", U[:, :1], Vh[:1], ("dominante", 1.0)), ("B = u_m, A = v_m", U[:, -1:], Vh[-1:], ("mineure", 1.0))):
        f, _, _ = _fracs(Bm, Am, e, 2, g); got = f[want[0]]
        good = abs(got[0] - 1) < 1e-4 and abs(got[1] - 1) < 1e-4 and got[2] < 0.5
        ok &= good; print(f"  {lab:18s} : part de B {got[0]:.4f}, part de A {got[1]:.4f} dans la bande {want[0]}, angle {got[2]:.2f} deg -> {'ok' if good else 'ECHEC'}")
    fr = [_fracs(torch.randn(64, 1, generator=g), torch.randn(1, 48, generator=g), e, 2, g)[0]["dominante"][0] for _ in range(300)]
    good = abs(st.mean(fr) - 2 / 64) < 0.01; ok &= good
    print(f"  B aleatoire       : part moyenne dans la bande dominante {st.mean(fr):.4f}, reference nulle k/d = {2 / 64:.4f} -> {'ok' if good else 'ECHEC'}")
    from lorasub.spectral import load_svd
    run = next(((c, d) for c, m, d in RUNS if POPS["format/Llama"][0](c) and c.get("mode") == "free" and c.get("rank") == 1 and glob.glob(d + "/factors_*.safetensors")), None)
    if run:
        from safetensors.torch import load_file
        c, d = run; fac = load_file(sorted(glob.glob(d + "/factors_*.safetensors"))[-1]); name = next(k[:-2] for k in fac if k.endswith(".B"))
        e = load_svd(c.get("svd_cache") or f"/tmp/lora-{os.environ['USER']}/svd", c["model"], name)
        m = e.S.numel(); dev = float((e.U.float().T @ e.U.float() - torch.eye(m)).abs().max())
        good = fac[name + ".B"].shape[0] == e.U.shape[0] and fac[name + ".A"].shape[1] == e.Vh.shape[1] and dev < 1e-2; ok &= good
        print(f"  cache reel, {name} : U {tuple(e.U.shape)}, Vh {tuple(e.Vh.shape)}, B {tuple(fac[name + '.B'].shape)}, A {tuple(fac[name + '.A'].shape)} ;"
              f" ecart d'orthonormalite de U {dev:.1e} -> {'ok' if good else 'ECHEC'}")
    dec, out = _profile(U[:, 0], U); good = abs(dec[0] - 1) < 1e-4 and out < 1e-4; ok &= good
    print(f"  profil de u1       : premier dixieme {dec[0]:.4f}, hors de l'espace {out:.4f} -> {'ok' if good else 'ECHEC'}")
    Wt = torch.randn(96, 48, generator=g); Ut = torch.linalg.svd(Wt, full_matrices=False)[0]
    dec, out = _profile(torch.randn(96, generator=g), Ut); good = abs(out - 0.5) < 0.25 and abs(sum(dec) + out - 1) < 1e-4; ok &= good
    print(f"  profil aleatoire, sortie 96 > rang 48 : hors de l'espace {out:.3f} (attendu ~0,5) -> {'ok' if good else 'ECHEC'}")
    print("  AUTOTEST : " + ("REUSSI" if ok else "ECHOUE -- ne pas lancer --writes"))
    return ok


def do_writes():
    print("==================== 1. ou ecrit le LoRA libre au rang 1 ====================")
    import torch
    from safetensors.torch import load_file
    from lorasub.spectral import load_svd
    TASKS = (("format/Llama", L, "~/lora-runs", (1e-3, 2e-3)), ("OBQA/Qwen1.5B", Q, "~/lora-runs-fw", (2e-3,)))
    for pop, model, root, rates in TASKS:
        pred = POPS[pop][0]; found = None
        for lr in rates:
            hits = {}
            for p_ in glob.glob(os.path.expanduser(root) + "/*/config.yaml"):
                c = yaml.safe_load(open(p_)) or {}; d = os.path.dirname(p_)
                if pred(c) and clean(c) and c.get("mode") == "free" and c.get("rank") == 1 and abs(float(c["lr"]) - lr) < 1e-12 and c.get("seed") in S26 and glob.glob(d + "/factors_*.safetensors"):
                    hits.setdefault(c["seed"], []).append((c, d))
            if sorted(hits) == list(S26) and all(len(v) == 1 for v in hits.values()):
                found = (lr, {s: hits[s][0] for s in S26}); break
        if found is None:
            print(f"  {pop} : facteurs absents ou incomplets pour les graines 2-6 aux taux {rates} (dans {root}) -> reentrainement a lancer"); continue
        lr, H = found; print(f"  --- {pop}, LoRA libre r=1 a {lr:g}, graines 2-6 ---"); prof = {}; med = {}
        key = POPS[pop][1]; acc = [json.load(open(d + "/metrics.json")).get(key) for c, d in H.values()]
        if None not in acc:
            ref = {"OBQA/Qwen1.5B": 0.5456, "format/Llama": 0.7684 if abs(lr - 1e-3) < 1e-12 else None}[pop]
            print(f"    exactitude de ces runs : {st.mean(acc):.4f}" + (f" (runs d'origine publies : {ref:.4f})" if ref else ""))
        for k in (2, 16):
            per = {}
            for s_, (c, d) in H.items():
                fac = load_file(sorted(glob.glob(d + "/factors_*.safetensors"), key=lambda f: int(f.rsplit("_", 1)[1].split(".")[0]))[-1])
                gen = torch.Generator().manual_seed(s_)
                for name in sorted({x[:-2] for x in fac if x.endswith(".B")}):
                    e = load_svd(c.get("svd_cache") or f"/tmp/lora-{os.environ['USER']}/svd", model, name)
                    Bm, Am = fac[name + ".B"].float(), fac[name + ".A"].float()
                    f, nb, na = _fracs(Bm, Am, e, k, gen)
                    mt = name.rsplit(".", 1)[-1]
                    for band, (fb, fa, ang) in f.items():
                        per.setdefault((mt, band), {}).setdefault(s_, []).append((fb / nb, fa / na, ang, fb, fa))
                    if k == 2:
                        U_, V_ = e.U.float(), e.Vh.float().T
                        prof.setdefault(mt, {}).setdefault(s_, []).append((_profile(Bm[:, 0], U_), _profile(Am[0, :], V_), U_.shape[1] / U_.shape[0], V_.shape[1] / V_.shape[0]))
            print(f"    largeur de bande k = {k} : parts d'energie divisees par la reference nulle k/d (1 = hasard), moyenne sur les couches, IC 95 % sur les graines")
            for mt in ("q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"):
                row = []
                for band in ("dominante", "mineure", "aleatoire"):
                    if (mt, band) not in per:
                        continue
                    seedv = {s: (st.mean(x[0] for x in v), st.mean(x[1] for x in v), st.mean(x[2] for x in v)) for s, v in per[(mt, band)].items()}
                    b_ = [v[0] for v in seedv.values()]; a_ = [v[1] for v in seedv.values()]; ang = [v[2] for v in seedv.values()]
                    ci = lambda x: 2.776 * st.stdev(x) / len(x) ** 0.5  # noqa: E731
                    row.append(f"{band} B {st.mean(b_):6.2f}+-{ci(b_):.2f} A {st.mean(a_):6.2f}+-{ci(a_):.2f}" + ("" if band == "aleatoire" else f" angle {st.mean(ang):5.1f}"))
                print(f"      {mt:9s} : " + " | ".join(row))
                if k == 2:
                    for band in ("dominante", "mineure"):
                        if (mt, band) in per:
                            md = {s: tuple(st.median(x[i] for x in v) for i in (0, 1, 3, 4)) for s, v in per[(mt, band)].items()}
                            med[(mt, band)] = tuple(st.mean(x[i] for x in md.values()) for i in range(4))
        print(f"    {RULE} ; {RULE_STATUS[pop]}")
        for mt in ("q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"):
            if (mt, "dominante") not in med:
                continue
            D, Mn = med[(mt, "dominante")], med[(mt, "mineure")]

            def verdict(lab, rd, rm, ed, em):
                if rd < 5 and rm < 5:
                    return f"{lab} HORS des bandes"
                band, e_ = ("dominante", ed) if rd >= rm else ("mineure", em)
                return f"{lab} DANS la {band} (part {e_:.3f})" if e_ >= 0.10 else f"{lab} au-dessus du hasard mais DIFFUSE (vers la {band}, part {e_:.3f})"
            print(f"      {mt:9s} : rapports B {D[0]:5.2f} / {Mn[0]:5.2f}, A {D[1]:5.2f} / {Mn[1]:5.2f} (dominante / mineure) -> "
                  f"{verdict('B', D[0], Mn[0], D[2], Mn[2])} ; {verdict('A', D[1], Mn[1], D[3], Mn[3])}")
        print("    profil par dixieme du spectre (mediane sur les couches, moyenne sur les graines ; en %, du plus dominant au plus mineur ; "
              "« hors » = hors de l'espace de W0 ; hasard = rang/d/10 par dixieme)")
        for mt in ("q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"):
            if mt not in prof:
                continue
            for side, j in (("B/U", 0), ("A/V", 1)):
                seeds = []
                for s, v in prof[mt].items():
                    seeds.append([st.median(x[j][0][i] for x in v) for i in range(10)] + [st.median(x[j][1] for x in v)])
                avg = [st.mean(z[i] for z in seeds) * 100 for i in range(11)]
                rnd = st.mean(x[2 + j] for v in prof[mt].values() for x in v) * 10
                print(f"      {mt:9s} {side} : " + " ".join(f"{a:4.1f}" for a in avg[:10]) + f" | hors {avg[10]:4.1f} | hasard {rnd:4.1f}")


if __name__ == "__main__":
    acts = {"--budget": do_budget, "--decomp": do_decomp, "--I": do_I, "--loss": do_loss, "--steps": do_steps, "--selftest": do_selftest, "--writes": do_writes}
    todo = [a for a in sys.argv[1:] if a in acts]
    if not todo:
        sys.exit(__doc__)
    if "--writes" in todo and "--selftest" not in todo and not do_selftest():
        sys.exit("ARRET : l'autotest a echoue ; --writes n'est pas lance")
    for a in todo:
        acts[a](); print()
