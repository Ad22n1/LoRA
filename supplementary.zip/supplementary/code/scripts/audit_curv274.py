"""Every check against the step-274 curvature, before it changes the mechanism section.

The claim: measured on the factors saved at the end of training rather than at initialisation, the
curvature ratio is 4.85 against a rate displacement of 5 — so the factor-of-two overshoot the paper
currently reports is an artefact of measuring at step 0.

This is the most convenient result of the day, which is why it gets the hardest look. Each check is
one way it could be an artefact instead of a measurement.
"""
import os
import sys

import pandas as pd
import yaml

ANA = os.path.expanduser("~/lora-analysis")
RUNS = os.path.expanduser("~/lora-runs")
FAILED = []


def check(name, ok, detail=""):
    print(f"  [{'ok ' if ok else 'FAIL'}] {name}" + (f"\n         {detail}" if detail else ""))
    if not ok:
        FAILED.append(name)


def main():
    p = os.path.join(ANA, "curvature_step274.csv")
    if not os.path.exists(p):
        raise SystemExit(f"not measured yet: {p}")
    d = pd.read_csv(p)
    d["spread"] = (d.curvature_max - d.curvature_min) / d.curvature_median

    print("\n=== A. the measurement itself ===")
    n = d.groupby("mode").size()
    check("five seeds for bottom and for top", set(n.values) == {5},
          n.to_dict())
    if "from_step" in d.columns:
        check("every row says it came from step 274",
              set(d.from_step.astype(str)) == {"274"}, sorted(set(d.from_step.astype(str))))
    else:
        check("the CSV records which point of the trajectory it measured", False,
              "no `from_step` column: this file cannot be told apart from an init measurement")
    if "n_batches_dropped" in d.columns:
        check("no batch dropped for non-convergence", int(d.n_batches_dropped.sum()) == 0,
              f"{int(d.n_batches_dropped.sum())} dropped")

    print("\n=== B. resolved at least as well as at initialisation ===")
    sp = d.groupby("mode").spread.median()
    print("         within-cell spread at step 274:")
    for m in sp.index:
        print(f"           {m:8s} {sp[m]:.2f}")
    print("         for comparison, at initialisation: bottom 0.47, top 1.68")
    check("top is better resolved at step 274 than at initialisation",
          float(sp.get("top", 9)) < 1.68, f"top spread = {sp.get('top', float('nan')):.2f}")
    check("neither arm's batches disagree by more than their median",
          float(sp.max()) < 1.0, f"worst {sp.idxmax()} at {sp.max():.2f}")

    print("\n=== C. the ratio does not rest on one seed ===")
    g = d.groupby("mode").curvature_median.median()
    if {"bottom", "top"} <= set(g.index):
        r = g["bottom"] / g["top"]
        print(f"         ratio at step 274 = {r:.2f}   (rate displacement is 5)")
        b = sorted(d[d["mode"] == "bottom"].curvature_median.values)
        t = sorted(d[d["mode"] == "top"].curvature_median.values)
        out = []
        for i in range(len(b)):
            bb = sorted(b[:i] + b[i + 1:])
            for j in range(len(t)):
                tt = sorted(t[:j] + t[j + 1:])
                out.append(bb[len(bb) // 2] / tt[len(tt) // 2])
        print(f"         leave-one-out: {min(out):.2f} to {max(out):.2f}")
        check("dropping any seed keeps the ratio within a factor of two of the displacement",
              2.5 < min(out) and max(out) < 10.0, f"{min(out):.2f}-{max(out):.2f}")

    print("\n=== D. the factors read are the population of the paper ===")
    LR = {"bottom": 2e-3, "top": 1e-2}
    bad = []
    for r in sorted({x for x in d.get("run", pd.Series(dtype=str)).dropna().astype(str)}):
        cfg = os.path.join(RUNS, r, "config.yaml")
        if not os.path.exists(cfg):
            bad.append((r, "config absent")); continue
        y = yaml.safe_load(open(cfg)) or {}
        why = []
        if y.get("update_norm_target") is not None: why.append("rescaled")
        if float(y.get("max_grad_norm", 0)) > 1.5: why.append("noclip")
        if len(y.get("target_modules") or []) != 7: why.append("module set")
        if abs(float(y.get("lr", 0)) - LR.get(y.get("mode"), -1)) > 1e-12: why.append("wrong rate")
        if why:
            bad.append((r, ", ".join(why)))
    if "run" in d.columns:
        check("no run outside the reported population", not bad, str(bad[:3]))
    else:
        print("         (the CSV has no `run` column; identities checked from the job log instead)")

    print("\n" + "=" * 70)
    if FAILED:
        print(f"  {len(FAILED)} CHECK(S) FAILED:")
        for f in FAILED:
            print(f"    - {f}")
    else:
        print("  every check passed.")
    print("""
  WHAT NO CHECK HERE CAN SETTLE. lambda at step 274 is the curvature of a point the run has
  already reached, not of the path it took to get there. A usable rate is constrained by the
  stiffest curvature encountered, and that is not necessarily the endpoint's. This measurement
  says the ratio at the endpoint matches the rate displacement; it does not prove the endpoint is
  what set the rate.""")


if __name__ == "__main__":
    main()
