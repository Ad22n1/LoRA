"""Night 4, each campaign read by its protocol. Every cell prints its seed count; nothing is concluded on incomplete data.

    python scripts/read_night4.py 2>&1 | grep -vE "FutureWarning|pd.concat"

1. top_unfrozen and bottom_unfrozen (PROTOCOL_top_unfrozen.md, 22/09, and its addendum, 26/09).
   Selection on seeds 0-1 (validation), among the seven rates; the reported seeds 2-6 are read at that rate only.
   Primary, rank 1 against the budget-matched reference: U = unfrozen(r=1) - frozen(r=2) against
   G = free(r=1) - frozen(r=2); U >= 0.7 G: freezing explains most of the gap; U <= 0.3 G: most of it comes from the
   initialisation, the basis or the rank; in between: shared. The protocol fixed G = 12.41 points for top: the script
   recomputes it and STOPS if it does not find it, since U would then be compared to another reference.
   Addendum: unfrozen(r=2) - frozen(r=2), paired t > 3.495. The principal angles between the initial and the final B.
2. ARC-Challenge at rank 32 (PROTOCOL_arcc_rank32.md): floor, freezing against choosing, rate shift.
3. Point 6 complete (PROTOCOL_norm_control.md and its deviation): the 9 reloaded pairs and the 11 retrained ones;
   the outcome with all 20 pairs, then with the 9 reloaded ones alone.
"""
import csv
import glob
import json
import math
import os
import random
import re
import statistics as st

import yaml

R = os.path.expanduser("~/lora-runs")
LLAMA, QWEN = "meta-llama/Llama-3.2-1B", "Qwen/Qwen2.5-1.5B"
S_SEL, S_REP = (0, 1), [2, 3, 4, 5, 6]


def tokens(c):
    t = c.get("target_tokens")
    return t.get(c.get("task")) if isinstance(t, dict) else t


RUNS = []
for p in glob.glob(R + "/*/config.yaml"):
    c = yaml.safe_load(open(p)) or {}
    d = os.path.dirname(p)
    try:
        if not open(d + "/status").read().startswith("DONE"):
            continue
        RUNS.append((c, json.load(open(d + "/metrics.json")), d))
    except OSError:
        continue


def clipped(c):
    """Gradient clipping at 1.0, the paper's setting. A noclip grid reran the same cells without clipping (collect()'s
    docstring); mixing both put two runs per seed in the frozen cells and moved G from 12.41 to 13.53 (26/09)."""
    v = c.get("max_grad_norm", 1.0)
    return v is not None and float(v) == 1.0


def seven(c):
    tm = c.get("target_modules")
    return tm is None or len(tm) == 7


def cell(pred, mode, rank, lr, seeds, key):
    """{seed: value}; several runs of one seed are averaged and flagged."""
    by = {}
    for c, m, d in RUNS:
        if (pred(c) and clipped(c) and c.get("mode") == mode and c.get("rank") == rank and abs(float(c.get("lr") or 0) - lr) < 1e-12
                and c.get("seed") in seeds and key in m and c.get("update_norm_target") in (None, "")):
            by.setdefault(c["seed"], []).append((m[key], d))
    dup = {s: len(v) for s, v in by.items() if len(v) > 1}
    if dup:   # say what separates the duplicates, so that the next filter is written from evidence
        s0 = sorted(dup)[0]; cfgs = [yaml.safe_load(open(d + "/config.yaml")) or {} for _, d in by[s0]]
        keys = sorted(k for k in set().union(*cfgs) if k not in ("run_id", "out_dir") and len({str(c_.get(k)) for c_ in cfgs}) > 1)
        dup["differ"] = {k: [c_.get(k) for c_ in cfgs] for k in keys} or "configs identiques"
    return {s: st.mean(x for x, _ in v) for s, v in by.items()}, dup, {s: [d for _, d in v] for s, v in by.items()}


def paired(a, b):
    k = sorted(set(a) & set(b)); dd = [(a[s] - b[s]) * 100 for s in k]
    if len(dd) < 2: return float("nan"), float("nan"), len(dd)
    sd = st.stdev(dd)
    return st.mean(dd), (st.mean(dd) / (sd / len(dd) ** 0.5) if sd > 0 else float("inf")), len(dd)


def show(lab, v, dup=None):
    extra = f"  DOUBLONS {dup}" if dup else ""
    print(f"    {lab:36s} " + (f"{st.mean(v.values()):.4f}  ({len(v)} graines){extra}" if v else "AUCUN RUN"))


def select(pred, mode, rank, lrs, key):
    full = {}
    for lr in lrs:
        v, _, _ = cell(pred, mode, rank, lr, S_SEL, key)
        if len(v) == 2: full[lr] = st.mean(v.values())
    if len(full) < len(lrs):
        return None, f"INCOMPLET ({len(full)}/{len(lrs)} taux avec leurs deux graines)"
    best = max(full, key=full.get)
    edge = best in (lrs[0], lrs[-1])
    return best, "  ".join(f"{lr:g}:{full[lr]:.3f}" for lr in lrs) + f"  -> {best:g}" + ("  AU BORD" if edge else "")


def angles(run_dirs):
    """Mean over modules of the largest principal angle (degrees) between the initial and the final B."""
    try:
        import torch
        from safetensors.torch import load_file
    except ImportError:
        return None
    out = []
    for d in run_dirs:
        steps = sorted(int(m.group(1)) for f in glob.glob(d + "/factors_*.safetensors")
                       if (m := re.search(r"factors_(\d+)\.safetensors$", f)))
        if 0 not in steps or len(steps) < 2: return None           # needs the initial B (step 0) and a later one
        f0, fe = [d + "/factors_0.safetensors"], [d + f"/factors_{steps[-1]}.safetensors"]
        t0, te = load_file(f0[0]), load_file(fe[-1])
        worst = []
        for k in t0:
            if not k.endswith(".B"): continue
            q0, _ = torch.linalg.qr(t0[k].double()); qe, _ = torch.linalg.qr(te[k].double())
            cos = torch.linalg.svdvals(q0.T @ qe).clamp(-1, 1)
            worst.append(math.degrees(math.acos(float(cos.min()))))
        out.append(st.mean(worst))
    return out


# ================================================================================================= 1. top/bottom_unfrozen
fmt = lambda c: (c.get("task") == "format" and str(c.get("model")) == LLAMA and tokens(c) == 600000 and seven(c)  # noqa: E731
                 and c.get("max_len") == 384 and c.get("batch_size") == 2 and c.get("grad_accum") == 16)
LRS1 = [1e-4, 5e-4, 1e-3, 2e-3, 5e-3, 1e-2, 2e-2]
print("==================== 1. top_unfrozen et bottom_unfrozen (protocole du 22/09 et additif du 26/09) ====================")
free, fdup, _ = cell(fmt, "free", 1, 1e-3, S_REP, "format_parsed"); show("free, rang 1, 1e-3", free, fdup)
FROZEN = {"top": 1e-2, "bottom": 5e-3}
stop = False
for arm, lr_f in FROZEN.items():
    fr, dup, _ = cell(fmt, arm, 2, lr_f, S_REP, "format_parsed")
    print(f"\n  --- {arm}"); show(f"{arm} gele, rang 2, {lr_f:g}", fr, dup)
    if dup or fdup:   # the same rule for both arms: a reference built on mixed populations is not read (26/09)
        print(f"    ARRET : doublons dans la cellule de reference ({arm} ou free) ; ajouter le filtre que 'differ' designe, puis relire.")
        stop = True; continue
    G, tG, nG = paired(free, fr)
    print(f"    G = free(r=1) - {arm}(r=2) = {G:+.2f} pt  ({nG} graines)")
    if arm == "top" and not (nG == 5 and abs(G - 12.41) < 0.01):
        print("    ARRET : le protocole a fixe G = 12,41 pour top ; la valeur recalculee differe. Verifier la population avant de lire U.")
        stop = True; continue
    for rank in (1, 2):
        mode = f"{arm}_unfrozen"
        best, txt = select(fmt, mode, rank, LRS1, "val_format_parsed")
        print(f"    selection {mode}, rang {rank} : {txt}")
        if best is None: continue
        un, udup, dirs = cell(fmt, mode, rank, best, S_REP, "format_parsed"); show(f"{mode}, rang {rank}, {best:g}", un, udup)
        if rank == 1:
            U, tU, nU = paired(un, fr)
            if nU == 5 and nG == 5:
                ratio = U / G if G else float("nan")
                half = 2.776 * abs(U / tU) if tU not in (0, float("inf")) else 0.0     # 95 % interval of U (paired t, 4 d.f.)
                lo, hi = U - half, U + half
                if U >= 0.7 * G:
                    verdict = "le gel explique l'essentiel" if lo >= 0.7 * G else "partage (l'intervalle chevauche 0,7 G)"
                elif U <= 0.3 * G:
                    verdict = "l'essentiel vient de l'initialisation, de la base ou du rang" if hi <= 0.3 * G else "partage (l'intervalle chevauche 0,3 G)"
                else:
                    verdict = "partage, sans attribution"
                print(f"    PRINCIPAL  U = {mode}(r=1) - {arm}(r=2) = {U:+.2f} pt, IC95 [{lo:+.2f}, {hi:+.2f}] (t = {tU:+.2f}) ; "
                      f"seuils 0,3 G = {0.3 * G:.2f} et 0,7 G = {0.7 * G:.2f} ; U/G = {ratio:.2f} -> {verdict}")
                print(f"    decomposition : G = U + (free - {mode}, r=1) = {U:+.2f} + {G - U:+.2f}")
                un2 = {} if best is None else cell(fmt, mode, 2, select(fmt, mode, 2, LRS1, "val_format_parsed")[0] or 0, S_REP, "format_parsed")[0]
                if len(un2) == 5:
                    for lab, a_, b_ in (("initialisation, free - unfrozen (r=1)", free, un), ("rang, unfrozen r=1 - unfrozen r=2", un, un2),
                                        ("gel seul, unfrozen r=2 - gele r=2", un2, fr)):
                        m_, t_, n_ = paired(a_, b_); h_ = 2.776 * abs(m_ / t_) if t_ not in (0, float("inf")) else 0.0
                        print(f"      terme {lab:40s} {m_:+6.2f} pt  IC95 [{m_ - h_:+.2f}, {m_ + h_:+.2f}]")
                s2, t2, n2 = paired(un, free); print(f"    second (sans revendication) : {mode}(r=1) - free(r=1) = {s2:+.2f} pt (t = {t2:+.2f})")
            else:
                print(f"    PRINCIPAL non calculable : {nU} graines appariees")
        else:
            D, tD, nD = paired(un, fr)
            print(f"    ADDITIF    {mode}(r=2) - {arm}(r=2) = {D:+.2f} pt, t = {tD:+.2f} ({nD} graines) -> "
                  + ("ETABLI" if nD == 5 and abs(tD) > 3.495 else "non etabli") + "  [budget 2,15x, non apparie]")
        ang = angles([d for s in sorted(dirs) for d in dirs[s][:1]])
        print("    derive : " + ("facteurs introuvables ou torch absent" if ang is None else
                                  f"plus grand angle principal entre B initial et B final, moyenne sur les modules : {st.mean(ang):.1f} degres (par graine : {', '.join(f'{a:.1f}' for a in ang)})"))


# ================================================================================================= 4. freezing A instead of B
print("\n==================== 4. geler A plutot que B (PROTOCOL_freeze_A.md) ====================")
est, sign = {}, {}
for arm, lr_f in FROZEN.items():
    fr, dup, _ = cell(fmt, arm, 2, lr_f, S_REP, "format_parsed")
    print(f"  --- {arm}"); show(f"{arm} (gel de B), rang 2, {lr_f:g}", fr, dup)
    if dup:
        print("    ARRET : doublons dans la reference ; ajouter le filtre que 'differ' designe."); continue
    best, txt = select(fmt, f"dual_{arm}", 2, LRS1, "val_format_parsed"); print(f"    selection dual_{arm} : {txt}")
    if best is None: continue
    du, ddup, _ = cell(fmt, f"dual_{arm}", 2, best, S_REP, "format_parsed"); show(f"dual_{arm} (gel de A), {best:g}", du, ddup)
    if ddup: print("    ARRET : doublons"); continue
    D, tD, nD = paired(du, fr); h = 2.776 * abs(D / tD) if tD not in (0, float("inf")) else 0.0
    est[arm] = nD == 5 and abs(tD) > 3.495; sign[arm] = D > 0
    print(f"    PRINCIPAL  dual_{arm} - {arm} = {D:+.2f} pt, IC95 [{D - h:+.2f}, {D + h:+.2f}], t = {tD:+.2f} ({nD} graines) -> "
          + ("ETABLI" if est[arm] else "non etabli") + ("" if not est[arm] else (" (geler A coute MOINS que geler B)" if D > 0 else " (geler A coute PLUS)")))
if len(est) == 2:
    pos = [a for a in est if est[a] and sign[a]]
    print("  -> issue " + ("1 : geler A coute moins que geler B aux deux extremites : le cout est propre au facteur de sortie" if len(pos) == 2
                           else ("2 : etabli a une seule extremite (" + ", ".join(pos) + ")" if pos else "3 : geler A coute autant ou plus : le cout tient au gel d'un facteur")))
    print("     reserve : les bras qui gelent A ont 15 % de budget en plus (r x d_out contre r x d_in).")
duals = {}
for mode in ("dual_top", "dual_bottom", "dual_random_ortho"):
    b, _ = select(fmt, mode, 2, LRS1, "val_format_parsed")
    if b is not None: duals[mode] = (b, cell(fmt, mode, 2, b, S_REP, "format_parsed")[0])
if len(duals) == 3 and all(len(v) == 5 for _, v in duals.values()) and len(free) == 5:
    m = {k: st.mean(v.values()) for k, (_, v) in duals.items()}
    print(f"  secondaire : free(r=1) - meilleur dual = {(st.mean(free.values()) - max(m.values())) * 100:+.2f} pt ; etendue entre bras dual = "
          f"{(max(m.values()) - min(m.values())) * 100:.2f} pt ; taux retenus : " + ", ".join(f"{k} {b:g}" for k, (b, _) in duals.items()))

# ================================================================================================= 2. ARC-Challenge, ranks 2 and 32
arc = lambda c: c.get("task") == "commonsense" and str(c.get("data_fingerprint")) == "0755bcdbdce3" and str(c.get("model")) == QWEN  # noqa: E731


def read_arc(rk, rk_free, lrs, label, issues):
    print(f"\n==================== 2. ARC-Challenge au rang {rk} ({label}) ====================")
    sel, own = {}, {}
    for mode, rank in (("top", rk), ("bottom", rk), ("random_ortho", rk), ("free", rk_free)):
        best, txt = select(arc, mode, rank, lrs, "val_mcq_acc"); print(f"    selection {mode:13s} : {txt}")
        if best is not None:
            sel[mode] = best; own[mode], dup, _ = cell(arc, mode, rank, best, S_REP, "mcq_acc"); show(f"{mode} a {best:g}", own[mode], dup)
    base = [m["mcq_acc"] for c, m, d in RUNS if c.get("mode") == "baseline" and arc(c) and "mcq_acc" in m]
    b0 = base[0] if base else 0.4360
    if own.get("free"):
        gap = (st.mean(own["free"].values()) - b0) * 100
        print(f"  plancher : free contre la base ({b0:.4f}{'' if base else ', valeur du rang 16'}) : {gap:+.1f} pt (seuil +5) -> {'PASSE' if gap >= 5 else 'ECHOUE : NON INFORMATIF'}")
    fz = {k: v for k, v in own.items() if k != "free"}
    if len(own) == 4 and all(len(v) == 5 for v in own.values()):
        S = sorted(set(own["free"]).intersection(*[set(v) for v in fz.values()]))
        def fc(ix):
            m = {k: st.mean(v[s] for s in ix) for k, v in fz.items()}; ff = st.mean(own["free"][s] for s in ix)
            return (ff - max(m.values())) * 100, (max(m.values()) - min(m.values())) * 100
        g, c = fc(S); rng = random.Random(0); B = sorted(a - b for a, b in (fc([S[rng.randrange(len(S))] for _ in S]) for _ in range(20000)))
        lo, hi = B[500], B[19499]
        print(f"  PRINCIPAL  geler {g:.2f}, choisir {c:.2f} -> geler - choisir {g - c:+.2f}  IC95 [{lo:+.2f}, {hi:+.2f}] -> "
              + (issues["neg"] if hi < 0 else (issues["pos"] if lo > 0 else issues["zero"])))
        lower = [k for k in ("top", "random_ortho") if sel["bottom"] < sel[k]]
        print(f"  secondaire : bottom ({sel['bottom']:g}) plus bas que {lower or 'aucun'} (top {sel['top']:g}, random_ortho {sel['random_ortho']:g})")
        spec = max(("top", "bottom"), key=lambda k: st.mean(fz[k].values()))
        d, t_, n = paired(fz[spec], fz["random_ortho"]); print(f"  secondaire : meilleur bras spectral ({spec}) - random_ortho = {d:+.2f} pt (t = {t_:+.2f}, {n} graines)")
    else:
        print("  PRINCIPAL non calculable : cellules incompletes")


read_arc(2, 1, [2e-4, 5e-4, 1e-3, 2e-3, 5e-3, 1e-2, 2e-2], "PROTOCOL_arcc_rank2.md : rang ou tache ?",
         {"pos": "issue 1 : geler coute plus au rang 2 -> l'ordre change avec le RANG, dans une meme tache",
          "zero": "issue 2 : non etabli au rang 2 ; rang ou tache reste ouvert",
          "neg": "issue 3 : choisir coute plus aussi au rang 2 -> le renversement est une propriete de la TACHE"})
read_arc(32, 14, [5e-5, 1e-4, 2e-4, 5e-4, 1e-3, 2e-3, 5e-3], "PROTOCOL_arcc_rank32.md",
         {"neg": "issue 1 : choisir coute plus, l'ordre inverse tient au rang 32",
          "zero": "issue 2 : non etabli au rang 32", "pos": "issue 3 : l'ordre revient a celui des rangs bas"})

# ================================================================================================= 3. point 6, complete
print("\n==================== 3. point 6, complet (protocole et son ecart) ====================")
TARGETS = [1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5]; ARMS = ("top", "random", "random_ortho", "bottom")
LR6 = {"top": 1e-2, "random": 1e-2, "random_ortho": 1e-2, "bottom": 5e-3}
rel, method = {}, {}
for f in glob.glob(os.path.expanduser("~/lora-analysis/norm_control/*.csv")):
    rows = list(csv.DictReader(open(f)))
    ownr = [r for r in rows if r["target"] == "own"]
    if ownr and ownr[0]["reproduced"] == "True":
        got = {float(r["target"]): float(r["format_parsed"]) for r in rows if r["target"] != "own"}
        if all(t in got for t in TARGETS):
            key = (ownr[0]["mode"], int(ownr[0]["seed"])); rel[key] = got; method[key] = "recharge"
for c, m, d in RUNS:
    t = c.get("update_norm_target")
    if t in (None, "") or c.get("seed") not in range(105, 110) or c.get("mode") not in ARMS or c.get("rank") != 2: continue
    if c.get("task") != "format" or str(c.get("model")) != LLAMA or not seven(c): continue
    if abs(float(c.get("lr")) - LR6[c["mode"]]) > 1e-12 or "format_parsed" not in m: continue
    key = (c["mode"], c["seed"])
    if method.get(key) == "recharge": continue
    rel.setdefault(key, {})[float(t)] = m["format_parsed"]; method[key] = "reentraine"
complete = {k: v for k, v in rel.items() if all(t in v for t in TARGETS)}
print(f"  couples complets : {len(complete)} sur 20 ({sum(method[k] == 'recharge' for k in complete)} recharges, {sum(method[k] == 'reentraine' for k in complete)} reentraines)")


def outcome(keys, label):
    means = {a: {t: [complete[k][t] for k in keys if k[0] == a] for t in TARGETS} for a in ARMS}
    print(f"  --- {label}")
    for a in ARMS:
        print(f"    {a:13s} ({len([k for k in keys if k[0] == a])}) " + "  ".join(f"{t}:{st.mean(means[a][t]):.3f}" if means[a][t] else f"{t}:-" for t in TARGETS))
    usable = [t for t in TARGETS if all(means[a][t] and st.mean(means[a][t]) >= 0.3 for a in ARMS)]
    print(f"    cibles utilisables : {usable or 'AUCUNE'}")
    if not usable:
        print("    -> issue 1 : controle inutilisable"); return
    est, ns = [], []
    for a in ("top", "random", "random_ortho"):
        seeds = sorted(s for (x, s) in keys if x == a and (("bottom", s) in keys))
        gap = {s: st.mean(complete[(a, s)][t] - complete[("bottom", s)][t] for t in usable) for s in seeds}
        mm, tt, n = paired(gap, {s: 0.0 for s in seeds}); ns.append(n); est.append(n == 5 and tt > 3.96)
        print(f"    {a:13s} - bottom : {mm:+.2f} pt, t = {tt:+.2f} ({n} graines) {'ETABLI' if est[-1] else 'non etabli'}")
    if any(n != 5 for n in ns):
        print("    -> pas de conclusion : moins de cinq graines appariees"); return
    k = sum(est)
    print("    -> issue " + ("2 : l'effet de position ne s'explique pas par la norme" if k == 3 else ("3 : partiel" if k else "4 : compatible avec un effet de norme")))


outcome(sorted(complete), "les vingt couples (recharges et reentraines)")
outcome(sorted(k for k in complete if method[k] == "recharge"), "les couples recharges seuls")
