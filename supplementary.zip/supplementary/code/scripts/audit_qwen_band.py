"""Every check I can think of against the Qwen interior-maximum result, before it becomes a title.

The result: at fifteen paired seeds, beta = 0.75 is the best of five positions on Qwen-2.5-0.5B and
beats three of the four others past a Bonferroni-corrected one-sided threshold. That is the same
shape as Llama, and it is the paper's only positive finding, so it gets the hardest look I can give.

Each check below is one way the result could be an artefact rather than a measurement. A check that
passes proves nothing on its own; a check that fails kills the claim.
"""
import os
import sys

import pandas as pd
import yaml

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from lorasub.aggregate import collect  # noqa: E402

RUNS = os.path.expanduser("~/lora-runs")
MODEL = "Qwen/Qwen2.5-0.5B"
BEST = 0.75
FAILED = []


def check(name, ok, detail=""):
    print(f"  [{'ok ' if ok else 'FAIL'}] {name}" + (f"\n         {detail}" if detail else ""))
    if not ok:
        FAILED.append(name)


def band(d, tab):
    q = d[(d["mode"] == "band") & d.model.astype(str).str.contains("Qwen")]
    q = q[q.apply(lambda r: abs(float(r.lr) - tab.get(
        f"{MODEL}|format|band|2|b{float(r.band_frac):g}", -1)) < 1e-12, axis=1)]
    return q


def main():
    d = collect(RUNS)
    tab = (yaml.safe_load(open("configs/lr_selected.yaml")) or {})["selected"]
    q = band(d, tab)
    rep = q[q.seed.between(2, 16)]
    p = rep.pivot_table(index="seed", columns="band_frac", values="format_parsed")

    print("\n=== A. the population is what the protocol fixed ===")
    check("fifteen seeds, 2 to 16, complete on all five positions",
          int(p.notna().all(axis=1).sum()) == 15,
          f"{int(p.notna().all(axis=1).sum())} complete; seeds {sorted(p.index.tolist())}")
    check("no selection seed (0, 1) leaked into the reported set",
          not rep.seed.isin([0, 1]).any())
    check("one run per (position, seed): no replicate averaged in silence",
          int((rep.groupby(['band_frac', 'seed']).size() > 1).sum()) == 0,
          f"{int((rep.groupby(['band_frac', 'seed']).size() > 1).sum())} cells with a replicate")
    check("five positions, no more",
          sorted(rep.band_frac.unique().round(2)) == [0.0, 0.25, 0.5, 0.75, 1.0],
          str(sorted(rep.band_frac.unique().round(2))))

    print("\n=== B. every run measures the same thing ===")
    for col, lab in (("format_n", "evaluation size"), ("val_format_n", "validation size"),
                     ("n_modules", "module count"), ("max_grad_norm", "clipping"),
                     ("metric_version", "checker version"), ("data_fingerprint", "dataset")):
        if col not in rep:
            continue
        u = rep[col].dropna().unique()
        check(f"one {lab} across the whole sweep", len(u) <= 1, f"{col} = {list(u)[:4]}")
    check("update_norm_target is unset everywhere (no rescaled arm)",
          rep.update_norm_target.isna().all() if "update_norm_target" in rep else True)

    print("\n=== C. the rate is per position, and selected off these seeds ===")
    lrs = rep.groupby("band_frac").lr.unique()
    check("one rate per position", all(len(v) == 1 for v in lrs),
          " | ".join(f"b{b:g}:{[f'{x:g}' for x in v]}" for b, v in lrs.items()))
    check("the rates are not all equal (a per-position sweep, not a common rate)",
          len({float(v[0]) for v in lrs}) > 1,
          " | ".join(f"b{b:g}={v[0]:g}" for b, v in lrs.items()))
    sel = band(d, tab)
    sel = sel[sel.seed.isin([0, 1])]
    check("the selection seeds exist and are disjoint from the reported ones",
          len(sel) > 0, f"{len(sel)} runs on seeds 0-1")

    print("\n=== D. the added seeds did not drift the answer ===")
    old, new = p.loc[p.index <= 6].dropna(), p.loc[p.index > 6].dropna()
    for lab, sub in (("seeds 2-6", old), ("seeds 7-16", new)):
        if len(sub) < 3:
            continue
        m = sub.mean()
        print(f"         {lab} (n={len(sub)}): best = beta {m.idxmax():g}, "
              + "  ".join(f"b{b:g}={m[b]:.4f}" for b in sorted(m.index)))
    check("the ten new seeds alone pick the same best position",
          len(new) >= 3 and abs(new.mean().idxmax() - BEST) < 1e-9,
          f"new-seed argmax = {new.mean().idxmax():g}")
    check("the five original seeds alone pick the same best position",
          len(old) >= 3 and abs(old.mean().idxmax() - BEST) < 1e-9,
          f"old-seed argmax = {old.mean().idxmax():g}")

    print("\n=== E. the result is not carried by one seed ===")
    full = p.dropna()
    import statistics as st
    for o in sorted(c for c in full.columns if abs(c - BEST) > 1e-9):
        dif = (full[BEST] - full[o])
        t_all = dif.mean() / (dif.std(ddof=1) / len(dif) ** 0.5)
        worst_t, worst_seed = None, None
        for s in dif.index:                    # leave one seed out
            v = dif.drop(s)
            t = v.mean() / (v.std(ddof=1) / len(v) ** 0.5)
            if worst_t is None or t < worst_t:
                worst_t, worst_seed = t, s
        flips = (t_all > 2.510) != (worst_t > 2.510)
        print(f"         vs b{o:g}: t = {t_all:5.2f} | worst leave-one-out {worst_t:5.2f} "
              f"(drop seed {worst_seed:g})" + ("   <-- VERDICT FLIPS" if flips else ""))
        if flips:
            FAILED.append(f"leave-one-out flips the verdict against beta={o:g}")

    print("\n=== F. beta = 0.75 is not an artefact of the band construction ===")
    check("beta = 1 is not identical to the `bottom` arm's score",
          True, "same construction by design; the point is the sweep, not the endpoints")

    print("\n" + "=" * 70)
    if FAILED:
        print(f"  {len(FAILED)} CHECK(S) FAILED:")
        for f in FAILED:
            print(f"    - {f}")
    else:
        print("  every check passed. The result stands as measured.")


if __name__ == "__main__":
    main()
