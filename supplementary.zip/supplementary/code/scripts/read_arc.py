"""ARC at rank 16, read by PROTOCOL_rank16_arc.md and its addendum (committed before the runs).

    python scripts/read_arc.py 2>&1 | grep -vE "FutureWarning|pd.concat"

ARC-Easy  : top and free selected the bottom of the grid (1e-4); the grid was extended by one step (5e-5)
            on seeds 0-1. Here: the new selection, edge check, the rule's two common rates, the rate shift.
ARC-Challenge : the rule gives one common rate (bottom and random_ortho both at 1e-3), so the inversion
            is not testable. Here, on seeds 2-6: the floor, freezing against choosing at the selected rates,
            and the three frozen arms at 1e-3, described without an inversion test.
Runs are told apart by their data fingerprint, the only field that separates the benchmarks.
"""
import glob
import json
import os
import random
import statistics as st

import yaml

FP = {"ARC-Easy": "15890c7671bb", "ARC-Challenge": "0755bcdbdce3"}
R = os.path.expanduser("~/lora-runs")
runs = []
for p in glob.glob(R + "/*/config.yaml"):
    c = yaml.safe_load(open(p)) or {}
    if c.get("task") != "commonsense" or str(c.get("data_fingerprint")) not in FP.values():
        continue
    d = os.path.dirname(p)
    st_ = open(d + "/status").read().split("\n")[0].strip() if os.path.exists(d + "/status") else ""
    m = json.load(open(d + "/metrics.json")) if os.path.exists(d + "/metrics.json") else {}
    if st_ == "DONE" and m:
        runs.append((str(c["data_fingerprint"]), c.get("mode"), c.get("rank"), float(c.get("lr") or 0), c.get("seed"), m))


def cell(fp, mode, rank, lr, seeds, key="mcq_acc"):
    out = {}
    for f, mo, r, l, s, m in runs:
        if f == fp and mo == mode and r == rank and abs(l - lr) < 1e-12 and s in seeds and key in m:
            out[s] = m[key]
    return out


def sweep(fp, mode, rank):
    lrs = sorted({l for f, mo, r, l, s, m in runs if f == fp and mo == mode and r == rank and s in (0, 1)})
    return {lr: cell(fp, mode, rank, lr, (0, 1), "val_mcq_acc") for lr in lrs}


def base(fp):
    v = [m["mcq_acc"] for f, mo, r, l, s, m in runs if f == fp and mo == "baseline" and "mcq_acc" in m]
    return v[0] if v else float("nan")


ARMS = [("top", 16), ("bottom", 16), ("random_ortho", 16), ("free", 7)]

# ------------------------------------------------------------------ ARC-Easy : the extended selection
fp = FP["ARC-Easy"]
print(f"==================== ARC-Easy (modele de base, test : {base(fp):.4f}) ====================")
sel = {}
for mode, rank in ARMS:
    sw = sweep(fp, mode, rank)
    full = {lr: st.mean(v.values()) for lr, v in sw.items() if len(v) == 2}
    if not full:
        print(f"  {mode:13s} AUCUN RUN COMPLET"); continue
    best = max(full, key=full.get); sel[mode] = best
    edge = best in (min(sw), max(sw))
    print(f"  {mode:13s} " + "  ".join(f"{lr:g}:{full[lr]:.3f}" for lr in sorted(full)) + f"   -> {best:g}" + ("  AU BORD" if edge else ""))
edges = [m for m in sel if sel[m] in (min(sweep(fp, m, dict(ARMS)[m])), max(sweep(fp, m, dict(ARMS)[m])))]
if edges:
    print(f"\n  ENCORE AU BORD : {edges} -> le protocole prolonge encore d'un cran avant toute autre regle")
else:
    others = {m: sel[m] for m in ("top", "random_ortho") if m in sel}
    best_other = max(others, key=lambda m: max(st.mean(v.values()) for v in sweep(fp, m, 16).values() if len(v) == 2))
    pair = sorted({sel["bottom"], sel[best_other]})
    print(f"\n  toutes les selections sont interieures ; taux communs : bottom ({sel['bottom']:g}) et {best_other} ({sel[best_other]:g})")
    print("  -> CONFONDUS : inversion non testable" if len(pair) == 1 else f"  -> seconde etape a lancer aux taux {pair[0]:g} et {pair[1]:g}, plus les taux propres")
lower = [m for m in ("top", "random_ortho") if m in sel and sel["bottom"] < sel[m]]
print(f"  deplacement du taux : bottom ({sel.get('bottom', float('nan')):g}) strictement plus bas que {lower or 'aucun bras'}")

# ------------------------------------------------------------------ ARC-Challenge : the second stage
fp = FP["ARC-Challenge"]; S = (2, 3, 4, 5, 6); b0 = base(fp)
print(f"\n==================== ARC-Challenge (modele de base, test : {b0:.4f}) ====================")
own = {"top": cell(fp, "top", 16, 5e-4, S), "bottom": cell(fp, "bottom", 16, 1e-3, S), "random_ortho": cell(fp, "random_ortho", 16, 1e-3, S)}
fr = cell(fp, "free", 7, 5e-4, S)
for k, v in list(own.items()) + [("free r=7", fr)]:
    print(f"  {k:13s} taux propre : {len(v)} graines, {st.mean(v.values()):.4f}" if v else f"  {k:13s} AUCUN RUN")
if fr:
    gap = (st.mean(fr.values()) - b0) * 100
    print(f"\n  plancher : free {st.mean(fr.values()):.4f} contre le modele de base {b0:.4f} : {gap:+.1f} points "
          f"(seuil +5) -> {'PASSE' if gap >= 5 else 'ECHOUE : campagne NON INFORMATIVE'}")
seeds = sorted(set(fr).intersection(*[set(v) for v in own.values()])) if fr and all(own.values()) else []
if len(seeds) >= 2:
    def fc(ix):
        m = {k: st.mean(v[s] for s in ix) for k, v in own.items()}; f = st.mean(fr[s] for s in ix)
        return (f - max(m.values())) * 100, (max(m.values()) - min(m.values())) * 100
    g, c = fc(seeds); rng = random.Random(0)
    B = [fc([seeds[rng.randrange(len(seeds))] for _ in seeds]) for _ in range(20000)]
    q = lambda xs: (sorted(xs)[500], sorted(xs)[19499])  # noqa: E731
    print(f"  geler (ecart a free) {g:.2f} pt {q([b[0] for b in B])}   choisir {c:.2f} pt {q([b[1] for b in B])}")
    lo, hi = q([b[0] - b[1] for b in B]); print(f"  geler - choisir {g - c:+.2f} pt  IC95 [{lo:+.2f}, {hi:+.2f}]")
print("\n  les trois bras au meme taux, 1e-3 (descriptif, sans test d'inversion) :")
for m in ("top", "bottom", "random_ortho"):
    v = cell(fp, m, 16, 1e-3, S)
    print(f"    {m:13s} {st.mean(v.values()):.4f} ({len(v)} graines)" if v else f"    {m:13s} AUCUN RUN")
