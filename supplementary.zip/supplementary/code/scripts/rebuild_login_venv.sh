#!/bin/bash
# Etape 0 (TMLR) : reconstruit l'environnement Python du serveur de connexion (/tmp/lora-$USER/venv), endommage par le nettoyage de /tmp,
# exactement comme le preambule des jobs (src/lorasub/launch_grid.py) : construction a part, verification, publication d'un seul geste.
# L'ancien environnement est mis de cote, pas efface. Ne touche a aucun run ni resultat.
set -u
R="$HOME/repo"; V="/tmp/lora-$USER/venv"; B="$V.building.$$"
pgrep -f "scripts/v2_nuit.sh" >/dev/null && { echo "  STOP : une passe du pilote tourne ; reessayez dans une minute"; exit 1; }
PYB="$HOME/.local/bin/python3.10"; [ -x "$PYB" ] || PYB=python3
if "$V/bin/python" -c "import lorasub, torch, yaml, scipy" 2>/dev/null; then echo "  l'environnement fonctionne deja : rien a faire"; exit 0; fi
rm -rf "$B"; "$PYB" -m venv "$B" || { echo "  STOP : creation impossible"; exit 1; }
"$B/bin/python" -m pip install -q --upgrade pip setuptools wheel
"$B/bin/python" -m pip install -q torch --extra-index-url https://download.pytorch.org/whl/cu121 || { echo "  STOP : torch"; exit 1; }
"$B/bin/python" -m pip install -q -r "$R/requirements.txt" || { echo "  STOP : requirements.txt"; exit 1; }
"$B/bin/python" -m pip install -q -e "$R" || { echo "  STOP : installation du depot"; exit 1; }
"$B/bin/python" -m pip install -q scipy      # pour les analyses (A1-A3 et lectures)
"$B/bin/python" -c "import lorasub, torch, yaml, scipy, pandas, safetensors; print('  nouvel environnement : torch', torch.__version__)" || { echo "  STOP : environnement incomplet"; exit 1; }
[ -e "$V" ] && mv "$V" "$V.endommage.$(date +%d%m_%H%M)"
mv "$B" "$V" && echo "  environnement publie : $V (l'ancien est garde a cote, suffixe .endommage)"
