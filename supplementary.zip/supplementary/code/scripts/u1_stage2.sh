#!/bin/bash
# Apres l'etape 1 de PROTOCOL_7b_unfrozen_r1.md : grilles du RAPPORT au taux retenu, committees avant leurs runs, puis lancees.
set -u
cd "$HOME/repo" || exit 1
PY="/tmp/lora-$USER/venv/bin/python"; [ -x "$PY" ] || PY=python3
echo "=== etape 2, rapport ==="
"$PY" scripts/make_u1_grids.py --stage2 || { echo "  STOP : selection incomplete ; rien n'est lance"; exit 1; }
git add configs/grids/u1_*_s2_*.yaml && git commit -qm "B entraine au rang 1 sur les deux 7B : taux retenus sur les graines 0-1 ; grilles du rapport avant leurs runs" && echo "  ok : committe ($(git log -1 --format=%h))"
git push -q 2>/dev/null; bash scripts/launch_u1_q7_s2.sh; bash scripts/launch_u1_m7_s2.sh
