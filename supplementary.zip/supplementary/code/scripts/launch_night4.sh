#!/usr/bin/env bash
# The night of 26/09: the point-6 deviation runs, the isolated cost of freezing (experiment 1) and ARC-Challenge
# at rank 32 (experiment 2), in one command. Experiment 1 goes only if the bottom_unfrozen test passes here.
#
#     bash scripts/launch_night3.sh --dry     # checks and counts only (any time); logs are never touched
#     bash scripts/launch_night3.sh           # submits; refuses between 09:00 and 17:00
#
# (Point 6 of the previous script was two steps: the 20 trainings (norm6_train_*), then one evaluation task per trained run
# (scripts/norm_rescale_eval.py), built from the training job by scripts/make_eval_array.sh and chained with
# --dependency=afterany, so it starts only once every training task has ended (a failed training is caught
# by the evaluation, which refuses a run that is not DONE).
set -u
cd "$HOME/repo" || exit 1
PY="/tmp/lora-$USER/venv/bin/python"; [ -x "$PY" ] || { echo "  venv introuvable : $PY"; exit 1; }
DRY=0; [ "${1:-}" = "--dry" ] && DRY=1
H=$(date +%H)
if [ $DRY -eq 0 ] && [ "$H" -ge 9 ] && [ "$H" -lt 17 ]; then echo "  REFUS : il est $(date +%H:%M), pas de PARTITION entre 9 h et 17 h"; exit 1; fi

G6="norm6_fix_bottom norm6_fix_random norm6_fix_random_ortho norm6_fix_top"
GE1="tu_r1_all tu_r2_all bu_r1_all bu_r2_all"
GE3="arcc2_frozen arcc2_free"
GE2="arcc32_frozen arcc32_free"
FILES="PROTOCOL_norm_control_deviation.md PROTOCOL_top_unfrozen.md PROTOCOL_top_unfrozen_addendum.md PROTOCOL_arcc_rank32.md PROTOCOL_arcc_rank2.md src/lorasub/lora.py src/lorasub/config.py \
src/lorasub/aggregate.py tests/test_lora.py $(for g in $G6 $GE1 $GE3 $GE2; do echo configs/grids/$g.yaml; done)"

echo "=== 1. tout est committe et a jour ==="
bad=0
for f in $FILES; do
    if [ ! -f "$f" ]; then echo "  ABSENT       $f"; bad=1
    elif ! git ls-files --error-unmatch "$f" >/dev/null 2>&1; then echo "  NON COMMITTE $f"; bad=1
    elif ! git diff --quiet HEAD -- "$f"; then echo "  MODIFIE      $f"; bad=1; fi
done
[ $bad -eq 0 ] && echo "  ok" || { echo "  REFUS : envoyer et committer d'abord"; exit 1; }

echo "=== 2. le test de bottom_unfrozen, sur ce serveur ==="
"$PY" -m pytest -q tests/test_lora.py "tests/test_additions.py::test_the_salted_modes_list_has_no_second_copy" 2>&1 | tail -3 > /tmp/bunf_test.txt
if grep -qE "passed" /tmp/bunf_test.txt && ! grep -qE "failed|error" /tmp/bunf_test.txt; then echo "  ok : l'experience 1 peut partir"; E1_OK=1
else echo "  ECHEC : l'experience 1 ne partira pas"; cat /tmp/bunf_test.txt; E1_OK=0; fi

TMP=$(mktemp -d)
count() {   # "done torun" for grid $1, or ACTIVE if jobs of this grid still run; the grid dir is never deleted
    # A grid is active if a job of the queue runs ITS slurm_array.sh (26/09: launch_grid's own check never fired, and
    # counting regenerated the directory of a running grid). Checked BEFORE launch_grid touches anything.
    if squeue -h -u "$USER" -o "%o" 2>/dev/null | grep -q "/lora-grid/$1/slurm_array.sh"; then echo "ACTIVE"; return; fi
    local dir="$HOME/lora-grid/$1"; [ $DRY -eq 1 ] && dir="$TMP/$1"
    local out; out=$("$PY" -m lorasub.launch_grid "configs/grids/$1.yaml" --grid_dir "$dir" --partition PARTITION \
        --time 01:59:00 --max_par 8 --venv "/tmp/lora-$USER/venv" 2>&1)
    if echo "$out" | grep -q "refusing to generate"; then echo "ACTIVE"; return; fi
    echo "$out" | grep -oE "[0-9]+ already done; [0-9]+ to run" | grep -oE "[0-9]+" | tr '\n' ' '
}
submit() {   # prints the job id on stdout (last line) when it submits
    local g=$1 res done torun
    res="$(count "$g")"
    if [ "$res" = "ACTIVE" ]; then echo "  EN COURS $g : des jobs tournent encore, rien n'est soumis en double" >&2; return; fi
    read -r done torun <<< "$res"
    if [ -z "${done:-}" ]; then echo "  ERREUR  $g : comptage impossible" >&2; return; fi
    if [ "$done" -gt 0 ]; then echo "  SAUTE   $g : $done runs existent deja (collision)" >&2; return; fi
    if [ $DRY -eq 1 ]; then echo "  pret    $g : $torun runs" >&2; return; fi
    local jid; jid=$(sbatch --parsable --exclude=node "$HOME/lora-grid/$g/slurm_array.sh")
    echo "  soumis  $g ($torun runs) : job $jid" >&2; echo "$jid"
}

echo "=== 3. point 6 : les onze couples remesures par reentrainement ==="
for g in $G6; do res="$(count "$g")"
  if [ "$res" = "ACTIVE" ]; then echo "  EN COURS $g"; continue; fi
  read -r done torun <<< "$res"
  if [ -z "${done:-}" ]; then echo "  ERREUR  $g : comptage impossible"; continue; fi
  if [ "$torun" -eq 0 ]; then echo "  RIEN    $g : deja complet ($done)"; continue; fi
  if [ "$done" -gt 0 ]; then echo "  SAUTE   $g : $done deja faits (collision)"; continue; fi
  [ $DRY -eq 1 ] && { echo "  pret    $g : $torun runs"; continue; }
  echo "  soumis  $g ($torun runs) : job $(sbatch --parsable --exclude=node "$HOME/lora-grid/$g/slurm_array.sh")"
done
echo "=== 4. experience 1 : top_unfrozen et bottom_unfrozen (protocole du 22/09 et son additif) ==="
if [ $E1_OK -eq 1 ]; then for g in $GE1; do submit "$g" >/dev/null; done; else echo "  non lancee (test)"; fi
echo "=== 5. ARC-Challenge au rang 2 (rang ou tache ?) ==="
for g in $GE3; do submit "$g" >/dev/null; done
echo "=== 6. experience 2 : ARC-Challenge au rang 32 ==="
for g in $GE2; do submit "$g" >/dev/null; done
rm -rf "$TMP"
echo "=== file ==="; squeue -u "$USER" | head -8
