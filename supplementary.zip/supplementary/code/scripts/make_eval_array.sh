#!/usr/bin/env bash
# Build the evaluation job of point 6 from the TRAINING job of a grid: the same preamble (exports, venv built on
# the node under a lock, the check for a busy card), the same list of configs, one task per trained run; only the
# last line changes, from training to scripts/norm_rescale_eval.py.
#     bash scripts/make_eval_array.sh norm6_train_frozen      # writes ~/lora-grid/norm6_train_frozen/eval_array.sh
set -eu
G="$HOME/lora-grid/$1"; SRC="$G/slurm_array.sh"; DST="$G/eval_array.sh"
[ -f "$SRC" ] || { echo "  absent : $SRC (compter la grille d'abord)"; exit 1; }
grep -q '"$PY" -m lorasub.train "$CFG"' "$SRC" || { echo "  derniere ligne inattendue dans $SRC : rien n'est ecrit"; exit 1; }
sed -e 's#"$PY" -m lorasub.train "$CFG"#"$PY" scripts/norm_rescale_eval.py --config "$CFG"#' \
    -e 's#^\#SBATCH --job-name=lorasub#\#SBATCH --job-name=normeval#' "$SRC" > "$DST"
grep -q 'norm_rescale_eval.py --config' "$DST" && echo "  ecrit : $DST" || { echo "  echec du remplacement"; rm -f "$DST"; exit 1; }
