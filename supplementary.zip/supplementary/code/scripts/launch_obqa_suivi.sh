#!/bin/bash
# Suivi (second additif de PROTOCOL_obqa_unfrozen.md) : reentraine les 10 references gelees avec leurs facteurs, puis
# reevalue les 30 checkpoints compares dans UN job, sur UNE machine, apres la fin des reentrainements.
#   bash scripts/launch_obqa_suivi.sh --dry                      (verifie, ne soumet rien)
#   bash scripts/launch_obqa_suivi.sh [--node ain] [--PARTITION "RTX 4000 Ada"]
set -u
DRY=0; NODE=ain; PARTITION="RTX 4000 Ada"
while [ $# -gt 0 ]; do case $1 in --dry) DRY=1;; --node) NODE=$2; shift;; --PARTITION) PARTITION=$2; shift;; esac; shift; done
cd "$HOME/repo" || { echo "STOP : ~/repo introuvable"; exit 1; }
PY="/tmp/lora-$USER/venv/bin/python"; [ -x "$PY" ] || { echo "STOP : environnement /tmp/lora-$USER/venv absent"; exit 1; }
FILES="PROTOCOL_obqa_unfrozen_suivi.md configs/grids/obqa_ref_top.yaml configs/grids/obqa_ref_bottom.yaml scripts/eval_single_gpu.py scripts/read_obqa_suivi.py"
echo "=== 1. tout est committe et a jour ==="
bad=0
for f in $FILES; do git ls-files --error-unmatch "$f" >/dev/null 2>&1 && git diff --quiet HEAD -- "$f" || { echo "  NON COMMITTE OU MODIFIE : $f"; bad=1; }; done
[ $bad -eq 0 ] && echo "  ok" || { echo "  REFUS : committer d'abord ; rien n'est lance"; exit 1; }
echo "=== 2. la machine imposee : $NODE ; modele de carte attendu : $PARTITION ==="
sinfo -h -n "$NODE" -o "  etat de $NODE : %T" 2>/dev/null || echo "  (sinfo indisponible)"
echo "=== 3. les reentrainements ==="
JOBS=""
for g in obqa_ref_top obqa_ref_bottom; do
  if squeue -h -u "$USER" -o "%o" 2>/dev/null | grep -q "/lora-grid/$g/slurm_array.sh"; then echo "  EN COURS $g"; continue; fi
  dir="$HOME/lora-grid/$g"; [ $DRY -eq 1 ] && dir="$(mktemp -d)/$g"
  out=$("$PY" -m lorasub.launch_grid "configs/grids/$g.yaml" --grid_dir "$dir" --partition PARTITION --time 01:59:00 --max_par 5 --venv "/tmp/lora-$USER/venv" 2>&1)
  n=$(echo "$out" | grep -oE "[0-9]+ already done; [0-9]+ to run")
  [ -n "$n" ] || { echo "  ERREUR $g :"; echo "$out" | tail -3 | sed 's/^/    /'; exit 1; }
  torun=$(echo "$n" | grep -oE "[0-9]+ to run" | grep -oE "[0-9]+")
  if [ "$torun" -eq 0 ]; then echo "  RIEN    $g : complet"; continue; fi
  if [ $DRY -eq 1 ]; then echo "  pret    $g : $torun runs"; TEMPLATE="$dir/slurm_array.sh"; continue; fi
  j=$(sbatch --parsable --exclude=node "$dir/slurm_array.sh"); JOBS="$JOBS:$j"; echo "  soumis  $g ($torun runs) : job $j"
done
echo "=== 4. le job de reevaluation (derive du script Slurm de la grille, trois lignes changees) ==="
TEMPLATE="${TEMPLATE:-$HOME/lora-grid/obqa_ref_top/slurm_array.sh}"
# in --dry the grids are generated in a scratch directory where no Slurm script is written: check the derivation on a real one
[ $DRY -eq 1 ] && [ ! -f "$TEMPLATE" ] && TEMPLATE=$(ls "$HOME"/lora-grid/*/slurm_array.sh 2>/dev/null | head -1)
[ -f "$TEMPLATE" ] || { echo "  STOP : modele de script introuvable ($TEMPLATE)"; exit 1; }
E="$HOME/lora-grid/obqa_suivi_eval"; [ $DRY -eq 1 ] && E="$(mktemp -d)/obqa_suivi_eval"; mkdir -p "$E/logs"
sed -e "s|^#SBATCH --array=.*|#SBATCH --array=0-0%1|" \
    -e "s|^#SBATCH --output=.*|#SBATCH --output=$E/logs/%A_%a.out|" \
    -e "s|^#SBATCH --partition=\(.*\)|#SBATCH --partition=\1\n#SBATCH --nodelist=$NODE|" \
    -e "s|^\"\$PY\" -m lorasub.train \"\$CFG\"$|\"\$PY\" \"$HOME/repo/scripts/eval_single_gpu.py\" --expect \"$PARTITION\"|" \
    "$TEMPLATE" > "$E/eval.sh"
for want in "--array=0-0%1" "--nodelist=$NODE" "eval_single_gpu.py"; do grep -q -- "$want" "$E/eval.sh" || { echo "  STOP : le job derive ne contient pas '$want'"; exit 1; }; done
grep -q "lorasub.train" "$E/eval.sh" && { echo "  STOP : le job derive lance encore un entrainement"; exit 1; }
echo "  ok : une tache, machine $NODE, commande d'evaluation (verifie)"
if [ $DRY -eq 1 ]; then echo "  pret    reevaluation : apres les reentrainements"; "$PY" scripts/eval_single_gpu.py --dry 2>&1 | head -4; exit 0; fi
DEP=""; [ -n "$JOBS" ] && DEP="--dependency=afterok$JOBS"
echo "  soumis  reevaluation : job $(sbatch --parsable $DEP "$E/eval.sh") ${DEP:+(apres $JOBS)}"
echo "=== file ==="; squeue -u "$USER" | head -6
