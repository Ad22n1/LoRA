#!/bin/bash
# lambda_max at step 274 for ALL FOUR constrained arms, with the strict run filter.
#
# WHY. The published table has bottom and top only; the audit asked three times for the two drawn
# arms. And the run lookup used for that table did not filter on module count, norm rescaling or the
# draw salt, so bottom and top are re-measured here too: if they reproduce 33.74 and 6.95, the table
# stood; if not, it read the factors of another experiment.
#
#SBATCH --job-name=curv274all
#SBATCH --partition=PARTITION
#SBATCH --cpus-per-task=4
#SBATCH --mem=32G
#SBATCH --array=0-3
#SBATCH --time=01:59:00
#SBATCH --exclude=node
#SBATCH --output=~/lora-results/curv274all-%A_%a.out

source /tmp/lora-$USER/venv/bin/activate
export SHARED=$HOME/lora-shared
cd $HOME/repo
FREE=$(nvidia-smi --query-PARTITION=memory.free --format=csv,noheader,nounits | head -1)
echo "node: $(hostname)  free: ${FREE} MiB"
if [ "$FREE" -lt 13000 ]; then echo "skip: only ${FREE} MiB free"; exit 1; fi
SPECS=("bottom 0.002" "top 0.01" "random 0.01" "random_ortho 0.01")
set -- ${SPECS[${SLURM_ARRAY_TASK_ID:-0}]}
python scripts/curvature.py \
  --model meta-llama/Llama-3.2-1B \
  --data_dir "$SHARED/data" --svd_cache "$SHARED/svd" \
  --task format --rank 2 --modes "$1" --seeds 2,3,4,5,6 \
  --from_step 274 --lr "$2" --max_grad_norm 1.0 \
  --runs_dir "$HOME/lora-runs" \
  --n_batches 3 --iters 60 --restarts 5 \
  --out "$HOME/lora-analysis/curv274strict_$1.csv"
