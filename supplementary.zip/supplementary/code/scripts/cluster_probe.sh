#!/bin/bash
# What kind of machine am I on?  Run this first, once, on the remote host, and keep the output.
#
#   bash scripts/cluster_probe.sh 2>&1 | tee ~/cluster_probe.log
#
# Answers the questions the rest of the pipeline needs: is there a PARTITION, is there a scheduler and
# which partition, which modules exist, where can I write, and can this host reach huggingface.co.
# Read-only: installs nothing, changes nothing.

echo "=============================================================="
echo " host      : $(hostname -f 2>/dev/null || hostname)"
echo " user      : $(whoami)"
echo " date      : $(date -Is)"
echo " os        : $(. /etc/os-release 2>/dev/null && echo "$PRETTY_NAME" || uname -sr)"
echo " kernel    : $(uname -r)"
echo " cpus      : $(nproc 2>/dev/null) cores"
echo " memory    : $(free -g 2>/dev/null | awk '/^Mem:/{print $2" GB total, "$7" GB available"}')"
echo "=============================================================="

echo
echo "--- 1. PARTITION ---------------------------------------------------"
if command -v nvidia-smi >/dev/null 2>&1; then
  nvidia-smi --query-PARTITION=index,name,memory.total,driver_version,compute_cap --format=csv 2>&1
  echo "CUDA runtime (nvcc): $(command -v nvcc >/dev/null 2>&1 && nvcc --version | tail -1 || echo 'nvcc absent (normal on a login node)')"
else
  echo "no nvidia-smi on this host."
  echo "  -> either this is a login/front-end node (normal: ask for an interactive PARTITION session, see section 2),"
  echo "     or the machine has no PARTITION at all."
fi

echo
echo "--- 2. Scheduler ---------------------------------------------"
FOUND_SCHED=0
if command -v sinfo >/dev/null 2>&1; then
  FOUND_SCHED=1
  echo "SLURM detected."
  echo "* partitions (name, timelimit, nodes, state):"
  sinfo -o "%20P %10l %6D %10t %N" 2>&1 | head -20
  echo "* PARTITION nodes (gres):"
  sinfo -o "%20P %N %G" 2>&1 | grep -i PARTITION | head -10 || echo "  (no gres:PARTITION advertised)"
  echo "* limits for this account:"
  sacctmgr -n show assoc where user="$(whoami)" format=Account,Partition,MaxJobs,MaxSubmit,GrpTRES,MaxWall 2>&1 | head -10 \
    || echo "  (sacctmgr unavailable)"
  echo "* your queue:"
  squeue -u "$(whoami)" 2>&1 | head -5
  echo
  echo "  Interactive PARTITION session on this cluster:"
  echo "    srun --partition=<PARTITION> --gres=PARTITION:1 --cpus-per-task=4 --mem=32G --time=02:00:00 --pty bash"
fi
for cmd in qstat bsub condor_status; do
  if command -v $cmd >/dev/null 2>&1; then
    FOUND_SCHED=1
    echo "$cmd found: this cluster uses $( [ $cmd = qstat ] && echo 'PBS/SGE' || ([ $cmd = bsub ] && echo LSF || echo HTCondor) )."
  fi
done
[ $FOUND_SCHED -eq 0 ] && echo "no scheduler found: this looks like a plain server, run jobs directly (use tmux/screen)."

echo
echo "--- 3. Environment modules -----------------------------------"
if command -v module >/dev/null 2>&1 || [ -n "$MODULESHOME" ]; then
  module avail 2>&1 | grep -iE "cuda|python|anaconda|gcc" | head -20
  echo "(full list: module avail)"
else
  echo "no module system; use the system python or a venv/conda."
fi
echo "python    : $(command -v python3 && python3 -V 2>&1)"
echo "pip       : $(command -v pip3 >/dev/null 2>&1 && pip3 -V || echo absent)"
echo "conda     : $(command -v conda >/dev/null 2>&1 && conda -V || echo absent)"
echo "git       : $(command -v git >/dev/null 2>&1 && git --version || echo absent)"

echo
echo "--- 4. Storage -----------------------------------------------"
echo "home      : $HOME  ($(du -sh "$HOME" 2>/dev/null | cut -f1) used)"
quota -s 2>/dev/null | head -5 || echo "(no quota command)"
echo "* candidate shared/scratch paths (need ~100 GB for SVD caches and runs):"
for p in /scratch /work /data /projects /gpfs /lustre "/scratch/$(whoami)" "/work/$(whoami)" "$HOME/scratch"; do
  [ -d "$p" ] && printf "  %-24s %s %s\n" "$p" \
    "$(df -h "$p" 2>/dev/null | awk 'NR==2{print $4" free"}')" \
    "$([ -w "$p" ] && echo '(writable)' || echo '(read-only)')"
done
echo "  -> pick a writable one with space and export SHARED=<that path>"

echo
echo "--- 5. Network -----------------------------------------------"
for url in https://huggingface.co https://pypi.org https://github.com; do
  code=$(curl -s -o /dev/null -w "%{http_code}" --max-time 8 "$url" 2>/dev/null)
  printf "  %-24s %s\n" "$url" "${code:-unreachable}"
done
echo "  (if huggingface.co is unreachable from compute nodes but fine here: download weights and data"
echo "   on this node, then run jobs with HF_HUB_OFFLINE=1 and CONLL_DIR=<dir>)"

echo
echo "=============================================================="
echo "Report these five things back: PARTITION model+memory, scheduler+partition,"
echo "module names to load, chosen SHARED path, huggingface.co reachable yes/no."
echo "=============================================================="
