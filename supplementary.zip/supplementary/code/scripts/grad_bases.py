"""Directions du gradient (protocole « B gele sur les directions du gradient », le placement sans oracle).

Pour chaque module cible : le gradient de la perte d'entrainement par rapport a W0, au modele de base, sans aucune mise a jour, moyenne
sur n sequences d'entrainement tirees avec une graine fixe ; la base est formee des r premiers vecteurs singuliers a gauche (cote sortie).
La perte est exactement celle de l'entrainement (lorasub.train) : la moyenne, sur chaque micro-lot, des tokens supervises, puis la moyenne
des micro-lots (le lot et la collation de l'entrainement).

    python scripts/grad_bases.py --config <config.yaml d'un run de reference> --out <bases.safetensors> [--n 64 --seed 1000 --rank 2]
"""
import argparse
import hashlib
import json
import os
import random
import sys
import time

import torch
import yaml
from safetensors.torch import save_file

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
from lorasub.config import RunConfig  # noqa: E402
from lorasub.data.loaders import build_dataset, collate  # noqa: E402
from lorasub.modeling import load_model, load_tokenizer  # noqa: E402
from lorasub.spectral import iter_target_modules  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--config", required=True); ap.add_argument("--out", required=True)
ap.add_argument("--n", default="64"); ap.add_argument("--seed", type=int, default=1000); ap.add_argument("--rank", type=int, default=2)
a = ap.parse_args()
t0 = time.time()
c = RunConfig(**(yaml.safe_load(open(a.config)) or {}))
dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"[grad] modele {c.model}, tache {c.task}, {c.data_dir} ; lot {c.batch_size} ; appareil {dev}"
      + (f" ({torch.cuda.get_device_name(0)})" if dev.type == "cuda" else ""), flush=True)
model = load_model(c.model, c.dtype, c.attn_implementation, device=dev)
tok = load_tokenizer(c.model)
ds = build_dataset(c.task, c.data_dir, tok, c.max_len, split="train", seed=c.seed)
N = len(ds); n = N if a.n == "all" else int(a.n)
if n < 64 or n > N:
    sys.exit(f"ARRET : {n} sequences demandees, pour {N} disponibles (minimum 64)")
# ensembles EMBOITES : d'abord les 64 sequences de `grad` (le meme tirage que le commit <commit>), puis les autres dans une permutation
# fixe (meme graine) ; avec n = 64, on retrouve exactement l'ensemble de `grad`
first = random.Random(a.seed).sample(range(N), 64); rest = [i for i in range(N) if i not in set(first)]; random.Random(a.seed).shuffle(rest)
idx = sorted((first + rest)[:n])
targets = list(iter_target_modules(model, c.target_modules))
for p in model.parameters():
    p.requires_grad_(False)
for _, lin in targets:
    lin.weight.requires_grad_(True)
model.eval()                                    # modele de base, sans abandon aleatoire
acc = {name: torch.zeros_like(lin.weight, dtype=torch.float32) for name, lin in targets}
n_micro = n_sup = 0
for i in range(0, len(idx), c.batch_size):
    batch = collate([ds[j] for j in idx[i:i + c.batch_size]], tok.pad_token_id)
    batch = {k: v.to(dev) for k, v in batch.items()}
    out = model(**batch)                          # out.loss : moyenne sur les tokens supervises de ce micro-lot, comme a l'entrainement
    n_sup += int((batch["labels"] != -100).sum())
    out.loss.backward(); n_micro += 1
    for name, lin in targets:
        acc[name] += lin.weight.grad.float(); lin.weight.grad = None
bases, conc = {}, []
for name, lin in targets:
    # decomposition en DOUBLE precision, sur le processeur : en simple precision sur PARTITION, les vecteurs singuliers ne sont orthonormaux
    # qu'a ~3e-4 pres (constate le 28/09, quatre jobs arretes par le controle ci-dessous) ; puis QR des r vecteurs retenus
    G = (acc[name] / n_micro).double().cpu()
    U, S, _ = torch.linalg.svd(G, full_matrices=False)
    if float(S[a.rank - 1]) <= 1e-8 * float(S[0]):
        sys.exit(f"ARRET : le gradient de {name} est de rang < {a.rank}")
    Q = torch.linalg.qr(U[:, :a.rank])[0]
    Q = (Q * torch.sign(torch.diagonal(Q.T @ U[:, :a.rank]))).float().contiguous()   # meme orientation que les vecteurs singuliers
    dev_orth = float((Q.T @ Q - torch.eye(a.rank)).abs().max())
    if dev_orth > 1e-5:
        sys.exit(f"ARRET : base de {name} non orthonormale ({dev_orth:.1e})")
    bases[name] = Q
    conc.append(float((S[:a.rank] ** 2).sum() / (S ** 2).sum()))
os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
save_file(bases, a.out)
raw = open(a.out, "rb").read(); md5 = hashlib.md5(raw).hexdigest(); sha256 = hashlib.sha256(raw).hexdigest()
rep = {"modele": c.model, "tache": c.task, "sequences": len(idx), "graine": a.seed, "indices": idx, "micro_lots": n_micro,
       "tokens_supervises": n_sup, "modules": len(bases), "rang": a.rank, "md5": md5, "sha256": sha256, "sequences_disponibles": N,
       "part_du_gradient_dans_les_2_premieres_directions": {"mediane": sorted(conc)[len(conc) // 2], "min": min(conc), "max": max(conc)},
       "duree_s": round(time.time() - t0, 1)}
json.dump(rep, open(a.out + ".json", "w"), indent=1)
print(f"[grad] {len(bases)} bases ; {len(idx)} sequences, {n_sup} tokens supervises, {n_micro} micro-lots ; part mediane du gradient dans "
      f"les {a.rank} premieres directions {rep['part_du_gradient_dans_les_2_premieres_directions']['mediane']:.3f} ; md5 {md5} ; {rep['duree_s']} s", flush=True)
print("[grad] TERMINE", flush=True)
