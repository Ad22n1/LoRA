"""The rate effect, as PROTOCOL_rate_r4_qwen.md fixed it before launch.

The swing of `bottom` = its lead over the best other arm at 2e-3 PLUS its deficit to the best other arm
at 1e-2, in points of format_parsed, mean over seeds 2-6. Same computation as Figure 2 at rank 2.
Same population as the tables. Refuses to report a cell that does not have its five seeds.

    python scripts/analyse_rate.py
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
from lorasub.aggregate import collect  # noqa: E402

d = collect(os.path.expanduser("~/lora-runs"))
B = d[(d.task == "format") & (d.n_modules == 7) & (d.max_grad_norm == 1.0) & d.update_norm_target.isna()
      & (d.format_n == 614) & d.seed.between(2, 6)]
B = B[~B["mode"].isin(["random", "random_ortho"]) | (B.subspace_salted == True)]


def cell(model, mode, rank, lr):
    x = B[(B.model.astype(str) == model) & (B["mode"] == mode) & (B["rank"] == rank) & ((B.lr - lr).abs() < 1e-12)]
    per = x.groupby("seed").format_parsed.mean()
    return (float(per.mean()), int(per.size))


def swing(label, model, rank, others):
    print(f"\n=== {label} ===")
    table, ok = {}, True
    for lr in (2e-3, 1e-2):
        for m in ["bottom"] + others:
            v, n = cell(model, m, rank, lr)
            table[(m, lr)] = v
            flag = "" if n == 5 else "   INCOMPLETE"
            ok &= n == 5
            print(f"  {m:13s} lr={lr:g}  {v:.4f}  (n={n}){flag}")
    if not ok:
        print("  -> not reported: a cell is incomplete. Wait for the jobs, or relaunch what is missing.")
        return
    lead = (table[("bottom", 2e-3)] - max(table[(m, 2e-3)] for m in others)) * 100
    last = (max(table[(m, 1e-2)] for m in others) - table[("bottom", 1e-2)]) * 100
    rank_lo = sorted(["bottom"] + others, key=lambda m: -table[(m, 2e-3)]).index("bottom") + 1
    rank_hi = sorted(["bottom"] + others, key=lambda m: -table[(m, 1e-2)]).index("bottom") + 1
    print(f"  bottom: rank {rank_lo}/{len(others) + 1} at 2e-3, rank {rank_hi}/{len(others) + 1} at 1e-2")
    print(f"  lead at 2e-3 {lead:+.1f} pt, deficit at 1e-2 {last:+.1f} pt  ->  SWING {lead + last:.1f} pt")
    print(f"  the ordering {'INVERTS' if rank_lo < rank_hi else 'does not invert'} between the two common rates")


swing("Llama-3.2-1B, rank 2 (Figure 2, for reference)", "meta-llama/Llama-3.2-1B", 2, ["top", "random_ortho"])
swing("Llama-3.2-1B, rank 4 (protocol)", "meta-llama/Llama-3.2-1B", 4, ["top", "random"])
swing("Qwen-2.5-0.5B, rank 2 (protocol)", "Qwen/Qwen2.5-0.5B", 2, ["top", "random_ortho"])
swing("Qwen-2.5-1.5B, rank 2 (scale protocol)", "Qwen/Qwen2.5-1.5B", 2, ["top", "random_ortho"])
print("\n  Protocol: at rank 4, if the swing is below the cost of freezing (8.4 to 10.1), the text says that")
print("  freezing comes before the rate at rank 4. Whatever the values, they are written as they are.")
