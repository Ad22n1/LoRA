"""Grids of PROTOCOL_square_modules.md, from configs/grids/sigma_residual_C2.yaml (checked), on q_proj and o_proj only (square on Llama).

    python scripts/make_sq_grids.py --stage1     # selection: 5 arms x 5 rates x seeds 130-131 = 50 runs (5 grids)
    python scripts/make_sq_grids.py --stage2     # report: seeds 140-144 at each arm's rate selected on seeds 130-131 = 25 runs (5 grids)
"""
import glob
import json
import os
import statistics as st
import sys
from pathlib import Path

import yaml

SRC = Path("configs/grids/sigma_residual_C2.yaml")
MODULES = ["q_proj", "o_proj"]
SEL, REP = [130, 131], [140, 141, 142, 143, 144]
ARMS = {"top": (2, [2e-3, 5e-3, 1e-2, 2e-2, 5e-2]), "bottom": (2, [2e-3, 5e-3, 1e-2, 2e-2, 5e-2]), "dual_top": (2, [2e-3, 5e-3, 1e-2, 2e-2, 5e-2]),
        "dual_bottom": (2, [2e-3, 5e-3, 1e-2, 2e-2, 5e-2]), "free": (1, [5e-4, 1e-3, 2e-3, 5e-3, 1e-2])}
H = "# PRE-ENREGISTRE (PROTOCOL_square_modules.md). Genere par scripts/make_sq_grids.py.\n"


def base():
    if not SRC.exists():
        sys.exit(f"STOP : {SRC} introuvable")
    b = dict((yaml.safe_load(open(SRC)) or {}).get("base") or {})
    tt = b.get("target_tokens"); tok = tt.get("format") if isinstance(tt, dict) else tt; mods = b.get("target_modules")
    checks = {"tache format": b.get("task") == "format", "Llama-3.2-1B": str(b.get("model")) == "meta-llama/Llama-3.2-1B", "600 000 tokens a l'origine": tok == 600000,
              "longueur 384": b.get("max_len") == 384, "lot 2": b.get("batch_size") == 2, "accumulation 16": b.get("grad_accum") == 16,
              "ecretage 1,0": b.get("max_grad_norm", 1.0) is not None and float(b.get("max_grad_norm", 1.0)) == 1.0, "sept modules": mods is None or len(mods) == 7}
    bad = [k for k, ok in checks.items() if not ok]
    if bad:
        sys.exit(f"STOP : la base differe de la campagne d'origine sur : {', '.join(bad)}")
    for k in ("mode", "rank", "lr", "seed", "band_frac", "update_norm_target"):
        b.pop(k, None)
    b["target_modules"] = list(MODULES)
    b["save_factor_steps"] = []
    return b


def write(name, rank, grid, note):
    b = base(); b["rank"] = rank
    Path(f"configs/grids/{name}.yaml").write_text(H + f"# {note}\n" + yaml.safe_dump({"base": b, "grid": grid}, sort_keys=False))


if "--stage1" in sys.argv:
    for mode, (rank, lrs) in ARMS.items():
        write(f"sq_s1_{mode}", rank, {"mode": [mode], "lr": lrs, "seed": SEL}, f"SELECTION, {mode}. 10 runs.")
        print(f"  sq_s1_{mode:12s} : rang {rank}, taux {lrs[0]:g} a {lrs[-1]:g}, graines 130-131, q_proj et o_proj")
    print("  total : 50 runs")
elif "--stage2" in sys.argv:
    vals = {}
    for p in glob.glob(os.path.expanduser("~/lora-runs/*/config.yaml")):
        c = yaml.safe_load(open(p)) or {}; d = os.path.dirname(p)
        tt = c.get("target_tokens"); tok = tt.get("format") if isinstance(tt, dict) else tt
        if c.get("task") != "format" or str(c.get("model")) != "meta-llama/Llama-3.2-1B" or tok != 600000 or list(c.get("target_modules") or []) != MODULES or c.get("seed") not in SEL:
            continue
        try:
            if open(d + "/status").read().startswith("DONE"):
                vals.setdefault((c.get("mode"), c.get("rank"), float(c.get("lr"))), []).append(json.load(open(d + "/metrics.json"))["val_format_parsed"])
        except (OSError, KeyError):
            pass
    total = 0
    for mode, (rank, lrs) in ARMS.items():
        means = {}
        for lr in lrs:
            v = vals.get((mode, rank, lr), [])
            if len(v) != 2:
                sys.exit(f"STOP : {mode} a {lr:g} : {len(v)} run(s) de selection au node de 2 ; rien n'est genere")
            means[lr] = st.mean(v)
        best = max(lrs, key=lambda lr: means[lr])
        write(f"sq_s2_{mode}", rank, {"mode": [mode], "lr": [best], "seed": REP}, f"RAPPORT, {mode} au taux retenu. 5 runs.")
        total += 5
        print(f"  sq_s2_{mode:12s} : " + "  ".join(f"{lr:g}:{means[lr]:.3f}" for lr in lrs) + f"  -> {best:g}" + ("  AU BORD" if best in (lrs[0], lrs[-1]) else ""))
    print(f"  total : {total} runs")
else:
    sys.exit("usage : --stage1 | --stage2")
