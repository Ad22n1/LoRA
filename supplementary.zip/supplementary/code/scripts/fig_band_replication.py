"""The position sweep, with its replication and its limit.

  left   rank 2: the first seven seeds (2-8) and the eight new seeds of the pre-registered extension
         (9-16), drawn side by side at each position, seeds as dots. Same rates, fixed before launch.
  right  rank 4: seeds 2-8, rates selected on seeds 0-1 (lr_selected_r4.yaml). No test was fixed.

Points only, joined by a dotted line: five discrete positions, not a curve. Every value is computed
from the runs and printed. Same population as the tables (Llama-3.2-1B, format, seven modules,
clipping at 1.0, no rescaling, 614 items, replicates averaged within a seed).

    python scripts/fig_band_replication.py paper/figures/band_replication.png
"""
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import yaml

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
from lorasub.aggregate import collect  # noqa: E402
# No conclusions inside the images (24/09): every title is dropped, only panel letters such as "(a)"
# are kept where a caption refers to them. What a figure shows is said in its caption, where it can
# be qualified -- a claim written in the image cannot.
import re as _re
import matplotlib.axes as _max
import matplotlib.figure as _mfig
_set_title = _max.Axes.set_title
def _letter_only(self, label="", *a, **k):
    m = _re.match(r"\s*\(([a-z])\)", str(label))
    return _set_title(self, f"({m.group(1)})" if m else "", loc="left", fontsize=10)
_max.Axes.set_title = _letter_only
_mfig.Figure.suptitle = lambda self, *a, **k: None

MODEL = "meta-llama/Llama-3.2-1B"
POS = [0.0, 0.25, 0.5, 0.75, 1.0]
d = collect(os.path.expanduser("~/lora-runs"))
base = d[(d.task == "format") & (d.model.astype(str) == MODEL) & (d.n_modules == 7) & (d.max_grad_norm == 1.0)
         & d.update_norm_target.isna() & (d.format_n == 614) & (d["mode"] == "band")]


def per_seed(rank, tab, seeds):
    out = {}
    for bf in POS:
        lr = tab.get(f"{MODEL}|format|band|{rank}|b{bf:g}")
        x = base[(base["rank"] == rank) & ((base.band_frac - bf).abs() < 1e-9) & ((base.lr - (lr or -1)).abs() < 1e-12)
                 & base.seed.isin(seeds)]
        out[bf] = x.groupby("seed").format_parsed.mean()
    return out


T2 = (yaml.safe_load(open("configs/lr_selected.yaml")) or {})["selected"]
T4 = (yaml.safe_load(open("configs/lr_selected_r4.yaml")) or {})["selected"]
groups = [("rank 2, seeds 2-8", per_seed(2, T2, range(2, 9)), "#4c72b0", -0.09),
          ("rank 2, new seeds 9-16 (pre-registered)", per_seed(2, T2, range(9, 17)), "#dd8452", +0.09)]
r4 = per_seed(4, T4, range(2, 9))

fig, (a, b) = plt.subplots(1, 2, figsize=(9.6, 3.9), sharey=True, gridspec_kw={"width_ratios": [1.35, 1]})
for lab, g, col, dx in groups:
    xs = [i + dx for i in range(len(POS))]
    for i, bf in enumerate(POS):
        a.plot([xs[i]] * len(g[bf]), g[bf].values, "o", ms=3, color=col, alpha=0.35)
    a.plot(xs, [g[bf].mean() for bf in POS], ":o", color=col, ms=8, lw=1.3, label=lab)
    print(f"  {lab}: " + "  ".join(f"{bf:g}:{g[bf].mean():.4f}(n={g[bf].size})" for bf in POS))
for i, bf in enumerate(POS):
    # a small deterministic spread, as on the left: without it seeds with equal scores overlap and a
    # full seven-seed cell looks incomplete
    n = len(r4[bf]); jit = [(k - (n - 1) / 2) * 0.035 for k in range(n)]
    b.plot([i + j for j in jit], r4[bf].sort_values().values, "o", ms=3, color="0.45", alpha=0.45)
b.plot(range(len(POS)), [r4[bf].mean() for bf in POS], ":o", color="0.25", ms=8, lw=1.3)
print("  rank 4, seeds 2-8: " + "  ".join(f"{bf:g}:{r4[bf].mean():.4f}(n={r4[bf].size})" for bf in POS))
# panel titles name what each panel holds; they are labels, not conclusions, so they bypass the no-title rule (01/10)
for ax, t in ((a, "rank 2"), (b, "rank 4, seeds 2 to 8")):
    ax.set_xticks(range(len(POS)), [f"β={bf:g}" for bf in POS])
    _set_title(ax, t, fontsize=10)
    ax.grid(axis="y", color="0.93", lw=0.7)
    ax.set_axisbelow(True)
    for sp in ("top", "right"):
        ax.spines[sp].set_visible(False)
a.set_ylabel("valid-format accuracy")
a.set_xlabel("position of the band (β = 0 is the top)", fontsize=9)
b.set_xlabel("position of the band", fontsize=9)
a.legend(frameon=False, fontsize=8, loc="lower left")
fig.tight_layout()
dst = sys.argv[1] if len(sys.argv) > 1 else "paper/figures/band_replication.png"
os.makedirs(os.path.dirname(dst) or ".", exist_ok=True)
fig.savefig(dst, dpi=200)
print(f"  written -> {dst}")
