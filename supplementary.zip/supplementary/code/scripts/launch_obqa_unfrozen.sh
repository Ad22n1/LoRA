#!/bin/bash
# Lance la replication de l'experience 1 sur OpenBookQA au rang 2 (PROTOCOL_obqa_unfrozen.md) : 4 grilles, 196 runs.
#   bash scripts/launch_obqa_unfrozen.sh --dry     (verifie et compte, ne soumet rien)
#   bash scripts/launch_obqa_unfrozen.sh           (soumet)
# Garde-fous : protocole, grilles et lecture committes AVANT tout run ; une grille dont des jobs tournent n'est jamais touchee.
set -u
DRY=0; [ "${1:-}" = "--dry" ] && DRY=1
cd "$HOME/repo" || { echo "STOP : ~/repo introuvable"; exit 1; }
PY="/tmp/lora-$USER/venv/bin/python"; [ -x "$PY" ] || { echo "STOP : environnement /tmp/lora-$USER/venv absent"; exit 1; }
GRIDS="obqa_tu_r1 obqa_bu_r1 obqa_tu_r2 obqa_bu_r2"
FILES="PROTOCOL_obqa_unfrozen.md scripts/read_obqa_unfrozen.py configs/grids/obqa_tu_r1.yaml configs/grids/obqa_bu_r1.yaml configs/grids/obqa_tu_r2.yaml configs/grids/obqa_bu_r2.yaml"
echo "=== 1. tout est committe et a jour ==="
bad=0
for f in $FILES; do
  git ls-files --error-unmatch "$f" >/dev/null 2>&1 && git diff --quiet HEAD -- "$f" || { echo "  NON COMMITTE OU MODIFIE : $f"; bad=1; }
done
[ $bad -eq 0 ] && echo "  ok" || { echo "  REFUS : committer d'abord ; rien n'est lance"; exit 1; }
echo "=== 2. place disque (les facteurs sont sauvegardes, ~3 Go au total) ==="
du -sh "$HOME" 2>/dev/null | sed 's/^/  dossier personnel : /'
echo "=== 3. lancement ==="
for g in $GRIDS; do
  if squeue -h -u "$USER" -o "%o" 2>/dev/null | grep -q "/lora-grid/$g/slurm_array.sh"; then echo "  EN COURS $g : rien n'est touche"; continue; fi
  dir="$HOME/lora-grid/$g"; [ $DRY -eq 1 ] && dir="$(mktemp -d)/$g"
  out=$("$PY" -m lorasub.launch_grid "configs/grids/$g.yaml" --grid_dir "$dir" --partition PARTITION --time 01:59:00 --max_par 8 --venv "/tmp/lora-$USER/venv" 2>&1)
  n=$(echo "$out" | grep -oE "[0-9]+ already done; [0-9]+ to run")
  [ -n "$n" ] || { echo "  ERREUR $g :"; echo "$out" | tail -3 | sed 's/^/    /'; continue; }
  done_=$(echo "$n" | grep -oE "^[0-9]+"); torun=$(echo "$n" | grep -oE "[0-9]+ to run" | grep -oE "[0-9]+")
  if [ "$torun" -eq 0 ]; then echo "  RIEN    $g : complet ($done_)"; continue; fi
  if [ "$done_" -gt 0 ]; then echo "  SAUTE   $g : $done_ runs existent deja (collision, a verifier)"; continue; fi
  if [ $DRY -eq 1 ]; then echo "  pret    $g : $torun runs"; continue; fi
  echo "  soumis  $g ($torun runs) : job $(sbatch --parsable --exclude=node "$HOME/lora-grid/$g/slurm_array.sh")"
done
echo "=== file ==="; squeue -u "$USER" | head -6
