"""Which rate does `bottom` deserve, and does the paper's thesis depend on the answer?

The paper reports `bottom` at 2e-3. Its own selection rule — the mean over seeds 0 and 1 on the
400-item validation set — prefers 5e-3 by 0.00125. The override exists because one seed of five
collapses to zero at 5e-3, and the `noclip` section shows that collapse is produced by the clipping
threshold rather than by the band.

So the tie-break is a judgement call, and this file measures what rides on it instead of arguing.
Every check below is a fact the answer must be consistent with; the last one is the question that
matters — whether the paper's conclusion is the same either way.
"""
import os
import sys

import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from lorasub.aggregate import collect  # noqa: E402

RUNS = os.path.expanduser("~/lora-runs")
FAILED = []


def check(name, ok, detail=""):
    print(f"  [{'ok ' if ok else 'FAIL'}] {name}" + (f"\n         {detail}" if detail else ""))
    if not ok:
        FAILED.append(name)


def bottom(d, **kw):
    L = d.model.astype(str).str.contains("Llama")
    x = d[(d["mode"] == "bottom") & (d.task == "format") & L & (d["rank"] == 2)
          & (d.n_modules == 7) & d.update_norm_target.isna()]
    for k, v in kw.items():
        x = x[x[k] == v]
    return x


def main():
    d = collect(RUNS)

    print("\n=== A. what the selection rule actually says ===")
    sel = bottom(d, val_format_n=400, max_grad_norm=1.0)
    sel = sel[sel.seed.isin([0, 1]) & sel.lr.isin([2e-3, 5e-3])]
    g = sel.groupby("lr").val_format_parsed.mean()
    print(g.round(5).to_string())
    if {2e-3, 5e-3} <= set(g.index):
        picked = g.idxmax()
        print(f"\n         the rule picks {picked:g}, by {abs(g[5e-3] - g[2e-3]):.5f}")
        check("the rule's answer is 5e-3, i.e. the paper overrides it",
              abs(picked - 5e-3) < 1e-12,
              "if this fails, there is no tie-break problem and nothing to decide")
    check("the rule rests on two seeds only", sel.seed.nunique() == 2,
          f"seeds {sorted(sel.seed.unique())}")

    print("\n=== B. is the collapse at 5e-3 caused by clipping? ===")
    clip = bottom(d, max_grad_norm=1.0, format_n=614)
    clip = clip[clip.seed.between(2, 6) & (abs(clip.lr - 5e-3) < 1e-12)]
    ncl = bottom(d, format_n=614)
    ncl = ncl[(ncl.max_grad_norm > 100) & ncl.seed.between(2, 6)
              & (abs(ncl.lr - 5e-3) < 1e-12)]
    nz_clip = int((clip.format_parsed <= 0.05).sum())
    nz_ncl = int((ncl.format_parsed <= 0.05).sum())
    print(f"         with clipping    : {nz_clip} collapse(s) out of {len(clip)}")
    print(f"         without clipping : {nz_ncl} collapse(s) out of {len(ncl)}")
    check("collapses with clipping, none without",
          nz_clip >= 1 and nz_ncl == 0 and len(ncl) >= 4,
          "this is what makes the override arguable rather than obviously right")

    print("\n=== C. the test scores, both ways, replicates averaged ===")
    t = bottom(d, max_grad_norm=1.0, format_n=614)
    t = t[t.seed.between(2, 6) & t.lr.isin([2e-3, 5e-3])]
    cell = t.groupby(["lr", "seed"]).format_parsed.mean().unstack()
    print(cell.round(4).to_string())
    m_all = cell.mean(axis=1)
    alive = cell.loc[5e-3] > 0.05
    print(f"\n         2e-3, five seeds        : {m_all[2e-3]:.4f}")
    print(f"         5e-3, five seeds        : {m_all[5e-3]:.4f}")
    print(f"         5e-3, dropping collapse : {cell.loc[5e-3][alive].mean():.4f}")
    print(f"         2e-3, same four seeds   : {cell.loc[2e-3][alive].mean():.4f}")

    print("\n=== D. does the paper's conclusion depend on the answer? ===")
    BEST, FREE_R1 = 0.6534, 0.7919          # random_ortho at r=2; free at r=1, budget-matched
    rows = []
    for lab, b in (("bottom at 2e-3", float(m_all[2e-3])),
                   ("bottom at 5e-3 (collapse dropped)", float(cell.loc[5e-3][alive].mean()))):
        choose, freeze = (BEST - b) * 100, (FREE_R1 - BEST) * 100
        rows.append((lab, b, choose, freeze, freeze / choose))
        print(f"         {lab:34s} choosing {choose:5.2f} pt | freezing {freeze:5.2f} pt"
              f" | ratio {freeze / choose:.1f}x")
    check("freezing costs more than choosing under BOTH tie-breaks",
          all(r[4] > 1.0 for r in rows),
          "the paper's central claim must not depend on a tie inside the noise")
    check("the ratio is at least 1.5 either way", all(r[4] >= 1.5 for r in rows))

    print("\n=== E. what does change ===")
    for lab, b in (("2e-3", float(m_all[2e-3])),
                   ("5e-3", float(cell.loc[5e-3][alive].mean()))):
        print(f"         bottom={lab}: top-bottom deficit = {(0.6443 - b) * 100:5.2f} pt, "
              f"rate displacement = {1e-2 / (2e-3 if lab == '2e-3' else 5e-3):.0f}")
    print("         the interior-maximum result is untouched: different arm, different sweep.")

    print("\n" + "=" * 70)
    if FAILED:
        print(f"  {len(FAILED)} CHECK(S) FAILED:")
        for f in FAILED:
            print(f"    - {f}")
    else:
        print("  every check passed: the tie-break is real, and the thesis survives it either way.")


if __name__ == "__main__":
    main()
