"""Night 3 readings, each by its committed protocol. Every cell prints its seed count.

    python scripts/read_night3.py 2>&1 | grep -vE "FutureWarning|pd.concat"

1. D, OpenBookQA at rank 2 (PROTOCOL_obqa_rank2.md + its addendum): floor; the inversion on BOTH pairs of common rates
   (A: 2e-3 / 5e-3, B: 2e-3 / 2e-2), halves at t > 3.495 and interaction at t > 4.851 (Bonferroni over the two pairs);
   established if it is on at least one pair; freezing against choosing at the selected rates.
2. ARC-Easy, second stage (PROTOCOL_rank16_arc.md + addendum): floor; common rates 1e-4 (top) and 5e-4 (bottom), halves at
   t > 2.776 against the best competitor recomputed per seed and each fixed competitor; freezing against choosing.
   NO interaction test: the ARC protocol does not pre-register one.

Precision written 25/09, 20 h, BEFORE any of these results was read (the commit of this script dates it): the ARC protocol says
"each half" without saying at which rate bottom must lead. The inversion means that each arm leads at its own rate, so bottom's
LEAD is tested at bottom's own selected rate and its DEFICIT at the other arm's rate -- exactly the definition used at rank 2 and
on OpenBookQA, where bottom's rate happened to be the lower one. On ARC-Easy bottom's rate (5e-4) is the higher one: its lead is
tested at 5e-4, its deficit at 1e-4. The same definition applies to D, where bottom's rate (2e-3) is the lower one.
3. C2 (PROTOCOL_sigma_residual_C2.md): top_sigma minus top_scalar on 40 fresh seeds, analysed ALONE (never pooled with C).
"""
import glob
import json
import os
import random
import statistics as st
import sys

import yaml

sys.path.insert(0, "src")

R = os.path.expanduser("~/lora-runs")
RUNS = []
for p in glob.glob(R + "/*/config.yaml"):
    c = yaml.safe_load(open(p)) or {}
    d = os.path.dirname(p)
    try:
        if not open(d + "/status").read().startswith("DONE"):
            continue
        m = json.load(open(d + "/metrics.json"))
    except OSError:
        continue
    RUNS.append((c, m))


def cell(fp, mode, rank, lr, seeds, key="mcq_acc"):
    out = {}
    for c, m in RUNS:
        if (c.get("task") == "commonsense" and str(c.get("data_fingerprint")) == fp and c.get("mode") == mode
                and c.get("rank") == rank and abs(float(c.get("lr") or 0) - lr) < 1e-12 and c.get("seed") in seeds and key in m):
            out[c["seed"]] = m[key]
    return out


def base(fp, fallback):
    v = [m["mcq_acc"] for c, m in RUNS if c.get("mode") == "baseline" and str(c.get("data_fingerprint")) == fp and "mcq_acc" in m]
    return (v[0], "mesure") if v else (fallback, "valeur du papier, aucun run de base avec cette empreinte")


def paired(a, b):
    k = sorted(set(a) & set(b)); dd = [(a[s] - b[s]) * 100 for s in k]
    if len(dd) < 2: return float("nan"), float("nan"), 0, len(dd)
    sd = st.stdev(dd); t = st.mean(dd) / (sd / len(dd) ** 0.5) if sd > 0 else float("inf")
    return st.mean(dd), t, sum(v > 0 for v in dd), len(dd)


def line(lab, a, b, thr):
    m, t, pos, n = paired(a, b)
    print(f"      {lab:46s} {m:+6.2f} pt  t = {t:+6.2f}  {pos}/{n}  {'ETABLI' if abs(t) > thr and t > 0 else 'non etabli'}")
    return t > thr


def show(lab, v):
    print(f"    {lab:30s} " + (f"{st.mean(v.values()):.4f}  ({len(v)} graines)" if v else "AUCUN RUN"))


def fc(own, fr, seeds):
    if len(seeds) < 2: print("    gel contre choix : graines insuffisantes"); return
    def f(ix):
        m = {k: st.mean(v[s] for s in ix) for k, v in own.items()}; ff = st.mean(fr[s] for s in ix)
        return (ff - max(m.values())) * 100, (max(m.values()) - min(m.values())) * 100
    g, c = f(seeds); rng = random.Random(0)
    B = [f([seeds[rng.randrange(len(seeds))] for _ in seeds]) for _ in range(20000)]
    q = lambda xs: (sorted(xs)[500], sorted(xs)[19499])  # noqa: E731
    lo, hi = q([b[0] - b[1] for b in B])
    print(f"    geler {g:.2f} pt  choisir {c:.2f} pt  ->  geler - choisir {g - c:+.2f}  IC95 [{lo:+.2f}, {hi:+.2f}]"
          f"  {'(exclut zero)' if lo > 0 or hi < 0 else '(contient zero)'}")


def inversion(fp, own, other, arms, rank, S, thr_half, thr_inter, label):
    lo, hi = own, other   # lo = bottom's OWN selected rate (where it should lead), hi = the other common rate
    A = {(m, lr): cell(fp, m, rank, lr, S) for m in ("bottom",) + arms for lr in (lo, hi)}
    print(f"  --- {label} : taux de bottom {lo:g} (ou il devrait mener), autre taux commun {hi:g}")
    for (m, lr), v in sorted(A.items(), key=str): show(f"{m} a {lr:g}", v)
    seeds = sorted(set.intersection(*[set(v) for v in A.values()]))
    if len(seeds) < 2: print("    graines communes insuffisantes"); return False
    bl, bh = A[("bottom", lo)], A[("bottom", hi)]
    best_lo = {s: max(A[(m, lo)][s] for m in arms) for s in seeds}; best_hi = {s: max(A[(m, hi)][s] for m in arms) for s in seeds}
    print(f"    avance de bottom a son propre taux (seuil {thr_half}) :")
    ok_lo = [line("contre le meilleur concurrent, recalcule", bl, best_lo, thr_half)] + [line(f"contre {m} (fixe)", bl, A[(m, lo)], thr_half) for m in arms]
    print(f"    retard de bottom a l'autre taux (seuil {thr_half}) :")
    ok_hi = [line("le meilleur concurrent moins bottom", best_hi, bh, thr_half)] + [line(f"{m} (fixe) moins bottom", A[(m, hi)], bh, thr_half) for m in arms]
    ok_int = []
    if thr_inter is None:
        print("    (pas de test d'interaction : ce protocole n'en pre-enregistre pas)")
        print(f"    bilan : avance etablie contre {sum(ok_lo)} contraste(s) sur {len(ok_lo)}, retard contre {sum(ok_hi)} sur {len(ok_hi)}")
        return all(ok_lo) and all(ok_hi)
    print(f"    interaction bras x taux, bilaterale (seuil {thr_inter}) :")
    for m in arms:
        inter = {s: (bl[s] - A[(m, lo)][s]) - (bh[s] - A[(m, hi)][s]) for s in seeds}
        mm, t, pos, n = paired(inter, {s: 0.0 for s in seeds})
        est = abs(t) > thr_inter
        print(f"      contre {m:40s} {mm:+6.2f} pt  t = {t:+6.2f}  {pos}/{n}  {'ETABLIE' if est else 'non etablie'}")
        ok_int.append(est)
    print(f"    bilan : avance etablie contre {sum(ok_lo)} contraste(s) sur {len(ok_lo)}, retard contre {sum(ok_hi)} sur {len(ok_hi)}, "
          f"interaction contre {sum(ok_int)} concurrent(s) sur {len(ok_int)}")
    inv = all(ok_lo) and all(ok_hi)
    print(f"    INVERSION (avance a son taux ET retard a l'autre, chacune contre tous les contrastes) : {'ETABLIE' if inv else 'NON etablie'}")
    if any(ok_int) and not all(ok_lo):
        print("    (une interaction etablie SANS avance de bottom a son propre taux decrit un ecart qui grandit avec le taux, pas une bascule)")
    return inv


# ------------------------------------------------------------------ 1. D
FP = "dc05f4d847f9"; S = [2, 3, 4, 5, 6]
print("==================== 1. D : OpenBookQA au rang 2, graines rapportees 2-6 ====================")
b0, src = base(FP, 0.422)
fr = cell(FP, "free", 1, 2e-3, S); show("free r=1 a 2e-3", fr)
if fr:
    gap = (st.mean(fr.values()) - b0) * 100
    print(f"  plancher : free contre le modele de base ({b0:.4f}, {src}) : {gap:+.1f} points (seuil +5) -> {'PASSE' if gap >= 5 else 'ECHOUE : NON INFORMATIF'}")
arms = ("top", "random", "random_ortho")
a = inversion(FP, 2e-3, 5e-3, arms, 2, S, 3.495, 4.851, "paire A")
b = inversion(FP, 2e-3, 2e-2, arms, 2, S, 3.495, 4.851, "paire B")
print(f"  -> inversion etablie sur au moins une paire (additif) : {'OUI' if a or b else 'NON'}  (paire A : {a}, paire B : {b})")
own = {"top": cell(FP, "top", 2, 5e-3, S), "bottom": cell(FP, "bottom", 2, 2e-3, S), "random": cell(FP, "random", 2, 5e-3, S),
       "random_ortho": cell(FP, "random_ortho", 2, 2e-2, S)}
print("  aux taux retenus :"); [show(f"{k}", v) for k, v in own.items()]
fc(own, fr, sorted(set(fr).intersection(*[set(v) for v in own.values()])) if fr and all(own.values()) else [])

# ------------------------------------------------------------------ 2. ARC-Easy
FP = "15890c7671bb"
print("\n==================== 2. ARC-Easy, rang 16, seconde etape, graines 2-6 ====================")
b0, src = base(FP, 0.711)
fr = cell(FP, "free", 7, 1e-4, S); show("free r=7 a 1e-4", fr)
if fr:
    gap = (st.mean(fr.values()) - b0) * 100
    print(f"  plancher : free contre le modele de base ({b0:.4f}, {src}) : {gap:+.1f} points (seuil +5) -> {'PASSE' if gap >= 5 else 'ECHOUE : NON INFORMATIF'}")
print("  (le taux de bottom, 5e-4, est ici le plus HAUT : son avance se teste a 5e-4, son retard a 1e-4 -- voir l'en-tete)")
inversion(FP, 5e-4, 1e-4, ("top", "random_ortho"), 16, S, 2.776, None, "taux communs")
own = {"top": cell(FP, "top", 16, 1e-4, S), "bottom": cell(FP, "bottom", 16, 5e-4, S), "random_ortho": cell(FP, "random_ortho", 16, 5e-4, S)}
print("  aux taux retenus :"); [show(f"{k}", v) for k, v in own.items()]
fc(own, fr, sorted(set(fr).intersection(*[set(v) for v in own.values()])) if fr and all(own.values()) else [])

# ------------------------------------------------------------------ 3. C2
print("\n==================== 3. C2 : top_sigma contre top_scalar, 40 graines fraiches (65-104), analyse SEULE ====================")
from lorasub.aggregate import collect  # noqa: E402
dd = collect(R)
x = dd[(dd.task == "format") & (dd["rank"] == 2) & ((dd.lr - 5e-3).abs() < 1e-12) & dd.seed.isin(range(65, 105)) & (dd.n_modules == 7)]
sg = x[x["mode"] == "top_sigma"].groupby("seed").format_parsed.mean().to_dict()
sc = x[x["mode"] == "top_scalar"].groupby("seed").format_parsed.mean().to_dict()
m, t, pos, n = paired(sg, sc)
if n > 1:
    k = sorted(set(sg) & set(sc)); d_ = [(sg[s] - sc[s]) * 100 for s in k]; se = st.stdev(d_) / n ** 0.5
    from math import isfinite
    if n != 40:
        print(f"  C2 INCOMPLET : {n} paires sur 40 (d provisoire {m:+.2f} pt) -- pas de verdict tant que les 40 ne sont pas la")
        raise SystemExit(0)
    lo90, hi90 = m - 1.685 * se, m + 1.685 * se
    print(f"  top_sigma {st.mean(sg.values()):.4f} ({len(sg)})   top_scalar {st.mean(sc.values()):.4f} ({len(sc)})   paires : {n}")
    thr = 2.023 if n == 40 else None
    print(f"  d = {m:+.2f} pt, t = {t:+.2f} ({n - 1} d.l.), {pos}/{n} ; IC90 [{lo90:+.2f}, {hi90:+.2f}]" + ("" if n == 40 else "  ATTENTION : pas 40 paires, les seuils du protocole supposent 40"))
    if n == 40 and isfinite(t):
        print("  -> " + ("ETABLI (le reste existe)" if (t > 2.023 and m > 0) else ("EQUIVALENCE (dans +/- 1 point)" if -1 <= lo90 and hi90 <= 1 else "NON TRANCHE")))
else:
    print(f"  pas assez de paires : {n}")
