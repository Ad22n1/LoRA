#!/usr/bin/env python3
"""Pre-submission check for the LaTeX source. Run this before every arXiv upload.

WHY. arXiv distributes the .tex source alongside the PDF, comments included. Anyone can download it
— including the authors of the papers we discuss. This file currently carries 35 comment lines, and
among them a numbered list of our own corrections ("C3 — les chiffres de ROSA portent une coquille
dans leur source", "RÉFUTÉ par notre propre mesure"). None of that is meant to be read by a third
party, and some of it names other people's errors in a register we would not use in print.

WHAT IT DOES.
  --check   (default) reports what would leak, and exits non-zero if anything would.
  --clean   writes a stripped copy next to the original, leaving the original untouched.

It also catches the two things that print *into* the PDF and must never reach a referee: \verif{...}
markers, and any \bascule or similar drafting macro.

This is a lint, not a substitute for reading the output. It cannot tell whether a sentence overstates
what the data support — that is what a human reader is for, and what the 16/09 review did.
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

# Macros that render visibly in the PDF and are drafting aids, not content.
DRAFT_MACROS = ("verif", "bascule", "todo", "TODO", "fixme", "note")

# Comment lines that are purely structural separators are harmless; everything else leaks.
SEPARATOR = re.compile(r"^%\s*[=\-*_]*\s*$")


def scan(text: str) -> dict:
    lines = text.splitlines()
    comments = [(i + 1, l) for i, l in enumerate(lines)
                if l.lstrip().startswith("%") and not SEPARATOR.match(l.strip())]
    macros = {}
    for m in DRAFT_MACROS:
        n = len(re.findall(r"\\" + m + r"\{", text))
        if n:
            macros[m] = n
    # \verif{} with an empty body is the worst case: it prints nothing and hides a gap
    empty = len(re.findall(r"\\verif\{\s*\}", text))
    return {"comments": comments, "macros": macros, "empty_verif": empty}


def clean(text: str) -> str:
    """Strip comment lines, keeping the ones that are pure separators for readability."""
    out = []
    for line in text.splitlines(keepends=True):
        stripped = line.lstrip()
        if stripped.startswith("%") and not SEPARATOR.match(stripped.strip()):
            continue
        # a trailing comment on a content line: keep the content, drop the comment.
        # An escaped \% is not a comment.
        i, esc = None, False
        for k, ch in enumerate(line):
            if ch == "\\":
                esc = not esc
            elif ch == "%" and not esc:
                i = k
                break
            else:
                esc = False
        out.append(line if i is None else line[:i].rstrip() + "\n")
    return "".join(out)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("tex", nargs="?", default="paper/paper.tex")
    ap.add_argument("--clean", action="store_true",
                    help="write a stripped copy as <name>.submit.tex")
    a = ap.parse_args()

    p = Path(a.tex)
    if not p.exists():
        raise SystemExit(f"{p} not found")
    text = p.read_text()
    r = scan(text)

    print(f"=== {p} ===")
    print(f"  comment lines that would be published : {len(r['comments'])}")
    for ln, l in r["comments"][:6]:
        print(f"    l.{ln}: {l.strip()[:88]}")
    if len(r["comments"]) > 6:
        print(f"    ... and {len(r['comments']) - 6} more")

    print(f"\n  drafting macros that PRINT in the PDF:")
    if r["macros"]:
        for m, n in sorted(r["macros"].items()):
            print(f"    \\{m}{{}} : {n}")
    else:
        print("    none")
    if r["empty_verif"]:
        print(f"    ⚠ {r['empty_verif']} of them are EMPTY — they print nothing and hide a gap")

    if a.clean:
        out = p.with_suffix(".submit.tex")
        out.write_text(clean(text))
        left = scan(out.read_text())
        print(f"\nwrote {out}")
        print(f"  comments left : {len(left['comments'])}")
        print(f"  ⚠ drafting macros are NOT removed: each one is a decision, not a formatting "
              f"issue. Resolve the {sum(r['macros'].values())} of them by hand.")
        return

    bad = len(r["comments"]) + sum(r["macros"].values())
    if bad:
        print(f"\nNOT ready for submission: {len(r['comments'])} comment lines would be published "
              f"and {sum(r['macros'].values())} drafting macros would print.")
        sys.exit(1)
    print("\nready for submission.")


if __name__ == "__main__":
    main()
