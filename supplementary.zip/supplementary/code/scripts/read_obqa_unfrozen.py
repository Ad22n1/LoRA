"""OpenBookQA at rank 2, Qwen2.5-1.5B: the cost of freezing B, isolated (PROTOCOL_obqa_unfrozen.md). No PARTITION.

    python scripts/read_obqa_unfrozen.py 2>&1 | grep -vE "FutureWarning|pd.concat"

GUARDS: G must be 8.04 for top and 12.36 for bottom (fixed in the protocol), to 0.01; a reference cell with duplicates stops the
reading of that band. Selection on seeds 0-1 (val_mcq_acc), reported seeds 2-6 at that rate only.
Tests: (1) U = unfrozen(r=1) - frozen(r=2) against 0.3 G / 0.7 G with the interval rule; (2) unfrozen(r=2) - frozen(r=2), t > 3.495;
(3) PRE-REGISTERED here: (bottom - top) unfrozen minus (bottom - top) frozen at rank 2, t > 2.776; (4) reported: the three-term
decomposition, the unfrozen gap with its equivalence at +/- 1, the principal angles.
ADDENDUM (PROTOCOL_obqa_unfrozen_addendum.md): the PARTITION model of every run, and tests (1)-(3) redone on the seeds where all compared
runs share one PARTITION model (t at n - 1 d.f.; not computable below three seeds).
"""
import glob
import json
import math
import os
import re
import statistics as st

import yaml

R = os.path.expanduser("~/lora-runs")
QWEN, FP = "Qwen/Qwen2.5-1.5B", "dc05f4d847f9"
S_SEL, S = (0, 1), [2, 3, 4, 5, 6]
LRS = [2e-4, 5e-4, 1e-3, 2e-3, 5e-3, 1e-2, 2e-2]
G_FIXED = {"top": 8.04, "bottom": 12.36}
FROZEN = {"top": 5e-3, "bottom": 2e-3}
T95, T90 = 2.776, 2.132


def ok(c):
    v = c.get("max_grad_norm", 1.0)
    return (c.get("task") == "commonsense" and str(c.get("data_fingerprint")) == FP and str(c.get("model")) == QWEN
            and v is not None and float(v) == 1.0 and c.get("update_norm_target") in (None, ""))


RUNS = []
for p in glob.glob(R + "/*/config.yaml"):
    c = yaml.safe_load(open(p)) or {}
    d = os.path.dirname(p)
    try:
        if ok(c) and open(d + "/status").read().startswith("DONE"):
            RUNS.append((c, json.load(open(d + "/metrics.json")), d))
    except OSError:
        continue


def cell(mode, rank, lr, seeds, key):
    by = {}
    for c, m, d in RUNS:
        if c.get("mode") == mode and c.get("rank") == rank and abs(float(c.get("lr") or 0) - lr) < 1e-12 and c.get("seed") in seeds and key in m:
            by.setdefault(c["seed"], []).append((m[key], d))
    dup = {s: len(v) for s, v in by.items() if len(v) > 1}
    return {s: v[0][0] for s, v in by.items()}, dup, {s: v[0][1] for s, v in by.items()}


def gpu_of(d):
    import csv as _csv
    try:
        with open(d + "/results.csv", newline="") as f:
            g = next(_csv.DictReader(f)).get("PARTITION") or "?"
    except (OSError, StopIteration):
        g = "?"
    return g.replace("NVIDIA ", "").replace("GeForce ", "").replace(" Generation", "")


def same_gpu_test(pairs, thresh_name):
    """pairs: {seed: [(value, dir), ...]} for the runs of one comparison; keeps seeds where every run has the same known PARTITION model."""
    keep = [s for s, runs in pairs.items() if len({gpu_of(d) for _, d in runs}) == 1 and gpu_of(runs[0][1]) != "?"]
    if len(keep) < 3:
        return f"controle a PARTITION egal : non calculable ({len(keep)} graine(s))"
    from statistics import mean, stdev
    diffs = [pairs[s][0][0] for s in keep]
    m = mean(x * 100 for x in diffs); se = stdev(x * 100 for x in diffs) / len(keep) ** 0.5
    return f"controle a PARTITION egal ({len(keep)} graines {sorted(keep)}) : {m:+.2f}, t = {m / se if se > 0 else float('inf'):+.2f} ({len(keep) - 1} d.l.)"


def stats(d):
    x = [d[s] * 100 for s in S]; m = st.mean(x); se = st.stdev(x) / len(x) ** 0.5
    return m, m - T95 * se, m + T95 * se, m - T90 * se, m + T90 * se, (m / se if se > 0 else float("inf"))


def select(mode, rank):
    full = {}
    for lr in LRS:
        v, dup, _ = cell(mode, rank, lr, S_SEL, "val_mcq_acc")
        if len(v) == 2 and not dup: full[lr] = st.mean(v.values())
    if len(full) < len(LRS):
        return None, f"INCOMPLET ({len(full)}/{len(LRS)} taux)"
    best = max(full, key=full.get)
    return best, "  ".join(f"{lr:g}:{full[lr]:.3f}" for lr in LRS) + f"  -> {best:g}" + ("  AU BORD" if best in (LRS[0], LRS[-1]) else "")


def angles(dirs):
    try:
        import torch
        from safetensors.torch import load_file
    except ImportError:
        return None
    out = []
    for d in dirs:
        steps = sorted(int(m.group(1)) for f in glob.glob(d + "/factors_*.safetensors") if (m := re.search(r"factors_(\d+)\.safetensors$", f)))
        if 0 not in steps or len(steps) < 2: return None
        t0, te = load_file(d + "/factors_0.safetensors"), load_file(d + f"/factors_{steps[-1]}.safetensors")
        worst = []
        for k in t0:
            if k.endswith(".B"):
                q0, _ = torch.linalg.qr(t0[k].double()); qe, _ = torch.linalg.qr(te[k].double())
                worst.append(math.degrees(math.acos(float(torch.linalg.svdvals(q0.T @ qe).clamp(-1, 1).min()))))
        out.append(st.mean(worst))
    return out


print("==================== OpenBookQA, rang 2, Qwen2.5-1.5B : le cout du gel de B, isole (PROTOCOL_obqa_unfrozen.md) ====================")
free, fdup, freedirs = cell("free", 1, 2e-3, S, "mcq_acc")
print(f"  free r=1 a 2e-3 : {st.mean(free.values()):.4f} ({len(free)} graines)" + (f"  DOUBLONS {fdup}" if fdup else ""))
UN = {}
for arm, lr_f in FROZEN.items():
    fr, dup, frdirs = cell(arm, 2, lr_f, S, "mcq_acc")
    print(f"\n  --- {arm} : gele r=2 a {lr_f:g} : {st.mean(fr.values()) if fr else float('nan'):.4f} ({len(fr)} graines)" + (f"  DOUBLONS {dup}" if dup else ""))
    if dup or fdup or len(fr) != 5 or len(free) != 5:
        print("    ARRET : reference incomplete ou doublons."); continue
    G = stats({s: free[s] - fr[s] for s in S})[0]
    print(f"    G = free(r=1) - {arm}(r=2) = {G:+.2f} (protocole : {G_FIXED[arm]:.2f})")
    if abs(G - G_FIXED[arm]) > 0.01:
        print("    ARRET : G ne correspond pas au protocole."); continue
    un, undirs = {}, {}
    for rank in (1, 2):
        best, txt = select(f"{arm}_unfrozen", rank); print(f"    selection {arm}_unfrozen, rang {rank} : {txt}")
        if best is None: continue
        v, d2, dirs = cell(f"{arm}_unfrozen", rank, best, S, "mcq_acc")
        if d2 or len(v) != 5:
            print(f"    ARRET : {len(v)} graines, doublons {d2 or 'aucun'}"); continue
        un[rank] = v; undirs[rank] = dirs
        ang = angles([dirs[s] for s in S])
        print(f"      {arm}_unfrozen r={rank} a {best:g} : {st.mean(v.values()):.4f} ; angle moyen : " + ("indisponible" if ang is None else f"{st.mean(ang):.1f} degres"))
    UN[arm] = (fr, un, frdirs, undirs)
    if 1 in un:
        U, lo, hi, _, _, t = stats({s: un[1][s] - fr[s] for s in S})
        if U >= 0.7 * G: verdict = "le gel explique l'essentiel" if lo >= 0.7 * G else "partage (l'intervalle chevauche 0,7 G)"
        elif U <= 0.3 * G: verdict = "l'essentiel vient de l'initialisation, de la base ou du rang" if hi <= 0.3 * G else "partage (l'intervalle chevauche 0,3 G)"
        else: verdict = "partage, sans attribution"
        print(f"    (1) PRINCIPAL  U = {U:+.2f}, IC95 [{lo:+.2f}, {hi:+.2f}] ; 0,3 G = {0.3 * G:.2f}, 0,7 G = {0.7 * G:.2f} ; U/G = {U / G:.2f} -> {verdict}")
        print("        " + same_gpu_test({s_: [(un[1][s_] - fr[s_], undirs[1][s_]), (0, frdirs[s_])] for s_ in S}, "U"))
    if 2 in un:
        D, lo, hi, _, _, t = stats({s: un[2][s] - fr[s] for s in S})
        print(f"    (2) gel seul, r=2 : {D:+.2f}, IC95 [{lo:+.2f}, {hi:+.2f}], t = {t:+.2f} -> " + ("ETABLI" if abs(t) > 3.495 else "non etabli"))
        print("        " + same_gpu_test({s_: [(un[2][s_] - fr[s_], undirs[2][s_]), (0, frdirs[s_])] for s_ in S}, "gel seul"))
        print("        PARTITION par graine : gele " + " ".join(f"{s_}:{gpu_of(frdirs[s_])}" for s_ in S) + " | degele r=2 " + " ".join(f"{s_}:{gpu_of(undirs[2][s_])}" for s_ in S))
    if 1 in un and 2 in un:
        for lab, a, b in (("initialisation, free - unfrozen (r=1)", free, un[1]), ("rang, unfrozen r=1 - r=2", un[1], un[2]), ("gel seul, unfrozen r=2 - gele r=2", un[2], fr)):
            m_, lo_, hi_, _, _, _ = stats({s: a[s] - b[s] for s in S}); print(f"    (4) terme {lab:40s} {m_:+6.2f}  IC95 [{lo_:+.2f}, {hi_:+.2f}]")
if all(a in UN and 2 in UN[a][1] for a in ("top", "bottom")):
    (tf, tu, tfd, tud), (bf, bu, bfd, bud) = UN["top"], UN["bottom"]
    mF = stats({s: bf[s] - tf[s] for s in S})[0]
    mU, lo, hi, lo90, hi90, tU = stats({s: bu[2][s] - tu[2][s] for s in S})
    m, lo3, hi3, _, _, t3 = stats({s: (bu[2][s] - tu[2][s]) - (bf[s] - tf[s]) for s in S})
    print(f"\n  (3) PRE-ENREGISTRE : bottom - top : {mF:+.2f} geles, {mU:+.2f} degeles ; difference = {m:+.2f}, IC95 [{lo3:+.2f}, {hi3:+.2f}], t = {t3:+.2f} -> "
          + ("ETABLI" if abs(t3) > 2.776 else "non etabli"))
    print("      " + same_gpu_test({s_: [((bu[2][s_] - tu[2][s_]) - (bf[s_] - tf[s_]), bud[2][s_]), (0, tud[2][s_]), (0, bfd[s_]), (0, tfd[s_])] for s_ in S}, "retrecissement")
          + "  <- si ce controle change le verdict du test (3) : campagne de suivi (additif)")
    print(f"  (4) bandes degelees : {mU:+.2f}, IC95 [{lo:+.2f}, {hi:+.2f}], IC90 [{lo90:+.2f}, {hi90:+.2f}] -> "
          + ("equivalentes a +/- 1" if -1 <= lo90 and hi90 <= 1 else "equivalence non etablie") + " ; " + ("difference etablie" if abs(tU) > 2.776 else "difference non etablie"))
