"""Rank 8 and rank 16 selection, read by the rules committed before the runs (24/09).

    python scripts/read_r816_selection.py 2>&1 | grep -vE "FutureWarning|pd.concat"

Protocols: PROTOCOL_rank8_16_format.md, its addendum (rank 8 on fresh seeds 40-41) and the rate-shift
addendum. Nothing is decided by hand here:
  - each arm's rate is its best validation mean on the selection seeds; a rate at the edge of the grid
    is flagged, and the protocol then extends the grid by one step before anything else;
  - the two common rates are bottom's rate and the rate of the best other frozen arm; if they coincide,
    the inversion is declared not testable at that rank;
  - the rate-shift prediction: bottom's rate is strictly lower than top's, random's and random_ortho's.
"""
import os
import sys

sys.path.insert(0, "src")
from lorasub.aggregate import collect  # noqa: E402

L = "meta-llama/Llama-3.2-1B"
GRID = [2e-4, 5e-4, 1e-3, 2e-3, 5e-3, 1e-2, 2e-2]
POP = {8: ([40, 41], 4), 16: ([0, 1], 8)}          # rank -> (selection seeds, rank of the free reference)
FROZEN = ["top", "bottom", "random", "random_ortho"]

d = collect(os.path.expanduser("~/lora-runs"))
base = d[(d.task == "format") & (d.model.astype(str) == L) & (d.n_modules == 7) & (d.max_grad_norm == 1.0)
         & d.update_norm_target.isna() & d.band_frac.isna() & ((d.alpha / d["rank"]).round(2) == 1.0)
         & d.lr.apply(lambda v: any(abs(v - g) < 1e-12 for g in GRID))]
base = base[~(base["mode"].isin(["random", "random_ortho"]) & (base.subspace_salted != True))]  # noqa: E712


def sweep(mode, rank, seeds):
    x = base[(base["mode"] == mode) & (base["rank"] == rank) & base.seed.isin(seeds)]
    g = x.groupby("lr").agg(v=("val_format_parsed", "mean"), n=("seed", "nunique"), fn=("format_n", "max"))
    return g


for rank, (seeds, fr) in POP.items():
    print(f"\n==================== RANG {rank}  (graines de selection {seeds} ; free au rang {fr}) ====================")
    sel, edge = {}, []
    for mode, r in [(m, rank) for m in FROZEN] + [("free", fr)]:
        g = sweep(mode, r, seeds)
        if g.empty:
            print(f"  {mode:13s} AUCUN RUN"); continue
        full = g[g.n == g.n.max()]
        best = float(full.v.idxmax())
        sel[mode] = best
        at_edge = best in (min(g.index), max(g.index))
        if at_edge: edge.append(mode)
        print(f"  {mode:13s} " + "  ".join(f"{lr:g}:{row.v:.3f}({int(row.n)})" for lr, row in g.iterrows())
              + f"   -> {best:g}" + ("  AU BORD" if at_edge else ""))
    if edge:
        print(f"\n  SELECTION AU BORD pour {edge} : le protocole prolonge la grille d'un cran AVANT toute autre regle.")
        continue
    others = {m: sel[m] for m in ("top", "random", "random_ortho") if m in sel}
    best_other = max(others, key=lambda m: float(sweep(m, rank, seeds).v.max()))
    lo_hi = sorted({sel["bottom"], sel[best_other]})
    print(f"\n  taux communs (regle) : celui de bottom ({sel['bottom']:g}) et celui du meilleur autre bras gele, "
          f"{best_other} ({sel[best_other]:g})")
    if len(lo_hi) == 1:
        print("  -> CONFONDUS : l'inversion est NON TESTABLE a ce rang (protocole) ; pas d'autre taux choisi apres coup")
    else:
        print(f"  -> les deux taux communs : {lo_hi[0]:g} et {lo_hi[1]:g}")
    lower = [m for m in ("top", "random", "random_ortho") if m in sel and sel["bottom"] < sel[m]]
    verdict = "CONFIRMEE" if len(lower) == 3 else ("REFUTEE" if not lower else "PARTIELLE")
    print(f"  prediction du deplacement : bottom ({sel['bottom']:g}) strictement plus bas que "
          f"{lower if lower else 'aucun bras'} -> {verdict}")
