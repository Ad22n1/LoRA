"""Does the change of checker move any selected rate? A diagnostic, not a new selection.

    python scripts/checker_rescore.py 2>&1 | grep -vE "FutureWarning|pd.concat"

Why. The selection sweeps behind the paper's rates (seeds 0 and 1, 400 items) were scored by the
earlier checker ("pre-field"); the reported seeds by the current one (885a796e96bb). Their validation
generations were not saved, so the selection itself cannot be redone. Their TEST generations were.
Rescoring those with the current checker tells whether the checker changes the ORDER of the rates
within an arm. It is not used to select anything: selecting on test items would be leakage. If the
best rate of every arm is the same under both checkers, the rates chosen with the earlier checker stand.
"""
import json
import os
import statistics as st
import sys

sys.path.insert(0, "src")
from lorasub.aggregate import collect, effective_metric_version  # noqa: E402
from lorasub.data.format import check_alien  # noqa: E402

R = os.path.expanduser("~/lora-runs")
d = collect(R)
x = d[(d.task == "format") & (d.model.astype(str) == "meta-llama/Llama-3.2-1B")
      & d["mode"].isin(["top", "bottom", "random", "random_ortho"]) & d["rank"].isin([1, 2, 4])
      & (d.n_modules == 7) & (d.max_grad_norm == 1.0) & d.update_norm_target.isna() & d.band_frac.isna()
      & d.seed.isin([0, 1]) & ((d.alpha / d["rank"]).round(2) == 1.0)]
x = x[~(x["mode"].isin(["random", "random_ortho"]) & (x.subspace_salted != True))]  # noqa: E712
x = x.assign(ver=effective_metric_version(x))
x = x[x.ver.astype(str).str.startswith("pre-field")]
print(f"  runs de selection notes par l'ancien verificateur : {len(x)}")

rows, missing = [], 0
for r in x.itertuples():
    f = os.path.join(R, str(r.run_id), "generations_test.jsonl")
    if not os.path.exists(f):
        missing += 1
        continue
    ok = []
    with open(f) as fh:
        for line in fh:
            g = json.loads(line)
            ok.append(bool(check_alien(g["gen"], g["gold"])["parsed"]))
    rows.append((r.mode, int(r.rank), float(r.lr), int(r.seed), float(r.format_parsed), st.mean(ok)))
print(f"  generations retrouvees : {len(rows)}, absentes : {missing}")

import pandas as pd  # noqa: E402

t = pd.DataFrame(rows, columns=["mode", "rank", "lr", "seed", "ancien", "actuel"])
agg = t.groupby(["mode", "rank", "lr"]).agg(ancien=("ancien", "mean"), actuel=("actuel", "mean"), n=("seed", "nunique"))
changed = 0
for (m, rk), g in agg.groupby(level=[0, 1]):
    g = g.droplevel([0, 1])
    b_old, b_new = g.ancien.idxmax(), g.actuel.idxmax()
    same = "meme taux" if b_old == b_new else "TAUX DIFFERENT"
    changed += b_old != b_new
    print(f"\n  {m:13s} r={rk}  meilleur taux : ancien {b_old:g}  actuel {b_new:g}  -> {same}")
    print("    " + "  ".join(f"{lr:g}: {a:.3f}->{b:.3f} ({n})" for lr, (a, b, n) in g.iterrows()))
print(f"\n  cellules ou le meilleur taux change avec le verificateur : {changed}")
print(f"  ecart moyen actuel - ancien : {(t.actuel - t.ancien).mean() * 100:+.2f} points")
