"""Points 5 and 6, each read by its committed protocol. Every cell prints its seed count; nothing is concluded on
incomplete data.

    python scripts/read_points56.py 2>&1 | grep -vE "FutureWarning|pd.concat"

POINT 5 (PROTOCOL_budget2x.md), budget 1 200 000 tokens:
  - selection control, seeds 0-1, three rates per arm: the retained rate is the best validation mean; an EXACT tie with the
    paper's rate keeps the paper's rate; a retained rate at /2 or x2 is at the edge of the small grid;
  - rate-shift prediction: bottom retains a strictly lower rate than top, random and random_ortho (confirmed / partial / not);
  - inversion, seeds 2-6, common rates 2e-3 (low) and 1e-2 (high): a half is established only if it passes (t > 2.776) against
    the best competitor recomputed per seed AND against each fixed competitor; interaction against each fixed competitor,
    t > 3.96. The classification reads "interaction established" as established against all three (counts are printed);
  - freezing against choosing at the paper's selected rates, bootstrap interval.
POINT 6 (PROTOCOL_norm_control.md): the evaluations of ~/lora-analysis/norm_control/. Only runs whose own-norm evaluation
  REPRODUCED and that have all seven targets are used. The test needs FIVE seeds per arm (4 d.f., t > 3.96): with fewer, the
  script says the test is NOT conclusive under the protocol, and concludes nothing.
"""
import csv
import glob
import json
import os
import random
import statistics as st

import yaml

R = os.path.expanduser("~/lora-runs")
L = "meta-llama/Llama-3.2-1B"


def tokens(c):
    t = c.get("target_tokens")
    return t.get(c.get("task")) if isinstance(t, dict) else t


RUNS = []
for p in glob.glob(R + "/*/config.yaml"):
    c = yaml.safe_load(open(p)) or {}
    # seven modules: the saved config lists them explicitly (None is resolved from the model registry at launch)
    tm = c.get("target_modules")
    if c.get("task") != "format" or str(c.get("model")) != L or str(tokens(c)) != "1200000" or (tm is not None and len(tm) != 7):
        continue
    d = os.path.dirname(p)
    try:
        if not open(d + "/status").read().startswith("DONE"):
            continue
        RUNS.append((c, json.load(open(d + "/metrics.json"))))
    except OSError:
        continue


def cell(mode, rank, lr, seeds, key="format_parsed"):
    return {c["seed"]: m[key] for c, m in RUNS if c.get("mode") == mode and c.get("rank") == rank
            and abs(float(c.get("lr") or 0) - lr) < 1e-12 and c.get("seed") in seeds and key in m}


def paired(a, b):
    k = sorted(set(a) & set(b)); dd = [(a[s] - b[s]) * 100 for s in k]
    if len(dd) < 2: return float("nan"), float("nan"), 0, len(dd)
    sd = st.stdev(dd); t = st.mean(dd) / (sd / len(dd) ** 0.5) if sd > 0 else float("inf")
    return st.mean(dd), t, sum(v > 0 for v in dd), len(dd)


def test(lab, a, b, thr):
    m, t, pos, n = paired(a, b)
    ok = t > thr and n == 5
    print(f"      {lab:44s} {m:+6.2f} pt  t = {t:+6.2f}  {pos}/{n}  {'ETABLI' if ok else 'non etabli'}{'' if n == 5 else '  (pas 5 graines)'}")
    return ok


def show(lab, v):
    print(f"    {lab:32s} " + (f"{st.mean(v.values()):.4f}  ({len(v)} graines)" if v else "AUCUN RUN"))


# ================================================================================================================== POINT 5
print("==================== POINT 5 : second budget (1 200 000 tokens) ====================")
print("--- controle de selection (graines 0 et 1, validation)")
SEL = {"top": (2, [5e-3, 1e-2, 2e-2], 1e-2), "random": (2, [5e-3, 1e-2, 2e-2], 1e-2), "random_ortho": (2, [5e-3, 1e-2, 2e-2], 1e-2),
       "bottom": (2, [2.5e-3, 5e-3, 1e-2], 5e-3), "free": (1, [5e-4, 1e-3, 2e-3], 1e-3)}
kept, retained = 0, {}
for mode, (rank, lrs, paper) in SEL.items():
    v = {lr: cell(mode, rank, lr, (0, 1), "val_format_parsed") for lr in lrs}
    full = {lr: st.mean(x.values()) for lr, x in v.items() if len(x) == 2}
    if len(full) < 3:
        print(f"    {mode:13s} INCOMPLET : {[(lr, len(x)) for lr, x in v.items()]}"); continue
    best = max(full.values()); winners = [lr for lr, x in full.items() if x == best]
    r = paper if paper in winners else winners[0]
    retained[mode] = r; kept += (r == paper)
    print(f"    {mode:13s} " + "  ".join(f"{lr:g}:{full[lr]:.4f}" for lr in lrs) + f"  -> {r:g}"
          + ("  (taux du papier conserve)" if r == paper else "  DEPLACE" + ("  AU BORD" if r in (lrs[0], lrs[-1]) else "")))
if len(retained) == 5:
    print(f"  -> taux du papier conserve pour {kept} bras sur 5 : " + ("reserve LEVEE" if kept == 5 else "optimum deplace pour au moins un bras, rapporte comme une limite"))
    lower = [m for m in ("top", "random", "random_ortho") if retained["bottom"] < retained[m]]
    print(f"  -> deplacement du taux : bottom ({retained['bottom']:g}) strictement plus bas que {lower or 'aucun bras'} : "
          + ("CONFIRME" if len(lower) == 3 else ("PARTIEL" if lower else "NON REPRODUIT")))

print("--- inversion (graines 2-6), taux communs 2e-3 (bas) et 1e-2 (haut)")
S = [2, 3, 4, 5, 6]; arms = ("top", "random", "random_ortho")
A = {(m, lr): cell(m, 2, lr, S) for m in ("bottom",) + arms for lr in (2e-3, 1e-2)}
for (m, lr), v in sorted(A.items(), key=str): show(f"{m} a {lr:g}", v)
seeds = sorted(set.intersection(*[set(v) for v in A.values()])) if all(A.values()) else []
if len(seeds) >= 2:
    bl, bh = A[("bottom", 2e-3)], A[("bottom", 1e-2)]
    blo = {s: max(A[(m, 2e-3)][s] for m in arms) for s in seeds}; bhi = {s: max(A[(m, 1e-2)][s] for m in arms) for s in seeds}
    print("    avance de bottom au taux bas (seuil 2.776) :")
    lo_ok = [test("contre le meilleur concurrent, recalcule", bl, blo, 2.776)] + [test(f"contre {m} (fixe)", bl, A[(m, 2e-3)], 2.776) for m in arms]
    print("    retard de bottom au taux haut (seuil 2.776) :")
    hi_ok = [test("le meilleur concurrent moins bottom", bhi, bh, 2.776)] + [test(f"{m} (fixe) moins bottom", A[(m, 1e-2)], bh, 2.776) for m in arms]
    print("    interaction bras x taux (seuil 3.96) :")
    in_ok = []
    for m in arms:
        inter = {s: (bl[s] - A[(m, 2e-3)][s]) - (bh[s] - A[(m, 1e-2)][s]) for s in seeds}
        in_ok.append(test(f"contre {m}", inter, {s: 0.0 for s in seeds}, 3.96))
    half_lo, half_hi, inter_all = all(lo_ok), all(hi_ok), all(in_ok)
    print(f"    bilan : avance {'ETABLIE' if half_lo else 'non etablie'} ; retard {'ETABLI' if half_hi else 'non etabli'} ; "
          f"interaction etablie contre {sum(in_ok)} concurrent(s) sur 3")
    issue = 1 if (inter_all and half_lo and half_hi) else (2 if inter_all else 3)
    print(f"  -> issue {issue} : " + {1: "l'inversion tient au double budget", 2: "partielle, rapportee moitie par moitie",
                                        3: "l'inversion n'est pas reproduite au double budget (effet dependant du budget)"}[issue]
          + ("" if sum(in_ok) in (0, 3) else "  [interaction etablie contre une partie des concurrents seulement : a discuter]"))
else:
    print("    graines communes insuffisantes")

print("--- gel contre choix, aux taux du papier (graines 2-6)")
own = {"top": cell("top", 2, 1e-2, S), "random": cell("random", 2, 1e-2, S), "random_ortho": cell("random_ortho", 2, 1e-2, S),
       "bottom": cell("bottom", 2, 5e-3, S)}
fr = cell("free", 1, 1e-3, S)
for k, v in list(own.items()) + [("free r=1", fr)]: show(k, v)
sd = sorted(set(fr).intersection(*[set(v) for v in own.values()])) if fr and all(own.values()) else []
if len(sd) >= 2:
    def fcv(ix):
        m = {k: st.mean(v[s] for s in ix) for k, v in own.items()}; ff = st.mean(fr[s] for s in ix)
        return (ff - max(m.values())) * 100, (max(m.values()) - min(m.values())) * 100
    g, c = fcv(sd); rng = random.Random(0); B = [fcv([sd[rng.randrange(len(sd))] for _ in sd]) for _ in range(20000)]
    diffs = sorted(b[0] - b[1] for b in B); lo, hi = diffs[500], diffs[19499]
    print(f"    geler {g:.2f}  choisir {c:.2f}  ->  geler - choisir {g - c:+.2f}  IC95 [{lo:+.2f}, {hi:+.2f}]  ({len(sd)} graines) -> "
          + ("l'ordre TIENT" if lo > 0 else ("l'ordre S'INVERSE" if hi < 0 else "NON ETABLI au double budget")))

# ================================================================================================================== POINT 6
print("\n==================== POINT 6 : position ou norme (evaluations remises a l'echelle) ====================")
rows = []
for f in glob.glob(os.path.expanduser("~/lora-analysis/norm_control/*.csv")):
    rows += list(csv.DictReader(open(f)))
TARGETS = [1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5]; ARMS = ("top", "random", "random_ortho", "bottom")
by = {}
for r in rows:
    by.setdefault((r["mode"], int(r["seed"])), []).append(r)
complete, notrep, partial = {}, [], []
for (mode, seed), rs in sorted(by.items()):
    ownr = [r for r in rs if r["target"] == "own"]
    if not ownr or ownr[0]["reproduced"] != "True":
        notrep.append((mode, seed)); continue
    got = {float(r["target"]): float(r["format_parsed"]) for r in rs if r["target"] != "own"}
    if all(t in got for t in TARGETS):
        complete[(mode, seed)] = (float(ownr[0]["format_parsed"]), got)
    else:
        partial.append((mode, seed, len(got)))
print(f"  runs complets : {len(complete)} sur 20 ; NON REPRODUITS : {notrep} ; incomplets : {partial}")
for arm in ARMS:
    print(f"    {arm:13s} graines completes : {sorted(s for (m, s) in complete if m == arm)}")
means = {arm: {t: [v[1][t] for (m, s), v in complete.items() if m == arm] for t in TARGETS} for arm in ARMS}
print("  courbe descriptive (score moyen par cible, graines completes) :")
for arm in ARMS:
    print(f"    {arm:13s} " + "  ".join(f"{t}:{st.mean(means[arm][t]):.3f}" if means[arm][t] else f"{t}:-" for t in TARGETS))
usable = [t for t in TARGETS if all(means[a][t] and st.mean(means[a][t]) >= 0.3 for a in ARMS)]
print(f"  cibles utilisables (les quatre bras >= 0,3) : {usable or 'AUCUNE'}")
if not usable:
    print("  -> issue 1 : controle inutilisable, rapporte tel quel")
else:
    est = []
    for arm in ("top", "random", "random_ortho"):
        common = sorted(s for (m, s) in complete if m == arm and ("bottom", s) in complete)
        gap = {s: st.mean(complete[(arm, s)][1][t] - complete[("bottom", s)][1][t] for t in usable) for s in common}
        m, t, pos, n = paired(gap, {s: 0.0 for s in common})
        ok = n == 5 and t > 3.96
        est.append(ok)
        print(f"    {arm:13s} moins bottom, ecart moyen sur les cibles utilisables : {m:+.2f} pt  t = {t:+.2f}  {pos}/{n}"
              f"  {'ETABLI' if ok else 'non etabli'}{'' if n == 5 else '  (PAS 5 graines : test non concluant au sens du protocole)'}")
        ref = {s: complete[(arm, s)][0] - complete[("bottom", s)][0] for s in common}
        if ref: print(f"      reference a norme libre, memes graines : {100 * st.mean(ref.values()):+.2f} pt")
    if any(n != 5 for n in [len([s for (m, s) in complete if m == a and ("bottom", s) in complete]) for a in ("top", "random", "random_ortho")]):
        print("  -> PAS DE CONCLUSION : le test demande 5 graines par bras ; decider et ECRIRE l'ecart au protocole avant de conclure")
    else:
        k = sum(est)
        print("  -> issue " + ("2 : l'effet de position ne s'explique pas par la norme" if k == 3 else
                                 ("3 : partiel, rapporte bras par bras" if k else "4 : compatible avec un effet de norme")))
