"""Machines on which a long-training run (2 400 000 tokens) has already finished (PROTOCOL_long_training_addendum.md): they have shown enough free PARTITION memory,
a working environment and room for the model on their local disk. Prints the exclusion list (all other machines) on the last line.

    python scripts/nodes_for_long.py            # --report for the lists
"""
import csv
import glob
import os
import subprocess
import sys

import yaml

good = set()
for root in ("~/lora-runs", "~/lora-runs-probe"):
    for p in glob.glob(os.path.expanduser(root) + "/*/config.yaml"):
        d = os.path.dirname(p)
        try:
            c = yaml.safe_load(open(p)) or {}; tt = c.get("target_tokens"); tok = tt.get("format") if isinstance(tt, dict) else tt
            if tok != 2_400_000 or not open(d + "/status").read().startswith("DONE"):
                continue
            with open(d + "/results.csv", newline="") as fh:
                r = next(csv.DictReader(fh))
        except (OSError, StopIteration):
            continue
        h, g = (r.get("host") or "").split(".")[0], r.get("PARTITION") or ""
        if h and "RTX 4000 Ada" in g:
            good.add(h)
try:
    out = subprocess.run(["sinfo", "-h", "-p", "PARTITION", "-N", "-o", "%N"], capture_output=True, text=True, timeout=30).stdout
    nodes = sorted({l.strip().split(".")[0] for l in out.split() if l.strip()})
except Exception:  # noqa: BLE001
    nodes = []
if not nodes:
    sys.exit("STOP : liste des machines de la partition indisponible (sinfo)")
good = sorted(good & set(nodes))
if len(good) < 4:
    sys.exit(f"STOP : seulement {len(good)} machine(s) eprouvee(s) pour l'entrainement long ; trop peu pour relancer")
if "--report" in sys.argv:
    print(f"  {len(nodes)} machines dans la partition ; {len(good)} ont deja termine un run long : {', '.join(good)}")
print(",".join(sorted(set(nodes) - set(good))))
