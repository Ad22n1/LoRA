"""PROTOCOL_freezeA_rank16.md: freezing A at rank 16 on ARC-Challenge and OpenBookQA (Qwen2.5-1.5B). No PARTITION.

    python scripts/read_ra.py 2>&1 | grep -vE "FutureWarning|pd.concat"

References: the frozen arms at rank 16, seeds 2-6, at their selected rates. New arms dual_top and dual_bottom, selected on seeds 0-1
(validation), reported on 2-6; the oracle rate (best on the reported seeds) is an optimistic bracket. Tests: (1) dual_X - X, t > 3.495;
(2) the band-gap shrinkage when A is frozen, t > 2.776, read only if the frozen gap is at least 2 points.
"""
import csv
import glob
import json
import math
import os
import random
import re
import statistics as st

import yaml


def is_obqa(c):
    """OpenBookQA on Qwen2.5-1.5B: identified by its data directory; the rank-16 campaign predates the data fingerprint (empty)."""
    return (c.get("task") == "commonsense" and str(c.get("model")) == "Qwen/Qwen2.5-1.5B"
            and os.path.basename(str(c.get("data_dir") or "").rstrip("/")) == "openbookqa"
            and str(c.get("data_fingerprint") or "") in ("", "None", "dc05f4d847f9"))

R = os.path.expanduser("~/lora-runs")
LLAMA, QWEN = "meta-llama/Llama-3.2-1B", "Qwen/Qwen2.5-1.5B"
S_SEL, S_REP = (0, 1), [2, 3, 4, 5, 6]


def tokens(c):
    t = c.get("target_tokens")
    return t.get(c.get("task")) if isinstance(t, dict) else t


RUNS = []
for p in glob.glob(R + "/*/config.yaml"):
    c = yaml.safe_load(open(p)) or {}
    d = os.path.dirname(p)
    try:
        if not open(d + "/status").read().startswith("DONE"):
            continue
        RUNS.append((c, json.load(open(d + "/metrics.json")), d))
    except OSError:
        continue


def clipped(c):
    """Gradient clipping at 1.0, the paper's setting. A noclip grid reran the same cells without clipping (collect()'s
    docstring); mixing both put two runs per seed in the frozen cells and moved G from 12.41 to 13.53 (26/09)."""
    v = c.get("max_grad_norm", 1.0)
    return v is not None and float(v) == 1.0


def seven(c):
    tm = c.get("target_modules")
    return tm is None or len(tm) == 7


def cell(pred, mode, rank, lr, seeds, key):
    """{seed: value}; several runs of one seed are averaged and flagged."""
    by = {}
    for c, m, d in RUNS:
        if (pred(c) and clipped(c) and c.get("mode") == mode and c.get("rank") == rank and abs(float(c.get("lr") or 0) - lr) < 1e-12
                and c.get("seed") in seeds and key in m and c.get("update_norm_target") in (None, "")):
            by.setdefault(c["seed"], []).append((m[key], d))
    dup = {s: len(v) for s, v in by.items() if len(v) > 1}
    if dup:   # say what separates the duplicates, so that the next filter is written from evidence
        s0 = sorted(dup)[0]; cfgs = [yaml.safe_load(open(d + "/config.yaml")) or {} for _, d in by[s0]]
        keys = sorted(k for k in set().union(*cfgs) if k not in ("run_id", "out_dir") and len({str(c_.get(k)) for c_ in cfgs}) > 1)
        dup["differ"] = {k: [c_.get(k) for c_ in cfgs] for k in keys} or "configs identiques"
    return {s: st.mean(x for x, _ in v) for s, v in by.items()}, dup, {s: [d for _, d in v] for s, v in by.items()}


def select(pred, mode, rank, lrs, key):
    full = {}
    for lr in lrs:
        v, _, _ = cell(pred, mode, rank, lr, S_SEL, key)
        if len(v) == 2: full[lr] = st.mean(v.values())
    if len(full) < len(lrs):
        return None, f"INCOMPLET ({len(full)}/{len(lrs)} taux avec leurs deux graines)"
    best = max(full, key=full.get)
    edge = best in (lrs[0], lrs[-1])
    return best, "  ".join(f"{lr:g}:{full[lr]:.3f}" for lr in lrs) + f"  -> {best:g}" + ("  AU BORD" if edge else "")



T4, BONF2 = 2.776, 3.495
TASKS = {"ARC-Challenge": (lambda c: c.get("task") == "commonsense" and str(c.get("data_fingerprint")) == "0755bcdbdce3" and str(c.get("model")) == QWEN,
                           {"top": (5e-4, 0.4970), "bottom": (1e-3, 0.4452)}, [5e-5, 1e-4, 2e-4, 5e-4, 1e-3, 2e-3, 5e-3]),
         "OpenBookQA": (is_obqa,
                        {"top": (2e-3, None), "bottom": (1e-3, None)}, [1e-4, 2e-4, 5e-4, 1e-3, 2e-3, 5e-3, 1e-2])}


def gpu_of(d):
    try:
        with open(d + "/results.csv", newline="") as f:
            return (next(csv.DictReader(f)).get("PARTITION") or "?").replace("NVIDIA ", "").replace(" Generation", "")
    except (OSError, StopIteration):
        return "?"


def pt(d):
    m = st.mean(d); se = st.stdev(d) / len(d) ** 0.5
    return m, m - T4 * se, m + T4 * se, (m / se if se > 0 else float("inf"))


FOLLOW = []
for p_ in glob.glob(os.path.expanduser("~/lora-runs-suivi") + "/*/config.yaml"):
    d_ = os.path.dirname(p_)
    try:
        if open(d_ + "/status").read().startswith("DONE"):
            FOLLOW.append((yaml.safe_load(open(p_)) or {}, json.load(open(d_ + "/metrics.json")), d_))
    except (OSError, ValueError):
        pass


def cell_follow(pred, mode, rank, lr, seeds, key):
    by = {}
    for c, m, d in FOLLOW:
        if pred(c) and c.get("mode") == mode and c.get("rank") == rank and abs(float(c.get("lr") or 0) - lr) < 1e-12 and c.get("seed") in seeds and key in m:
            by.setdefault(c["seed"], []).append((m[key], d))
    return ({s: st.mean(x for x, _ in v) for s, v in by.items()}, any(len(v) > 1 for v in by.values()), {s: [d for _, d in v] for s, v in by.items()})


col = lambda x, thr: f"{x[0]:+.2f} [{x[1]:+.2f}, {x[2]:+.2f}] t={x[3]:+.2f} -> " + ("ETABLI" if abs(x[3]) > thr else "non etabli")  # noqa: E731
for task, (pred, refs, lrs) in TASKS.items():
    print(f"\n==================== {task}, Qwen2.5-1.5B, rang 16 : geler A ====================")
    print("  budget (additif, point 1) : A gele +26,8 % de parametres par rapport a B gele (10 321 920 contre 8 142 848)")
    R, gpus, bad = {}, set(), []
    for X, (lr, exp) in refs.items():
        v, dup, dirs = cell(pred, X, 16, lr, S_REP, "mcq_acc")
        if len(v) != 5 or dup:
            bad.append(f"reference {X} ({len(v)} graines)"); continue
        R[X] = v; gpus |= {gpu_of(dirs[s][0]) for s in S_REP}
        print(f"  reference {X:6s} (r=16 a {lr:g}) : {st.mean(v.values()):.4f}" + (f" (attendu {exp:.4f})" if exp else ""))
    D, O = {}, {}
    for X in ("top", "bottom"):
        b, txt = select(pred, "dual_" + X, 16, lrs, "val_mcq_acc")
        full = {lr: cell(pred, "dual_" + X, 16, lr, S_REP, "mcq_acc")[0] for lr in lrs}
        done = {lr: v for lr, v in full.items() if len(v) == 5}
        o = max(done, key=lambda lr: st.mean(done[lr].values())) if done else None
        print(f"  selection dual_{X:6s} : {txt}  | oracle : {o if o is None else f'{o:g}'}")
        if b is None or b not in done or o is None:
            bad.append(f"dual_{X}"); continue
        D[X], O[X] = done[b], done[o]
        gpus |= {gpu_of(cell(pred, "dual_" + X, 16, b, S_REP, "mcq_acc")[2][s][0]) for s in S_REP}
        print(f"    dual_{X} a {b:g} : {st.mean(D[X].values()):.4f}" + ("  AU BORD" if b in (lrs[0], lrs[-1]) else ""))
    if bad:
        print("  ARRET : " + "; ".join(bad)); continue
    print(f"  modeles de carte : {sorted(gpus)}")
    for X in ("top", "bottom"):
        print(f"  (1) geler A plutot que B, {X:6s} : retenu {col(pt([(D[X][s] - R[X][s]) * 100 for s in S_REP]), BONF2)}  |  oracle {col(pt([(O[X][s] - R[X][s]) * 100 for s in S_REP]), BONF2)}")
    print("  modeles de carte des references : " + " | ".join(f"{X} " + ",".join(sorted({gpu_of(cell(pred, X, 16, refs[X][0], S_REP, 'mcq_acc')[2][s][0]) for s in S_REP})) for X in ("top", "bottom")))
    if task == "ARC-Challenge":
        F = {}
        for X in ("top", "bottom"):
            v, dup, dirs = cell_follow(pred, X, 16, refs[X][0], S_REP, "mcq_acc")
            if len(v) == 5 and not dup:
                F[X] = v; print(f"  reference {X:6s} reentrainee sur une carte : {st.mean(v.values()):.4f} ({','.join(sorted({gpu_of(dirs[s][0]) for s in S_REP}))})")
        if len(F) == 2:
            for X in ("top", "bottom"):
                print(f"  controle a carte egale (1) {X:6s} : {col(pt([(D[X][s] - F[X][s]) * 100 for s in S_REP]), BONF2)}")
            dF = [((D["bottom"][s] - D["top"][s]) - (F["bottom"][s] - F["top"][s])) * 100 for s in S_REP]
            print(f"  controle a carte egale (2) : ecart gele {st.mean([(F['bottom'][s] - F['top'][s]) * 100 for s in S_REP]):+.2f} ; retrecissement {col(pt(dF), T4)}")
        else:
            print("  controle a carte egale : references reentrainees incompletes, non calcule")
    # additif, point 3 : dual_X - free (free au rang 7, a son seul taux a cinq graines), sans test ; pas a budget egal (+27,8 %)
    frees = {}
    for c_, m_, d_ in RUNS:
        if pred(c_) and clipped(c_) and c_.get("mode") == "free" and c_.get("rank") == 7 and c_.get("seed") in S_REP and "mcq_acc" in m_:
            frees.setdefault(float(c_["lr"]), {}).setdefault(c_["seed"], []).append(m_["mcq_acc"])
    full = {lr: {s: st.mean(v) for s, v in by.items()} for lr, by in frees.items() if sorted(by) == S_REP and all(len(v) == 1 for v in by.values())}
    if len(full) == 1:
        lr_f, Fr = next(iter(full.items()))
        print(f"  LoRA libre au rang 7 a {lr_f:g} : {st.mean(Fr.values()):.4f} (additif, point 3 ; les bras A gele ont +27,8 % de parametres)")
        for X in ("top", "bottom"):
            print(f"    dual_{X} - free, sans test : retenu {st.mean([(D[X][s] - Fr[s]) * 100 for s in S_REP]):+.2f} ; oracle {st.mean([(O[X][s] - Fr[s]) * 100 for s in S_REP]):+.2f}")
    else:
        print(f"  LoRA libre au rang 7 : {len(full)} taux avec cinq graines au node d'un seul ; dual_X - free non calcule")
    est = all(abs(pt([(D[X][s] - R[X][s]) * 100 for s in S_REP])[3]) > BONF2 and st.mean([(D[X][s] - R[X][s]) for s in S_REP]) > 0 for X in ("top", "bottom"))
    print("  lecture fixee (additif, point 2) : " + ("test (1) etabli pour les deux bandes -> l'asymetrie tient au rang 16 sur cette tache" if est
          else "test (1) non etabli pour les deux bandes -> asymetrie rapportee comme propre aux rangs bas ; texte sur PiCa limite au rang 2 pour cette tache"))
    fz = [(R["bottom"][s] - R["top"][s]) * 100 for s in S_REP]; floor = abs(st.mean(fz)) >= 2.0
    for lab, Z in (("retenu", D), ("oracle", O)):
        d = [((Z["bottom"][s] - Z["top"][s]) - (R["bottom"][s] - R["top"][s])) * 100 for s in S_REP]
        print(f"  (2) {lab} : ecart bottom - top {st.mean(fz):+.2f} B gele, {st.mean([(Z['bottom'][s] - Z['top'][s]) * 100 for s in S_REP]):+.2f} A gele ; plancher "
              + ("atteint" if floor else "NON atteint (pas lu)") + f" ; retrecissement {col(pt(d), T4)}")
