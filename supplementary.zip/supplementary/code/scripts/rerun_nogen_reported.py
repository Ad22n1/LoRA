"""Re-run, under today's code, the reported runs whose verifier version cannot be established.

RULE, FIXED BEFORE ANY RE-RUN SCORE WAS SEEN. A run in a reported cell that recorded no verifier
fingerprint AND saved no generations cannot be re-scored; it is re-run under the current code and
REPLACES the original (moved to ~/lora-quarantine-nogen, never averaged with the re-run). The reason
depends on no score: eval.py says the format checker was redefined three times, and these runs predate
the repository, so nothing shows which checker scored them. The 91 runs that did save generations were
re-scored and match today's checker exactly; these 15 are the ones that could not be checked that way.

Same configuration, same run_id: the re-run lands in the same place once the original is moved out.

    python scripts/rerun_nogen_reported.py            # lists the runs, touches nothing
    python scripts/rerun_nogen_reported.py --apply    # quarantine + grid in ~/lora-grid/nogen_rerun
then:  sbatch --exclude=node ~/lora-grid/nogen_rerun/slurm_array.sh
"""
import glob
import os
import shutil
import sys
from pathlib import Path

import pandas as pd
import yaml

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from lorasub.config import load_config  # noqa: E402
from lorasub.launch_grid import write_slurm  # noqa: E402

RUNS = os.path.expanduser("~/lora-runs")
QUAR = Path(os.path.expanduser("~/lora-quarantine-nogen"))
GRID = Path(os.path.expanduser("~/lora-grid/nogen_rerun"))
SEL = (yaml.safe_load(open("configs/lr_selected.yaml")) or {})["selected"]


def reported(y, fmt_n):
    k = f"{y.get('model')}|format|{y.get('mode')}|{int(y.get('rank', -1))}"
    lr = SEL.get(k)
    return (lr is not None and abs(float(y.get("lr", 0)) - lr) < 1e-12 and 2 <= int(y.get("seed", -1)) <= 6
            and len(y.get("target_modules") or []) == 7 and y.get("update_norm_target") is None
            and abs(float(y.get("max_grad_norm") or 0) - 1.0) < 1e-6 and fmt_n == 614)


def targets():
    out = []
    for rdir in sorted(glob.glob(os.path.join(RUNS, "*"))):
        res, cfg = os.path.join(rdir, "results.csv"), os.path.join(rdir, "config.yaml")
        if not (os.path.exists(res) and os.path.exists(cfg)):
            continue
        y = yaml.safe_load(open(cfg)) or {}
        if y.get("task") != "format":
            continue
        t = pd.read_csv(res, dtype=str)
        mv = next((t[c].iloc[0] for c in ("metric_version", "_metric_version") if c in t.columns), None)
        if mv not in (None, "", "nan") and not pd.isna(mv):
            continue
        if os.path.exists(os.path.join(rdir, "generations_test.jsonl")):
            continue
        fmt_n = int(float(t["format_n"].iloc[0])) if "format_n" in t.columns else -1
        if reported(y, fmt_n):
            out.append((rdir, y, float(t["format_parsed"].iloc[0])))
    return out


def main():
    tg = targets()
    print(f"\n=== {len(tg)} reported runs with neither a fingerprint nor saved generations ===")
    for rdir, y, sc in tg:
        print(f"  {os.path.basename(rdir)}  {y['mode']:7s} r={y['rank']} seed={y['seed']} lr={y['lr']}  recorded={sc:.4f}")
    if "--apply" not in sys.argv:
        print("\n  nothing touched. Re-run with --apply to quarantine them and write the grid.")
        return
    QUAR.mkdir(parents=True, exist_ok=True)
    (GRID / "configs").mkdir(parents=True, exist_ok=True)
    cfgs = []
    for rdir, y, sc in tg:
        cfg = load_config(os.path.join(rdir, "config.yaml"))
        if cfg.run_id != os.path.basename(rdir):
            print(f"  note: {os.path.basename(rdir)} regenerates as {cfg.run_id} under today's config code")
        shutil.move(rdir, QUAR / os.path.basename(rdir))
        cfg.to_yaml(GRID / "configs" / f"{cfg.run_id}.yaml")
        cfgs.append(cfg)
    (QUAR / "README.txt").write_text(
        "Reported runs with no verifier fingerprint and no saved generations, moved here before their\n"
        "re-run under the current code (rule fixed before any re-run score was seen). Never average them\n"
        "with the re-runs.\n" + "\n".join(f"{os.path.basename(r)} {y['mode']} r={y['rank']} seed={y['seed']} "
                                           f"lr={y['lr']} recorded={s:.4f}" for r, y, s in tg) + "\n")
    p = write_slurm(GRID, cfgs, partition="PARTITION", time="01:59:00", mem="32G", max_par=8,
                    venv="/tmp/lora-$USER/venv")
    print(f"\n  {len(cfgs)} moved to {QUAR}; grid written: {p}")
    print(f"  submit with:  sbatch --exclude=node {p}")


if __name__ == "__main__":
    main()
