"""Curvature against optimal learning rate — the figure that carries the mechanism.

WHAT IT SHOWS. One point per arm: the curvature of the loss restricted to that arm's trainable
parameters (x), against the learning rate its own sweep selected (y). Log-log. If the usable step
size were set by curvature alone, the points would lie on a line of slope -1, since the stability
condition of a gradient step is lambda * lr < constant. The dashed line is that condition fitted to
`top`; it is drawn as a reference, not as a fit to the five points.

WHAT IT CANNOT SHOW, and the caption must say so. There are five points and four of them are
piled on top of each other: `top`, `random`, `random_ortho` and `free` have indistinguishable
curvatures and identical selected rates. This is a TWO-CLUSTER picture, not a regression — a line
through it is guaranteed to look good and means almost nothing on its own. What carries the claim is
the paired test (three of four comparisons at p <= 0.0083), not the visual alignment.

The horizontal bars are the interquartile range over five seeds, which is wide for `bottom` — its
spread is about half its median. Drawing it honestly is the point: a reader who sees a tight fit
with no error bars will rightly distrust it.
"""

from __future__ import annotations

import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import pandas as pd  # noqa: E402

CSV = os.path.expanduser(sys.argv[1] if len(sys.argv) > 1
                         else "~/lora-analysis/curvature_5seeds_restarts.csv")
OUT = os.path.expanduser("~/lora-analysis/curvature_vs_lr.png")

# Selected rates, from each arm's own sweep (configs/lr_selected.yaml, Llama-3.2-1B, format).
# `free` is at rank 1, the budget-matched reference; the others at rank 2.
LR = {"bottom": 5e-3, "top": 1e-2, "random": 1e-2, "random_ortho": 1e-2, "free": 1e-3}   # free r=1 selects 1e-3
COL = {"bottom": "#c44e52", "top": "#4c72b0", "random": "#55a868",
       "random_ortho": "#8172b2", "free": "#937860"}
MK = {"bottom": "o", "top": "s", "random": "^", "random_ortho": "D", "free": "v"}

d = pd.read_csv(CSV)
g = d.groupby("mode")["curvature_median"]
med, lo, hi = g.median(), g.quantile(0.25), g.quantile(0.75)

# ---------------------------------------------------------------- panneau (a) : par graine
# The scatter of curvature against learning rate has five points and four of them are piled on top
# of each other — two clusters, not a relationship, and a reader is right to find it uninformative.
# What actually carries the claim is that bottom is stiffer on EVERY seed, which is what the paired
# test measures and what this panel shows: twenty ratios, one per seed and per comparison, all above
# one. The eye checks the sign; the test gives the size.
w = d.pivot_table(index="seed", columns="mode", values="curvature_median")
# `free` is drawn in grey and set apart: it trains BOTH factors, so its Hessian at initialisation
# depends on the scale of A and carries the cross block between the two. It is not commensurable
# with the constrained arms, and treating it as one more comparator would be misleading.
pairs = [m for m in ("top", "random", "random_ortho") if m in w]
faded = [m for m in ("free",) if m in w]

fig, (axa, axb) = plt.subplots(1, 2, figsize=(10.2, 4.3),
                               gridspec_kw={"width_ratios": [1.25, 1]})

# No connecting segments: the seeds are CATEGORIES, not an ordered axis, and a line between seed 2
# and seed 3 draws a trend that does not exist. Points, jittered so they do not hide each other, and
# the geometric mean of each comparison marked on the right.
import math
# No conclusions inside the images (24/09): every title is dropped, only panel letters such as "(a)"
# are kept where a caption refers to them. What a figure shows is said in its caption, where it can
# be qualified -- a claim written in the image cannot.
import re as _re
import matplotlib.axes as _max
import matplotlib.figure as _mfig
_set_title = _max.Axes.set_title
def _letter_only(self, label="", *a, **k):
    m = _re.match(r"\s*\(([a-z])\)", str(label))
    return _set_title(self, f"({m.group(1)})" if m else "", loc="left", fontsize=10)
_max.Axes.set_title = _letter_only
_mfig.Figure.suptitle = lambda self, *a, **k: None
for i, m in enumerate(pairs):
    r = (w["bottom"] / w[m]).dropna()
    jit = (i - (len(pairs) - 1) / 2) * 0.13
    axa.plot([x + jit for x in r.index], r.values, MK.get(m, "o"), color=COL.get(m, "0.3"),
             markersize=7, label=f"/ {m}", alpha=0.9, ls="none")
    gm = math.exp(sum(math.log(v) for v in r.values) / len(r))
    # The three geometric means land within 15 % of each other and pile into one unreadable blob at
    # a single x. Spread them along x instead, and label each with its value.
    gx = max(w.index) + 0.45 + i * 0.30
    axa.plot([gx], [gm], MK.get(m, "o"), color=COL.get(m, "0.3"),
             markersize=9, mec="0.2", mew=0.8)
    axa.annotate(f"{gm:.1f}", (gx, gm), xytext=(0, 9), textcoords="offset points",
                 fontsize=7, color=COL.get(m, "0.3"), ha="center")
for m in faded:
    r = (w["bottom"] / w[m]).dropna()
    axa.plot([x + 0.30 for x in r.index], r.values, MK.get(m, "v"), color="0.72",
             markersize=6, label=f"/ {m} (not comparable)", alpha=0.8, ls="none")
axa.axvline(max(w.index) + 0.28, color="0.8", lw=0.8)
axa.annotate("geom.\nmean", (max(w.index) + 0.75, axa.get_ylim()[0]), xytext=(0, 4),
             textcoords="offset points", fontsize=6.8, color="0.45", ha="center")
axa.axhline(1.0, color="0.25", lw=1.2)
# The prediction is a factor five, so draw it. Fourteen of the twenty ratios fall below — the eye
# should see that, not have to infer it from a table.
axa.axhline(2.0, color="0.45", ls="--", lw=1.0)
axa.annotate("prediction: factor of 2 (the ratio of the rates)", (2.0, 2.0), xytext=(0, 5),
             textcoords="offset points", fontsize=7.2, color="0.4")
# La graine 3 donne un rapport de 1,00 face a `top` : les deux courbures y sont identiques.
# C'est le point qui fait que cette comparaison seule ne passe pas Bonferroni, et le tableau des
# medianes le cachait. Le montrer est le but du panneau.
axa.axhspan(0.95, 1.05, color="0.85", alpha=0.45, zorder=0)
axa.annotate("equal", (w.index.min(), 1.0), xytext=(0, -13),
             textcoords="offset points", fontsize=7.5, color="0.35")
axa.set_yscale("log")
axa.set_xticks(list(w.index))
axa.set_xlabel("seed")
axa.set_ylabel("curvature of bottom / curvature of the other arm")
# Counted from the data, not written by hand: the previous title said "19 of 20, but 14 below the
# prediction" and described the measurement that was later found wrong by five orders of magnitude.
_all = [v for m in pairs for v in (w["bottom"] / w[m]).dropna().values]
_above1 = sum(1 for v in _all if v > 1)
_below5 = sum(1 for v in _all if v < 2)
# `free` is DRAWN in this panel but not counted: it trains both factors, so its curvature is not
# comparable. A reader who counts markers finds 20 where the title says 15, so the title says both.
_n_drawn = len(_all) + len((w["bottom"] / w["free"]).dropna()) if "free" in w else len(_all)
axa.set_title(f"(a) bottom is stiffer on {_above1} of the {len(_all)} comparable ratios\n"
              f"({_n_drawn} drawn: free is shown but not counted, it trains both factors)\n"
              f"{'none falls' if _below5 == 0 else ('1 of them falls' if _below5 == 1 else f'{_below5} of them fall')}"
              f" below the factor of two the rates predict",
              fontsize=9)
# (01/10) the legend of panel (a) is placed after the final layout, where it hides no point and no label (see below)
axa.grid(True, which="both", ls=":", lw=0.5, alpha=0.5)

# ---------------------------------------------------------------- panneau (b) : lambda * lr
# The product lambda * lr is what a stability argument says should be constant. It nearly is across
# the four CONSTRAINED arms, whose rates differ by a factor five and whose curvatures differ by four.
# `free` sits five times lower and is the one the mechanism does not account for: it trains both
# factors, so its dynamics are not those of an arm with B frozen.
names = [m for m in ("bottom", "top", "random", "random_ortho", "free") if m in med]
vals = [med[m] * LR[m] for m in names]
# the three arms bottom is compared to: not bottom itself, and not free, which trains both
# factors. Defined here because both the mean line and the ratio below need it.
_others = [v for m, v in zip(names, vals) if m not in ("bottom", "free")]
# Error bars, propagated from the interquartile range of the curvature: naked bars next to panel
# (a), where ratios run from 1 to 12, suggest a constancy the data do not support.
errs = [[(med[m] - lo[m]) * LR[m] for m in names], [(hi[m] - med[m]) * LR[m] for m in names]]
bars = axb.bar(range(len(names)), vals, yerr=errs, capsize=3, error_kw=dict(lw=1.1, ecolor="0.3"),
               color=[COL.get(m, "0.4") for m in names], alpha=0.85)
# The x1e-6 scaling dates from the measurement that was wrong by five orders of magnitude. With
# lambda around 330 the product is of order one, and "661751.58 x1e-6" is unreadable as 0.66.
for i, (m, v) in enumerate(zip(names, vals)):
    axb.text(i, v * 1.03, f"{v:.3f}", ha="center", fontsize=7.5, color="0.25",
             bbox=dict(boxstyle="round,pad=0.12", fc="white", ec="none", alpha=0.85))
# The mean must EXCLUDE bottom: a line that averages in the arm it is there to set apart
# shrinks the very gap it measures (0.394 with bottom, 0.303 without).
_m_others = sum(_others) / len(_others)
axb.axhline(_m_others, color="0.35", ls="--", lw=1.1)
# No label on this line. It sits at 0.303, the three bars it crosses reach 0.29-0.33 and
# `bottom` fills the left, so there is nowhere to put text that is not on top of a bar.
# The caption already says what the line is; a label here only competed with the data.
axb.set_xlim(-0.7, len(names) - 0.3)   # free's bar was touching the frame
axb.set_xticks(range(len(names)))
axb.set_xticklabels(names, fontsize=8.5, rotation=18, ha="right")
axb.set_ylabel(r"$\lambda_{\max} \times$ selected rate")
axb.ticklabel_format(axis="y", style="plain")
# Same: computed. bottom sits well above the other three, so "compatible medians" is false.
# max/min answers "how far apart are the extremes", bottom/mean answers "how far is bottom from
# the rest". They give 2.7 and 2.5 on the same data, and a caption quoting one while the figure
# shows the other reads as an error. Give the interval: bottom against each of the other three.
_c = vals[:4]
_rat = sorted(_c[0] / v for v in _c[1:])
axb.set_title(f"(b) the product is not constant\nbottom is {_rat[0]:.1f} to {_rat[-1]:.1f} times the other\nconstrained arms", fontsize=9)
axb.grid(True, axis="y", ls=":", lw=0.5, alpha=0.5)

fig.set_constrained_layout(True) if False else fig.tight_layout(rect=(0, 0.085, 1, 1))
# Two lines, and short ones: adding the mean to a single line pushed it past both edges, so the
# reader lost "(b) bottom sits" on the left and "not commensurable" on the right.
# (01/10) the two lines of notes under the panels are removed, as in the paper's version (no note inside the image)
os.makedirs(os.path.dirname(OUT), exist_ok=True)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _layout import place_legend, save_at_width  # noqa: E402
place_legend(axa, fontsize=7.5, ncol=2)
save_at_width(fig, OUT, 1568)   # (01/10) the width of the paper's version
fig.savefig(OUT.replace(".png", ".pdf"))

print(f"written -> {OUT}")
print("\ncurvature and selected rate per arm:")
for m in sorted(med.index, key=lambda z: -med[z]):
    if m in LR:
        print(f"  {m:14s} lambda {med[m]:.3e}  [{lo[m]:.3e} ; {hi[m]:.3e}]   lr {LR[m]:g}"
              f"   lambda*lr {med[m]*LR[m]:.2e}")
print("\n  If curvature alone set the step size, lambda*lr would be constant on the right.")
print("  The departure from that constant is what the section reports as unexplained.")
