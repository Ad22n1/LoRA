"""First half-hour on the cluster, automated.  Stops at the first failure with the reason.

    export SHARED=/path/shared HF_HOME=$SHARED/hf
    python scripts/preflight.py --model Qwen/Qwen2.5-0.5B          # smoke model, ~10 min on one A5000
    python scripts/preflight.py --model meta-llama/Llama-3.2-1B    # then the real one

Steps: environment -> data (small) -> SVD cache -> sanity checks -> 20-step training run -> grad probe.
"""
from __future__ import annotations

import argparse
import os
import sys
import time
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))


def step(name):
    def deco(fn):
        def run(*a, **k):
            t0 = time.time()
            print(f"\n=== {name} ===", flush=True)
            try:
                out = fn(*a, **k)
                print(f"--- OK ({time.time() - t0:.0f}s)", flush=True)
                return out
            except Exception:
                print(f"--- FAIL ({time.time() - t0:.0f}s)")
                traceback.print_exc()
                sys.exit(1)
        return run
    return deco


@step("1. environment")
def env():
    import torch
    import transformers

    print("torch", torch.__version__, "| transformers", transformers.__version__)
    print("cuda", torch.cuda.is_available(), "|", torch.cuda.get_device_name(0) if torch.cuda.is_available() else "CPU")
    if torch.cuda.is_available():
        print("bf16", torch.cuda.is_bf16_supported(), "| mem GB", round(torch.cuda.get_device_properties(0).total_memory / 1e9, 1))
    for opt in ("peft", "bitsandbytes", "lm_eval", "flash_attn", "datasets"):
        try:
            mod = __import__(opt)
            ver = getattr(mod, "__version__", "")
            print(f"{opt}: yes {ver}")
            if opt == "datasets" and ver and int(ver.split(".")[0]) >= 4:
                print("  note: datasets>=4 dropped loading scripts; the format dataset uses the Parquet "
                      "mirror tomaarsen/conll2003 (see data/format.py SOURCES)")
        except Exception:
            print(f"{opt}: no ({'required for the format dataset' if opt == 'datasets' else 'optional'})")
    assert os.environ.get("SHARED"), "set SHARED"


@step("2. data (small: 60 entities, CoNLL 200/50/50)")
def data(shared: Path):
    import os

    from lorasub.data.facts import generate_facts
    from lorasub.data.format import build_format_dataset

    d = shared / "data_preflight"
    print(generate_facts(d / "facts", n_entities=60, seed=0, n_test_mcq=60, n_test_completion=60, n_val_mcq=30))
    try:
        print(build_format_dataset(d / "format", n_train=200, n_val=50, n_test=50,
                                   conll_dir=os.environ.get("CONLL_DIR")))
    except Exception as e:
        print(f"format dataset FAILED: {type(e).__name__}: {e}")
        print("If this machine has no access to huggingface.co, download the CoNLL-2003 column files "
              "elsewhere and re-run with CONLL_DIR=/path/to/dir (expects eng.train / eng.testa / eng.testb).")
        raise
    return d


@step("3. model + tokenizer + SVD cache")
def svd(model_id: str, shared: Path):
    from lorasub.modeling import load_model, load_tokenizer
    from lorasub.models import target_modules_for
    from lorasub.spectral import compute_svd_cache, list_cached

    tok = load_tokenizer(model_id)
    model = load_model(model_id)
    names = compute_svd_cache(model, shared / "svd", model_id, suffixes=target_modules_for(model_id), verbose=False)
    print(f"{len(names)} modules cached; {len(list_cached(shared / 'svd', model_id))} files")
    return tok, model


@step("4. sanity checks on the un-adapted model (MCQ ~25 %, parsed < 10 %)")
def sanity(model, tok, d: Path):
    from lorasub.eval import format_metrics, mcq_accuracy

    m = mcq_accuracy(model, tok, d / "facts" / "mcq_test.jsonl", 60)
    f = format_metrics(model, tok, d / "format" / "test.jsonl", 30)
    print(m, f)
    if not (0.12 <= m["mcq_acc"] <= 0.40):
        print("WARNING: MCQ far from chance on 60 items (noisy); re-check with --n 500 on the full data")
    if f["format_parsed"] >= 0.10:
        print("WARNING: alien format already parsed by the base model -> change keys/tags")


@step("5. 20-step training run (bottom, r=8) -> results.csv")
def train(model_id: str, shared: Path, d: Path, tok):
    from lorasub.config import RunConfig
    from lorasub.train import run

    cfg = RunConfig(model=model_id, task="format", mode="bottom", rank=8, lr=5e-4, seed=0, max_steps=20,
                    save_factor_steps=[0, 10, "end"], svd_cache=str(shared / "svd"), data_dir=str(d),
                    out_dir=str(shared / "runs_preflight"), eval_limit=20, eval_forgetting=False, log_every=5)
    row = run(cfg, tokenizer=tok)
    print({k: row[k] for k in ("run_id", "n_trainable", "total_steps", "tokens_seen", "format_parsed", "wallclock_s")})
    assert (cfg.run_dir / "results.csv").exists()


@step("6. gradient probe (16 examples, 2 layer groups)")
def probe(model_id: str, shared: Path, d: Path):
    import torch

    from lorasub.grad_probe import plot, probe
    from lorasub.modeling import enable_checkpointing, load_model, load_tokenizer

    tok = load_tokenizer(model_id)
    model = load_model(model_id)
    enable_checkpointing(model)
    df = probe(model, tok, model_id, str(d), str(shared / "svd"), n_examples=16, batch_size=4, max_len=256,
               group_layers=8)
    out = shared / "runs_preflight" / "grad_probe"
    plot(df, out, "left")
    print(df.groupby(["dataset", "band"])["energy"].mean().unstack("dataset").loc[["top:16", "bottom:16"]])
    del model
    torch.cuda.empty_cache() if torch.cuda.is_available() else None


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="Qwen/Qwen2.5-0.5B")
    a = ap.parse_args()
    env()
    shared = Path(os.environ["SHARED"])
    d = data(shared)
    tok, model = svd(a.model, shared)
    sanity(model, tok, d)
    train(a.model, shared, d, tok)
    del model
    probe(a.model, shared, d)
    print("\nPREFLIGHT PASSED — run scripts/setup_data.sh for the full data, then sbatch scripts/smoke_test.sh")
