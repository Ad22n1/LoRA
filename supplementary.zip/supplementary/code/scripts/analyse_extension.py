"""Analysis of the pre-registered Llama extension, exactly as PROTOCOL_llama_extension.md fixed it.

Order matters and is the protocol's: completeness first (a seed missing any cell is excluded from all
comparisons), then the PRIMARY test on the eight new seeds alone, then the pooled fifteen as secondary.
Nothing here is chosen after seeing a score. The rank-4 sweep and the trajectory curvature follow,
reported descriptively.

    python scripts/analyse_extension.py
"""
import glob
import itertools
import os
import statistics as st
import sys
from math import comb

import yaml

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from lorasub.aggregate import collect  # noqa: E402

MODEL = "meta-llama/Llama-3.2-1B"
POS = [0.0, 0.25, 0.5, 0.75, 1.0]
NEW = list(range(9, 17))
OLD = list(range(2, 9))
T_PRIMARY, T_POOLED = 2.998, 2.624          # one-sided, Bonferroni over five, 7 and 14 d.f.


def wilcoxon_exact(dif):
    a = sorted(range(len(dif)), key=lambda i: abs(dif[i])); rk = [0.0] * len(dif); i = 0
    while i < len(a):
        j = i
        while j + 1 < len(a) and abs(dif[a[j + 1]]) == abs(dif[a[i]]):
            j += 1
        for k in range(i, j + 1):
            rk[a[k]] = (i + j) / 2 + 1
        i = j + 1
    wp = sum(r for r, x in zip(rk, dif) if x > 0)
    tot = [sum(r for r, s in zip(rk, sg) if s) for sg in itertools.product([0, 1], repeat=len(dif))]
    return sum(x >= wp - 1e-12 for x in tot) / len(tot)          # one-sided, direction fixed


def sign_p(dif):
    n, w = len(dif), sum(x > 0 for x in dif)
    return sum(comb(n, i) for i in range(w, n + 1)) / 2 ** n      # one-sided


def tstat(dif):
    return st.mean(dif) / (st.stdev(dif) / len(dif) ** 0.5)


def main():
    d = collect(os.path.expanduser("~/lora-runs"))
    tab = (yaml.safe_load(open("configs/lr_selected.yaml")) or {})["selected"]
    L = d.model.astype(str).str.contains("Llama")
    base = ((d.task == "format") & (d.format_n == 614) & L & (d["rank"] == 2) & (d.n_modules == 7)
            & d.update_norm_target.isna() & (d.max_grad_norm == 1.0))

    arms = {}
    for bf in POS:
        lr = tab[f"{MODEL}|format|band|2|b{bf:g}"]
        x = d[base & (d["mode"] == "band") & (abs(d.band_frac - bf) < 1e-9) & (abs(d.lr - lr) < 1e-12)]
        arms[f"beta={bf:g}"] = x.groupby("seed").format_parsed.mean()
    r = d[base & (d["mode"] == "random_ortho") & (d.subspace_salted == True) & (abs(d.lr - 0.01) < 1e-12)]
    arms["random_ortho"] = r.groupby("seed").format_parsed.mean()
    rep = {k: int((g.groupby("seed").size() > 1).sum()) for k, g in
           [("random_ortho", r)]}

    print("\n=== 1. completeness (protocol: a seed missing any cell is excluded everywhere) ===")
    keep = [s for s in NEW if all(s in v.index for v in arms.values())]
    for k, v in arms.items():
        miss = [s for s in NEW if s not in v.index]
        print(f"  {k:13s} new seeds present {len(NEW) - len(miss)}/8" + (f"   MISSING {miss}" if miss else ""))
    print(f"  seeds kept for the primary test: {keep}  ({len(keep)}/8)")
    print(f"  random_ortho seeds with replicates (averaged): {rep['random_ortho']}")

    def family(seeds, thr, label):
        print(f"\n=== {label}: beta=0.75 against each, seeds {seeds[0]}-{seeds[-1]} (n={len(seeds)}), t > {thr} ===")
        best = arms["beta=0.75"]
        passed = 0
        for k in ["beta=0", "beta=0.25", "beta=0.5", "beta=1", "random_ortho"]:
            dif = [best[s] - arms[k][s] for s in seeds]
            t = tstat(dif); ok = t > thr; passed += ok
            print(f"  vs {k:13s} {st.mean(dif) * 100:+6.2f} pt | t={t:5.2f} {'PASS' if ok else '    '} | "
                  f"{sum(x > 0 for x in dif)}/{len(dif)} | sign p={sign_p(dif):.4f} | Wilcoxon p={wilcoxon_exact(dif):.4f}")
        print(f"  -> {passed} of 5 pass")
        means = {k: st.mean(v[s] for s in seeds) for k, v in arms.items() if k.startswith("beta")}
        top = max(means, key=means.get)
        print("  means: " + "  ".join(f"{k.split('=')[1]}:{v:.4f}" for k, v in means.items())
              + f"   best position: {top}")

    if len(keep) >= 3:
        family(keep, T_PRIMARY, "2. PRIMARY, new seeds alone")
    pooled = [s for s in OLD + keep if all(s in v.index for v in arms.values())]
    family(pooled, T_POOLED, "3. SECONDARY, pooled")

    print("\n=== 4. rank 4 sweep (seeds 2-8, rates from lr_selected_r4.yaml) ===")
    p4 = "configs/lr_selected_r4.yaml"
    if os.path.exists(p4):
        t4 = (yaml.safe_load(open(p4)) or {})["selected"]
        b4 = d[(d.task == "format") & (d.format_n == 614) & L & (d["rank"] == 4) & (d.n_modules == 7)
               & d.update_norm_target.isna() & (d.max_grad_norm == 1.0) & (d["mode"] == "band")
               & d.seed.between(2, 8)]
        m4 = {}
        for bf in POS:
            lr = t4.get(f"{MODEL}|format|band|4|b{bf:g}")
            g = b4[(abs(b4.band_frac - bf) < 1e-9) & (abs(b4.lr - (lr or -1)) < 1e-12)].groupby("seed").format_parsed.mean()
            m4[bf] = g
            print(f"  beta={bf:<5g} lr={lr}  n={len(g)}  mean={g.mean():.4f}" if len(g) else f"  beta={bf:<5g} lr={lr}  no runs")
        full = [s for s in range(2, 9) if all(s in g.index for g in m4.values())]
        if len(full) >= 3:
            best = max(POS, key=lambda b: st.mean(m4[b][s] for s in full))
            print(f"  best position at rank 4: beta={best:g}  (on {len(full)} complete seeds)")
            for bf in POS:
                if bf == best:
                    continue
                dif = [m4[best][s] - m4[bf][s] for s in full]
                print(f"    best vs beta={bf:<5g} {st.mean(dif) * 100:+6.2f} pt | t={tstat(dif):5.2f} | {sum(x > 0 for x in dif)}/{len(dif)}")
    else:
        print("  lr_selected_r4.yaml absent")

    print("\n=== 5. curvature along the path ===")
    n = len(glob.glob(os.path.expanduser("~/lora-analysis/curvtraj_*.csv")))
    print(f"  {n}/20 measurements; the summary is ~/lora-analysis/curvature_traj.csv when all 20 exist")


if __name__ == "__main__":
    main()
