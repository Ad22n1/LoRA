"""Is the rate displacement a property of the band, or of our clipping threshold?

The paper's contribution 6 says `bottom` selects a lower rate than the other arms. That selection
was made WITH clipping at 1.0, and section `regimes` shows that `bottom`'s collapse at 5e-3 is
produced by that threshold rather than by the band. So the displacement could be an artefact of a
hyperparameter we chose, which would be a bigger methodological finding than the one we report --
and would also mean contribution 6 says the wrong thing.

The unclipped runs answer it directly: they are the same sweep with the threshold removed. If
`bottom` still peaks lower there, the displacement is real. If every arm peaks at the same rate,
it is not.

The same runs also test the bracket in the mechanism section. That table reports lambda*lr
intervals that do not intersect; divided by each arm's lambda, those intervals are just learning
rates, and if every arm trains at the same rate and dies at the same rate, the table measures the
curvature gap and nothing else.
"""
import os
import sys

import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from lorasub.aggregate import collect  # noqa: E402

RUNS = os.path.expanduser("~/lora-runs")
ARMS = ("bottom", "top", "random", "random_ortho")
DEAD = 0.05
FAILED = []


def check(name, ok, detail=""):
    print(f"  [{'ok ' if ok else 'FAIL'}] {name}" + (f"\n         {detail}" if detail else ""))
    if not ok:
        FAILED.append(name)


def main():
    d = collect(RUNS)
    L = d.model.astype(str).str.contains("Llama")
    base = d[(d.task == "format") & (d["rank"] == 2) & (d.n_modules == 7) & L
             & d.update_norm_target.isna() & d["mode"].isin(ARMS) & d.seed.between(2, 6)]
    un = base[base.max_grad_norm > 100]
    cl = base[base.max_grad_norm == 1.0]

    print("\n=== A. the unclipped sweep is wide enough to answer ===")
    p = un.pivot_table(index="lr", columns="mode", values="format_parsed", aggfunc="mean")
    n = un.pivot_table(index="lr", columns="mode", values="seed", aggfunc="size")
    print(p.round(4).to_string())
    check("every arm has at least three rates without clipping",
          all(p[m].notna().sum() >= 3 for m in p.columns),
          {m: int(p[m].notna().sum()) for m in p.columns})
    check("at least four seeds per surviving cell",
          bool((n.fillna(0) >= 4).sum().sum() >= 8),
          f"{int((n.fillna(0) >= 4).sum().sum())} cells with 4+ seeds")

    print("\n=== B. the bracket: does it separate anything in RATE space? ===")
    rows = {}
    for m in p.columns:
        s = p[m].dropna()
        alive, dead = s[s > DEAD], s[s <= DEAD]
        rows[m] = (alive.index.max() if len(alive) else None,
                   dead.index.min() if len(dead) else None)
        print(f"         {m:14s} trains up to {rows[m][0]}   dies at {rows[m][1]}")
    tops = {v[0] for v in rows.values() if v[0]}
    bots = {v[1] for v in rows.values() if v[1]}
    same = len(tops) == 1 and len(bots) == 1
    print(f"\n         all arms train up to the same rate: {len(tops) == 1}; "
          f"die at the same rate: {len(bots) == 1}")
    check("the bracket does NOT separate the arms in rate space",
          same,
          "if true, the lambda*lr table measures the curvature gap and nothing else, and must go")

    print("\n=== C. does the displacement survive without clipping? ===")
    opt = {}
    for m in p.columns:
        s = p[m].dropna()
        s = s[s > DEAD]
        opt[m] = s.idxmax() if len(s) else None
        print(f"         {m:14s} peaks at {opt[m]:g}   (score {s.max():.4f})" if len(s) else "")
    ob, others = opt.get("bottom"), [opt[m] for m in ("random", "random_ortho") if opt.get(m)]
    check("bottom peaks LOWER than the drawn arms, with no clipping anywhere",
          ob is not None and others and ob < min(others),
          f"bottom {ob:g} against {sorted(set(others))}")
    if ob and others:
        print(f"\n         displacement without clipping: a factor of {min(others) / ob:.0f}")

    print("\n=== D. the same picture with clipping, for comparison ===")
    q = cl.pivot_table(index="lr", columns="mode", values="format_parsed", aggfunc="mean")
    print(q.round(4).to_string())
    print("         (bottom's zero at 5e-3 here is the collapse that section `regimes` "
          "attributes to the threshold)")

    print("\n" + "=" * 70)
    if FAILED:
        print(f"  {len(FAILED)} CHECK(S) FAILED:")
        for f in FAILED:
            print(f"    - {f}")
    else:
        print("  every check passed.")
    print("""
  WHAT THIS SETTLES. The bracket table separates nothing once divided by lambda, so it goes. The
  displacement does survive the removal of clipping, so contribution 6 stands -- at a factor of
  two, which is also what the selection rule picks when the collapsed seed is not counted.""")


if __name__ == "__main__":
    main()
