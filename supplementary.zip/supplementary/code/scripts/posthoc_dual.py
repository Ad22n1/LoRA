"""POST HOC (not in any protocol): do the two bands score alike when A, not B, is frozen? No PARTITION.

    python scripts/posthoc_dual.py

Reads the runs of PROTOCOL_freeze_A.md at the rates it selected on seeds 0-1: dual_top and dual_bottom at 1e-2 (A frozen on the
dominant or minor rows of V^T); and the B-frozen arms of experiment 1, top at 1e-2 and bottom at 5e-3. Seeds 2 to 6, paired.
Two questions, both post hoc: (1) dual_bottom - dual_top, with equivalence within +/- 1 point (the margin C2 fixed in advance
for another comparison); (2) the interaction: (bottom - top) with A frozen minus (bottom - top) with B frozen.
GUARD: every cell must have exactly one run per seed; duplicates stop the script.
"""
import glob
import json
import os
import statistics as st

import yaml

R = os.path.expanduser("~/lora-runs")
LLAMA = "meta-llama/Llama-3.2-1B"
S = [2, 3, 4, 5, 6]
T4_95, T4_90 = 2.776, 2.132            # two-sided 95 % and 90 % quantiles of Student's t, 4 d.f.


def tokens(c):
    t = c.get("target_tokens")
    return t.get(c.get("task")) if isinstance(t, dict) else t


def ok(c):
    v = c.get("max_grad_norm", 1.0)
    tm = c.get("target_modules")
    return (c.get("task") == "format" and str(c.get("model")) == LLAMA and tokens(c) == 600000 and v is not None and float(v) == 1.0
            and (tm is None or len(tm) == 7) and c.get("update_norm_target") in (None, ""))


RUNS = []
for p in glob.glob(R + "/*/config.yaml"):
    c = yaml.safe_load(open(p)) or {}
    d = os.path.dirname(p)
    try:
        if ok(c) and open(d + "/status").read().startswith("DONE"):
            RUNS.append((c, json.load(open(d + "/metrics.json"))))
    except OSError:
        continue


def cell(mode, rank, lr):
    by = {}
    for c, m in RUNS:
        if c.get("mode") == mode and c.get("rank") == rank and abs(float(c.get("lr") or 0) - lr) < 1e-12 and c.get("seed") in S and "format_parsed" in m:
            by.setdefault(c["seed"], []).append(m["format_parsed"])
    dup = {s: len(v) for s, v in by.items() if len(v) > 1}
    if dup or len(by) != len(S):
        raise SystemExit(f"  ARRET : {mode} r={rank} lr={lr:g} : {len(by)} graines, doublons {dup or 'aucun'}")
    return {s: v[0] for s, v in by.items()}


def stats(d):
    x = [d[s] * 100 for s in S]; m = st.mean(x); se = st.stdev(x) / len(x) ** 0.5
    return m, m - T4_95 * se, m + T4_95 * se, m - T4_90 * se, m + T4_90 * se, (m / se if se > 0 else float("inf"))


print("POST HOC -- aucun protocole ne prevoyait ce test ; il est rapporte comme tel.\n")
tA, bA = cell("dual_top", 2, 1e-2), cell("dual_bottom", 2, 1e-2)
tB, bB = cell("top", 2, 1e-2), cell("bottom", 2, 5e-3)
m, lo, hi, lo90, hi90, t = stats({s: bA[s] - tA[s] for s in S})
eq = -1 <= lo90 and hi90 <= 1; diff = abs(t) > T4_95
print(f"  gel de A : dual_bottom ({st.mean(bA.values()):.4f}) - dual_top ({st.mean(tA.values()):.4f}) = {m:+.2f} pt, IC95 [{lo:+.2f}, {hi:+.2f}], "
      f"t = {t:+.2f} ; IC90 [{lo90:+.2f}, {hi90:+.2f}] -> " + ("EQUIVALENTS a +/- 1 point" if eq else "equivalence NON etablie") + " ; "
      + ("difference ETABLIE" if diff else "difference non etablie"))
mB = stats({s: bB[s] - tB[s] for s in S})[0]; mA = stats({s: bA[s] - tA[s] for s in S})[0]
m, lo, hi, _, _, t = stats({s: (bA[s] - tA[s]) - (bB[s] - tB[s]) for s in S})
change = "l'ecart change de SIGNE" if mB * mA < 0 and abs(mA) >= 1 else ("l'ecart RETRECIT" if abs(mA) < abs(mB) else "l'ecart GRANDIT")
print(f"\n  bottom - top : {mB:+.2f} pt avec B gele, {mA:+.2f} pt avec A gele ({change})")
print(f"  interaction : difference des deux ecarts = {m:+.2f} pt, IC95 [{lo:+.2f}, {hi:+.2f}], t = {t:+.2f} -> " + ("ETABLIE" if (lo > 0 or hi < 0) else "non etablie"))
