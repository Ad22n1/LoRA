"""Test d'equivalence numerique, sans entrainement : notre bras `bottom` (B gele sur la bande mineure) contre PEFT 0.21.0,
init_lora_weights="mica". Aucun resultat publie n'est modifie.

    python scripts/test_mica_peft.py [--model Qwen/Qwen2.5-1.5B] [--layers 0,14] [--r 2]

PEFT est importe depuis un dossier a part (PEFT_DIR, par defaut /tmp/lora-$USER/peft021), place APRES les bibliotheques de l'environnement :
l'environnement des runs n'est pas modifie. Trois constructions du meme bras, sur des copies fp32 des memes poids :
  1. PEFT 0.21.0, init "mica" (SVD fp32 calculee a l'initialisation) ;
  2. notre `bottom`, a partir d'une SVD fp32 fraiche (`spectral.svd_of_weight`, la fonction du cache, sans l'arrondi de stockage) ;
  3. notre `bottom` tel que les runs l'ont construit, a partir du cache SVD (stocke en fp16).
Le signe de chaque vecteur singulier est arbitraire : B est compare brut, puis apres alignement des signes colonne par colonne, et comme
sous-espace (ecart des projecteurs). Ecrit VERIF_mica_peft.md et test_mica_peft.json.
"""
import argparse
import copy
import json
import os
import sys

import torch
import yaml
from torch import nn

REPO = os.path.expanduser("~/repo")
sys.path.insert(0, f"{REPO}/src")
sys.path.append(os.environ.get("PEFT_DIR", f"/tmp/lora-{os.environ.get('USER', '')}/peft021"))   # APRES l'environnement des runs
import peft  # noqa: E402
from peft import LoraConfig, inject_adapter_in_model  # noqa: E402

from lorasub.lora import LoRALinear  # noqa: E402
from lorasub.modeling import load_model  # noqa: E402
from lorasub.spectral import SVDEntry, load_svd, svd_of_weight  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--model", default="Qwen/Qwen2.5-1.5B"); ap.add_argument("--layers", default="0,14"); ap.add_argument("--r", type=int, default=2)
a = ap.parse_args()
if peft.__version__ != "0.21.0":
    sys.exit(f"ARRET : PEFT {peft.__version__} importe ({peft.__file__}), 0.21.0 attendu")
r, alpha = a.r, float(a.r)            # alpha = r, comme dans tous les runs : alpha / r = 1
SVDROOT = f"/tmp/lora-{os.environ.get('USER', '')}/svd"
TYPES = ("q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj")
ref = None                                     # la configuration d'un run `bottom` de ce modele : la precision de chargement des runs
for d in sorted(os.listdir(os.path.expanduser("~/lora-runs"))):
    p_ = os.path.expanduser(f"~/lora-runs/{d}/config.yaml")
    if os.path.exists(p_):
        c_ = yaml.safe_load(open(p_)) or {}
        if c_.get("model") == a.model and c_.get("mode") == "bottom":
            ref = c_; break
if ref is None:
    sys.exit(f"ARRET : aucun run `bottom` de {a.model} pour lire la precision de chargement des runs")
model = load_model(a.model, ref.get("dtype", "bfloat16"), ref.get("attn_implementation", "eager"), device="cpu")   # comme les runs
layers = [int(x) for x in a.layers.split(",")]
names = [n for n, m in model.named_modules() if isinstance(m, nn.Linear) and n.rsplit(".", 1)[-1] in TYPES
         and any(f".layers.{L}." in n for L in layers)]
print(f"  PEFT {peft.__version__} ({os.path.dirname(peft.__file__)}) ; modele {a.model} charge en {ref.get('dtype', 'bfloat16')} comme les runs ; "
      f"couches {layers} ; {len(names)} modules ; r = {r}, alpha / r = 1")


class Box(nn.Module):
    def __init__(self, lin):
        super().__init__(); self.lin = lin


def peft_mica(base):
    box = Box(copy.deepcopy(base))
    inject_adapter_in_model(LoraConfig(r=r, lora_alpha=alpha, lora_dropout=0.0, init_lora_weights="mica", target_modules=["lin"]), box)
    lin = box.lin
    return lin, lin.lora_A["default"].weight, lin.lora_B["default"].weight


def ours(base, svd):
    m = LoRALinear(copy.deepcopy(base), r, "bottom", alpha=alpha, svd=svd)
    return m, m.A, m.B


def trainable(mod):
    return sorted((n, tuple(p.shape)) for n, p in mod.named_parameters() if p.requires_grad)


R = {"B_brut": [], "B_aligne": [], "projecteurs": [], "sorties_A0": [], "sorties_A": [], "gradients_A": []}
C = {"B_aligne": [], "projecteurs": [], "sorties_A": [], "gradients_A": [], "sorties_A_relatif": [], "gradients_A_relatif": [],
     "signes_retournes": 0, "colonnes": 0}
P = {"B_brut": [], "B_aligne": [], "projecteurs": [], "sorties_A": [], "gradients_A": []}
same_params = True
g = torch.Generator().manual_seed(0)
for name in names:
    lin = model.get_submodule(name)
    base = nn.Linear(lin.in_features, lin.out_features, bias=lin.bias is not None)
    with torch.no_grad():
        base.weight.copy_(lin.weight.float())
        if lin.bias is not None:
            base.bias.copy_(lin.bias.float())
    U, S, Vh = svd_of_weight(base.weight)
    fresh = SVDEntry(name=name, shape=tuple(base.weight.shape), S=S, U=U, Vh=Vh)
    cached = load_svd(SVDROOT, a.model, name)
    mp, Ap, Bp = peft_mica(base); mf, Af, Bf = ours(base, fresh); mc, Ac, Bc = ours(base, cached)
    # parametres entrainables : A seul, de meme forme, dans les trois
    tp, tf = trainable(mp), trainable(mf)
    same_params &= [s for _, s in tp] == [s for _, s in tf] == [(r, base.in_features)] and not Bp.requires_grad and not Bf.requires_grad

    def cmp(Bx, By):
        s = torch.sign((Bx * By).sum(0)); s[s == 0] = 1
        return (Bx - By).abs().max().item(), (Bx * s - By).abs().max().item(), (Bx @ Bx.T - By @ By.T).abs().max().item(), s
    x = torch.randn(2, 8, base.in_features, generator=g); w = torch.randn(2, 8, base.out_features, generator=g)
    A0 = torch.randn(r, base.in_features, generator=g) * 0.02

    def run(mod, A_param, A_val):
        with torch.no_grad():
            A_param.copy_(A_val)
        A_param.grad = None
        y = mod(x); (y * w).sum().backward()
        return y.detach(), A_param.grad.detach().clone()
    # 1. PEFT contre notre bras depuis une SVD fp32 fraiche
    raw, ali, proj, s = cmp(Bf, Bp.detach())
    y0p, _ = run(mp, Ap, torch.zeros_like(Ap)); y0f, gf0 = run(mf, Af, torch.zeros_like(Af)); _, gp0 = run(mp, Ap, torch.zeros_like(Ap))
    yp, _ = run(mp, Ap, s[:, None] * A0); yf, _ = run(mf, Af, A0)
    for k, v in (("B_brut", raw), ("B_aligne", ali), ("projecteurs", proj), ("sorties_A0", (y0p - y0f).abs().max().item()),
                 ("sorties_A", (yp - yf).abs().max().item()), ("gradients_A", (gp0 - s[:, None] * gf0).abs().max().item())):
        R[k].append(v)
    # 2. effet du cache fp16 : notre bras depuis le cache contre notre bras depuis la SVD fp32 fraiche
    raw_c, ali_c, proj_c, s_c = cmp(Bc.detach(), Bf.detach())
    C["signes_retournes"] += int((s_c < 0).sum()); C["colonnes"] += r
    yc, _ = run(mc, Ac, s_c[:, None] * A0); yf2, _ = run(mf, Af, A0)
    _, gc0 = run(mc, Ac, torch.zeros_like(Ac)); _, gf1 = run(mf, Af, torch.zeros_like(Af))
    C["B_aligne"].append(ali_c); C["projecteurs"].append(proj_c); C["sorties_A"].append((yc - yf2).abs().max().item())
    C["gradients_A"].append((s_c[:, None] * gc0 - gf1).abs().max().item())
    C["sorties_A_relatif"].append(C["sorties_A"][-1] / max(1e-12, (yf2 - y0f).abs().max().item()))    # rapporte a l'apport de l'adaptateur
    C["gradients_A_relatif"].append(C["gradients_A"][-1] / max(1e-12, gf1.abs().max().item()))
    # 3. directement : le bras des runs (cache) contre PEFT
    raw_d, ali_d, proj_d, s_d = cmp(Bc.detach(), Bp.detach())
    P["B_brut"].append(raw_d); P["B_aligne"].append(ali_d); P["projecteurs"].append(proj_d)

mx = lambda v: max(v) if v else float("nan")  # noqa: E731
out = {"peft": peft.__version__, "modele": a.model, "couches": layers, "modules": len(names), "r": r,
       "memes_parametres_entrainables": bool(same_params),
       "peft_contre_notre_bras_svd_fp32": {k: mx(v) for k, v in R.items()},
       "effet_du_cache_fp16": {k: (mx(v) if isinstance(v, list) else v) for k, v in C.items()},
       "peft_contre_le_bras_des_runs_cache_fp16": {k: mx(v) for k, v in P.items() if v}}
json.dump(out, open(f"{REPO}/test_mica_peft.json", "w"), indent=1)
E, F, D = out["peft_contre_notre_bras_svd_fp32"], out["effet_du_cache_fp16"], out["peft_contre_le_bras_des_runs_cache_fp16"]
ok_math = E["B_aligne"] < 1e-5 and E["projecteurs"] < 1e-5 and E["sorties_A"] < 1e-4 and E["gradients_A"] < 1e-4 and same_params
ok_fp16 = D["B_aligne"] < 2e-3 and D["projecteurs"] < 2e-3
lines = [
    f"# Equivalence numerique : bras `bottom` contre PEFT {peft.__version__} `init_lora_weights=\"mica\"` (sans entrainement)",
    "",
    f"Modele {a.model}, couches {layers} ({len(names)} modules : q, k, v, o, gate, up, down), r = {r}, alpha / r = 1, copies fp32 des poids ;",
    "un lot aleatoire fixe (graine 0) ; perte lineaire en la sortie. Script : `scripts/test_mica_peft.py` ; valeurs completes : `test_mica_peft.json`.",
    "Les vecteurs singuliers sont definis au signe pres : B est compare brut, apres alignement des signes, et comme sous-espace.",
    "",
    "| comparaison (ecart absolu maximal sur les modules) | B brut | B aligne | projecteurs BBᵀ | sorties, A = 0 | sorties, meme A | gradient sur A |",
    "|---|---|---|---|---|---|---|",
    f"| PEFT contre notre `bottom`, SVD fp32 fraiche | {E['B_brut']:.2e} | {E['B_aligne']:.2e} | {E['projecteurs']:.2e} | {E['sorties_A0']:.2e} | {E['sorties_A']:.2e} | {E['gradients_A']:.2e} |",
    f"| notre `bottom` : cache fp16 contre SVD fp32 fraiche | — | {F['B_aligne']:.2e} | {F['projecteurs']:.2e} | — | {F['sorties_A']:.2e} | {F['gradients_A']:.2e} |",
    f"| PEFT contre le bras des runs (cache fp16) | {D['B_brut']:.2e} | {D['B_aligne']:.2e} | {D['projecteurs']:.2e} | — | — | — |",
    "",
    f"- Parametres entrainables : {'identiques (A seul, r x d_in par module ; B gele dans les deux)' if same_params else 'DIFFERENTS'}.",
    f"- Ecarts relatifs dus au cache : sorties {F['sorties_A_relatif']:.1e} de l'apport de l'adaptateur ; gradients sur A {F['gradients_A_relatif']:.1e} de leur valeur maximale.",
    f"- Signes : le cache retourne {F['signes_retournes']} colonne(s) de B sur {F['colonnes']} par rapport a la SVD fp32 fraiche ; sans effet sur le sous-espace.",
    f"- **Mathematiquement, les deux constructions coincident** : {'oui' if ok_math else 'NON'} (B et gradient a la precision fp32, une fois les signes alignes).",
    f"- **Le cache fp16** decale B de {F['B_aligne']:.1e} au plus (sous-espace : {F['projecteurs']:.1e}) : {'a la precision fp16' if ok_fp16 else 'AU-DELA de la precision fp16'}.",
]
open(f"{REPO}/VERIF_mica_peft.md", "w").write("\n".join(lines) + "\n")
print("\n".join(lines))
print("  TEST : " + ("REUSSI" if ok_math and ok_fp16 and same_params else "ECHOUE"))
sys.exit(0 if ok_math and ok_fp16 and same_params else 1)
