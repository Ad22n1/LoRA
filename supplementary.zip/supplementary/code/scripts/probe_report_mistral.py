"""The probe of PROTOCOL_scale_mistral.md and its rule (precision 1). No PARTITION. Last line: DECISION : M7B | NONE

    python scripts/probe_report.py

Rule, for the model probed last: (a) DONE, (b) peak PARTITION memory < 18.5 GB, (c) 105 runs x probe duration / 56 ends before 30/09 08:00.
Mistral-7B passes -> M7B ; fails -> NONE (no campaign, no fallback).
"""
import csv
import datetime as dt
import glob
import os
import shutil

import yaml

DEADLINE = dt.datetime(2026, 9, 30, 8, 0)
runs = []
for p in glob.glob(os.path.expanduser("~/lora-runs-probe/*/config.yaml")):
    c = yaml.safe_load(open(p)) or {}
    m = str(c.get("model"))
    if m == "mistralai/Mistral-7B-v0.3" and c.get("mode") == "top_unfrozen":
        runs.append((os.path.getmtime(p), m, os.path.dirname(p)))
if not runs:
    print("  aucune sonde trouvee dans ~/lora-runs-probe"); print("DECISION : NONE"); raise SystemExit
_, model, d = sorted(runs)[-1]
key = "M7B"
status = open(d + "/status").read() if os.path.exists(d + "/status") else ""
print(f"  sonde {model} : {os.path.basename(d)} ; statut : {status.split()[0] if status.strip() else 'ABSENT'}")
ok, why = False, []
if not status.startswith("DONE"):
    why.append("(a) la sonde ne s'est pas terminee")
    if status.strip():
        print("  fin de la trace :\n    " + "\n    ".join(status.strip().split("\n")[-3:]))
else:
    mem = wall = None
    try:
        with open(d + "/log.csv", newline="") as f:
            mem = max(float(r["gpu_mem_gb"]) for r in csv.DictReader(f) if r.get("gpu_mem_gb") not in (None, ""))
    except (OSError, KeyError, ValueError):
        pass
    try:
        with open(d + "/results.csv", newline="") as f:
            row = next(csv.DictReader(f)); wall = float(row.get("wallclock_s") or "nan"); print(f"  carte : {row.get('PARTITION')}")
    except (OSError, StopIteration, ValueError):
        pass
    est = dt.timedelta(seconds=105 * wall / 56) if wall else None
    end = dt.datetime.now() + est if est else None
    print(f"  (b) memoire de pointe : {mem} Go (seuil 18,5) ; duree de la sonde : {wall / 60 if wall else float('nan'):.1f} min")
    print(f"  (c) duree totale estimee : 105 x {wall:.0f} s / 56 = {est} ; fin estimee {end:%d/%m %H:%M} (limite {DEADLINE:%d/%m %H:%M})" if est else "  (c) duree inconnue")
    if mem is None or mem >= 18.5: why.append("(b) memoire")
    if end is None or end >= DEADLINE: why.append("(c) duree")
    ok = not why
total, used, free = shutil.disk_usage(os.path.expanduser("~"))
print(f"  disque du dossier personnel : {used / 1e9:.1f} Go utilises, {free / 1e9:.1f} Go libres")
if why: print("  echec : " + ", ".join(why))
print("DECISION : " + (key if ok else "NONE"))
