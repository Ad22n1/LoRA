"""The position sweep: the best band is neither the top nor the bottom.

This is the paper's only positive result that no prior work has and none predicts — PiSSA argues for
the dominant components, MiLoRA and MiCA for the minor ones, and the optimum is at neither end. It
lived as a twelve-line table in the middle of the paper, with no figure.

Seven seeds, shared across positions, so every comparison is paired. The panel shows the seeds
themselves rather than a bar with an error bar: with n=7 the reader should be able to count.
"""
import statistics as st
import sys
from math import comb

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# Rank 2, 614 items, per-position selected rate (1e-2 everywhere except beta=1, where 5e-3 wins).
# SEEDS 2-8. An earlier version hard-coded seeds 0-6, and seeds 0 and 1 are the ones the learning
# rate was SELECTED on: every position's score then included the two seeds its rate was chosen to
# maximise. That is the contamination section 5.3 rules out, and it inflated beta = 0.75 from
# 0.6768 to 0.6875. These are the reporting seeds, disjoint from selection, one run per cell.
P = {0.00: [0.6564, 0.6417, 0.6645, 0.6450, 0.6466, 0.6710, 0.6580],
     0.25: [0.6433, 0.6336, 0.6547, 0.6042, 0.6303, 0.6270, 0.6645],
     0.50: [0.6270, 0.6726, 0.6596, 0.6726, 0.6743, 0.6873, 0.6759],
     0.75: [0.6759, 0.6450, 0.6808, 0.6922, 0.6971, 0.6726, 0.6743],
     1.00: [0.5798, 0.5896, 0.6189, 0.5847, 0.5635, 0.6124, 0.6010]}
BEST = 0.75
xs = sorted(P)
mean = {b: st.mean(P[b]) for b in xs}

fig, ax = plt.subplots(figsize=(7.0, 4.2))

# every seed, jittered, so the pairing is visible
for i, b in enumerate(xs):
    for k, v in enumerate(P[b]):
        ax.plot(i + (k - 3) * 0.035, v, "o", ms=3.4, color="0.62", zorder=2)
# Dotted, not solid: five discrete positions, and the text says the profile is a cliff that it
# cannot localise to a quarter of the spectrum. A solid line would draw a curve we never measured.
ax.plot(range(len(xs)), [mean[b] for b in xs], ":o", color="#4c72b0", lw=1.4, ms=9, zorder=3)
ax.plot([xs.index(BEST)], [mean[BEST]], "o", ms=13, mfc="none", mec="#c44e52", mew=2.2, zorder=4)

for i, b in enumerate(xs):
    ax.annotate(f"{mean[b]:.3f}", (i, mean[b]), xytext=(26 if b == BEST else 0, 0 if b == BEST else -18),
                textcoords="offset points", ha="center", fontsize=8.5, zorder=5,
                color="#c44e52" if b == BEST else "0.3",
                fontweight="bold" if b == BEST else "normal")

# who argues for what
lo, hi = ax.get_ylim()
ax.set_ylim(lo - 0.035, hi + 0.02)
# PiSSA and MiLoRA INITIALISE on their band, they do not freeze it; only MiCA freezes. Saying
# "argues for this end" of a frozen-subspace sweep would make the amalgam the paper's related-work
# section is careful to avoid, so the labels name the end, not the method's mechanism.
for x, txt in ((0, "the dominant end\n(PiSSA, by initialisation)"),
               (len(xs) - 1, "the minor end\n(MiLoRA by init., MiCA frozen)")):
    ax.annotate(txt, (x, ax.get_ylim()[0]), xytext=(0, 6), textcoords="offset points",
                ha="center", va="bottom", fontsize=7.5, color="0.45", style="italic")
ax.annotate("best of the five", (xs.index(BEST), mean[BEST]), xytext=(0, 34),
            textcoords="offset points", ha="center", fontsize=8.5, zorder=5, color="#c44e52",
            fontweight="bold",
            arrowprops=dict(arrowstyle="-|>", color="#c44e52", lw=1.2, shrinkB=12))

ax.set_xticks(range(len(xs)))
ax.set_xticklabels([f"$\\beta={b:g}$" for b in xs], fontsize=10)
ax.set_xlabel("position of the band along the spectrum of $W_0$   "
              "($\\beta=0$ is the top, $\\beta=1$ the bottom)", fontsize=9.5)
ax.set_ylabel("format_parsed", fontsize=9.5)
ax.grid(axis="y", color="0.92", lw=0.7)
ax.set_axisbelow(True)
for sp in ("top", "right"):
    ax.spines[sp].set_visible(False)

# the paired tests, computed here so the title cannot drift from the data
res = {}
for b in xs:
    if b == BEST:
        continue
    dif = [a - c for a, c in zip(P[BEST], P[b])]
    n = len(dif)
    res[b] = (st.mean(dif) * 100, st.mean(dif) / (st.stdev(dif) / n ** 0.5), sum(v > 0 for v in dif), n)
top_g, top_t, top_w, n = res[0.00]
bot_g, bot_t, bot_w, _ = res[1.00]
ax.set_title(f"Neither the top nor the bottom: the best band is at " + r"$\beta=0.75$" + "\n"
             f"$+{top_g:.1f}$ points over the top ($t={top_t:.1f}$, {top_w}/{n} seeds) and "
             f"$+{bot_g:.1f}$ over the bottom ($t={bot_t:.1f}$, {bot_w}/{n})",
             fontsize=10.5, pad=12)

fig.tight_layout()
out = sys.argv[1] if len(sys.argv) > 1 else "paper/figures/band_sweep.png"
fig.savefig(out, dpi=200)
print(f"  {len(P[BEST])} seeds per position")
for b, (g, t, w, n) in res.items():
    p = 2 * sum(comb(n, i) for i in range(w, n + 1)) / 2 ** n
    print(f"  beta={BEST} vs {b:<5g}: +{g:5.2f} pt  t={t:5.2f}  {w}/{n}  sign p={min(p,1):.3f}")
print("  ecrit ->", out)
