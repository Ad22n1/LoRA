"""Reentrainement declare de PROTOCOL_free_writes.md : le LoRA libre au rang 1 sur OpenBookQA (Qwen2.5-1.5B), 2e-3, graines 2-6, a l'identique,
en sauvegardant les facteurs au dernier pas, dans ~/lora-runs-fw (un dossier a part : un suivi anterieur a pu reentrainer ce bras sans facteurs).

    python scripts/make_fw_grid.py
"""
import csv
import glob
import os
import sys
from pathlib import Path

import yaml

ref = []
for p in glob.glob(os.path.expanduser("~/lora-runs/*/config.yaml")):
    c = yaml.safe_load(open(p)) or {}; d = os.path.dirname(p)
    if (os.path.basename(str(c.get("data_dir") or "").rstrip("/")) == "openbookqa" and str(c.get("model")) == "Qwen/Qwen2.5-1.5B" and c.get("mode") == "free"
            and c.get("rank") == 1 and abs(float(c.get("lr") or 0) - 2e-3) < 1e-12 and c.get("seed") == 2 and float(c.get("max_grad_norm", 1.0) or 0) == 1.0):
        try:
            if open(d + "/status").read().startswith("DONE") and os.path.exists(d + "/log.csv"):
                ref.append((c, d))
        except OSError:
            pass
if len(ref) != 1:
    sys.exit(f"STOP : run de reference (libre r=1, 2e-3, graine 2, OpenBookQA) trouve {len(ref)} fois au node d'une")
c, d = ref[0]; last = int(list(csv.DictReader(open(d + "/log.csv")))[-1]["step"])
b = dict(c)
for k in ("mode", "lr", "seed"):
    b.pop(k, None)
b.update(save_factor_steps=[last], out_dir=os.path.expanduser("~/lora-runs-fw"))
Path("configs/grids/fw_obqa_free.yaml").write_text("# REENTRAINEMENT DECLARE (PROTOCOL_free_writes.md) : facteurs au dernier pas. Genere par scripts/make_fw_grid.py. 5 runs.\n"
                                                   + yaml.safe_dump({"base": b, "grid": {"mode": ["free"], "lr": [2e-3], "seed": [2, 3, 4, 5, 6]}}, sort_keys=False))
print(f"  fw_obqa_free : libre r=1 a 2e-3, graines 2-6, facteurs au pas {last} (le dernier du run de reference), dans ~/lora-runs-fw ; 5 runs")
