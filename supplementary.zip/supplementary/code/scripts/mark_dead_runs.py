"""PROTOCOL_long_training_addendum.md: marks as FAILED the long-training selection runs left in RUNNING with no job in the queue
(killed without writing a final status). Refuses if ANY job of this user is still in the queue, so a run that is really running is
never touched. Prints how long ago each run last wrote, to tell a time limit from a lost machine.

    python scripts/mark_dead_runs.py --dry     # lists, changes nothing
    python scripts/mark_dead_runs.py           # marks
"""
import getpass
import glob
import os
import subprocess
import sys
import time

import yaml

q = subprocess.run(["squeue", "-h", "-u", getpass.getuser()], capture_output=True, text=True).stdout.strip()
if q:
    sys.exit("STOP : des jobs sont encore dans la file ; rien n'est marque")
dead = []
for p in glob.glob(os.path.expanduser("~/lora-runs/*/config.yaml")):
    c = yaml.safe_load(open(p)) or {}; d = os.path.dirname(p)
    tt = c.get("target_tokens"); tok = tt.get("format") if isinstance(tt, dict) else tt
    if tok != 2_400_000 or c.get("seed") not in (0, 1):
        continue
    try:
        st = open(d + "/status").read()
    except OSError:
        continue
    if st.startswith("RUNNING"):
        last = max(os.path.getmtime(f) for f in glob.glob(d + "/*") if os.path.isfile(f))
        dead.append((d, c, (time.time() - last) / 60, os.path.getmtime(d + "/config.yaml")))
for d, c, ago, t0 in dead:
    ran = (max(os.path.getmtime(f) for f in glob.glob(d + "/*") if os.path.isfile(f)) - t0) / 60
    print(f"  {c.get('mode')} lr={float(c.get('lr')):g} graine {c.get('seed')} : a tourne ~{ran:.0f} min, derniere ecriture il y a {ago:.0f} min")
    if "--dry" not in sys.argv:
        open(d + "/status", "w").write("FAILED tue sans statut final (aucun job dans la file) ; relance a l'identique (PROTOCOL_long_training_addendum.md)\n")
print(f"  {len(dead)} run(s) " + ("a marquer (essai a blanc)" if "--dry" in sys.argv else "marques FAILED"))
