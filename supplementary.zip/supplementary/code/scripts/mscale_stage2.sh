#!/bin/bash
# Apres l'etape 1 (selection) : genere les grilles du RAPPORT au taux retenu par bras, les committe avant leurs runs, puis les lance.
set -u
cd "$HOME/repo" || exit 1
PY="/tmp/lora-$USER/venv/bin/python"; [ -x "$PY" ] || PY=python3
M=$(grep -h "^  model:" configs/grids/mscale_s1_top.yaml | grep -q "Mistral-7B" && echo M7B)
[ -n "$M" ] || { echo "  STOP : modele de l'etape 1 introuvable"; exit 1; }
echo "=== etape 2, rapport, modele $M ==="
"$PY" scripts/make_mscale_grids.py --stage2 "$M" || { echo "  STOP : selection incomplete ; rien n'est lance"; exit 1; }
git add configs/grids/mscale_s2_*.yaml && git commit -qm "echelle Mistral : taux retenus sur les graines 0-1 ; grilles du rapport avant leurs runs" && echo "  ok : committe ($(git log -1 --format=%h))"
git push -q 2>/dev/null; bash scripts/launch_mscale_s2.sh
