"""Analyse A6, post hoc et descriptive (PROTOCOL_analyse_A6.md), sans entrainement. Script committe AVANT son execution.

    python scripts/analyses_v5.py --cuts      # sans PARTITION : pas, tokens, epoques et taux d'apprentissage a chaque coupe du prechauffage
    python scripts/analyses_v5.py --energy    # apres les deux jobs de scripts/submit_grad32.py : energie des bases dans les sous-espaces

Sorties aussi dans analyses_v5.json (une cle par partie).
"""
import csv
import glob
import hashlib
import json
import math
import os
import statistics as st
import sys

import torch
import yaml

REPO = os.path.expanduser("~/repo")
sys.path.insert(0, f"{REPO}/src")
OUT = json.load(open(f"{REPO}/analyses_v5.json")) if os.path.exists(f"{REPO}/analyses_v5.json") else {}
TYPES = ("q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj")
ty = lambda name: name.rsplit(".", 1)[-1]  # noqa: E731


def _tok(c):
    tt = c.get("target_tokens")
    return tt.get("format") if isinstance(tt, dict) else tt


PAIRS = {
    "OpenBookQA, Qwen2.5-1.5B": dict(
        model="Qwen/Qwen2.5-1.5B", cuts={5: 3, 10: 5, 25: 13},
        pred=lambda c: "openbookqa" in str(c.get("data_dir")) and str(c.get("model")).endswith("Qwen2.5-1.5B") and not c.get("answer_only"),
        bases={"warm5": "learned_warm5_obqa_r2", "warm10": "learned_warm10_obqa_r2", "warm25": "learned_warm25_obqa_r2",
               "learned (phase 2, graine 0)": "learned_obqa_r2_s0"},
        grad32="gradk32_obqa_r32", grad2="learned_grad_obqa_r2"),
    "tache de format, Llama-3.2-1B": dict(
        model="meta-llama/Llama-3.2-1B", cuts={5: 14, 10: 28, 25: 69},
        pred=lambda c: c.get("task") == "format" and str(c.get("model")).endswith("Llama-3.2-1B") and _tok(c) == 600000,
        bases={"warm5": "learned_warm5_format_llama_r2", "warm10": "learned_warm10_format_llama_r2", "warm25": "learned_warm25_format_llama_r2",
               "learned (replique B, graine 0)": "learned_format_llama_r2_s0"},
        grad32="gradk32_format_llama_r32", grad2="learned_grad_format_llama_r2")}


def direction_run(P):
    hits = []
    for p in glob.glob(os.path.expanduser("~/lora-runs-warm/*/config.yaml")):
        c = yaml.safe_load(open(p)) or {}; d = os.path.dirname(p)
        if (P["pred"](c) and c.get("mode") == "free" and c.get("rank") == 2 and c.get("seed") == 0 and abs(float(c.get("lr") or 0) - 2e-3) < 1e-12
                and open(d + "/status").read().startswith("DONE")):
            hits.append(d)
    if len(hits) != 1:
        sys.exit(f"ARRET : run de direction du prechauffage trouve {len(hits)} fois au node d'une")
    return hits[0]


def do_cuts():
    from torch.utils.data import DataLoader
    from lorasub.config import RunConfig
    from lorasub.data.loaders import build_dataset, collate
    from lorasub.modeling import load_tokenizer
    from lorasub.train import _cosine_with_warmup     # la formule meme de l'entrainement
    print("==================== A6, partie 1 : les coupes du prechauffage (rejeu exact de l'entrainement, sans modele) ====================")
    OUT["coupes"] = {}
    for pair, P in PAIRS.items():
        d = direction_run(P); c = RunConfig(**(yaml.safe_load(open(d + "/config.yaml")) or {}))
        tok = load_tokenizer(c.model); ds = build_dataset(c.task, c.data_dir, tok, c.max_len, split="train", seed=c.seed)
        g = torch.Generator().manual_seed(c.seed)
        loader = DataLoader(ds, batch_size=c.batch_size, shuffle=True, generator=g, drop_last=False,
                            collate_fn=lambda b: collate(b, tok.pad_token_id), num_workers=0)
        tps = ds.n_tokens / max(1, len(ds)) * c.batch_size * c.grad_accum
        tt = c.target_tokens.get(c.task) if isinstance(c.target_tokens, dict) else c.target_tokens
        if c.max_steps:                                # la regle meme de l'entrainement (train.py)
            total = c.max_steps
        elif tt:
            total = max(1, math.ceil(tt / tps))
        else:
            total = max(1, int(round(c.epochs * math.ceil(len(loader) / c.grad_accum))))
        warmup = int(c.warmup_ratio * total)
        at, step, micro, seen = {}, 0, 0, 0
        while step < total:
            for batch in loader:                       # le meme iterateur que l'entrainement : nouvelle permutation a chaque epoque
                seen += int((batch["labels"] != -100).sum()); micro += 1
                if micro % c.grad_accum != 0:
                    continue
                step += 1; at[step] = seen
                if step >= total:
                    break
        logged = {int(r["step"]): int(r["tokens_seen"]) for r in csv.DictReader(open(d + "/log.csv"))}
        bad = {s: (logged[s], at.get(s)) for s in logged if at.get(s) != logged[s]}
        if bad:
            sys.exit(f"ARRET : {pair} : le rejeu ne redonne pas les tokens journalises aux pas {sorted(bad)[:5]} ({list(bad.values())[:3]})")
        print(f"  {pair} : {total} pas en tout, dont {warmup} de montee ; taux de pointe {c.lr:g} ; {len(ds)} sequences, {ds.n_tokens:,} tokens supervises "
              f"par epoque ; rejeu verifie sur les {len(logged)} pas journalises")
        rows = {}
        for k, s in sorted(P["cuts"].items()):
            lr_last = c.lr * _cosine_with_warmup(s - 1, total, warmup); lr_next = c.lr * _cosine_with_warmup(s, total, warmup)
            rows[f"{k} %"] = {"pas": s, "sur": total, "tokens": at[s], "epoques": at[s] / ds.n_tokens, "lr_derniere_mise_a_jour": lr_last,
                              "lr_atteint_apres_la_coupe": lr_next, "fraction_du_pic": lr_last / c.lr}
            print(f"      coupe a {k:2d} % : pas {s:3d} / {total} ; {at[s]:>7,} tokens supervises ; {at[s] / ds.n_tokens:.3f} epoque ; "
                  f"taux de la derniere mise a jour {lr_last:.3e} ({100 * lr_last / c.lr:.1f} % du pic), puis {lr_next:.3e}")
        OUT["coupes"][pair] = {"pas_total": total, "pas_de_montee": warmup, "taux_de_pointe": c.lr, "tokens_par_epoque": ds.n_tokens, "coupes": rows,
                               "run_de_direction": os.path.basename(d)}


def do_energy():
    from safetensors.torch import load_file
    from lorasub.spectral import load_svd
    print("==================== A6, partie 2 : energie des bases dans les sous-espaces du gradient initial et dans les bandes de W0 ====================")
    print("  chiffre = energie ||P Q||_F^2 / 2 d'une base Q de rang 2 dans le sous-espace ; entre parentheses, le rapport a la reference")
    print("  aleatoire (k / d_out pour le top-k du gradient, 2 / d_out pour les bandes de rang 2) ; medianes sur les couches")
    svdroot = f"/tmp/lora-{os.environ.get('USER', '')}/svd"; OUT["energie"] = {}
    for pair, P in PAIRS.items():
        f32 = f"{REPO}/bases/{P['grad32']}.safetensors"
        if not os.path.exists(f32):
            print(f"  {pair} : bases du gradient a 32 directions absentes ({f32}) ; lancez d'abord scripts/submit_grad32.py"); continue
        G = load_file(f32); G2 = load_file(f"{REPO}/bases/{P['grad2']}.safetensors")
        chk = [float((G[n][:, :2].double().T @ G2[n].double()).pow(2).sum() / 2) for n in G2 if n in G]
        sha = hashlib.sha256(open(f32, "rb").read()).hexdigest()
        print(f"  {pair} : controle, les 2 premieres des 32 directions redonnent les bases de `grad` : recouvrement median {st.median(chk):.4f} "
              f"(min {min(chk):.4f}) ; SHA-256 {sha[:16]}...")
        res = {"controle_recouvrement_median": st.median(chk), "sha256_gradient_32": sha}
        for label, fname in P["bases"].items():
            p = f"{REPO}/bases/{fname}.safetensors"
            if not os.path.exists(p):
                print(f"    {label} : base absente ({fname})"); continue
            B = load_file(p); per = {}
            for n, Q in B.items():
                Q = Q.double(); d = Q.shape[0]; Gn = G[n].double()
                e = load_svd(svdroot, P["model"], n); U = e.U.double(); m = e.S.numel()
                vals = {f"gradient top-{k}": (float((Gn[:, :k].T @ Q).pow(2).sum() / 2), k / d) for k in (2, 8, 32)}
                vals["bande dominante"] = (float((U[:, :2].T @ Q).pow(2).sum() / 2), 2 / d)
                vals["bande mineure"] = (float((U[:, m - 2:m].T @ Q).pow(2).sum() / 2), 2 / d)
                for key, (v, ref) in vals.items():
                    per.setdefault(key, {}).setdefault(ty(n), []).append((v, v / ref, ref))
            tab = {key: {t: {"energie": st.median(x[0] for x in v), "rapport": st.median(x[1] for x in v), "reference": st.median(x[2] for x in v)}
                         for t, v in dt.items()} for key, dt in per.items()}
            res[label] = tab
            print(f"    {label} :")
            for key, dt in tab.items():
                print(f"      {key:16s} : " + "  ".join(f"{t.replace('_proj', '')} {dt[t]['energie']:.3f} ({dt[t]['rapport']:.0f}x)" for t in TYPES if t in dt))
        OUT["energie"][pair] = res


if __name__ == "__main__":
    acts = {"--cuts": do_cuts, "--energy": do_energy}
    todo = [a for a in sys.argv[1:] if a in acts]
    if not todo:
        sys.exit(__doc__)
    for a in todo:
        acts[a](); print()
    json.dump(OUT, open(f"{REPO}/analyses_v5.json", "w"), indent=1, default=float)
    print(f"  sorties enregistrees : {REPO}/analyses_v5.json")
