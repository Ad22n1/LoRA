"""Curvature of the loss in each arm's subspace — the last mechanism left standing.

WHY THIS AND NOT SOMETHING ELSE. Five candidate explanations for the displacement of the optimal
learning rate have been measured and have fallen:

* the gradient NORM (12/09) — AdamW divides by the running RMS of the gradient, so a gradient a
  hundred times smaller takes the same step. Verified, then re-proposed by mistake on 15/09;
* numerical conditioning (13/09) — refuted, sigma_min/sigma_max is 1.86e-7 at worst, not 3e-9;
* Davis-Kahan subspace instability (15/09) — refuted three ways: the bottom band is not more
  degenerate (p = 0.30), its gap relative to the LOCAL scale is LARGER (p = 3.6e-8, the wrong
  direction), and the bound is vacuous for both arms (237 and 24, against a useful bound of < 1);
* the band gradient SNR (15/09) — its prediction was pre-registered three times and is refuted:
  18.05 for bottom against 19.27 for top, indistinguishable, because the numerator and the
  denominator both scale by 2.2;
* the share of the layer's OUTPUT each band carries — tautological, it goes as sigma^2.

Curvature is what AdamW does NOT normalise away. Adam rescales by the gradient's second moment, not
by the local Hessian: two subspaces with the same gradient scale and curvatures differing by a
factor ten need learning rates differing by a factor ten. Lee et al. measure exactly that for PiSSA
and use it to explain why it needs a rate ten times lower. Our displacement is a factor five between
`bottom` and the other three, REPRODUCED ON TWO ARCHITECTURES — so unlike the score deficit, it is
the robust effect, and it is the one worth explaining.

WHAT IS COMPUTED. The largest eigenvalue of the loss Hessian RESTRICTED to the trainable parameters
of each arm, by power iteration on Hessian-vector products (double backward). Restricted, because
the full Hessian of a 1.24 G-parameter model is not the question: what sets an arm's usable learning
rate is the curvature along the directions it can actually move in.

PREDICTION, WRITTEN BEFORE RUNNING — and this one is falsifiable in a way the SNR was not, because
it predicts an ORDER and a RATIO:

    curvature(bottom) > curvature(random) ~ curvature(top),  by roughly the ratio of their optimal
    learning rates, i.e. a factor of about five.

If the curvatures are equal, curvature does not explain the displacement either, and the paper says
that six mechanisms were measured and none accounts for it — which is a result, and an unusual one
to be able to state.

PRECISION. The base model is bf16 but the LoRA factors are fp32 (see `LoRALinear`), and the Hessian
is taken with respect to those factors only — so the curvature is computed in the same precision the
optimiser sees. The bf16 activations still limit the accuracy of the second derivative; that is why
the reported quantity is a median over several batches and why the prediction is about a RATIO of
about five, not about a third decimal.

WHAT THIS CANNOT SETTLE. Curvature at initialisation is not curvature along the trajectory, and the
optimal rate is a property of the whole run. A single-point measurement is suggestive; the honest
claim is about the initial landscape, not about what happens after a hundred steps.
"""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import os  # noqa: E402
import torch  # noqa: E402
from torch.utils.data import DataLoader  # noqa: E402

from lorasub.data.loaders import build_dataset, collate  # noqa: E402
from lorasub.lora import inject_lora, load_factors_into  # noqa: E402
from lorasub.modeling import load_model, load_tokenizer  # noqa: E402


def top_eigenvalue(loss_fn, params, iters: int = 20, tol: float = 1e-3,
                   shift: float | None = None, restarts: int = 1) -> tuple[float, int, float, bool]:
    """Largest Hessian eigenvalue by SHIFTED power iteration on Hessian-vector products.

    Plain power iteration converges to the eigenvalue of largest MODULUS, which is not the largest
    eigenvalue when the Hessian is indefinite — and at initialisation it is. The first version of
    this script reported a median curvature of -5.4 for the free arm: a maximum cannot be negative,
    so the iteration had locked onto the most negative direction. `top` ran from -26.3 to +43.0
    across batches and was affected too; only `bottom`, whose values were all positive, was safe.
    The ratio of nine between them was therefore not established.

    The fix is standard: iterate on H + cI, whose eigenvalues are those of H shifted by c. Choose c
    large enough that every eigenvalue is positive and the largest one also has the largest modulus,
    then subtract c. We estimate c from a first unshifted pass — |lambda| of that pass bounds the
    spectral node — and take twice it.

    Returns (eigenvalue, iterations used, shift used).
    """
    def _power(c: float) -> tuple[float, int]:
        v = [torch.randn_like(p) for p in params]
        n = torch.sqrt(sum((x * x).sum() for x in v))
        v = [x / n for x in v]
        lam, lam_prev, used = 0.0, None, 0
        for it in range(iters):
            loss = loss_fn()
            g = torch.autograd.grad(loss, params, create_graph=True)
            gv = sum((gi * vi).sum() for gi, vi in zip(g, v))
            hv = torch.autograd.grad(gv, params, retain_graph=False)
            hv = [h.detach() + c * x for h, x in zip(hv, v)]      # (H + cI) v
            lam = float(sum((h * x).sum() for h, x in zip(hv, v)))
            n = torch.sqrt(sum((h * h).sum() for h in hv))
            if float(n) == 0.0:
                return c, it + 1, False
            v = [h / n for h in hv]
            used = it + 1
            # The convergence test must be on the SHIFTED-BACK eigenvalue, not on the raw Rayleigh
            # quotient. With a shift near 1 and a true eigenvalue near 4e-4, `tol * max(1, |lam|)`
            # is 1e-3 — LARGER than the quantity being estimated — so the loop exits on the first
            # iteration and returns whatever the random start gave. That produced exact zeros,
            # negative maxima and a standard deviation larger than the median, on four of five arms
            # and on both models. Only `bottom` on Qwen (1.1e-2) sat above the tolerance and was
            # actually resolved.
            est = lam - c
            if lam_prev is not None:
                prev = lam_prev - c
                scale = max(abs(est), abs(prev), 1e-12)
                if abs(est - prev) <= tol * scale:
                    break
            lam_prev = lam
        else:
            # the loop ran to completion without the break: not converged
            return lam, used, False
        return lam, used, True

    if restarts > 1:
        # WHY THE MAX OVER RESTARTS, NOT THE MEDIAN. The Rayleigh quotient v^T H v is bounded ABOVE
        # by lambda_max for every v: an iteration that stalls UNDERestimates, it can never come back
        # too high. So among several random starts the largest value is the best estimate, and a
        # small one carries no information beyond "this start did not find the top direction".
        #
        # This is not a refinement. On `bottom` the five batches of a single seed returned values
        # between 0.0005 and 357 — a factor of half a million — with `converged` true on all five,
        # and the median landed at 173, 249 or 331 depending on how many batches fell on each side.
        # That is how the published ratio moved from 12.04 to 8.98 between two runs of this script.
        # The failure mode is the one the shift comment below predicts: when the unshifted pass
        # stalls, the shift collapses with it and the shifted pass stalls the same way.
        best, best_used, best_shift, any_ok = None, 0, 0.0, False
        for _ in range(restarts):
            lam_i, used_i, shift_i, ok_i = top_eigenvalue(loss_fn, params, iters=iters, tol=tol,
                                                          shift=shift, restarts=1)
            any_ok |= ok_i
            if best is None or lam_i > best:
                best, best_used, best_shift = lam_i, used_i, shift_i
        return best, best_used, best_shift, any_ok

    if shift is None:
        # An unshifted pass bounds the spectral node: |lambda_1| >= |lambda_i| for all i, so
        # 3|lambda_1| leaves H + cI positive definite with margin. The additive 1e-6 only keeps the
        # shift away from exactly zero.
        #
        # This depends on the unshifted pass converging, and that is a real weakness: when it
        # stalls, the shift collapses with it. A probe-based bound (max ||Hu|| over random u) was
        # tried and made convergence WORSE on a known spectrum, because a larger shift needs more
        # iterations — so it is not used. The failure mode remains visible in the logs as a value
        # near 1e-3 recurring as the per-batch minimum across unrelated arms.
        lam0, it0, ok0 = _power(0.0)
        shift = 3.0 * abs(lam0) + 1e-6
    lam, used, ok = _power(shift)
    # Report whether BOTH passes converged. A measurement where the unshifted pass ran out of
    # iterations has a shift derived from a number that means nothing, and the value that comes
    # back is not a curvature — it must not enter a CSV looking like one.
    return lam - shift, used, shift, bool(ok0 and ok)


def find_trajectory_factors(runs_dir: str, model_id: str, task: str, rank: int, mode: str,
                            seed: int, step: str, lr=None, max_grad_norm=None) -> str:
    """Path of the factors saved at `step` of a real run of this arm.

    WHY. Curvature at initialisation is not curvature where a run diverges, and this file's own
    docstring says the honest claim is about the initial landscape. The collapse we bracket happens
    after ~274 steps; reading lambda_max there is what makes the statement about the landscape the
    optimiser actually walks.

    Raises when nothing matches: silently measuring at initialisation while the CSV column says
    `from_step=274` would be worse than failing.
    """
    import glob

    import yaml

    # SORTED, and the first match is kept deterministically. `glob.glob` returns directory
    # order, so with a replicated cell two runs of this script read two different runs and
    # report two different curvatures for the same cell. The trajectory grid has two runs
    # per (arm, seed); which one we read must not depend on the file system.
    for cfg_path in sorted(glob.glob(os.path.join(os.path.expanduser(runs_dir), "*",
                                                  "config.yaml"))):
        y = yaml.safe_load(open(cfg_path)) or {}
        if (str(y.get("model")) == model_id and y.get("task") == task
                and int(y.get("rank", -1)) == rank and y.get("mode") == mode
                and int(y.get("seed", -1)) == seed
                and (lr is None or abs(float(y.get("lr", 0)) - lr) < 1e-12)
                and (max_grad_norm is None
                     or abs(float(y.get("max_grad_norm", 0)) - max_grad_norm) < 1e-6)
                # THE REPORTED POPULATION ONLY. Without these three, a 3- or 5-module ablation run,
                # a norm-rescaled run or an unsalted draw of the same (arm, seed, rate) could be
                # loaded instead, silently: the motif of every drift this project has had.
                and len(y.get("target_modules") or []) == 7
                and y.get("update_norm_target") is None
                and (mode not in ("random", "random_ortho") or y.get("subspace_salted", True) is True)):
            f = os.path.join(os.path.dirname(cfg_path), f"factors_{step}.safetensors")
            if os.path.exists(f):
                print(f"  [{mode} seed={seed}] factors from {os.path.basename(os.path.dirname(cfg_path))}")
                return f
    raise SystemExit(f"no run with factors_{step} for {mode} seed={seed} lr={lr}: "
                     f"measure at initialisation, or save that step first")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--model", default="meta-llama/Llama-3.2-1B")
    ap.add_argument("--data_dir", required=True)
    ap.add_argument("--svd_cache", required=True)
    ap.add_argument("--task", default="format")
    ap.add_argument("--rank", type=int, default=2)
    ap.add_argument("--modes", default="bottom,top,random,random_ortho,free")
    ap.add_argument("--seeds", default="0,1")
    ap.add_argument("--from_step", default=None,
                    help="measure on the factors saved at this step instead of at initialisation, "
                         "e.g. --from_step 274 for the end of a format run. Needs --lr and "
                         "--runs_dir to find the run whose trajectory to read.")
    ap.add_argument("--runs_dir", default="~/lora-runs")
    ap.add_argument("--lr", type=float, default=None,
                    help="with --from_step: the rate of the run to read the factors from")
    ap.add_argument("--max_grad_norm", type=float, default=None,
                    help="with --from_step: restrict to runs with this clipping threshold")
    ap.add_argument("--batch", type=int, default=4)
    ap.add_argument("--max_len", type=int, default=384,
                    help="must match the training runs: 384, not the 512 default elsewhere")
    ap.add_argument("--n_batches", type=int, default=3,
                    help="curvature is averaged over this many batches; a single batch is a very "
                         "noisy estimate of the loss surface")
    ap.add_argument("--restarts", type=int, default=5,
                    help="random starts per batch; the LARGEST Rayleigh quotient is kept, since a "
                         "stalled power iteration underestimates lambda_max and can never exceed "
                         "it. With 1 restart, `bottom` returned values between 5e-4 and 357 on the "
                         "same seed and the median moved the published ratio from 12.0 to 9.0.")
    ap.add_argument("--iters", type=int, default=60,
                    help="power iterations per measurement; the shifted quotient needs "
                         "more of them than the unshifted one to resolve a small eigenvalue")
    ap.add_argument("--out", default="~/lora-analysis/curvature.csv")
    a = ap.parse_args()

    dev = "cuda" if torch.cuda.is_available() else "cpu"
    tok = load_tokenizer(a.model)
    ds = build_dataset(a.task, a.data_dir, tok, a.max_len, split="train", seed=0)
    dl = DataLoader(ds, batch_size=a.batch, shuffle=False,
                    collate_fn=lambda b: collate(b, tok.pad_token_id or 0))
    batches = [b for _, b in zip(range(a.n_batches), dl)]

    rows = []
    for mode in a.modes.split(","):
        for seed in [int(x) for x in a.seeds.split(",")]:
            # The fused attention kernels have no SECOND derivative: a double backward on
            # scaled_dot_product_attention raises
            # "derivative for aten::_scaled_dot_product_efficient_attention_backward is not
            # implemented". Hessian-vector products therefore need the eager attention path, which
            # is slower but differentiable twice. This changes the implementation, not the
            # function: the loss and its gradient are identical, only the kernel differs.
            model = load_model(a.model, device=dev, attn_implementation="eager")
            inject_lora(model, r=a.rank, mode=mode, cache_dir=a.svd_cache, model_id=a.model,
                        seed=seed, subspace_salted=True)
            if a.from_step is not None:
                # `load_factors_into` already knows the on-disk naming (<module>.A / <module>.B),
                # which does NOT match the model's parameter names: matching by parameter name
                # would have loaded nothing and measured the initialisation instead.
                src = find_trajectory_factors(a.runs_dir, a.model, a.task, a.rank, mode, seed,
                                              a.from_step, a.lr, a.max_grad_norm)
                load_factors_into(model, src)
                print(f"  [{mode} seed={seed}] factors from {os.path.basename(os.path.dirname(src))}"
                      f"/{os.path.basename(src)}", flush=True)
            model.train()
            # only the trainable factors: what sets an arm's usable rate is the curvature along the
            # directions it can move in, not the curvature of the frozen 1.24 G parameters
            params = [p for p in model.parameters() if p.requires_grad]
            n_par = sum(p.numel() for p in params)

            lams, convs, shifts = [], [], []
            for b in batches:
                b = {k: v.to(dev) for k, v in b.items()}

                def loss_fn(_b=b):
                    # `out.loss` is the mean over the supervised tokens of this batch, which is
                    # exactly what the optimiser minimises: `token_weighted_loss` is False in every
                    # run of the database and sits in the run id, so the two forms can never be
                    # silently averaged. Measuring curvature of a different objective than the one
                    # trained would make the comparison with the optimal learning rate meaningless.
                    return model(**_b).loss

                lam, used, sh, ok = top_eigenvalue(loss_fn, params, iters=a.iters,
                                                   restarts=a.restarts)
                lams.append(lam)
                convs.append(ok)
                shifts.append(sh)
            # Keep only the batches where BOTH power passes converged. A batch that ran out of
            # iterations returns a number, and that number is indistinguishable from a curvature in
            # the CSV — which is how `top` on Qwen came to read 1e-3 with negative minima while its
            # neighbours read 40, and how the same ~1e-3 turned up as the per-batch minimum on six
            # unrelated cells.
            good = [x for x, c in zip(lams, convs) if c]
            n_bad = len(lams) - len(good)
            use = good if good else lams
            us = sorted(use)
            med = us[len(us) // 2]
            rows.append(dict(model=a.model, task=a.task, mode=mode, rank=a.rank, seed=seed,
                             n_trainable=n_par, curvature_median=med,
                             curvature_min=us[0], curvature_max=us[-1],
                             n_batches=len(use), n_batches_dropped=n_bad,
                             converged=bool(good), shift_median=sorted(shifts)[len(shifts)//2],
                             iters=a.iters, restarts=a.restarts, max_len=a.max_len,
                             # WHICH POINT of the trajectory: without it a curvature at step 274
                             # and one at initialisation land in the same column of the same CSV
                             from_step=(a.from_step if a.from_step is not None else "init"),
                             traj_lr=a.lr))
            flag = "" if not n_bad else f"  ** {n_bad}/{len(lams)} lots non converges, ecartes"
            if not good:
                flag = f"  *** AUCUN lot converge sur {len(lams)} — valeur NON FIABLE"
            print(f"  {mode:14s} seed={seed}  lambda_max median {med:.4g}  "
                  f"[{us[0]:.4g}; {us[-1]:.4g}]  (shift {sorted(shifts)[len(shifts)//2]:.3g}){flag}",
                  flush=True)
            del model, params
            torch.cuda.empty_cache()

    out = Path(a.out).expanduser()
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"\nwrote {len(rows)} rows -> {out}")

    try:
        import pandas as pd
    except ImportError:
        return
    d = pd.DataFrame(rows)
    print("\n=== curvature by arm (median over seeds and batches) ===")
    agg = d.groupby("mode")["curvature_median"].agg(["median", "count"]).round(4)
    print(agg.to_string())
    ref = agg.loc["top", "median"] if "top" in agg.index else None
    if ref:
        print("\n  ratio to `top`, to compare with the ratio of optimal learning rates:")
        for m in agg.index:
            print(f"    {m:14s} {agg.loc[m, 'median'] / ref:6.2f}x")
        print("\n  optimal learning rates: bottom 2e-3, top/random/random_ortho 1e-2 -> a factor 5.")
        print("  The prediction is that curvature(bottom) exceeds the others by roughly that much.")
        print("  Equal curvatures mean curvature does not explain the displacement either — which")
        print("  would make six measured mechanisms and no explanation, and that is itself a result.")


if __name__ == "__main__":
    main()
