"""Where does the FREE arm put its update in the spectrum of W0? Batch version, from saved factors.

    python scripts/free_arm_spectrum.py --runs_dir ~/lora-runs --svd_cache $SHARED/svd \
        [--task format] [--out ~/lora-analysis/free_arm_spectrum.csv]

Why this is the cheapest and possibly most telling measurement in the project. The toy model showed
that, left unconstrained, LoRA places 0.99 of its update energy in the band where the target lives.
On the real model nobody has looked. If the free arm — which beats every constrained arm by 20 to 50
points — concentrates its dW in the MINOR directions of W0, that is direct support for H2 that depends
on no constrained arm, no learning rate, no budget confound. If its energy sits at the null-reference
level in every band, the update lives nowhere in particular in the spectrum of W0 — which is H4, and
consistent with the intruder dimensions of Shuttleworth et al. If it sits OUTSIDE span(U)/span(V), the
whole spectral framing is beside the point.

Reads the last ``factors_<step>.safetensors`` of every `free` run; no PARTITION, no re-run.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd
import yaml
from safetensors.torch import load_file

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from lorasub import expand_path  # noqa: E402
from lorasub.spectral import band_energies, decile_bands, load_svd, null_reference, parse_module_name  # noqa: E402


def last_factor_file(run_dir: Path) -> Path | None:
    """Last saved factor file, or None when the only checkpoint is step 0 (A = 0, so dW = 0 by
    construction: that is the absence of a measurement, not a measurement of zero)."""
    steps = [(int(p.stem.split("_")[1]), p) for p in run_dir.glob("factors_*.safetensors")
             if p.stem.split("_")[1].isdigit()]
    if not steps:
        return None
    last_step, path = max(steps)
    return None if last_step == 0 else path


def analyse_free_run(run_dir: Path, svd_cache: str, ranks=(1, 2, 4, 16)) -> list[dict]:
    if not (run_dir / "results.csv").exists():     # never finished: its factors describe nothing
        return []
    cfg_path = run_dir / "config.yaml"
    if not cfg_path.exists():
        return []
    with open(cfg_path) as f:
        cfg = yaml.safe_load(f)
    if cfg.get("mode") != "free":
        return []
    fpath = last_factor_file(run_dir)
    if fpath is None:
        return []
    rank = int(cfg["rank"])
    scaling = float(cfg.get("alpha") or rank) / rank
    t = load_file(str(fpath), device="cpu")
    names = sorted({k.rsplit(".", 1)[0] for k in t if k.endswith(".A")})
    rows = []
    for name in names:
        try:
            svd = load_svd(svd_cache, cfg["model"], name, device="cpu")
        except FileNotFoundError:
            continue
        A, B = t[f"{name}.A"].float() * scaling, t[f"{name}.B"].float()   # dW = scaling * B A
        layer, mtype = parse_module_name(name)
        bands = list(decile_bands()) + [f"top:{r}" for r in ranks if r <= svd.m] + \
            [f"bottom:{r}" for r in ranks if r <= svd.m]
        e = band_energies(A, B, svd, bands)      # energies are scale-invariant; scaling kept for dw_norm
        common = dict(run_id=run_dir.name, model=cfg["model"], task=cfg.get("task"), rank=rank,
                      lr=cfg.get("lr"), seed=cfg.get("seed"), layer=layer, module_type=mtype,
                      dw_norm=float((B @ A).norm()))
        for band in bands:
            left, right = e[band]
            rows.append(dict(**common, band=band, side="left", energy=left,
                             null=null_reference(svd, band, "left")))
            rows.append(dict(**common, band=band, side="right", energy=right,
                             null=null_reference(svd, band, "right")))
        rows.append(dict(**common, band="_outside", side="left", energy=e["_outside_left"], null=0.0))
        rows.append(dict(**common, band="_outside", side="right", energy=e["_outside_right"], null=0.0))
    return rows


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs_dir", required=True)
    ap.add_argument("--svd_cache", required=True)
    ap.add_argument("--task", default=None)
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    rows: list[dict] = []
    for d in sorted(Path(expand_path(a.runs_dir)).glob("*/")):
        rows.extend(analyse_free_run(d, expand_path(a.svd_cache)))
    if not rows:
        print("no free run with saved factors found")
        return
    df = pd.DataFrame(rows)
    if a.task:
        df = df[df.task == a.task]
    out = Path(expand_path(a.out)) if a.out else Path(expand_path(a.runs_dir)).parent / "free_arm_spectrum.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out, index=False)
    print(f"{df.run_id.nunique()} free runs, {len(df)} (run, module, band, side) rows\n")

    dec = df[df.band.str.startswith("frac:")].copy()
    dec["over_null"] = dec.energy / dec.null.replace(0, float("nan"))
    print("ENERGY OF THE FREE ARM'S dW PER DECILE OF THE SPECTRUM OF W0, relative to the null reference")
    print("(1.0 = no preference; >1 = the update concentrates there; the toy gave ~8x in the target band)")
    piv = dec.pivot_table(index=["task", "rank", "side"], columns="band", values="over_null", aggfunc="mean")
    piv = piv[[c for c in sorted(piv.columns, key=lambda b: float(b.split(":")[1].split("-")[0]))]]
    print(piv.round(2).to_string())

    print("\ntop-r vs bottom-r vs OUTSIDE span, by task and rank (left side):")
    sub = df[df.side == "left"]
    for (task, rank), g in sub.groupby(["task", "rank"]):
        tr = g[g.band == f"top:{rank}"].energy.mean()
        br = g[g.band == f"bottom:{rank}"].energy.mean()
        nl = g[g.band == f"top:{rank}"].null.mean()
        outside = g[g.band == "_outside"].energy.mean()
        print(f"  {task:7} r={rank:<3} top:{rank}={tr:.3f}  bottom:{rank}={br:.3f}  (null {nl:.4f})  "
              f"outside span(U)={outside:.3f}")
    print("\nby module type, bottom-r energy over null (left):")
    m = sub[sub.band.str.startswith("bottom:")].copy()
    m["over_null"] = m.energy / m.null.replace(0, float("nan"))
    print(m.pivot_table(index="module_type", columns=["task", "rank"], values="over_null",
                        aggfunc="mean").round(2).to_string())
    print(f"\nwritten to {out}")


if __name__ == "__main__":
    main()
