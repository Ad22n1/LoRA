#!/bin/bash
# Apres chaque SONDE (PROTOCOL_scale.md) : applique la regle ecrite d'avance. 7B ou 3B -> grilles de SELECTION committees, puis lancees ;
# PROBE_3B -> sonde du 3B committee, puis lancee ; NONE -> pas de campagne. Aucune decision a la main.
set -u
cd "$HOME/repo" || exit 1
PY="/tmp/lora-$USER/venv/bin/python"; [ -x "$PY" ] || PY=python3
out=$("$PY" scripts/probe_report.py 2>&1); echo "$out" | sed 's/^/  /'
D=$(echo "$out" | grep -oE "^DECISION : (7B|3B|PROBE_3B|NONE)$" | awk '{print $3}')
case "$D" in
  7B|3B)
    echo "=== modele retenu par la regle : $D -> etape 1, selection ==="
    "$PY" scripts/make_scale_grids.py --stage1 "$D" || { echo "  STOP : generation refusee"; exit 1; }
    git add configs/grids/scale_s1_*.yaml && git commit -qm "echelle : modele $D retenu par la regle (sonde lue) ; grilles de selection avant leurs runs" && echo "  ok : committe ($(git log -1 --format=%h))"
    git push -q 2>/dev/null; bash scripts/launch_scale_s1.sh ;;
  PROBE_3B)
    echo "=== le 7B ne passe pas la regle -> seconde sonde, sur Qwen2.5-3B ==="
    "$PY" scripts/make_scale_grids.py --probe 3B || exit 1
    git add configs/grids/scale_probe.yaml && git commit -qm "echelle : le 7B echoue a la regle ; sonde du 3B avant son run" && echo "  ok : committe ($(git log -1 --format=%h))"
    git push -q 2>/dev/null; bash scripts/launch_scale_probe.sh
    echo "  quand elle aura fini : bash scripts/scale_go.sh" ;;
  NONE) echo "=== aucune des deux sondes ne passe la regle : PAS DE CAMPAGNE ; le papier part sans elle ===" ;;
  *) echo "  STOP : pas de decision lisible"; exit 1 ;;
esac
