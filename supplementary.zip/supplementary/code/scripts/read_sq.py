"""PROTOCOL_square_modules.md: freezing A against freezing B at equal parameter count, on q_proj and o_proj only (square on Llama). No PARTITION.

    python scripts/read_sq.py 2>&1 | grep -vE "FutureWarning|pd.concat"

Each arm's rate selected on seeds 130-131 (validation) among five; reported seeds 140-144. Tests: (1) dual_X - X, t > 3.495;
(2) the band-gap shrinkage when A is frozen, t > 2.776, read only if the frozen gap is at least 2 points. The parameter-count reading
rests on the dominant band; the minor band of q and o is degenerate on Llama and is reported with that caveat.
"""
import csv
import glob
import json
import math
import os
import random
import re
import statistics as st

import yaml

R = os.path.expanduser("~/lora-runs")
LLAMA, QWEN = "meta-llama/Llama-3.2-1B", "Qwen/Qwen2.5-1.5B"
S_SEL, S_REP = (0, 1), [2, 3, 4, 5, 6]


def tokens(c):
    t = c.get("target_tokens")
    return t.get(c.get("task")) if isinstance(t, dict) else t


RUNS = []
for p in glob.glob(R + "/*/config.yaml"):
    c = yaml.safe_load(open(p)) or {}
    d = os.path.dirname(p)
    try:
        if not open(d + "/status").read().startswith("DONE"):
            continue
        RUNS.append((c, json.load(open(d + "/metrics.json")), d))
    except OSError:
        continue


def clipped(c):
    """Gradient clipping at 1.0, the paper's setting. A noclip grid reran the same cells without clipping (collect()'s
    docstring); mixing both put two runs per seed in the frozen cells and moved G from 12.41 to 13.53 (26/09)."""
    v = c.get("max_grad_norm", 1.0)
    return v is not None and float(v) == 1.0


def seven(c):
    tm = c.get("target_modules")
    return tm is None or len(tm) == 7


def cell(pred, mode, rank, lr, seeds, key):
    """{seed: value}; several runs of one seed are averaged and flagged."""
    by = {}
    for c, m, d in RUNS:
        if (pred(c) and clipped(c) and c.get("mode") == mode and c.get("rank") == rank and abs(float(c.get("lr") or 0) - lr) < 1e-12
                and c.get("seed") in seeds and key in m and c.get("update_norm_target") in (None, "")):
            by.setdefault(c["seed"], []).append((m[key], d))
    dup = {s: len(v) for s, v in by.items() if len(v) > 1}
    if dup:   # say what separates the duplicates, so that the next filter is written from evidence
        s0 = sorted(dup)[0]; cfgs = [yaml.safe_load(open(d + "/config.yaml")) or {} for _, d in by[s0]]
        keys = sorted(k for k in set().union(*cfgs) if k not in ("run_id", "out_dir") and len({str(c_.get(k)) for c_ in cfgs}) > 1)
        dup["differ"] = {k: [c_.get(k) for c_ in cfgs] for k in keys} or "configs identiques"
    return {s: st.mean(x for x, _ in v) for s, v in by.items()}, dup, {s: [d for _, d in v] for s, v in by.items()}


def select(pred, mode, rank, lrs, key):
    full = {}
    for lr in lrs:
        v, _, _ = cell(pred, mode, rank, lr, S_SEL, key)
        if len(v) == 2: full[lr] = st.mean(v.values())
    if len(full) < len(lrs):
        return None, f"INCOMPLET ({len(full)}/{len(lrs)} taux avec leurs deux graines)"
    best = max(full, key=full.get)
    edge = best in (lrs[0], lrs[-1])
    return best, "  ".join(f"{lr:g}:{full[lr]:.3f}" for lr in lrs) + f"  -> {best:g}" + ("  AU BORD" if edge else "")



MODULES = ["q_proj", "o_proj"]
S_SEL, S_REP = (130, 131), [140, 141, 142, 143, 144]
T4, BONF2 = 2.776, 3.495
sq_fmt = lambda c: (c.get("task") == "format" and str(c.get("model")) == LLAMA and tokens(c) == 600000 and list(c.get("target_modules") or []) == MODULES  # noqa: E731
                    and c.get("max_len") == 384 and c.get("batch_size") == 2 and c.get("grad_accum") == 16)
G5 = [2e-3, 5e-3, 1e-2, 2e-2, 5e-2]
ARMS = {"top": (2, G5), "bottom": (2, G5), "dual_top": (2, G5), "dual_bottom": (2, G5), "free": (1, [5e-4, 1e-3, 2e-3, 5e-3, 1e-2])}


def gpu_of(d):
    try:
        with open(d + "/results.csv", newline="") as f:
            return (next(csv.DictReader(f)).get("PARTITION") or "?").replace("NVIDIA ", "").replace(" Generation", "")
    except (OSError, StopIteration):
        return "?"


def pt(d):
    m = st.mean(d); se = st.stdev(d) / len(d) ** 0.5
    return m, m - T4 * se, m + T4 * se, (m / se if se > 0 else float("inf"))


print("==================== geler A contre geler B a parametres egaux : q_proj et o_proj seuls (tache de format, Llama, rang 2) ====================")
print("  parametres par module : B gele (r=2) 2 x 2048 = 4096 ; A gele (r=2) 2 x 2048 = 4096 ; free (r=1) 1 x (2048 + 2048) = 4096 -> budgets egaux")
V, gpus, bad, RDIRS = {}, set(), [], {}
for mode, (rank, lrs) in ARMS.items():
    b, txt = select(sq_fmt, mode, rank, lrs, "val_format_parsed")
    print(f"  selection {mode:12s} : {txt}")
    if b is None:
        bad.append(mode); continue
    v, dup, dirs = cell(sq_fmt, mode, rank, b, S_REP, "format_parsed")
    if len(v) != 5 or dup:
        bad.append(mode); continue
    V[mode] = v; gpus |= {gpu_of(dirs[s][0]) for s in S_REP}; RDIRS[mode] = [dirs[s][0] for s in S_REP]
    print(f"    {mode} a {b:g} : {st.mean(v.values()):.4f}" + ("  AU BORD" if b in (lrs[0], lrs[-1]) else ""))
if bad:
    print(f"  ARRET : cellules incompletes : {bad}")
else:
    print(f"  modeles de carte : {sorted(gpus)}")
    col = lambda x, thr: f"{x[0]:+.2f} [{x[1]:+.2f}, {x[2]:+.2f}] t={x[3]:+.2f} -> " + ("ETABLI" if abs(x[3]) > thr else "non etabli")  # noqa: E731
    print("\n  mesures du format enregistrees, moyenne sur les graines rapportees (additif, point 3) :")
    for mode in ARMS:
        vals = {}
        for dd in RDIRS[mode]:
            try:
                m = json.load(open(dd + "/metrics.json"))
            except (OSError, ValueError):
                continue
            for k, x in m.items():
                if isinstance(x, (int, float)) and ("format" in k or "base" in k) and not k.startswith("val_"):
                    vals.setdefault(k, []).append(float(x))
        print(f"    {mode:12s} : " + "  ".join(f"{k}={st.mean(v):.3f}" for k, v in sorted(vals.items())))
    top_mean = st.mean(V["top"].values())
    collapse = top_mean < 0.45
    print(f"\n  regle de l'additif : top (B gele) a son taux retenu = {top_mean:.4f} ; seuil 0,45 -> " + ("EFFONDREMENT : test 1 pour top NON INTERPRETABLE pour le budget" if collapse else "pas d'effondrement : test 1 pour top interpretable"))
    for X in ("top", "bottom"):
        G = (st.mean(V["free"].values()) - st.mean(V[X].values())) * 100
        print(f"\n  --- {X} : G = {G:+.2f} (rapporte)" + ("   [lecture principale]" if X == "top" else "   [bande mineure de q et o degeneree : reserve]"))
        verdict = col(pt([(V['dual_' + X][s] - V[X][s]) * 100 for s in S_REP]), BONF2)
        if X == "top" and collapse:
            verdict += "  [NON INTERPRETABLE pour le budget : top s'effondre (additif)]"
        print(f"    (1) geler A plutot que B, a parametres egaux : {verdict}")
    fz = [(V["bottom"][s] - V["top"][s]) * 100 for s in S_REP]
    d = [((V["dual_bottom"][s] - V["dual_top"][s]) - (V["bottom"][s] - V["top"][s])) * 100 for s in S_REP]
    floor = abs(st.mean(fz)) >= 2.0
    print(f"\n  (2) PRE-ENREGISTRE  ecart bottom - top : {st.mean(fz):+.2f} B gele, {st.mean([(V['dual_bottom'][s] - V['dual_top'][s]) * 100 for s in S_REP]):+.2f} A gele ; plancher "
          + ("atteint" if floor else "NON atteint : pas lu comme un retrecissement"))
    print(f"      retrecissement : {col(pt(d), T4)}")
