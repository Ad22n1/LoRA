#!/bin/bash
# Pilote automatique des experiences v2 : toutes les 10 minutes, lance l'etape suivante de chaque campagne dont aucun job n'est dans la file.
#   nohup bash scripts/v2_nuit.sh > ~/v2_nuit.log 2>&1 &      (suivre : tail -f ~/v2_nuit.log)
# Chaque etape passe par v2_stage.sh (committee avant ses runs). Une seule relance par prefixe pour les runs en echec, puis ALERTE.
# Aucun lancement apres mardi 29/09/2026 20 h ; les lectures restent permises. Etat dans ~/.v2_nuit/.
# COUVRE-FEU : aucune etape lancee s'il ne reste pas assez de temps avant 8 h ; a 7 h 55, annule tous les jobs lorasub et s'arrete.
set -u
cd "$HOME/repo" || exit 1
PY="/tmp/lora-$USER/venv/bin/python"; [ -x "$PY" ] || PY=python3
S="$HOME/.v2_nuit"; mkdir -p "$S"
DEADLINE=$(date -d "$(cat "$HOME/.v2_nuit/arret" 2>/dev/null || echo "2026-09-29 20:00")" +%s)   # heure d'arret du protocole en cours
ONCE=0; [ "${1:-}" = "--une-passe" ] && ONCE=1
declare -A FIRST=( [budget15]=sel [budget7]=sel [trend]=sel [r16_7b]=probe_read [p2]=attente [p2a]=attente [p2b]=attente [g2a]=attente [g2b]=attente [g3a256]=attente [g3aall]=attente [g3b256]=attente [g3b1024]=attente [g3ball]=attente [w2ad]=attente [w2a5]=attente [w2a10]=attente [w2a25]=attente [w2bd]=attente [w2b5]=attente [w2b10]=attente [w2b25]=attente [ao]=attente )
declare -A LASTP=( [budget15]=s1 [budget7]=s1 [trend]=s1 [r16_7b]=probe [p2]=dir [p2a]=dir [p2b]=dir [g2a]=gdir [g2b]=gdir [g3a256]=gdir [g3aall]=gdir [g3b256]=gdir [g3b1024]=gdir [g3ball]=gdir [w2ad]=dir [w2a5]=wbasis [w2a10]=wbasis [w2a25]=wbasis [w2bd]=dir [w2b5]=wbasis [w2b10]=wbasis [w2b25]=wbasis [ao]=s1 )
log() { echo "$(date '+%d/%m %H:%M')  $*"; }
for k in "${!FIRST[@]}"; do [ -f "$S/$k.etape" ] || echo "${FIRST[$k]}" > "$S/$k.etape"; [ -f "$S/$k.prefixe" ] || echo "${LASTP[$k]}" > "$S/$k.prefixe"; done
next_of() {  # etape suivante apres une etape reussie
  case "$1:$2" in
    budget*:sel|p2*:sel|g[23]*:sel|w2*:sel|ao:sel) echo read ;; *:sel) echo G ;; *:G) echo read ;; r16_7b:probe_read) echo s1 ;; r16_7b:s1|p2*:s1|g[23]*:s1|w2*:s1|ao:s1) echo sel ;;
    p2*:dir|g[23]*:gdir|w2?d:dir) echo basis ;; w2?d:basis) echo fini ;; w2*:wbasis) echo s1 ;; p2*:basis|g[23]*:basis) echo s1 ;; *) echo read ;; esac; }
left_min() { local D8; D8=$(date -d "08:00" +%s); [ "$(date +%s)" -ge "$D8" ] && D8=$(date -d "tomorrow 08:00" +%s); echo $(( (D8 - $(date +%s)) / 60 )); }
need_min() { case "$1" in budget7|r16_7b) echo 80 ;; *) echo 35 ;; esac; }
DEBUT=$(cat "$S/debut" 2>/dev/null || echo "20:00")          # debut de la fenetre de nuit (fin : 8 h)
in_window() { local n h; n=$(date +%s); h=$(date -d "$DEBUT" +%s); [ "$n" -ge "$h" ] || [ "$n" -lt "$(date -d "08:00" +%s)" ]; }
stamp() { date +%s > "$S/$1.lance_$2"; }
while true; do
  L=$(left_min)
  if [ "$L" -le 12 ]; then
    log "COUVRE-FEU : 8 h dans $L min ; annulation de tous les jobs lorasub et arret du pilote"
    for k in budget15 budget7 trend r16_7b p2 p2a p2b g2a g2b g3a256 g3aall g3b256 g3b1024 g3ball w2ad w2a5 w2a10 w2a25 w2bd w2b5 w2b10 w2b25 ao; do
      if [ "$(squeue -h -u "$USER" -o "%o" 2>/dev/null | grep -c "/lora-grid/v2_${k}_")" -gt 0 ]; then
        p=$(cat "$S/$k.prefixe"); rm -f "$S/$k.relance_$p"; echo "$p" > "$S/$k.interrompu"
        log "$k : runs interrompus par le couvre-feu (prefixe « $p ») ; ce n'est pas une panne, la relance unique n'est pas comptee"
      fi
    done
    scancel -u "$USER" -n lorasub 2>/dev/null; sleep 20; log "file apres annulation : $(squeue -h -u "$USER" -n lorasub 2>/dev/null | wc -l) tache(s)"; break
  fi
  actifs=0
  for k in budget15 budget7 trend r16_7b p2 p2a p2b g2a g2b g3a256 g3aall g3b256 g3b1024 g3ball w2ad w2a5 w2a10 w2a25 w2bd w2b5 w2b10 w2b25 ao; do
    e=$(cat "$S/$k.etape"); case "$e" in fini|arrete|bloque|attente) continue ;; esac; actifs=$((actifs + 1))
    busy=$(squeue -h -u "$USER" -o "%o" 2>/dev/null | grep -c "/lora-grid/v2_${k}_")
    [ "$busy" -gt 0 ] && { log "$k : $busy tache(s) dans la file, etape « $e » en attente"; continue; }
    if [ "$e" = read ]; then
      out=$("$PY" scripts/v2camp.py "$k" read 2>&1); code=$?
    elif ! in_window; then
      [ $ONCE -eq 1 ] || log "$k : hors de la fenetre de nuit ($DEBUT - 8 h) ; « $e » attend"; continue
    elif [ "$L" -lt "$(need_min "$k")" ]; then
      log "$k : plus assez de temps avant 8 h ($L min) pour l'etape « $e » ; reprise la nuit suivante"; continue
    else
      if [ "$(date +%s)" -ge "$DEADLINE" ]; then log "$k : heure d'arret des lancements depassee ; « $e » n'est pas lance"; echo arrete > "$S/$k.etape"; continue; fi
      out=$(bash scripts/v2_stage.sh "$k" "$e" 2>&1); code=$?
    fi
    echo "$out" | sed "s/^/    [$k $e] /"
    if [ $code -eq 4 ] || echo "$out" | grep -q "^ATTENTE"; then log "$k : « $e » en attente : $(echo "$out" | grep -m1 "^ATTENTE" | cut -c11-)"; continue; fi
    if [ $code -eq 0 ] && ! echo "$out" | grep -qE "^\s*STOP|REFUS"; then
      if [ "$e" = read ]; then echo "$out" > "$HOME/v2_lecture_$k.txt"; log "$k : LECTURE FAITE -> ~/v2_lecture_$k.txt"; echo fini > "$S/$k.etape"; continue; fi
      if [ "$e" = probe_read ] && ! echo "$out" | grep -q -- "-> GO"; then log "$k : la sonde dit STOP ; campagne arretee, sans repli"; echo arrete > "$S/$k.etape"; continue; fi
      p=$(echo "$out" | grep -oE "soumis  v2_${k}_[a-z0-9]+_" | head -1 | sed "s/soumis  v2_${k}_//; s/_$//")
      [ -n "$p" ] && { echo "$p" > "$S/$k.prefixe"; stamp "$k" "$p"; }
      if [ "$e" = sel ] && echo "$out" | grep -q "cran de prolongement"; then log "$k : cran de prolongement lance ; « sel » sera refaite"; continue; fi
      n=$(next_of "$k" "$e"); echo "$n" > "$S/$k.etape"; log "$k : « $e » faite ; prochaine etape « $n »"
    else
      p=$(cat "$S/$k.prefixe"); r="$S/$k.relance_$p"
      if echo "$out" | grep -qiE "incomplet"; then
        if ! in_window || [ "$L" -lt "$(need_min "$k")" ]; then
          log "$k : runs manquants au prefixe « $p », mais hors fenetre ou plus assez de temps avant 8 h ; reprise plus tard"; continue
        fi
        nf=$("$PY" scripts/v2camp.py "$k" failed "$(cat "$S/$k.lance_$p" 2>/dev/null || echo 0)" 2>/dev/null | awk '/^ECHECS/ {print $2}')
        np=$(cat "$S/$k.reprises_$p" 2>/dev/null || echo 0)
        if [ "${nf:-1}" -eq 0 ] && [ "$np" -lt 3 ] && [ "$(date +%s)" -lt "$DEADLINE" ]; then
          echo $((np + 1)) > "$S/$k.reprises_$p"; stamp "$k" "$p"
          log "$k : runs manquants au prefixe « $p », AUCUN en echec depuis le dernier lancement (abandons faute de memoire libre) ; reprise $((np + 1))/3, hors relance unique"
          bash scripts/launch_v2.sh "$k" "$p" 2>&1 | grep -E "REPRISE|soumis|REFUS|ATTENTE" | sed "s/^/    [$k reprise] /"; continue
        fi
        if [ -f "$S/$k.interrompu" ] && [ "$(cat "$S/$k.interrompu")" = "$p" ] && [ "$(date +%s)" -lt "$DEADLINE" ]; then
          rm -f "$S/$k.interrompu"; stamp "$k" "$p"; log "$k : reprise des runs interrompus par le couvre-feu au prefixe « $p » (hors relance unique)"
          bash scripts/launch_v2.sh "$k" "$p" 2>&1 | grep -E "REPRISE|soumis|REFUS|ATTENTE" | sed "s/^/    [$k reprise] /"; continue
        fi
        if [ ! -f "$r" ] && [ "$(date +%s)" -lt "$DEADLINE" ]; then
          touch "$r"; stamp "$k" "$p"; log "$k : $nf run(s) EN ECHEC au prefixe « $p » ; RELANCE UNIQUE"
          bash scripts/launch_v2.sh "$k" "$p" 2>&1 | grep -E "REPRISE|soumis|REFUS|ATTENTE" | sed "s/^/    [$k relance] /"
        else
          log "$k : ALERTE, toujours incomplet apres la relance autorisee (« $p ») ; campagne bloquee, a regarder"; echo bloque > "$S/$k.etape"
        fi
      else
        log "$k : ALERTE, l'etape « $e » a echoue autrement ; campagne bloquee, a regarder"; echo bloque > "$S/$k.etape"
      fi
    fi
  done
  [ "$actifs" -eq 0 ] && { [ $ONCE -eq 1 ] || log "toutes les campagnes sont terminees, arretees ou bloquees"; break; }
  [ $ONCE -eq 1 ] && break
  sleep $(( L > 15 ? 600 : 120 ))
done
