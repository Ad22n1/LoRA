"""Qwen, recomputed once the two `node` runs are replaced.

Two things the paper needs, from the same data:
  - the protocol's four tests on fifteen seeds (2-16), one-sided, Bonferroni over four, t > 2.510;
  - the test on the TEN FRESH SEEDS ALONE (7-16), the only statistic that was truly pre-registered:
    the decision to extend was taken after seeing seeds 2-6, so the pooled p-values carry an
    optional-stopping bias. Threshold t > 2.685 (9 d.f., one-sided, Bonferroni over four).
Seeds 2-6 are printed for reference only, with no threshold: they are the ones that led to the
extension.

    python scripts/analyse_qwen.py
"""
import itertools
import os
import statistics as st
import sys
from math import comb

import yaml

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from lorasub.aggregate import collect  # noqa: E402

MODEL = "Qwen/Qwen2.5-0.5B"
POS = [0.0, 0.25, 0.5, 1.0]
PAPER = {0.0: 4.09, 0.25: 5.50, 0.5: 5.88, 1.0: 2.30}


def wilcoxon_exact(dif):
    a = sorted(range(len(dif)), key=lambda i: abs(dif[i])); rk = [0.0] * len(dif); i = 0
    while i < len(a):
        j = i
        while j + 1 < len(a) and abs(dif[a[j + 1]]) == abs(dif[a[i]]):
            j += 1
        for k in range(i, j + 1):
            rk[a[k]] = (i + j) / 2 + 1
        i = j + 1
    wp = sum(r for r, x in zip(rk, dif) if x > 0)
    tot = [sum(r for r, s in zip(rk, sg) if s) for sg in itertools.product([0, 1], repeat=len(dif))]
    return sum(x >= wp - 1e-12 for x in tot) / len(tot)


def main():
    d = collect(os.path.expanduser("~/lora-runs"))
    tab = (yaml.safe_load(open("configs/lr_selected.yaml")) or {})["selected"]
    q = d[(d["mode"] == "band") & d.model.astype(str).str.contains("Qwen") & (d.task == "format")
          & (d["rank"] == 2) & (d.n_modules == 7) & d.update_norm_target.isna() & (d.max_grad_norm == 1.0)
          & d.seed.between(2, 16)]
    q = q[q.apply(lambda r: abs(float(r.lr) - tab.get(f"{MODEL}|format|band|2|b{float(r.band_frac):g}", -1)) < 1e-12,
                  axis=1)]
    p = q.pivot_table(index="seed", columns="band_frac", values="format_parsed")
    reps = int((q.groupby(["band_frac", "seed"]).size() > 1).sum())
    print(f"\n=== population: {int(p.notna().all(axis=1).sum())} complete seeds of 15 | cells with replicates: {reps} ===")
    if "host" in q.columns:
        bad = q[q.host.astype(str).str.contains("node")]
        print(f"  runs still from node: {len(bad)}  (must be 0)")
    for s, bf in ((4, 0.0), (5, 0.5)):
        print(f"  re-run cell beta={bf:g} seed {s}: {'present' if s in p.index and p.loc[s].notna().get(bf, False) else 'MISSING'}")
    if p.notna().all(axis=1).sum() < 15:
        print("  incomplete: wait for the re-runs before reading anything below.")
        return

    def family(seeds, thr, label):
        print(f"\n=== {label} (n={len(seeds)})" + (f", t > {thr}" if thr else ", reference only") + " ===")
        for bf in POS:
            dif = [p.loc[s, 0.75] - p.loc[s, bf] for s in seeds]; n = len(dif)
            t = st.mean(dif) / (st.stdev(dif) / n ** 0.5); w = sum(x > 0 for x in dif)
            sg = sum(comb(n, i) for i in range(w, n + 1)) / 2 ** n
            flag = ("PASS" if t > thr else "    ") if thr else ""
            ref = f" | paper t={PAPER[bf]}" if len(seeds) == 15 else ""
            print(f"  vs beta={bf:<5g} {st.mean(dif) * 100:+6.2f} pt | t={t:5.2f} {flag} | {w}/{n} | "
                  f"sign p={sg:.4f} | Wilcoxon p={wilcoxon_exact(dif):.4f}{ref}")
        m = {bf: st.mean(p.loc[s, bf] for s in seeds) for bf in p.columns}
        print("  means: " + "  ".join(f"{k:g}:{v:.4f}" for k, v in m.items()) + f"   best: beta={max(m, key=m.get):g}")

    family(list(range(2, 17)), 2.510, "PROTOCOL, fifteen seeds 2-16")

    print("\n=== leave-one-out on the fifteen: the worst t when any single seed is dropped ===")
    seeds = list(range(2, 17))
    for bf in POS:
        worst = min(
            (lambda dif: st.mean(dif) / (st.stdev(dif) / len(dif) ** 0.5))(
                [p.loc[s, 0.75] - p.loc[s, bf] for s in seeds if s != out])
            for out in seeds)
        print(f"  vs beta={bf:<5g} worst t = {worst:.2f}  ({'still passes' if worst > 2.510 else 'no longer passes'} 2.51)")
    family(list(range(7, 17)), 2.685, "PRE-REGISTERED, ten fresh seeds 7-16 alone")
    family(list(range(2, 7)), None, "the five seeds that led to the extension")


if __name__ == "__main__":
    main()
