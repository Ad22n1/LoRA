"""PROTOCOL_exp1_format_qwen.md: freezing B isolated on the format task with Qwen2.5-1.5B at rank 2 (experiment 1, second model). No PARTITION.

    python scripts/read_e1q.py 2>&1 | grep -vE "FutureWarning|pd.concat"

References: the pre-registered format-on-Qwen campaign (PROTOCOL_format_qwen_rank.md), seeds 22-26, which must give back their
published values to 1e-4. New arms: top_unfrozen and bottom_unfrozen at ranks 1 and 2, selection on seeds 20-21 (validation), reported
seeds 22-26. Tests (1)-(3) of experiment 1 with G fixed in advance, the same-PARTITION-model control, and the oracle bracket.
"""
import glob
import json
import os
import random
import statistics as st

import yaml

R = os.path.expanduser("~/lora-runs")
LLAMA, QWEN = "meta-llama/Llama-3.2-1B", "Qwen/Qwen2.5-1.5B"
S_SEL, S_REP = (20, 21), [22, 23, 24, 25, 26]      # fresh seeds (PROTOCOL_format_qwen_rank.md)


def tokens(c):
    t = c.get("target_tokens")
    return t.get(c.get("task")) if isinstance(t, dict) else t


RUNS = []
for p in glob.glob(R + "/*/config.yaml"):
    c = yaml.safe_load(open(p)) or {}
    d = os.path.dirname(p)
    try:
        if not open(d + "/status").read().startswith("DONE"):
            continue
        RUNS.append((c, json.load(open(d + "/metrics.json")), d))
    except OSError:
        continue


def clipped(c):
    """Gradient clipping at 1.0, the paper's setting. A noclip grid reran the same cells without clipping (collect()'s
    docstring); mixing both put two runs per seed in the frozen cells and moved G from 12.41 to 13.53 (26/09)."""
    v = c.get("max_grad_norm", 1.0)
    return v is not None and float(v) == 1.0


def seven(c):
    tm = c.get("target_modules")
    return tm is None or len(tm) == 7


def cell(pred, mode, rank, lr, seeds, key):
    """{seed: value}; several runs of one seed are averaged and flagged."""
    by = {}
    for c, m, d in RUNS:
        if (pred(c) and clipped(c) and c.get("mode") == mode and c.get("rank") == rank and abs(float(c.get("lr") or 0) - lr) < 1e-12
                and c.get("seed") in seeds and key in m and c.get("update_norm_target") in (None, "")):
            by.setdefault(c["seed"], []).append((m[key], d))
    dup = {s: len(v) for s, v in by.items() if len(v) > 1}
    if dup:   # say what separates the duplicates, so that the next filter is written from evidence
        s0 = sorted(dup)[0]; cfgs = [yaml.safe_load(open(d + "/config.yaml")) or {} for _, d in by[s0]]
        keys = sorted(k for k in set().union(*cfgs) if k not in ("run_id", "out_dir") and len({str(c_.get(k)) for c_ in cfgs}) > 1)
        dup["differ"] = {k: [c_.get(k) for c_ in cfgs] for k in keys} or "configs identiques"
    return {s: st.mean(x for x, _ in v) for s, v in by.items()}, dup, {s: [d for _, d in v] for s, v in by.items()}


def paired(a, b):
    k = sorted(set(a) & set(b)); dd = [(a[s] - b[s]) * 100 for s in k]
    if len(dd) < 2: return float("nan"), float("nan"), len(dd)
    sd = st.stdev(dd)
    return st.mean(dd), (st.mean(dd) / (sd / len(dd) ** 0.5) if sd > 0 else float("inf")), len(dd)


def show(lab, v, dup=None):
    extra = f"  DOUBLONS {dup}" if dup else ""
    print(f"    {lab:36s} " + (f"{st.mean(v.values()):.4f}  ({len(v)} graines){extra}" if v else "AUCUN RUN"))


def select(pred, mode, rank, lrs, key):
    full = {}
    for lr in lrs:
        v, _, _ = cell(pred, mode, rank, lr, S_SEL, key)
        if len(v) == 2: full[lr] = st.mean(v.values())
    if len(full) < len(lrs):
        return None, f"INCOMPLET ({len(full)}/{len(lrs)} taux avec leurs deux graines)"
    best = max(full, key=full.get)
    edge = best in (lrs[0], lrs[-1])
    return best, "  ".join(f"{lr:g}:{full[lr]:.3f}" for lr in lrs) + f"  -> {best:g}" + ("  AU BORD" if edge else "")


fq = lambda c: c.get("task") == "format" and str(c.get("model")) == QWEN and seven(c)  # noqa: E731



import sys
import glob
import json
import os
import yaml
import csv
T4, BONF2 = 2.776, 3.495


def gpu_of(d):
    try:
        with open(d + "/results.csv", newline="") as f:
            return (next(csv.DictReader(f)).get("PARTITION") or "?").replace("NVIDIA ", "").replace(" Generation", "")
    except (OSError, StopIteration):
        return "?"


def load(root):
    out = []
    for p_ in glob.glob(os.path.expanduser(root) + "/*/config.yaml"):
        c = yaml.safe_load(open(p_)) or {}; d = os.path.dirname(p_)
        try:
            if open(d + "/status").read().startswith("DONE"):
                out.append((c, json.load(open(d + "/metrics.json")), d))
        except OSError:
            pass
    return out


MAIN = RUNS
SUIVI = "--suivi" in sys.argv
if SUIVI:
    FOLLOW = load("~/lora-runs-suivi")


def cell_in(runs, *a):
    global RUNS
    keep = RUNS; RUNS = runs
    try:
        return cell(*a)
    finally:
        RUNS = keep


def pt(a, b, seeds):
    d = [(a[s] - b[s]) * 100 for s in seeds]; m = st.mean(d)
    if len(d) < 2: return m, float("nan"), float("nan"), float("nan")
    se = st.stdev(d) / len(d) ** 0.5; tq = {2: 12.706, 3: 4.303, 4: 3.182, 5: 2.776}.get(len(d), 2.776)
    return m, m - tq * se, m + tq * se, (m / se if se > 0 else float("inf"))


def oracle_rate(pred, mode, rank, lrs, key):
    full = {}
    for lr in lrs:
        v, dup, _ = cell_in(MAIN, pred, mode, rank, lr, S_REP, key)
        if len(v) == 5 and not dup: full[lr] = v
    return max(full, key=lambda lr: st.mean(full[lr].values())) if len(full) == len(lrs) else None


def verdict1(m, lo_, hi_, G):
    if m >= 0.7 * G: return "le gel explique l'essentiel" if lo_ >= 0.7 * G else "partage (chevauche 0,7 G)"
    if m <= 0.3 * G: return "l'essentiel vient d'ailleurs" if hi_ <= 0.3 * G else "partage (chevauche 0,3 G)"
    return "partage, sans attribution"


def block(title, pred, refs, lo, lrs, vkey, key, hi=2):
    print(f"\n==================== {title}" + ("  [SUIVI : references reentrainees, ~/lora-runs-suivi]" if SUIVI else "") + " ====================")
    R, D = {}, {}
    for name, (mode, rank, lr, expect) in refs.items():
        src = FOLLOW if (SUIVI and name != "free") else MAIN
        v, dup, dirs = cell_in(src, pred, mode, rank, lr, S_REP, key)
        m_ = st.mean(v.values()) if v else float("nan")
        guard = (name == "free" or not SUIVI)
        ok = len(v) == 5 and not dup and (abs(m_ - expect) < 1e-4 if guard else True)
        print(f"  reference {name:7s} ({mode} r={rank} a {lr:g}) : {m_:.4f} ({'attendu' if guard else 'origine'} {expect:.4f})"
              + ("" if ok else "  <- ARRET : reference inattendue, incomplete ou doublons"))
        if not ok: return
        R[name], D[name] = v, {s: dirs[s][0] for s in S_REP}
    U, UO = {}, {}
    for band in ("top", "bottom"):
        for rank in (lo, hi):
            b, txt = select(pred, f"{band}_unfrozen", rank, lrs, vkey); o = oracle_rate(pred, f"{band}_unfrozen", rank, lrs, key)
            print(f"  selection {band}_unfrozen r={rank:2d} : {txt}  | oracle : {o if o is not None else 'non calculable'}")
            if b is None: return
            v, dup, dirs = cell_in(MAIN, pred, f"{band}_unfrozen", rank, b, S_REP, key)
            if len(v) != 5 or dup:
                print(f"    ARRET : {len(v)} graines, doublons {dup or 'aucun'}"); return
            U[(band, rank)] = v; D[(band, rank)] = {s: dirs[s][0] for s in S_REP}
            UO[(band, rank)] = cell_in(MAIN, pred, f"{band}_unfrozen", rank, o, S_REP, key)[0] if o is not None else None
            print(f"    {band}_unfrozen r={rank} a {b:g} : {st.mean(v.values()):.4f}")
    col = lambda x: "non calculable" if x is None else f"{x[0]:+.2f} [{x[1]:+.2f}, {x[2]:+.2f}]" + (f" t={x[3]:+.2f}" if x[3] == x[3] else "")  # noqa: E731
    for band in ("top", "bottom"):
        G = (st.mean(R["free"].values()) - st.mean(R[band].values())) * 100
        print(f"\n  --- {band} : G = {G:+.2f} ; 0,3 G = {0.3 * G:.2f}, 0,7 G = {0.7 * G:.2f}")
        a, b_ = pt(U[(band, lo)], R[band], S_REP), (pt(UO[(band, lo)], R[band], S_REP) if UO[(band, lo)] else None)
        if G >= 2:
            print(f"    (1) PRINCIPAL  U : retenu {col(a)} -> {verdict1(a[0], a[1], a[2], G)}   |   oracle {col(b_)}" + (f" -> {verdict1(b_[0], b_[1], b_[2], G)}" if b_ else ""))
        else:
            print(f"    (1) U (sans issue, G < 2) : retenu {col(a)}   |   oracle {col(b_)}")
        a, b_ = pt(U[(band, hi)], R[band], S_REP), (pt(UO[(band, hi)], R[band], S_REP) if UO[(band, hi)] else None)
        print(f"    (2) gel seul, r={hi} : retenu {col(a)} -> " + ("ETABLI" if abs(a[3]) > BONF2 else "non etabli")
              + f"   |   oracle {col(b_)}" + ((" -> " + ("ETABLI" if abs(b_[3]) > BONF2 else "non etabli")) if b_ else ""))
        same = [s for s in S_REP if len({gpu_of(D[(band, hi)][s]), gpu_of(D[band][s])}) == 1]
        print(f"        a PARTITION egal ({len(same)} graines) : " + (col(pt(U[(band, hi)], R[band], same)) if len(same) >= 3 else "non calculable"))
    fz = {s: R["bottom"][s] - R["top"][s] for s in S_REP}; zero = {s: 0.0 for s in S_REP}
    def shrink(u):
        return {s: (u[("bottom", hi)][s] - u[("top", hi)][s]) - fz[s] for s in S_REP}
    a = pt(shrink(U), zero, S_REP); b_ = pt(shrink(UO), zero, S_REP) if UO[("bottom", hi)] and UO[("top", hi)] else None
    floor_ok = abs(st.mean(fz.values()) * 100) >= 2.0
    print(f"\n  plancher (protocole) : ecart gele {st.mean(fz.values()) * 100:+.2f} -> " + ("au-dessus de 2 points : (3) est lu" if floor_ok else "SOUS 2 points : (3) rapporte, PAS lu comme un retrecissement"))
    print(f"\n  (3) PRE-ENREGISTRE  ecart bottom - top : {st.mean(fz.values()) * 100:+.2f} geles, {st.mean({s: U[('bottom', hi)][s] - U[('top', hi)][s] for s in S_REP}.values()) * 100:+.2f} degeles")
    print(f"      reduction : retenu {col(a)} -> " + ("ETABLI" if abs(a[3]) > T4 else "non etabli")
          + f"   |   oracle {col(b_)}" + ((" -> " + ("ETABLI" if abs(b_[3]) > T4 else "non etabli")) if b_ else ""))
    same = [s for s in S_REP if len({gpu_of(D[k][s]) for k in (("bottom", hi), ("top", hi), "bottom", "top")}) == 1]
    print(f"      a PARTITION egal ({len(same)} graines) : " + (col(pt(shrink(U), zero, same)) if len(same) >= 3 else "non calculable"))
    if len(same) < 3:
        print("      (controle a carte egale incalculable : rapporte comme tel ; toutes les campagnes comparees etaient epinglees sur RTX 4000 Ada)")
    print("  PARTITION : " + " | ".join(f"{k if isinstance(k, str) else k[0] + '_unfrozen' + str(k[1])} " + ",".join(gpu_of(D[k][s])[:12] for s in S_REP) for k in D))
    print("  (oracle : taux choisi en test sur les graines rapportees -- borne optimiste, controle de robustesse ; references a leur taux dans les deux colonnes)")




block("tache de format, Qwen2.5-1.5B, rang 2", fq,
      {"top": ("top", 2, 1e-2, 0.6257), "bottom": ("bottom", 2, 5e-3, 0.6391), "free": ("free", 1, 5e-3, 0.7879)},
      1, [1e-4, 5e-4, 1e-3, 2e-3, 5e-3, 1e-2, 2e-2], "val_format_parsed", "format_parsed")
