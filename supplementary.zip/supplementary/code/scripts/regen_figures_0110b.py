"""Second pass on three figures (01/10): curvature_arms, curvature_vs_lr, score_vs_norm. No plotted value of the paper changes.

    python scripts/regen_figures_0110b.py            # from the repository root

The paper's versions of these figures were not the output of the committed scripts: the two curvature figures had their in-image
notes removed and another export; score_vs_norm was drawn before runs at 2x and 4x the token budget entered its population. Here:
  REFERENCE = the original script (as before commit <commit>), with, for score_vs_norm only, the tables' budget (600,000 tokens)
              added to its filter; for score_vs_norm the reference must reproduce the paper's figure PIXEL FOR PIXEL;
  NEW       = the edited script; every plotted value must equal the reference's.
Also: the curvature figures must have the paper's width; the moved legend must cover nothing; no two rate labels within 4 px.
Only if every check passes are the files copied into paper/figures (and zipped).
"""
import io
import json
import os
import shutil
import subprocess
import sys
import zipfile

import numpy as np
from PIL import Image

REPO = os.getcwd(); WORK = os.path.expanduser("~/fig_regen_0110b"); PY = sys.executable; BASE = "<commit>~1"
POP_PATCH = [("for c in ('seed','update_norm_target','max_grad_norm','lr','rank','mode','subspace_salted'):",
              "for c in ('seed','update_norm_target','max_grad_norm','lr','rank','mode','subspace_salted','target_tokens'):"),
             ("f = f[~f['mode'].isin(['random','random_ortho']) | (f.subspace_salted == True)]",
              "f = f[~f['mode'].isin(['random','random_ortho']) | (f.subspace_salted == True)]\n"
              "f = f[f.target_tokens.map(lambda t: (t.get('format') if isinstance(t, dict) else t) == 600000)]")]
FIGS = [("curvature_arms.png", "scripts/fig_curvature_arms.py", ["{o}/curvature_arms.png"], 10, [], False),
        ("curvature_vs_lr.png", "scripts/fig_curvature.py", [], 11, [], False),
        ("score_vs_norm.png", "scripts/score_vs_norm.py", [], 12, POP_PATCH, True)]


def run(tag, script, args):
    out = os.path.join(WORK, tag); dump = os.path.join(WORK, f"{tag}_{os.path.basename(script)}.json")
    env = dict(os.environ, PYTHONPATH=os.path.join(REPO, "src") + os.pathsep + os.path.join(REPO, "scripts"))
    p = subprocess.run([PY, os.path.join(REPO, "scripts/fig_capture.py"), out, dump, script] + [a.format(o=out) for a in args],
                       cwd=REPO, env=env, capture_output=True, text=True)
    if p.returncode != 0:
        sys.exit(f"STOP: {tag} {script} failed:\n{p.stderr[-2500:]}")
    return out, {r["file"]: r for r in json.load(open(dump))}


def paper(name):
    raw = subprocess.run(["git", "show", f"HEAD:paper/figures/{name}"], cwd=REPO, capture_output=True).stdout
    return Image.open(io.BytesIO(raw)).convert("RGB") if raw else None


shutil.rmtree(WORK, ignore_errors=True); os.makedirs(os.path.join(WORK, "ref_scripts"))
ok_all, lines, made = True, [], []
for name, script, args, num, patch, must_match_paper in FIGS:
    src = subprocess.run(["git", "show", f"{BASE}:{script}"], cwd=REPO, capture_output=True, text=True).stdout
    if not src:
        sys.exit(f"STOP: {script} not found at {BASE}")
    for a, b in patch:
        if src.count(a) != 1:
            sys.exit(f"STOP: population patch does not apply to {script}")
        src = src.replace(a, b, 1)
    ref_path = os.path.join(WORK, "ref_scripts", os.path.basename(script)); open(ref_path, "w").write(src)
    r_dir, r_rec = run("ref", ref_path, args)
    n_dir, n_rec = run("new", os.path.join(REPO, script), args)
    pap = paper(name); r_img = Image.open(os.path.join(r_dir, name)).convert("RGB"); n_img = Image.open(os.path.join(n_dir, name)).convert("RGB")
    note, ok = [], True
    if must_match_paper:
        same_pix = pap is not None and pap.size == r_img.size and not np.any(np.asarray(pap) != np.asarray(r_img))
        note.append(f"reference (original script + 600,000-token budget) {'IDENTICAL' if same_pix else 'DIFFERENT'} to the paper's figure, pixel for pixel")
        ok &= bool(same_pix)
    ro, rn = r_rec.get(name), n_rec.get(name)
    same = ro is not None and rn is not None and len(ro["axes"]) == len(rn["axes"]) and all(x["data"] == y["data"] for x, y in zip(ro["axes"], rn["axes"]))
    ok &= bool(same)
    if ro and rn:
        n_items = sum(len(x["data"]["lines"]) + len(x["data"]["collections"]) + len(x["data"]["patches"]) + len(x["data"]["anchors"]) for x in rn["axes"])
        note.append(f"{n_items} plotted artists {'identical' if same else 'DIFFERENT'} to the reference")
        for i, (x, y) in enumerate(zip(ro["axes"], rn["axes"])):
            gone = sorted(set(x["texts"]) - set(y["texts"])); new = sorted(set(y["texts"]) - set(x["texts"]))
            if gone or new:
                note.append(f"axes {i}: labels removed {[g[:40] for g in gone[:6]]}, added {[g[:40] for g in new[:6]]}")
            lo, ln = x["layout"], y["layout"]
            if name == "curvature_vs_lr.png" and i == 0:
                note.append(f"legend covers {lo['legend_covers_markers']} marker(s) before, {ln['legend_covers_markers']} after")
                ok &= ln["legend_covers_markers"] == 0 and ln["legend_covers_labels"] == 0
            if name == "score_vs_norm.png" and i == 0:
                note.append(f"rate-label pairs within 4 px: {lo['label_pairs_within_4px']} before, {ln['label_pairs_within_4px']} after")
                ok &= ln["label_pairs_within_4px"] == 0
    if name.startswith("curvature") and pap is not None:
        note.append(f"width {n_img.size[0]} (paper {pap.size[0]}), height {n_img.size[1]} (paper {pap.size[1]})")
        ok &= n_img.size[0] == pap.size[0]
    lines.append(f"  {num:>2}. {name:20s} {'OK ' if ok else 'ECHEC'} size {pap.size if pap else None} -> {n_img.size} ; " + " ; ".join(note))
    ok_all &= ok; made.append((name, n_dir))
print("=== before / after\n" + "\n".join(lines))
if not ok_all:
    sys.exit("STOP: at least one check failed; nothing was copied into paper/figures")
copied = []
for name, d in made:
    shutil.copy(os.path.join(d, name), os.path.join(REPO, "paper/figures", name)); copied.append(name)
with zipfile.ZipFile(os.path.expanduser("~/figures_0110b.zip"), "w") as z:
    for f in copied:
        z.write(os.path.join(REPO, "paper/figures", f), f"figures/{f}")
print(f"  copied into paper/figures and zipped in ~/figures_0110b.zip: {', '.join(copied)}")
