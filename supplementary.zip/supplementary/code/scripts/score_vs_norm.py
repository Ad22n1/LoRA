import pandas as pd
import sys, os, glob, yaml; sys.path.insert(0,'src')
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from lorasub.aggregate import collect
# No conclusions inside the images (24/09): every title is dropped, only panel letters such as "(a)"
# are kept where a caption refers to them. What a figure shows is said in its caption, where it can
# be qualified -- a claim written in the image cannot.
import re as _re
import matplotlib.axes as _max
import matplotlib.figure as _mfig
_set_title = _max.Axes.set_title
def _letter_only(self, label="", *a, **k):
    m = _re.match(r"\s*\(([a-z])\)", str(label))
    return _set_title(self, f"({m.group(1)})" if m else "", loc="left", fontsize=10)
_max.Axes.set_title = _letter_only
_mfig.Figure.suptitle = lambda self, *a, **k: None

d = collect(os.path.expanduser('~/lora-runs'))
m = {}
for p in glob.glob(os.path.expanduser('~/lora-runs/*/config.yaml')):
    m[os.path.basename(os.path.dirname(p))] = yaml.safe_load(open(p)) or {}
for c in ('seed','update_norm_target','max_grad_norm','lr','rank','mode','subspace_salted','target_tokens'):
    d[c] = d.run_id.map(lambda r: (m.get(r) or {}).get(c))
d['nmod'] = d.run_id.map(lambda r: len((m.get(r) or {}).get('target_modules') or []))

f = d[(d.task=='format') & (d.format_n==614) & d.model.astype(str).str.contains('Llama')
      & d.update_norm_target.isna() & (d.max_grad_norm==1.0) & (d.nmod==7) & (d['rank']==2)]
f = f[~f['mode'].isin(['random','random_ortho']) | (f.subspace_salted == True)]
# (01/10) THE BUDGET OF THE TABLES: 600,000 tokens. Without this, the runs at 2x and 4x the budget (25-27/09) entered the means
# (top at 1e-2 read 0.6749 instead of the tables' 0.6443, bottom at 5e-3 0.6164 instead of 0.5922).
f = f[f.target_tokens.map(lambda t: (t.get('format') if isinstance(t, dict) else t) == 600000)]

fig, (ax, axb) = plt.subplots(1, 2, figsize=(10.6, 4.0),
                              gridspec_kw={'width_ratios': [1.35, 1]})
# THE POPULATION OF THE TABLES, and nothing else: seeds 2-6, means and standard errors over seeds,
# as every table reports. The earlier panel pooled every seed at every rate (n = 4 to 11) and gave
# medians where the right panel gave means, so its labels mixed populations the text never uses.
# A seed with a collapsed run at a rate is dropped at that rate, exactly as Table 19 drops it at
# 5e-3 (mean over four seeds, 0.5965), and a ring marks the cell.
f = f[f.seed.between(2, 6)]
_labels = []   # (01/10) the rate labels of the left panel, pulled apart below if two of them overlap
for mode, col, mk, dy in (('bottom', '#c44e52', 'o', -14), ('top', '#4c72b0', 's', 10)):
    rows = []
    for lr, c in f[f['mode'] == mode].groupby('lr'):
        bad = set()   # no seed is dropped: the collapse once seen at 5e-3 was an alpha=16 run, now quarantined
        c = c[~c.seed.isin(bad)]
        per = c.groupby('seed').agg(score=('format_parsed', 'mean'), norm=('update_norm_mean', 'mean'))
        if len(per) < 4:
            continue
        rows.append(dict(lr=lr, score=per.score.mean(), se=per.score.std() / len(per) ** 0.5,
                         norm=per.norm.mean(), n=len(per), dropped=len(bad)))
    if not rows:
        continue
    g = pd.DataFrame(rows).sort_values('norm')
    ax.errorbar(g['norm'], g['score'], yerr=g['se'], marker=mk, color=col, capsize=3, lw=1.6,
                label=mode, markersize=6)
    for _, r in g.iterrows():
        lab = f"{r['lr']:g}" + ("" if r['n'] == 5 else f"  (n={int(r['n'])})")
        # one label per point, in the arm's colour, on the arm's own side of its curve: top above,
        # bottom below, so no label can be read as belonging to the other arm
        _labels.append(ax.annotate(lab, (r['norm'], r['score']), textcoords="offset points", xytext=(0, dy),
                                   ha='center', va='bottom' if dy > 0 else 'top', fontsize=7, color=col))
        if r['dropped']:
            ax.scatter([r['norm']], [r['score']], s=170, facecolors='none', edgecolors=col, lw=1.4, zorder=5)
            ax.annotate("one seed collapsed at this rate and is dropped, as in Table 19",
                        xy=(r['norm'], r['score']), xycoords='data', xytext=(0.03, 0.05),
                        textcoords='axes fraction', ha='left', va='bottom', fontsize=7, color='0.35',
                        arrowprops=dict(arrowstyle="-", color='0.6', lw=0.7, shrinkA=0, shrinkB=9))
    print(f"{mode}:")
    print(g.round(4).to_string(index=False))

ax.set_xlabel(r"$\|\Delta W\|_F$ reached at this rate")
ax.set_ylabel("valid-format accuracy")
ax.set_title("Score against attained norm, rank 2, 614 items", fontsize=11)
ax.text(0.5, -0.20, "mean over seeds 2-6, bars = standard error; labels are the learning rate",
        transform=ax.transAxes, ha='center', fontsize=7.5, color='0.4')
ax.legend(loc='upper left'); ax.set_ylim(0.44, 0.71)

# ---------------------------------------------------------------------------------------------
# SECOND PANEL: the position sweep, on the same axes.
#
# The left panel is what makes the objection: across ARMS, score and attained norm move together,
# so the axis the score is ordered on could be the norm rather than the position. The sweep answers
# it, and the answer is not that the norm is small but that the SCORE IS NOT MONOTONE IN IT: four
# positions run at the same rate, their norms rise 4.646 -> 4.754, and the score dips in the middle.
# A reader who sees that dip does not need the paragraph.
#
# beta = 1 is drawn apart: it is the one position that runs at 5e-3 rather than 1e-2, so its norm
# gap follows the rate and not the band, and joining it to the others with a line would suggest a
# trend that crosses a change of rate.
b = d[(d['mode'] == 'band') & (d.task == 'format') & (d.format_n == 614)
      & d.model.astype(str).str.contains('Llama') & (d['rank'] == 2) & (d.nmod == 7)
      & d.update_norm_target.isna() & (d.max_grad_norm == 1.0) & d.seed.between(2, 8)]
tab = (yaml.safe_load(open('configs/lr_selected.yaml')) or {})['selected']
b = b[b.apply(lambda r: abs(float(r.lr) - tab.get(
    f"meta-llama/Llama-3.2-1B|format|band|2|b{float(r.band_frac):g}", -1)) < 1e-12, axis=1)]
g = (b.groupby('band_frac')
     .agg(score=('format_parsed', 'mean'), norm=('update_norm_mean', 'mean'),
          lr=('lr', 'first'), n=('format_parsed', 'size')).reset_index())
hi = g[g.band_frac < 1.0].sort_values('norm')
lo = g[g.band_frac >= 1.0]
axb.plot(hi['norm'], hi['score'], '-o', color='#55a868', lw=1.6, ms=7,
         label=r'$\beta$ = 0 to 0.75, all at $10^{-2}$')
# Labels to the LEFT, not above and below. The four positions are spread in score but packed in
# norm (4.646 to 4.754), so a label offset vertically lands next to the NEXT point up or down and
# the reader cannot tell which one it belongs to. Horizontally there is nothing in the way.
for _, r in hi.iterrows():
    axb.annotate(rf"$\beta$={r['band_frac']:g}", (r['norm'], r['score']),
                 textcoords='offset points', xytext=(-11, -3),
                 ha='right', va='center', fontsize=7.5, color='0.3')
for _, r in lo.iterrows():
    axb.plot([r['norm']], [r['score']], marker='D', color='#c44e52', ms=8,
             label=r'$\beta$ = 1, at $5\cdot10^{-3}$')
    axb.annotate(r"$\beta$=1", (r['norm'], r['score']), textcoords='offset points',
                 xytext=(11, -3), ha='left', va='center', fontsize=7.5, color='0.3')
if len(hi) >= 2:
    a0 = hi.iloc[0]
    a1 = hi[hi.band_frac == 0.25]
    if len(a1):
        a1 = a1.iloc[0]
        axb.annotate("norm up, score down", xy=(a1['norm'], a1['score']),
                     xytext=(0.06, 0.12), textcoords='axes fraction', fontsize=7.5, color='0.35',
                     arrowprops=dict(arrowstyle="-", color='0.6', lw=0.7, shrinkA=0, shrinkB=7))
axb.set_xlabel(r"$\|\Delta W\|_F$ reached at this rate")
axb.set_title("The position sweep, same quantities", fontsize=11)
axb.legend(fontsize=7.5, frameon=False, loc='lower right')
axb.text(0.5, -0.20, "mean over seeds 2-8, each position at its own selected rate",
         transform=axb.transAxes, ha='center', fontsize=7.5, color='0.4')
for a in (ax, axb):
    a.grid(color='0.94', lw=0.7); a.set_axisbelow(True)
    for sp in ('top', 'right'):
        a.spines[sp].set_visible(False)

fig.tight_layout(rect=(0, 0.06, 1, 1))
import sys as _sys  # noqa: E402
_sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _layout import separate_labels  # noqa: E402
separate_labels(ax, _labels)
o = _sys.argv[1] if len(_sys.argv) > 1 else os.path.expanduser('~/lora-analysis/score_vs_norm.png')
fig.savefig(o, dpi=150)
print("\necrit ->", o)
