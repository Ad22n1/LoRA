"""PROTOCOL_rank2_fresh.md: the rank-2 comparison of the introduction on fresh seeds (120-124), pinned to one PARTITION model. No PARTITION.

    python scripts/read_r2f.py 2>&1 | grep -vE "FutureWarning|pd.concat"

Nine arms at the rates already selected on the original selection seeds (no new selection). Tests: (1) the band-gap shrinkage,
(bottom_unfrozen - top_unfrozen) - (bottom - top) at rank 2, t > 2.776, read only if the frozen gap is at least 2 points; (2) freezing
alone, X_unfrozen(2) - X(2), t > 3.495; (3) U = X_unfrozen(1) - X(2) against 0.7 G and 0.3 G, G recomputed on seeds 120-124 (seeds 2-6 alongside);
(4) the band-gap shrinkage when A is frozen instead of B, t > 2.776. Reported without a test: gap minus spread (descriptive).
"""
import csv
import glob
import json
import math
import os
import random
import re
import statistics as st

import yaml

R = os.path.expanduser("~/lora-runs")
LLAMA, QWEN = "meta-llama/Llama-3.2-1B", "Qwen/Qwen2.5-1.5B"
S_SEL, S_REP = (0, 1), [2, 3, 4, 5, 6]


def tokens(c):
    t = c.get("target_tokens")
    return t.get(c.get("task")) if isinstance(t, dict) else t


RUNS = []
for p in glob.glob(R + "/*/config.yaml"):
    c = yaml.safe_load(open(p)) or {}
    d = os.path.dirname(p)
    try:
        if not open(d + "/status").read().startswith("DONE"):
            continue
        RUNS.append((c, json.load(open(d + "/metrics.json")), d))
    except OSError:
        continue


def clipped(c):
    """Gradient clipping at 1.0, the paper's setting. A noclip grid reran the same cells without clipping (collect()'s
    docstring); mixing both put two runs per seed in the frozen cells and moved G from 12.41 to 13.53 (26/09)."""
    v = c.get("max_grad_norm", 1.0)
    return v is not None and float(v) == 1.0


def seven(c):
    tm = c.get("target_modules")
    return tm is None or len(tm) == 7


def cell(pred, mode, rank, lr, seeds, key):
    """{seed: value}; several runs of one seed are averaged and flagged."""
    by = {}
    for c, m, d in RUNS:
        if (pred(c) and clipped(c) and c.get("mode") == mode and c.get("rank") == rank and abs(float(c.get("lr") or 0) - lr) < 1e-12
                and c.get("seed") in seeds and key in m and c.get("update_norm_target") in (None, "")):
            by.setdefault(c["seed"], []).append((m[key], d))
    dup = {s: len(v) for s, v in by.items() if len(v) > 1}
    if dup:   # say what separates the duplicates, so that the next filter is written from evidence
        s0 = sorted(dup)[0]; cfgs = [yaml.safe_load(open(d + "/config.yaml")) or {} for _, d in by[s0]]
        keys = sorted(k for k in set().union(*cfgs) if k not in ("run_id", "out_dir") and len({str(c_.get(k)) for c_ in cfgs}) > 1)
        dup["differ"] = {k: [c_.get(k) for c_ in cfgs] for k in keys} or "configs identiques"
    return {s: st.mean(x for x, _ in v) for s, v in by.items()}, dup, {s: [d for _, d in v] for s, v in by.items()}


fmt = lambda c: (c.get("task") == "format" and str(c.get("model")) == LLAMA and tokens(c) == 600000 and seven(c)  # noqa: E731
                 and c.get("max_len") == 384 and c.get("batch_size") == 2 and c.get("grad_accum") == 16)

S_REP = [120, 121, 122, 123, 124]
T4, BONF2 = 2.776, 3.495
G_ORIG = {"top": 12.41, "bottom": 17.62}   # seeds 2-6, reported for reference only
ARMS = {"top": ("top", 2, 1e-2, 0.6443), "bottom": ("bottom", 2, 5e-3, 0.5922), "random": ("random", 2, 1e-2, None), "random_ortho": ("random_ortho", 2, 1e-2, None),
        "free": ("free", 1, 1e-3, 0.7684), "top_u1": ("top_unfrozen", 1, 5e-3, 0.7928), "top_u2": ("top_unfrozen", 2, 5e-3, 0.8000),
        "bottom_u1": ("bottom_unfrozen", 1, 5e-3, 0.7954), "bottom_u2": ("bottom_unfrozen", 2, 2e-3, 0.8072),
        "dual_top": ("dual_top", 2, 1e-2, 0.7739), "dual_bottom": ("dual_bottom", 2, 1e-2, 0.7818)}


def gpu_of(d):
    try:
        with open(d + "/results.csv", newline="") as f:
            return (next(csv.DictReader(f)).get("PARTITION") or "?").replace("NVIDIA ", "").replace(" Generation", "")
    except (OSError, StopIteration):
        return "?"


def pt(d):
    m = st.mean(d); se = st.stdev(d) / len(d) ** 0.5
    return m, m - T4 * se, m + T4 * se, (m / se if se > 0 else float("inf"))


print("==================== la comparaison du rang 2, graines neuves 120-124 (tache de format, Llama-3.2-1B) ====================")
V, gpus, bad = {}, set(), []
for k, (mode, rank, lr, orig) in ARMS.items():
    v, dup, dirs = cell(fmt, mode, rank, lr, S_REP, "format_parsed")
    if len(v) != 5 or dup:
        bad.append(f"{k} ({len(v)} graines, doublons {dup or 'aucun'})"); continue
    V[k] = v; gpus |= {gpu_of(dirs[s][0]) for s in S_REP}
    print(f"  {mode:16s} r={rank} a {lr:g} : {st.mean(v.values()):.4f}" + (f"   (origine {orig:.4f}, ecart {(st.mean(v.values()) - orig) * 100:+.2f})" if orig else ""))
if bad:
    print("  ARRET : cellules incompletes : " + "; ".join(bad))
else:
    print(f"  modeles de carte : {sorted(gpus)}" + ("  -> un seul modele" if len(gpus) == 1 else "  -> ATTENTION : plusieurs modeles"))
    col = lambda x, thr: f"{x[0]:+.2f} [{x[1]:+.2f}, {x[2]:+.2f}] t={x[3]:+.2f} -> " + ("ETABLI" if abs(x[3]) > thr else "non etabli")  # noqa: E731
    fz = [(V["bottom"][s] - V["top"][s]) * 100 for s in S_REP]
    d1 = [((V["bottom_u2"][s] - V["top_u2"][s]) - (V["bottom"][s] - V["top"][s])) * 100 for s in S_REP]
    floor = abs(st.mean(fz)) >= 2.0
    print(f"\n  (1) PRINCIPAL  ecart bottom - top : {st.mean(fz):+.2f} geles, {st.mean([(V['bottom_u2'][s] - V['top_u2'][s]) * 100 for s in S_REP]):+.2f} degeles ; plancher " + ("atteint" if floor else "NON atteint : pas lu comme un retrecissement"))
    print(f"      retrecissement : {col(pt(d1), T4)}   (origine, post hoc : +5,93, t = 4,96)")
    for X in ("top", "bottom"):
        print(f"\n  --- {X}")
        print(f"    (2) gel seul, r=2 : {col(pt([(V[X + '_u2'][s] - V[X][s]) * 100 for s in S_REP]), BONF2)}")
        m, lo, hi, _ = pt([(V[X + '_u1'][s] - V[X][s]) * 100 for s in S_REP]); G = (st.mean(V["free"].values()) - st.mean(V[X].values())) * 100
        v = ("le gel explique l'essentiel" if lo >= 0.7 * G else "partage (chevauche 0,7 G)") if m >= 0.7 * G else (("l'essentiel vient d'ailleurs" if hi <= 0.3 * G else "partage (chevauche 0,3 G)") if m <= 0.3 * G else "partage")
        print(f"    (3) U = {m:+.2f} [{lo:+.2f}, {hi:+.2f}] contre 0,7 G = {0.7 * G:.2f} (G recalcule sur 120-124 : {G:+.2f} ; graines 2-6 : {G_ORIG[X]:+.2f}) -> {v}")
    frozen = ("top", "bottom", "random", "random_ortho")
    def fc(ix):
        m = {k: st.mean(V[k][s] for s in ix) for k in frozen}; ff = st.mean(V["free"][s] for s in ix)
        return (ff - max(m.values())) * 100 - (max(m.values()) - min(m.values())) * 100
    fzv = {k: st.mean(V[k].values()) for k in frozen}; gap = (st.mean(V["free"].values()) - max(fzv.values())) * 100; spread = (max(fzv.values()) - min(fzv.values())) * 100
    print("\n  (4) PRE-ENREGISTRE  ecart entre bandes, A gele contre B gele : " + col(pt([((V["dual_bottom"][s] - V["dual_top"][s]) - (V["bottom"][s] - V["top"][s])) * 100 for s in S_REP]), T4)
          + f"   (A gele : {st.mean([(V['dual_bottom'][s] - V['dual_top'][s]) * 100 for s in S_REP]):+.2f} ; plancher " + ("atteint)" if floor else "NON atteint)"))
    print(f"\n  rapporte, descriptif, sans test : gap minus spread = {gap:.2f} - {spread:.2f} = {gap - spread:+.2f}   (origine : +5,4)")
