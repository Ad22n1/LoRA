"""Curvature of the four frozen arms: at initialisation, at the end of training, and along the path.

  left   lambda_max per arm, median over seeds, at initialisation and at step 274 (log scale). The
         step-274 values come from the strict campaign (curv274strict_*.csv, reported population only).
  right  lambda_max along the path for bottom (5e-3) and top (1e-2), if curvature_traj.csv exists.
         bottom's trajectory runs were trained at 5e-3, the step-274 table uses bottom at 2e-3: the two
         panels are not compared number for number, and the caption must say so.

Reads the analysis CSVs; types nothing in. Prints every value it draws and the file it came from.

    python scripts/fig_curvature_arms.py paper/figures/curvature_arms.png
"""
import glob
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
# No conclusions inside the images (24/09): every title is dropped, only panel letters such as "(a)"
# are kept where a caption refers to them. What a figure shows is said in its caption, where it can
# be qualified -- a claim written in the image cannot.
import re as _re
import matplotlib.axes as _max
import matplotlib.figure as _mfig
_set_title = _max.Axes.set_title
def _letter_only(self, label="", *a, **k):
    m = _re.match(r"\s*\(([a-z])\)", str(label))
    return _set_title(self, f"({m.group(1)})" if m else "", loc="left", fontsize=10)
_max.Axes.set_title = _letter_only
_mfig.Figure.suptitle = lambda self, *a, **k: None
import pandas as pd

A = os.path.expanduser("~/lora-analysis")
ARMS = ["bottom", "top", "random", "random_ortho"]
COL = {"bottom": "#c44e52", "top": "#4c72b0", "random": "#55a868", "random_ortho": "#8172b2"}


def init_values():
    """Initialisation: any curvature CSV that is not a step-274 or trajectory file, rank 2, Llama."""
    # The paper's initialisation values are the five-restart measurement: a single random start
    # stalls on bottom's subspace (see the text), and curvature.csv is an early 20-iteration probe
    # on a different normalisation. Read the restart file first, and only fall back if it is absent.
    pref = os.path.join(A, "curvature_5seeds_restarts.csv")
    if os.path.exists(pref):
        t = pd.read_csv(pref)
        if "model" in t:
            t = t[t.model.astype(str).str.contains("Llama")]
        if "rank" in t:
            t = t[t["rank"] == 2]
        return pref, t.groupby("mode").curvature_median.median()
    best = None
    for f in sorted(glob.glob(os.path.join(A, "curvature*.csv"))):
        if any(k in os.path.basename(f) for k in ("strict", "traj", "step274", "274")):
            continue
        t = pd.read_csv(f)
        if "mode" not in t or "curvature_median" not in t:
            continue
        if "from_step" in t:
            t = t[t.from_step.isna() | (t.from_step.astype(str).isin(["", "0", "0.0", "init", "nan"]))]
        if "model" in t:
            t = t[t.model.astype(str).str.contains("Llama")]
        if "rank" in t:
            t = t[t["rank"] == 2]
        g = t.groupby("mode").curvature_median.median()
        if best is None or g.index.isin(ARMS).sum() > best[1].index.isin(ARMS).sum():
            best = (f, g)
    return best


# bottom is read at its selected rate, 5e-3; curv274strict_bottom.csv holds the old 2e-3 measurement
s274 = pd.concat([pd.read_csv(f) for f in sorted(glob.glob(os.path.join(A, "curv274strict_*.csv")))
                  if os.path.basename(f) != "curv274strict_bottom.csv"],
                 ignore_index=True).groupby("mode").curvature_median.median()
ini = init_values()
print("  step 274 (strict): " + "  ".join(f"{m}:{s274.get(m, float('nan')):.2f}" for m in ARMS))
if ini:
    print(f"  initialisation ({os.path.basename(ini[0])}): " + "  ".join(f"{m}:{ini[1].get(m, float('nan')):.2f}" for m in ARMS))
else:
    print("  initialisation: no CSV found, left panel shows step 274 only")

traj_p = os.path.join(A, "curvature_traj.csv")
traj = pd.read_csv(traj_p) if os.path.exists(traj_p) else None
fig, axes = plt.subplots(1, 2 if traj is not None else 1, figsize=(9.6 if traj is not None else 5.4, 3.8))
axes = axes if traj is not None else [axes]
ax = axes[0]
w = 0.38
for i, m in enumerate(ARMS):
    if ini and m in ini[1]:
        ax.bar(i - w / 2, ini[1][m], w, color=COL[m], alpha=0.35)
    ax.bar(i + w / 2 if ini else i, s274.get(m, float("nan")), w, color=COL[m])
    # two decimals: at one, 33.55 prints as "33.5" (binary rounding) and reads as a third value
    ax.text(i + w / 2 if ini else i, s274.get(m, 0) * 1.08, f"{s274.get(m, float('nan')):.2f}", ha="center", fontsize=7)
    if ini and m in ini[1]:
        ax.text(i - w / 2, ini[1][m] * 1.08, f"{ini[1][m]:.2f}", ha="center", fontsize=7, color="0.35")   # 2 decimals, as the step-274 bars
ax.set_yscale("log")
ax.set_xticks(range(len(ARMS)), ARMS, fontsize=8.5)
ax.set_ylabel(r"$\lambda_{\max}$, median over seeds (log)")
ax.set_title("The minor band is the stiffest, before and after", fontsize=10)
# neutral swatches: each arm has its own colour, so a legend in bottom's red would read as bottom's
from matplotlib.patches import Patch
ax.legend(handles=[Patch(color="0.55", alpha=0.35, label="at initialisation (left bar)"),
                   Patch(color="0.35", label="at step 274 (right bar)")], frameon=False, fontsize=8)
if traj is not None:
    b = axes[1]
    step = "from_step" if "from_step" in traj else "step"
    for m in ("bottom", "top"):
        t = traj[traj["mode"] == m].copy()
        t[step] = pd.to_numeric(t[step], errors="coerce")
        g = t.groupby(step).curvature_median.median().sort_index()
        q1 = t.groupby(step).curvature_median.quantile(0.25).sort_index()
        q3 = t.groupby(step).curvature_median.quantile(0.75).sort_index()
        b.fill_between(g.index, q1.values, q3.values, color=COL[m], alpha=0.18, lw=0)
        b.plot(g.index, g.values, "o-", color=COL[m], ms=4, label=f"{m} ({'5e-3' if m == 'bottom' else '1e-2'})")
        print(f"  path {m}: " + "  ".join(f"{int(k)}:{v:.1f}" for k, v in g.items()))
    b.set_yscale("log")
    b.set_xlabel("training step")
    b.set_title("Along the path (other runs: seeds 17-21)", fontsize=10)
    # (01/10) the note "medians over five seeds, band = interquartile range; ..." is removed, as in the paper's version (no note
    # inside the image): the caption says it
    b.legend(frameon=False, fontsize=8)
for x in axes:
    for sp in ("top", "right"):
        x.spines[sp].set_visible(False)
fig.tight_layout()
dst = sys.argv[1] if len(sys.argv) > 1 else "paper/figures/curvature_arms.png"
os.makedirs(os.path.dirname(dst) or ".", exist_ok=True)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _layout import save_at_width  # noqa: E402
save_at_width(fig, dst, 1568)   # (01/10) the width of the paper's version
print(f"  written -> {dst}")
