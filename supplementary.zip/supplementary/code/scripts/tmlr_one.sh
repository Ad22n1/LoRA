#!/bin/bash
# Conducteur d'UNE experience TMLR (meme logique que tmlr_weekend.sh) :  nohup bash scripts/tmlr_one.sh e6 sel > ~/tmlr_e6.log 2>&1 &
# Toutes les 3 minutes : si aucun run de l'experience n'est dans la file, execute son etape suivante ; runs manquants, file vide :
# deux relances au plus, puis blocage signale. S'arrete a FINI, au blocage, ou a l'echeance (~/.tmlr/arret).
set -u
USER="${USER:-$(whoami)}"; K="$1"; FIRST="$2"
cd "$HOME/repo" || exit 1
PY="/tmp/lora-$USER/venv/bin/python"; S="$HOME/.tmlr"; mkdir -p "$S"
[ -f "$S/$K.etape" ] || echo "$FIRST" > "$S/$K.etape"
log() { echo "$(date '+%d/%m %H:%M')  $*"; }
END=$(date -d "$(cat "$S/arret" 2>/dev/null || date -d 'next monday 07:55' '+%Y-%m-%dT%H:%M:%S')" +%s)
log "conducteur de $K demarre ; echeance $(date -d "@$END" '+%d/%m %H:%M')"
while [ "$(date +%s)" -lt "$END" ]; do
  e=$(cat "$S/$K.etape"); case "$e" in fini|bloque) log "$K : $e"; exit 0 ;; esac
  if [ "$(squeue -h -u "$USER" -o "%o" 2>/dev/null | grep -c "/lora-grid/v2_${K}_")" -gt 0 ]; then sleep 180; continue; fi
  out=$("$PY" scripts/tmlr.py "$K" "$e" 2>&1); code=$?
  echo "$out" | sed "s/^/    [$K $e] /"
  if echo "$out" | grep -q "^FINI"; then echo fini > "$S/$K.etape"; log "$K : FINI -> ~/tmlr_lecture_$K.txt"; exit 0; fi
  if { echo "$out" | grep -qE "^STOP|Traceback" || [ $code -ne 0 ]; } && ! echo "$out" | grep -q "^ATTENTE"; then echo bloque > "$S/$K.etape"; log "$K : BLOQUE a l'etape « $e »"; exit 1; fi
  nx=$(echo "$out" | grep -oE "^ETAPE: [a-z]+" | cut -d' ' -f2)
  if [ -n "$nx" ]; then echo "$nx" > "$S/$K.etape"; rm -f "$S/$K.relances"; log "$K : « $e » faite -> « $nx »"; continue; fi
  if echo "$out" | grep -q "^ATTENTE"; then
    sleep 60; [ "$(squeue -h -u "$USER" -o "%o" 2>/dev/null | grep -c "/lora-grid/v2_${K}_")" -gt 0 ] && continue
    n=$(cat "$S/$K.relances" 2>/dev/null || echo 0)
    if [ "$n" -lt 2 ]; then echo $((n + 1)) > "$S/$K.relances"; log "$K : runs manquants, file vide : relance $((n + 1))/2"; "$PY" scripts/tmlr.py "$K" relaunch 2>&1 | sed "s/^/    [$K relance] /"
    else echo bloque > "$S/$K.etape"; log "$K : BLOQUE (runs manquants apres deux relances)"; exit 1; fi
  fi
  sleep 180
done
log "$K : echeance atteinte"
