#!/bin/bash
# Two forgetting evaluations, no training, same script and options as forget_common_lr.sh:
#  (1) bottom at 5e-3, the rate the selection rule picks: does the forgetting inversion survive the
#      other tie-break? seeds 2-6; seed 2 has two runs (the collapsed one and its converged rerun),
#      both are measured and reported separately by the analysis, never averaged into one number.
#  (2) top at 1e-2, seed 2 alone, measured again: its perplexity of 69 is the outlier of Table 16.
#      A deterministic evaluation of the same factors should give the same value if it is real.
#SBATCH --job-name=forgetx
#SBATCH --partition=PARTITION
#SBATCH --cpus-per-task=4
#SBATCH --mem=32G
#SBATCH --time=01:59:00
#SBATCH --exclude=node
#SBATCH --output=~/lora-results/forgetx-%j.out
source /tmp/lora-$USER/venv/bin/activate
export SHARED=$HOME/lora-shared
cd $HOME/repo
python -c "
import yaml
yaml.safe_dump({'selected': {'meta-llama/Llama-3.2-1B|format|bottom|2': 0.005}}, open('configs/lr_bottom_5e-3.yaml', 'w'))
yaml.safe_dump({'selected': {'meta-llama/Llama-3.2-1B|format|top|2': 0.01}}, open('configs/lr_top_1e-2.yaml', 'w'))"
python scripts/forgetting_from_factors.py --svd_cache "$SHARED/svd" --lr_from configs/lr_bottom_5e-3.yaml \
  --modes bottom --seeds 2,3,4,5,6 --out "$HOME/lora-analysis/forgetting_bottom_5e-3.csv"
python scripts/forgetting_from_factors.py --svd_cache "$SHARED/svd" --lr_from configs/lr_top_1e-2.yaml \
  --modes top --seeds 2 --out "$HOME/lora-analysis/forgetting_top_seed2_recheck.csv"
