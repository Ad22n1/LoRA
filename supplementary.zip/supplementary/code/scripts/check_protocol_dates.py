"""Does the date written in each protocol match the date of the commit that first registered it?

    python scripts/check_protocol_dates.py

For every PROTOCOL_*.md: the first commit that added it (git), and the dates written in its text (dd/mm). A text date that
differs from the commit date is flagged. The commit is what proves the order of events; the text must not contradict it.
The flagged files are then corrected by ONE dated note, never by rewriting a committed protocol.
"""
import glob
import re
import subprocess

rows, bad = [], 0
for f in sorted(glob.glob("PROTOCOL_*.md")):
    log = subprocess.run(["git", "log", "--diff-filter=A", "--format=%ci %h", "--", f], capture_output=True, text=True).stdout.strip().splitlines()
    if not log:
        print(f"  {f:44s} NON COMMITTE"); continue
    when, h = log[-1][:16], log[-1].split()[-1]
    dd, mm = when[8:10], when[5:7]
    text = open(f, encoding="utf-8").read()
    head = "\n".join(text.splitlines()[:6])                     # the date a protocol claims is in its first lines
    claimed = sorted(set(re.findall(r"\b(\d{2})/(\d{2})\b", head)))
    mism = [f"{d}/{m}" for d, m in claimed if (d, m) != (dd, mm)]
    flag = "  <-- A CORRIGER" if mism else ""
    bad += bool(mism)
    print(f"  {f:44s} commit {h} {when}   texte : {', '.join(f'{d}/{m}' for d, m in claimed) or '-'}{flag}")
print(f"\n  {bad} protocole(s) dont le texte contredit la date du commit")
