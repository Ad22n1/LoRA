#!/bin/bash
# Lance « geler A plutot que B » sur OpenBookQA au rang 2 (PROTOCOL_obqa_freeze_A.md) : 1 grille, 147 runs.
#   bash scripts/launch_obqa_freeze_A.sh --dry               (verifie et compte, ne soumet rien)
#   bash scripts/launch_obqa_freeze_A.sh                     (soumet)
#   bash scripts/launch_obqa_freeze_A.sh --avec-freezeA      (soumet, et complete les runs manquants de freezeA_all,
#                                                             A UTILISER seulement apres scripts/check_dual_ro.py)
# Garde-fous : protocole, grilles et lecture committes AVANT tout run ; une grille dont des jobs tournent n'est jamais touchee.
set -u
DRY=0; FA=0; PARTITION="RTX 4000 Ada"; for a in "$@"; do [ "$a" = "--dry" ] && DRY=1; [ "$a" = "--avec-freezeA" ] && FA=1; done
cd "$HOME/repo" || { echo "STOP : ~/repo introuvable"; exit 1; }
PY="/tmp/lora-$USER/venv/bin/python"; [ -x "$PY" ] || { echo "STOP : environnement /tmp/lora-$USER/venv absent"; exit 1; }
GRIDS="obqa_dual"
FILES="PROTOCOL_obqa_freeze_A.md scripts/read_obqa_freeze_A.py configs/grids/obqa_dual.yaml scripts/nodes_for_gpu.py"
echo "=== 1. tout est committe et a jour ==="
bad=0
for f in $FILES; do
  git ls-files --error-unmatch "$f" >/dev/null 2>&1 && git diff --quiet HEAD -- "$f" || { echo "  NON COMMITTE OU MODIFIE : $f"; bad=1; }
done
[ $bad -eq 0 ] && echo "  ok" || { echo "  REFUS : committer d'abord ; rien n'est lance"; exit 1; }
echo "=== 2. place disque (facteurs finaux sauvegardes, ~1 Go au total) ==="
du -sh "$HOME" 2>/dev/null | sed 's/^/  dossier personnel : /'
echo "=== 2 bis. epinglage sur un seul modele de carte : $PARTITION ==="
EXCL=$("$PY" scripts/nodes_for_gpu.py "$PARTITION" 2>&1 | tail -1)
case "$EXCL" in STOP*|"") echo "  $EXCL"; echo "  REFUS : epinglage impossible ; rien n'est lance"; exit 1;; esac
"$PY" scripts/nodes_for_gpu.py "$PARTITION" --report 2>&1 | head -3
echo "=== 3. lancement ==="
for g in $GRIDS; do
  if squeue -h -u "$USER" -o "%o" 2>/dev/null | grep -q "/lora-grid/$g/slurm_array.sh"; then echo "  EN COURS $g : rien n'est touche"; continue; fi
  dir="$HOME/lora-grid/$g"; [ $DRY -eq 1 ] && dir="$(mktemp -d)/$g"
  out=$("$PY" -m lorasub.launch_grid "configs/grids/$g.yaml" --grid_dir "$dir" --partition PARTITION --time 01:59:00 --max_par 8 --venv "/tmp/lora-$USER/venv" 2>&1)
  n=$(echo "$out" | grep -oE "[0-9]+ already done; [0-9]+ to run")
  [ -n "$n" ] || { echo "  ERREUR $g :"; echo "$out" | tail -3 | sed 's/^/    /'; continue; }
  done_=$(echo "$n" | grep -oE "^[0-9]+"); torun=$(echo "$n" | grep -oE "[0-9]+ to run" | grep -oE "[0-9]+")
  if [ "$torun" -eq 0 ]; then echo "  RIEN    $g : complet ($done_)"; continue; fi
  if [ "$done_" -gt 0 ]; then echo "  SAUTE   $g : $done_ runs existent deja (collision, a verifier)"; continue; fi
  if [ $DRY -eq 1 ]; then echo "  pret    $g : $torun runs"; continue; fi
  { echo "campagne $g, epinglee sur $PARTITION, le $(date +'%d/%m %H:%M') ; machines exclues :"; echo "node,$EXCL" | tr ',' '\n'; } > "$HOME/lora-grid/$g/machines_epinglees.txt"
  echo "  soumis  $g ($torun runs, epingle sur $PARTITION) : job $(sbatch --parsable --exclude="node,$EXCL" "$HOME/lora-grid/$g/slurm_array.sh")"
done
if [ $FA -eq 1 ]; then
  echo "=== 4. completer les runs manquants de freezeA_all (meme grille, meme protocole) ==="
  g=freezeA_all
  if squeue -h -u "$USER" -o "%o" 2>/dev/null | grep -q "/lora-grid/$g/slurm_array.sh"; then echo "  EN COURS $g : rien n'est touche"
  else
    out=$("$PY" -m lorasub.launch_grid "configs/grids/$g.yaml" --grid_dir "$HOME/lora-grid/$g" --partition PARTITION --time 01:59:00 --max_par 8 --venv "/tmp/lora-$USER/venv" 2>&1)
    n=$(echo "$out" | grep -oE "[0-9]+ already done; [0-9]+ to run"); torun=$(echo "$n" | grep -oE "[0-9]+ to run" | grep -oE "[0-9]+")
    if [ -z "$n" ]; then echo "  ERREUR $g"; elif [ "$torun" -eq 0 ]; then echo "  RIEN    $g : complet"
    elif [ $DRY -eq 1 ]; then echo "  pret    $g : $torun runs manquants"
    else echo "  soumis  $g ($torun runs manquants) : job $(sbatch --parsable --exclude=node "$HOME/lora-grid/$g/slurm_array.sh")"; fi
  fi
fi
echo "=== file ==="; squeue -u "$USER" | head -6
