"""PROTOCOL_long_training.md: the rank-2 isolation with four times more training tokens (2 400 000). No PARTITION.

    python scripts/read_long.py 2>&1 | grep -vE "FutureWarning|pd.concat"

Each arm's rate selected on seeds 0-1 (validation) among its four; reported seeds 2-6. Tests: (1) X_unfrozen - X at rank 2, t > 3.495;
(2) the band-gap shrinkage, t > 2.776, read only if the frozen gap is at least 2 points. Reported: G, and the values at 600 000 tokens.
"""
import csv
import glob
import json
import math
import os
import random
import re
import statistics as st

import yaml

R = os.path.expanduser("~/lora-runs")
LLAMA, QWEN = "meta-llama/Llama-3.2-1B", "Qwen/Qwen2.5-1.5B"
S_SEL, S_REP = (0, 1), [2, 3, 4, 5, 6]


def tokens(c):
    t = c.get("target_tokens")
    return t.get(c.get("task")) if isinstance(t, dict) else t


RUNS = []
for p in glob.glob(R + "/*/config.yaml"):
    c = yaml.safe_load(open(p)) or {}
    d = os.path.dirname(p)
    try:
        if not open(d + "/status").read().startswith("DONE"):
            continue
        RUNS.append((c, json.load(open(d + "/metrics.json")), d))
    except OSError:
        continue


def clipped(c):
    """Gradient clipping at 1.0, the paper's setting. A noclip grid reran the same cells without clipping (collect()'s
    docstring); mixing both put two runs per seed in the frozen cells and moved G from 12.41 to 13.53 (26/09)."""
    v = c.get("max_grad_norm", 1.0)
    return v is not None and float(v) == 1.0


def seven(c):
    tm = c.get("target_modules")
    return tm is None or len(tm) == 7


def cell(pred, mode, rank, lr, seeds, key):
    """{seed: value}; several runs of one seed are averaged and flagged."""
    by = {}
    for c, m, d in RUNS:
        if (pred(c) and clipped(c) and c.get("mode") == mode and c.get("rank") == rank and abs(float(c.get("lr") or 0) - lr) < 1e-12
                and c.get("seed") in seeds and key in m and c.get("update_norm_target") in (None, "")):
            by.setdefault(c["seed"], []).append((m[key], d))
    dup = {s: len(v) for s, v in by.items() if len(v) > 1}
    if dup:   # say what separates the duplicates, so that the next filter is written from evidence
        s0 = sorted(dup)[0]; cfgs = [yaml.safe_load(open(d + "/config.yaml")) or {} for _, d in by[s0]]
        keys = sorted(k for k in set().union(*cfgs) if k not in ("run_id", "out_dir") and len({str(c_.get(k)) for c_ in cfgs}) > 1)
        dup["differ"] = {k: [c_.get(k) for c_ in cfgs] for k in keys} or "configs identiques"
    return {s: st.mean(x for x, _ in v) for s, v in by.items()}, dup, {s: [d for _, d in v] for s, v in by.items()}


def select(pred, mode, rank, lrs, key):
    full = {}
    for lr in lrs:
        v, _, _ = cell(pred, mode, rank, lr, S_SEL, key)
        if len(v) == 2: full[lr] = st.mean(v.values())
    if len(full) < len(lrs):
        return None, f"INCOMPLET ({len(full)}/{len(lrs)} taux avec leurs deux graines)"
    best = max(full, key=full.get)
    edge = best in (lrs[0], lrs[-1])
    return best, "  ".join(f"{lr:g}:{full[lr]:.3f}" for lr in lrs) + f"  -> {best:g}" + ("  AU BORD" if edge else "")



LONG = 2_400_000
T4, BONF2 = 2.776, 3.495
long_fmt = lambda c: (c.get("task") == "format" and str(c.get("model")) == LLAMA and tokens(c) == LONG and seven(c)  # noqa: E731
                      and c.get("max_len") == 384 and c.get("batch_size") == 2 and c.get("grad_accum") == 16)
ARMS = {"top": (2, [2e-3, 5e-3, 1e-2, 2e-2], 1e-2, 0.6443), "bottom": (2, [1e-3, 2e-3, 5e-3, 1e-2], 5e-3, 0.5922),
        "top_unfrozen": (2, [1e-3, 2e-3, 5e-3, 1e-2], 5e-3, 0.8000), "bottom_unfrozen": (2, [5e-4, 1e-3, 2e-3, 5e-3], 2e-3, 0.8072),
        "free": (1, [2e-4, 5e-4, 1e-3, 2e-3], 1e-3, 0.7684)}


def gpu_of(d):
    try:
        with open(d + "/results.csv", newline="") as f:
            return (next(csv.DictReader(f)).get("PARTITION") or "?").replace("NVIDIA ", "").replace(" Generation", "")
    except (OSError, StopIteration):
        return "?"


def pt(d):
    m = st.mean(d); se = st.stdev(d) / len(d) ** 0.5
    return m, m - T4 * se, m + T4 * se, (m / se if se > 0 else float("inf"))


print("==================== l'isolation au rang 2, entrainement quatre fois plus long (2 400 000 tokens, tache de format, Llama) ====================")
V, gpus, bad = {}, set(), []
for mode, (rank, lrs, paper_lr, orig) in ARMS.items():
    b, txt = select(long_fmt, mode, rank, lrs, "val_format_parsed")
    print(f"  selection {mode:16s} : {txt}   (taux du papier : {paper_lr:g})")
    if b is None:
        bad.append(mode); continue
    v, dup, dirs = cell(long_fmt, mode, rank, b, S_REP, "format_parsed")
    if len(v) != 5 or dup:
        bad.append(mode); continue
    V[mode] = v; gpus |= {gpu_of(dirs[s][0]) for s in S_REP}
    print(f"    {mode} a {b:g} : {st.mean(v.values()):.4f}   (a 600 000 tokens : {orig:.4f}, ecart {(st.mean(v.values()) - orig) * 100:+.2f})" + ("  AU BORD" if b in (lrs[0], lrs[-1]) else ""))
if bad:
    print(f"  ARRET : cellules incompletes : {bad}")
else:
    print(f"  modeles de carte : {sorted(gpus)}")
    col = lambda x, thr: f"{x[0]:+.2f} [{x[1]:+.2f}, {x[2]:+.2f}] t={x[3]:+.2f} -> " + ("ETABLI" if abs(x[3]) > thr else "non etabli")  # noqa: E731
    for X, orig in (("top", 15.57), ("bottom", 21.50)):
        G = (st.mean(V["free"].values()) - st.mean(V[X].values())) * 100
        print(f"\n  --- {X} : G = {G:+.2f} (rapporte)")
        print(f"    (1) gel seul, r=2 : {col(pt([(V[X + '_unfrozen'][s] - V[X][s]) * 100 for s in S_REP]), BONF2)}   (a 600 000 tokens : +{orig})")
    fz = [(V["bottom"][s] - V["top"][s]) * 100 for s in S_REP]
    d = [((V["bottom_unfrozen"][s] - V["top_unfrozen"][s]) - (V["bottom"][s] - V["top"][s])) * 100 for s in S_REP]
    floor = abs(st.mean(fz)) >= 2.0
    print(f"\n  (2) PRE-ENREGISTRE  ecart bottom - top : {st.mean(fz):+.2f} geles, {st.mean([(V['bottom_unfrozen'][s] - V['top_unfrozen'][s]) * 100 for s in S_REP]):+.2f} degeles ; plancher "
          + ("atteint" if floor else "NON atteint : pas lu comme un retrecissement"))
    print(f"      retrecissement : {col(pt(d), T4)}   (a 600 000 tokens : +5,93 post hoc ; +6,78 sur graines neuves)")
