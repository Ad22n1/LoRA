#!/bin/bash
#SBATCH --partition=PARTITION
#SBATCH --time=01:59:00
#SBATCH --job-name=curv5
#SBATCH --exclusive
#SBATCH --mem=32G
#SBATCH --cpus-per-task=4
#SBATCH --output=~/lora-results/curv5-%j.out
source /tmp/lora-$USER/venv/bin/activate
export SHARED=$HOME/lora-shared
FREE=$(nvidia-smi --query-PARTITION=memory.free --format=csv,noheader,nounits | head -1)
echo "node: $(hostname)  free: ${FREE} MiB"
if [ "$FREE" -lt 13000 ]; then echo "skip: only ${FREE} MiB free"; exit 0; fi
cd $HOME/repo
python scripts/curvature.py --data_dir $SHARED/data --svd_cache $SHARED/svd \
  --rank 2 --seeds 2,3,4,5,6 --n_batches 3 --batch 1 --restarts 5 --max_len 384 \
  --out $HOME/lora-analysis/curvature_5seeds_restarts.csv
