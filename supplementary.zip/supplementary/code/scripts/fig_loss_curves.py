"""Figure « Training loss of each arm » (post hoc) pour le papier : une colonne, en anglais, noms du papier.

    python fig_loss_curves.py analyses_loss_curves.csv analyses_loss_curves.png
Le CSV est celui qu'ecrit scripts/analyses_v2.py --loss (colonnes : population, bras, pas, perte_moyenne, graines).
"""
import csv
import sys
from collections import defaultdict

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402
from matplotlib.ticker import FixedLocator, FuncFormatter, NullFormatter  # noqa: E402

src, out = sys.argv[1], sys.argv[2]
data = defaultdict(list)
for r in csv.DictReader(open(src)):
    data[(r["population"], r["bras"])].append((int(r["pas"]), float(r["perte_moyenne"])))
PANELS = [("OBQA/Qwen1.5B", "OpenBookQA, Qwen2.5-1.5B"), ("format/Llama", "format task, Llama-3.2-1B")]  # l'ordre de la legende du papier
# convention commune des figures : rouge B gele, orange A gele ; B entraine bleu FONCE au rang a budget egal, bleu CLAIR au rang egal
# (ici r = 2, le rang des bras geles : bleu clair) ; LoRA libre en TIRETS ; modele de base en pointilles. Bande : plein = dominante,
# trait mixte = mineure (les tirets sont reserves au LoRA libre).
LIGHT_BLUE = "#6fa8dc"
STYLE = {"top": ("#c0392b", "-"), "bottom": ("#c0392b", "-."), "dual_top": ("#e08a4f", "-"), "dual_bottom": ("#e08a4f", "-."),
         "tu2": (LIGHT_BLUE, "-"), "bu2": (LIGHT_BLUE, "-."), "free": ("#222222", "--")}
plt.rcParams.update({"font.size": 8, "axes.titlesize": 8.5, "axes.labelsize": 8, "xtick.labelsize": 7.5, "ytick.labelsize": 7.5,
                     "legend.fontsize": 7.2, "axes.spines.top": False, "axes.spines.right": False})
fig, axes = plt.subplots(2, 1, figsize=(3.3, 4.4), constrained_layout=True)
for ax, (pop, title) in zip(axes, PANELS):
    for arm, (col, ls) in STYLE.items():
        pts = sorted(data.get((pop, arm), []))
        if not pts:
            sys.exit(f"ARRET : pas de donnees pour {pop} / {arm}")
        ax.plot([p for p, _ in pts], [v for _, v in pts], color=col, ls=ls, lw=1.3)
    ax.set_title(title, loc="left"); ax.set_ylabel("training loss"); ax.grid(axis="y", color="#e6e6e6", lw=0.6)
    if pop.startswith("format"):          # la perte y varie d'un facteur dix : echelle log, graduations en nombres simples
        ax.set_yscale("log"); ax.yaxis.set_major_locator(FixedLocator([0.01, 0.02, 0.05, 0.1, 0.2, 0.5, 1.0, 2.0]))
        ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:g}")); ax.yaxis.set_minor_formatter(NullFormatter())
axes[-1].set_xlabel("optimiser step")
handles = [Line2D([], [], color="#c0392b", lw=1.3, label="$B$ frozen, $r=2$"), Line2D([], [], color="#e08a4f", lw=1.3, label="$A$ frozen, $r=2$"),
           Line2D([], [], color=LIGHT_BLUE, lw=1.3, label="$B$ trained, $r=2$"), Line2D([], [], color="#222222", lw=1.3, ls="--", label="free LoRA, $r=1$"),
           Line2D([], [], color="#777777", lw=1.3, ls="-", label="dominant band"), Line2D([], [], color="#777777", lw=1.3, ls="-.", label="minor band")]
fig.legend(handles=handles, loc="outside lower center", ncol=2, frameon=False, handlelength=2.2, columnspacing=1.2)
fig.savefig(out, dpi=300); print(f"  ecrit -> {out}")
