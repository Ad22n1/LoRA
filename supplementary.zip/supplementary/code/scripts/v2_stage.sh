#!/bin/bash
# Une etape d'une experience v2 : bash scripts/v2_stage.sh <campagne> <etape> [--dry]
# Execute l'etape du moteur, COMMITTE ce qu'elle produit (grilles, selection, G, verdict de la sonde) AVANT tout run, puis lance ce qu'elle designe.
set -u
cd "$HOME/repo" || exit 1
PY="/tmp/lora-$USER/venv/bin/python"; [ -x "$PY" ] || PY=python3
K="${1:?campagne}"; E="${2:?etape}"; DRY="${3:-}"
out=$("$PY" scripts/v2camp.py "$K" "$E" 2>&1); code=$?
echo "$out" | grep -v "^LANCER:"
[ $code -eq 4 ] && { echo "  (en attente d'une autre campagne ; rien n'est committe ni lance)"; exit 4; }
[ $code -eq 0 ] || { echo "  STOP : l'etape $E s'est arretee ; rien n'est committe ni lance"; exit 1; }
L=$(echo "$out" | grep "^LANCER:" | tail -1 | awk '{print $2}')
for f in configs/grids/v2_${K}_* v2_${K}_*.json; do [ -e "$f" ] && git add "$f"; done      # un par un : un motif vide ne bloque pas les autres
for f in bases/learned_*.safetensors bases/learned_*.json; do [ -e "$f" ] && git add -f "$f"; done   # -f : .gitignore exclut les .safetensors
if git diff --cached --quiet; then echo "  (rien de nouveau a committer)"; else
  git commit -qm "v2 $K : etape $E (produite avant ses runs)" && echo "  ok : committe ($(git log -1 --format='%h %ad' --date=format:'%d/%m %H:%M'))"; git push -q 2>/dev/null || echo "  ATTENTION : push echoue"; fi
[ -z "$L" ] || [ "$L" = "rien" ] && { echo "  rien a lancer a cette etape"; exit 0; }
bash scripts/launch_v2.sh "$K" "$L" $DRY
