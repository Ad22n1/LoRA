"""beta=0.75 against random_ortho on Qwen, exactly as PROTOCOL_qwen_rortho.md fixed it before launch.

Primary, the only test that counts: seeds 7-16 alone, one-sided paired t, one comparison, t > 1.833.
Secondary, no claim: seeds 2-16 pooled, t > 1.761. Sign test and exact Wilcoxon beside each t.
A seed missing either arm is excluded; the script says so and does not test on fewer than ten.

    python scripts/analyse_qwen_rortho.py
"""
import itertools
import os
import statistics as st
import sys
from math import comb

import yaml

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
from lorasub.aggregate import collect  # noqa: E402

M = "Qwen/Qwen2.5-0.5B"
T = (yaml.safe_load(open("configs/lr_selected.yaml")) or {})["selected"]
d = collect(os.path.expanduser("~/lora-runs"))
B = d[(d.task == "format") & (d.model.astype(str) == M) & (d["rank"] == 2) & (d.n_modules == 7)
      & (d.max_grad_norm == 1.0) & d.update_norm_target.isna() & (d.format_n == 614)]
lr75 = T[f"{M}|format|band|2|b0.75"]
band = B[(B["mode"] == "band") & ((B.band_frac - 0.75).abs() < 1e-9) & ((B.lr - lr75).abs() < 1e-12)]
ro = B[(B["mode"] == "random_ortho") & (B.subspace_salted == True) & ((B.lr - 0.01).abs() < 1e-12)]
b75 = band.groupby("seed").format_parsed.mean()
rorth = ro.groupby("seed").format_parsed.mean()
reps = int((ro.groupby("seed").size() > 1).sum())


def wilcoxon_one_sided(dif):
    a = sorted(range(len(dif)), key=lambda i: abs(dif[i])); rk = [0.0] * len(dif); i = 0
    while i < len(a):
        j = i
        while j + 1 < len(a) and abs(dif[a[j + 1]]) == abs(dif[a[i]]):
            j += 1
        for k in range(i, j + 1):
            rk[a[k]] = (i + j) / 2 + 1
        i = j + 1
    wp = sum(r for r, x in zip(rk, dif) if x > 0)
    tot = [sum(r for r, s in zip(rk, sg) if s) for sg in itertools.product([0, 1], repeat=len(dif))]
    return sum(x >= wp - 1e-12 for x in tot) / len(tot)


def test(seeds, thr, label):
    have = [s for s in seeds if s in b75.index and s in rorth.index]
    print(f"\n=== {label}: seeds {seeds[0]}-{seeds[-1]}, {len(have)} complete, t > {thr} ===")
    if len(have) < len(seeds):
        print(f"  missing: {sorted(set(seeds) - set(have))} -> not tested; relaunch identically and rerun")
        return
    dif = [b75[s] - rorth[s] for s in have]
    n = len(dif); t = st.mean(dif) / (st.stdev(dif) / n ** 0.5); w = sum(x > 0 for x in dif)
    sg = sum(comb(n, i) for i in range(w, n + 1)) / 2 ** n
    print(f"  beta=0.75 {st.mean(b75[s] for s in have):.4f} | random_ortho {st.mean(rorth[s] for s in have):.4f}")
    print(f"  gap {st.mean(dif) * 100:+.2f} pt | t={t:.2f} {'PASS' if t > thr else 'does not pass'} | {w}/{n} seeds"
          f" | sign p={sg:.4f} | Wilcoxon p={wilcoxon_one_sided(dif):.4f}")


print(f"  random_ortho seeds with a replicate (averaged): {reps}")
test(list(range(7, 17)), 1.833, "PRIMARY, pre-registered")
test(list(range(2, 17)), 1.761, "SECONDARY, pooled, no claim")
