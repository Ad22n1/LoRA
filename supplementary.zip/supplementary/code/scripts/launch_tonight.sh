#!/usr/bin/env bash
# Tonight's launches (24/09), in priority order, after checks that refuse rather than guess.
#
#     bash scripts/launch_tonight.sh            # refuses before 17:00
#     bash scripts/launch_tonight.sh --dry      # checks and counts only, submits nothing (any time)
#
# Refuses to submit when: it is before 17:00 (no PARTITION in the daytime); a protocol or grid is not committed
# or differs from its commit (pre-registration is dated by the commit); a file still carries the wrong
# date "25/09"; a grid already has runs (a collision to understand first); a forgetting output exists.
set -u
cd "$HOME/repo" || exit 1
source "/tmp/lora-$USER/venv/bin/activate" || { echo "venv introuvable"; exit 1; }
DRY=0; [ "${1:-}" = "--dry" ] && DRY=1

if [ $DRY -eq 0 ] && [ "$(date +%H)" -lt 17 ]; then echo "  REFUS : il est $(date +%H:%M), pas de PARTITION avant 17:00 (ou --dry pour verifier)"; exit 1; fi

GRIDS_SMALL="random_r4_5e3_seeds facts_r64_bottom_edge"
GRIDS_ARC="arc_easy_edge_down arc_easy_edge_down_free arcc_own_top arcc_own_bottom_ro arcc_own_free"
GRIDS_R816="format_r8_sweep_s40 format_r8_free_sweep_s40 format_r16_sweep format_r16_free_sweep"   # rang 8 : graines neuves (additif)
PROTOS="PROTOCOL_rank16_arc_addendum.md PROTOCOL_rank8_16_format.md PROTOCOL_rank8_16_format_addendum.md"

echo "=== 1. protocoles et grilles committes, a jour, bien dates ==="
bad=0
for f in $PROTOS $(for g in $GRIDS_SMALL $GRIDS_ARC $GRIDS_R816; do echo configs/grids/$g.yaml; done); do
    if [ ! -f "$f" ]; then echo "  ABSENT       $f"; bad=1; continue; fi
    if ! git ls-files --error-unmatch "$f" >/dev/null 2>&1; then echo "  NON COMMITTE $f"; bad=1; continue; fi
    if ! git diff --quiet HEAD -- "$f"; then echo "  MODIFIE      $f (differe de son commit)"; bad=1; continue; fi
    if grep -q "25/09" "$f"; then echo "  MAUVAISE DATE $f (25/09 au node de 24/09)"; bad=1; continue; fi
done
[ $bad -eq 0 ] && echo "  ok : tout est committe, a jour et date du 24/09" || { echo "  REFUS : faire d'abord l'etape 0 de la todo (envoyer les fichiers corriges, puis committer)"; exit 1; }

count() {  # prints "done torun" for grid $1, after rebuilding its grid dir
    rm -rf "$HOME/lora-grid/$1"
    python -m lorasub.launch_grid "configs/grids/$1.yaml" --grid_dir "$HOME/lora-grid/$1" --partition PARTITION \
        --time 01:59:00 --max_par 4 --venv '/tmp/lora-$USER/venv' 2>&1 | grep -oE "[0-9]+ already done; [0-9]+ to run" | grep -oE "[0-9]+" | tr '\n' ' '
}
submit_grids() {
    for g in $1; do
        read -r done torun <<< "$(count "$g")"
        if [ -z "${done:-}" ]; then echo "  ERREUR  $g : comptage impossible"; continue; fi
        if [ "$done" -gt 0 ]; then echo "  SAUTE   $g : $done runs existent deja (collision a comprendre avant)"; continue; fi
        if [ "$torun" -eq 0 ]; then echo "  RIEN    $g"; continue; fi
        if [ $DRY -eq 1 ]; then echo "  pret    $g : $torun runs"; continue; fi
        sbatch --exclude=node "$HOME/lora-grid/$g/slurm_array.sh" | sed "s/^/  soumis  $g ($torun runs) : /"
    done
}

echo "=== 2. les petits runs qui reglent des notes ==="
submit_grids "$GRIDS_SMALL"

echo "=== 3. la remesure de l'oubli (evaluations seulement, sorties neuves) ==="
for spec in "top,random,random_ortho 2 own_r2" "free 1 free_r1" "free 2 free_r2"; do
    set -- $spec; out="$HOME/lora-analysis/forgetting_recheck_$3.csv"
    if [ -e "$out" ]; then echo "  SAUTE   $3 : $out existe deja (ne pas l'ecraser)"; continue; fi
    if [ $DRY -eq 1 ]; then echo "  pret    oubli $3"; continue; fi
    sbatch --partition=PARTITION --time=01:59:00 --exclude=node --mem=32G --cpus-per-task=4 \
        --output="$HOME/lora-results/forget-$3-%j.out" --wrap "source /tmp/lora-$USER/venv/bin/activate; cd $HOME/repo; \
        python scripts/forgetting_from_factors.py --svd_cache $HOME/lora-shared/svd --modes $1 --rank $2 \
        --seeds 2,3,4,5,6 --max_runs_per_cell 20 --out $out" | sed "s/^/  soumis  oubli $3 : /"
done

echo "=== 4. ARC ==="
submit_grids "$GRIDS_ARC"

echo "=== 5. format aux rangs 8 et 16, selection ==="
submit_grids "$GRIDS_R816"

echo "=== file ==="
squeue -u "$USER" | head -12
