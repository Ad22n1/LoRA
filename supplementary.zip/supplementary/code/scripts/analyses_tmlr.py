"""Analyses for the TMLR version (ANALYSES_tmlr.md), post hoc and descriptive; no new run.

    python scripts/analyses_tmlr.py --a1        # Holm over the 145 tests; writes analyses_tmlr_a1.json and analyses_tmlr_a1.md
    python scripts/analyses_tmlr.py --a2        # minimum detectable effects of the band comparisons not established
    python scripts/analyses_tmlr.py --a3        # PARTITION model behind each reported cell (reads ~/lora-runs*)

Definitions: ANALYSES_tmlr.md, committed before execution. Inputs: analyses_inputs/tests_spec.json, analyses_inputs/companion_tmlr.tex.
"""
import json
import os
import re
import sys

from scipy import stats

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SPEC = os.path.join(HERE, "analyses_inputs", "tests_spec.json")
TEX = os.path.join(HERE, "analyses_inputs", "companion_tmlr.tex")
M, ALPHA = 145, 0.05


# ------------------------------------------------------------------ p-values, one rule per class (ANALYSES_tmlr.md, A1)
def p_t(t, df, sided):
    return 2 * stats.t.sf(abs(t), df) if sided == 2 else stats.t.sf(t, df)


def p_boot(lo, hi, est=None):
    e = (lo + hi) / 2 if est is None else est
    se = (e - lo) / 1.96 if e >= 0 else (hi - e) / 1.96
    return 2 * (1 - stats.norm.cdf(abs(e) / se)) if se > 0 else 1.0


def p_ci_t(lo, hi, thr, df, side):
    e = (lo + hi) / 2; se = (hi - lo) / (2 * stats.t.ppf(0.975, df))
    return stats.t.sf((e - thr) / se if side == "above" else (thr - e) / se, df)


def p_ci_t_two(lo, hi, est, df):
    e = (lo + hi) / 2 if est is None else est; se = (hi - lo) / (2 * stats.t.ppf(0.975, df))
    return 2 * stats.t.sf(abs(e) / se, df)


def p_tost(lo, hi, df, m, level=0.90):
    e = (lo + hi) / 2; se = (hi - lo) / (2 * stats.t.ppf(1 - (1 - level) / 2, df))
    return max(stats.t.sf((e + m) / se, df), stats.t.sf((m - e) / se, df))


def components(spec):
    """p-value of each component of a row, in order."""
    c = spec["cls"]
    if c == "t":
        return [p_t(t, spec["df"], spec["sided"]) for t in spec["t"]]
    if c == "ci" and spec["method"] == "boot":
        return [p_boot(*spec["iv"], spec.get("est"))]
    if c == "ci" and spec["method"] == "t" and spec["sided"] == 2:
        return [p_ci_t_two(*spec["iv"], spec.get("est"), spec["df"])]
    if c == "ci":
        return [p_ci_t(lo, hi, thr, spec["df"], spec.get("side", "above")) for (lo, hi), thr in zip(spec["iv"], spec["null"])]
    if c == "cis":
        return [p_boot(lo, hi) for lo, hi in spec["ivs"]]
    if c == "tost":
        return [p_tost(*spec["iv"], spec["df"], spec["margin"], spec.get("level", 0.90))]
    if c == "conj":
        return [max(p for part in spec["parts"] for p in components(part))]
    if c == "ci2":
        lo, hi = spec["iv"]
        return [min(p_ci_t(lo, hi, spec["lo_thr"], spec["df"], "below"), p_ci_t(lo, hi, spec["hi_thr"], spec["df"], "above"))]
    if c == "p":
        return list(spec["p"])
    if c == "none":
        return [1.0]
    raise ValueError(c)


def row_p(r):
    ps = components(r["spec"])
    if r["row"] in (56, 58):                       # predicted sign positive, observed negative (ANALYSES_tmlr.md)
        ps = [1.0 for _ in ps]
    est = [ps[i] for i in r["established"] if i < len(ps)]
    return (max(est) if est else min(ps)), ps


# ------------------------------------------------------------------ each row's own level, read from the versioned companion
def own_levels():
    S = open(TEX).read(); out, n = {}, 0
    for lab in ("tab:tests", "tab:tests2", "tab:tests3", "tab:tests4"):
        i = S.find(r"\label{" + lab + "}"); t0 = S.rfind(r"\begin{table", 0, i); T = S[t0:S.find(r"\end{table", i)]
        for r in re.split(r"\\\\", T[T.find(r"\midrule"):]):
            if "&" not in r:
                continue
            c = r.replace(r"\midrule", "").split("&")
            if len(c) < 6:
                continue
            n += 1; thr = re.sub(r"\s+", " ", c[3])
            crits = [float(x) for x in re.findall(r"t > ([\d.]+)", thr.replace("$", ""))]    # several thresholds: the family's, the largest
            df = re.search(r"(\d+) d\.f\.", thr); one = "1-sided" in thr
            out[n] = {"threshold": thr.strip(), "crit": max(crits) if crits else None, "df_text": int(df.group(1)) if df else None, "one_sided": one}
    return out


def level_of(r, lv):
    spec = r["spec"]; L = lv.get(r["row"], {})
    if spec["cls"] == "t" and L.get("crit"):
        df = spec["df"]; c = L["crit"]
        return stats.t.sf(c, df) if spec["sided"] == 1 else 2 * stats.t.sf(c, df)
    if spec["cls"] == "p":
        m = re.search(r"p < ([\d.]+)", L.get("threshold", "").replace("$", ""))
        return float(m.group(1)) if m else 0.05
    if spec["cls"] == "ci" and spec.get("method") == "t" and spec.get("sided") == 2:
        return 0.05                                    # row 16: a two-sided t interval against 0
    if spec["cls"] in ("ci", "conj", "ci2") and (spec.get("method") == "t" or spec["cls"] != "ci"):
        return 0.025                                   # one-sided side of a 95 % interval
    return 0.05


# ------------------------------------------------------------------ A1
def a1():
    spec = json.load(open(SPEC)); rows = spec["tests"]
    if len(rows) != M:
        sys.exit(f"STOP: {len(rows)} tests in the specification, {M} expected")
    lv = own_levels()
    res = []
    for r in rows:
        p, ps = row_p(r)
        res.append({"row": r["row"], "status": r["status"], "cls": r["spec"]["cls"], "p": p, "components": ps,
                    "established": bool(r["established"]), "level": level_of(r, lv), "note": r.get("note", "")})
    # check of the transcription: does each row reproduce the paper's own verdict at its own level?
    mism = []
    for x in res:
        if x["cls"] == "none":
            continue
        own_e = x["p"] <= x["level"] * 1.0001
        if own_e != x["established"]:
            mism.append(x)
    # Holm, step-down, over m = 145
    order = sorted(range(len(res)), key=lambda i: res[i]["p"]); running = 0.0
    for rank, i in enumerate(order):
        running = max(running, min(1.0, (M - rank) * res[i]["p"])); res[i]["holm"] = running
    for x in res:
        x["after"] = ("outside Holm (not a test)" if x["cls"] == "none" else
                      ("stays established" if x["holm"] <= ALPHA else "no longer established") if x["established"] else "not established")
    stay = [x for x in res if x["established"] and x["cls"] != "none" and x["holm"] <= ALPHA]
    fall = [x for x in res if x["established"] and x["cls"] != "none" and x["holm"] > ALPHA]
    approx = [x for x in res if x["cls"] in ("ci", "cis") and 0.01 <= x["holm"] <= 0.1 and x["cls"] != "none"]
    json.dump(res, open(os.path.join(HERE, "analyses_tmlr_a1.json"), "w"), indent=1)
    L = ["# A1 — Holm over the 145 tests (post hoc, descriptive; definitions: ANALYSES_tmlr.md)", "",
         f"Tests: {len(res)}; established by the paper: {sum(x['established'] for x in res)} "
         f"(of which {sum(x['established'] and x['cls'] == 'none' for x in res)} outside Holm, not a test).",
         f"**After Holm over 145 at 0.05: {len(stay)} stay established, {len(fall)} no longer established.**", "",
         f"Check of the transcription: {len(mism)} row(s) whose conversion does not reproduce the paper's own verdict at its own level"
         + (":" if mism else "."), ""]
    for x in mism:
        L.append(f"- row {x['row']} ({x['status']}): p = {x['p']:.3g} against its own level {x['level']:.3g} — {x['note'] or 'see the row'}")
    L += ["", "## Established results that no longer hold after Holm", ""]
    L += [f"- row {x['row']} ({x['status']}): p = {x['p']:.3g}, Holm-adjusted {x['holm']:.3g}" for x in sorted(fall, key=lambda x: x["row"])] or ["(none)"]
    L += ["", "## Rows under the approximate (bootstrap or interval) rule with an adjusted p between 0.01 and 0.1", ""]
    L += [f"- row {x['row']} ({x['status']}): Holm-adjusted {x['holm']:.3g}" for x in approx] or ["(none)"]
    L += ["", "## Every row", "", "| row | paper's status | class | p | Holm-adjusted | after Holm |", "|---|---|---|---|---|---|"]
    L += [f"| {x['row']} | {x['status']} | {x['cls']} | {x['p']:.3g} | {x['holm']:.3g} | {x['after']} |" for x in res]
    open(os.path.join(HERE, "analyses_tmlr_a1.md"), "w").write("\n".join(L) + "\n")
    print("\n".join(L[:12 + len(mism) + len(fall) + 6]))
    print("\n  full table: analyses_tmlr_a1.md ; values: analyses_tmlr_a1.json")


# ------------------------------------------------------------------ A2
def dz_80(n, alpha, sided, power=0.80):
    """Standardised effect d_z = delta / sigma_d that a paired t-test on n seeds detects with the given power (exact, non-central t)."""
    df = n - 1; crit = stats.t.ppf(1 - alpha / sided, df)
    pw = lambda d: stats.nct.sf(crit, df, d * n ** 0.5) + (stats.nct.cdf(-crit, df, d * n ** 0.5) if sided == 2 else 0.0)  # noqa: E731
    lo, hi = 0.0, 50.0
    for _ in range(200):
        mid = (lo + hi) / 2
        lo, hi = (mid, hi) if pw(mid) < power else (lo, mid)
    return hi


def a2():
    spec = json.load(open(os.path.join(HERE, "analyses_inputs", "a2_spec.json"))); out = []
    for c in spec:
        dz = dz_80(c["n"], c["alpha"], c["sided"])
        if c["d"] is not None and c["t"]:
            sd = abs(c["d"]) * c["n"] ** 0.5 / abs(c["t"]); mde = dz * sd; how = "sigma_d = |mean| sqrt(n) / |t|, printed values"
        elif c["ci"]:
            se = (c["ci"][1] - c["ci"][0]) / (2 * 1.96); z = stats.norm.ppf(1 - c["alpha"] / c["sided"])
            sd = se * c["n"] ** 0.5; mde = (z + stats.norm.ppf(0.80)) * se; how = "bootstrap interval: MDE = (z_alpha + z_0.80) SE, normal approximation"
        else:
            sd = mde = None; how = "sigma_d from the runs (A2b): the paper prints no mean difference"
        out.append(dict(c, dz=dz, sigma_d=sd, mde=mde, how=how))
    json.dump(out, open(os.path.join(HERE, "analyses_tmlr_a2.json"), "w"), indent=1)
    L = ["# A2 — Minimum detectable effect at 80 % power of the band comparisons not established (post hoc, descriptive)", "",
         "| row | comparison | n | alpha (sided) | d_z | sigma_d | MDE | observed | how |", "|---|---|---|---|---|---|---|---|---|"]
    for x in out:
        obs = f"{x['d']:+.2f}" if x["d"] is not None else (f"[{x['ci'][0]:+.2f}, {x['ci'][1]:+.2f}]" if x["ci"] else "—")
        sd = "—" if x["sigma_d"] is None else f"{x['sigma_d']:.2f}"
        mde = "—" if x["mde"] is None else f"{x['mde']:.2f} {x['unit']}"
        L.append(f"| {x['row']} | {x['what']} | {x['n']} | {x['alpha']:.4g} ({x['sided']}) | {x['dz']:.2f} | {sd} | {mde} | {obs} | {x['how']} |")
    open(os.path.join(HERE, "analyses_tmlr_a2.md"), "w").write("\n".join(L) + "\n"); print("\n".join(L))


# ------------------------------------------------------------------ A3
REPORT_SEEDS = [tuple(range(2, 7)), tuple(range(2, 9)), tuple(range(9, 17)), tuple(range(7, 17)), tuple(range(2, 17)), tuple(range(120, 125)),
                tuple(range(22, 27)), tuple(range(42, 47)), tuple(range(140, 145)), tuple(range(50, 65)), tuple(range(65, 105))]
RUN_SPECIFIC = {"seed", "out_dir", "notes", "save_factor_steps", "svd_cache", "data_fingerprint", "run_id"}


def table_values(tex):
    """Every 4-decimal number inside a table of the main paper, with the label of its table."""
    S = open(tex).read(); out = {}
    for m in re.finditer(r"\\begin\{table\*?\}(.*?)\\end\{table\*?\}", S, re.S):
        T = m.group(1); lab = re.search(r"\\label\{([^}]+)\}", T); lab = lab.group(1) if lab else "?"
        for v in re.findall(r"(?<![\d.])0\.(\d{4})(?!\d)", T):
            out.setdefault(round(float("0." + v), 4), set()).add(lab)
    return out


def a3():
    import csv
    import glob
    import yaml
    vals = table_values(os.path.join(HERE, "analyses_inputs", "main_tmlr.tex"))
    groups = {}
    for p in glob.glob(os.path.expanduser("~/lora-runs*/*/config.yaml")):
        d = os.path.dirname(p)
        try:
            if not open(d + "/status").read().startswith("DONE"):
                continue
            c = yaml.safe_load(open(p)) or {}; m = json.load(open(d + "/metrics.json"))
        except (OSError, ValueError):
            continue
        key_metric = "format_parsed" if c.get("task") == "format" else ("mcq_acc" if "mcq_acc" in m else None)
        if key_metric is None or key_metric not in m or c.get("seed") is None:
            continue
        try:
            PARTITION = (next(csv.DictReader(open(d + "/results.csv"))).get("PARTITION") or "").replace("NVIDIA ", "").replace(" Generation", "").strip()
        except (OSError, StopIteration):
            PARTITION = ""
        key = json.dumps({k: v for k, v in c.items() if k not in RUN_SPECIFIC}, sort_keys=True, default=str)
        groups.setdefault(key, {}).setdefault(c["seed"], []).append((m[key_metric], os.path.basename(d), PARTITION, os.path.getmtime(p)))
    found, used = [], set()
    for key, by in groups.items():
        for seeds in REPORT_SEEDS:
            if not all(s in by for s in seeds):
                continue
            for pick in (0, -1):                       # duplicates: the earliest, then the latest run of each seed
                runs = [sorted(by[s], key=lambda x: x[3])[pick] for s in seeds]
                mean = round(sum(r[0] for r in runs) / len(runs), 4)
                hit = [v for v in (mean,) if v in vals and abs(sum(r[0] for r in runs) / len(runs) - v) < 5e-5]
                if hit:
                    c = json.loads(key); models = {}
                    for r in runs:
                        models[r[2] or "(none)"] = models.get(r[2] or "(none)", 0) + 1
                    found.append(dict(value=hit[0], tables=sorted(vals[hit[0]]), task=c.get("task"), model=str(c.get("model")).split("/")[-1],
                                      mode=c.get("mode"), rank=c.get("rank"), lr=c.get("lr"), seeds=f"{seeds[0]}-{seeds[-1]}", gpus=models,
                                      no_gpu=[r[1] for r in runs if not r[2]]))
                    used.add(hit[0]); break
    uniq = {(f["value"], f["task"], f["model"], f["mode"], f["rank"], f["lr"], f["seeds"]): f for f in found}
    found = sorted(uniq.values(), key=lambda f: (f["tables"][0], f["task"], f["model"], str(f["mode"]), f["rank"] or 0))
    json.dump({"cells": found, "values_not_matched": sorted(v for v in vals if v not in used)}, open(os.path.join(HERE, "analyses_tmlr_a3.json"), "w"), indent=1, default=str)
    L = ["# A3 — PARTITION model behind each reported cell (post hoc, descriptive)", "",
         f"Cells found by their published value: {len(found)}; 4-decimal values in the main paper's tables: {len(vals)}, of which {len(vals) - len(used)} matched no cell "
         "(not all are cell scores: some are ratios or differences).", "",
         "| table(s) | task | model | arm | rank | rate | seeds | value | PARTITION models (runs) | runs without a PARTITION record |", "|---|---|---|---|---|---|---|---|---|---|"]
    for f in found:
        g = ", ".join(f"{k} ({v})" for k, v in sorted(f["gpus"].items()))
        L.append(f"| {', '.join(f['tables'])} | {f['task']} | {f['model']} | {f['mode']} | {f['rank']} | {f['lr']} | {f['seeds']} | {f['value']:.4f} | {g} | {', '.join(f['no_gpu']) or '—'} |")
    mixed = [f for f in found if len([k for k in f["gpus"] if k != "(none)"]) > 1]
    L += ["", f"Cells whose runs ran on more than one PARTITION model: {len(mixed)}.", f"Cells with at least one run without a PARTITION record: {sum(1 for f in found if f['no_gpu'])}."]
    open(os.path.join(HERE, "analyses_tmlr_a3.md"), "w").write("\n".join(L) + "\n"); print("\n".join(L[:6] + L[-2:]))


# ------------------------------------------------------------------ A3b (ANALYSES_tmlr_addendum2.md)
def a3b():
    """A3 corrected: runs grouped as the trainer identifies them; TMLR runs excluded; every matching run set reported."""
    import csv
    import glob
    import itertools
    import yaml
    sys.path.insert(0, os.path.join(HERE, "src"))
    from lorasub.config import _NON_ID_FIELDS
    from lorasub.lora import SALTED_MODES
    legacy = {"data_fingerprint": "", "max_new_tokens": 128, "token_weighted_loss": False}

    def norm(c):
        d = {k: v for k, v in c.items() if k not in _NON_ID_FIELDS and k not in ("seed", "run_id")}
        for k, v in legacy.items():
            if d.get(k) is None:
                d[k] = v
        if d.get("mode") in SALTED_MODES:
            d["subspace_salted"] = bool(d.get("subspace_salted"))
        else:
            d.pop("subspace_salted", None)
        return json.dumps(d, sort_keys=True, default=str)

    vals = table_values(os.path.join(HERE, "analyses_inputs", "main_tmlr.tex"))
    groups, meta = {}, {}
    for p in glob.glob(os.path.expanduser("~/lora-runs*/*/config.yaml")):
        if "lora-runs-tmlr" in p:
            continue
        d = os.path.dirname(p)
        try:
            if not open(d + "/status").read().startswith("DONE"):
                continue
            c = yaml.safe_load(open(p)) or {}; m = json.load(open(d + "/metrics.json"))
        except (OSError, ValueError):
            continue
        km = "format_parsed" if c.get("task") == "format" else ("mcq_acc" if "mcq_acc" in m else None)
        if km is None or km not in m or c.get("seed") is None:
            continue
        try:
            PARTITION = (next(csv.DictReader(open(d + "/results.csv"))).get("PARTITION") or "").replace("NVIDIA ", "").replace(" Generation", "").strip()
        except (OSError, StopIteration):
            PARTITION = ""
        k = norm(c); meta[k] = c
        groups.setdefault(k, {}).setdefault(c["seed"], []).append((m[km], os.path.basename(d), PARTITION))
    found = []
    for k, by in groups.items():
        for seeds in REPORT_SEEDS:
            if not all(s in by for s in seeds):
                continue
            lists = [by[s] for s in seeds]
            n = 1
            for x in lists:
                n *= len(x)
            combos = itertools.product(*lists) if n <= 256 else [[sorted(x, key=lambda r: r[1])[0] for x in lists], [sorted(x, key=lambda r: r[1])[-1] for x in lists]]
            hits = {}
            for cb in combos:
                mean = sum(r[0] for r in cb) / len(cb); v = round(mean, 4)
                if v in vals and abs(mean - v) < 5e-5:
                    hits.setdefault(v, []).append(cb)
            for v, cbs in hits.items():
                c = meta[k]; cb = cbs[0]; g = {}
                for r in cb:
                    g[r[2] or "(none)"] = g.get(r[2] or "(none)", 0) + 1
                found.append(dict(value=v, tables=sorted(vals[v]), task=c.get("task"), model=str(c.get("model")).split("/")[-1], mode=c.get("mode"),
                                  rank=c.get("rank"), lr=c.get("lr"), seeds=f"{seeds[0]}-{seeds[-1]}", gpus=g, run_sets=len({tuple(sorted(r[1] for r in x)) for x in cbs}),
                                  runs=[r[1] for r in cb], no_gpu=[r[1] for r in cb if not r[2]]))
    used = {f["value"] for f in found}
    by_val = {}
    for f in found:
        by_val.setdefault(f["value"], []).append(f)
    multi = {v: fs for v, fs in by_val.items() if len(fs) > 1}
    runs = {}; comp = {}
    for f in found:
        for gname, n in f["gpus"].items():
            runs[gname] = runs.get(gname, 0) + n
        comp[" + ".join(sorted(f["gpus"]))] = comp.get(" + ".join(sorted(f["gpus"])), 0) + 1
    pure = sum(1 for f in found if set(f["gpus"]) == {"RTX 4000 Ada"})
    json.dump({"cells": found, "values_not_matched": sorted(v for v in vals if v not in used), "runs_by_model": runs, "compositions": comp},
              open(os.path.join(HERE, "analyses_tmlr_a3b.json"), "w"), indent=1, default=str)
    L = ["# A3b — PARTITION model behind each reported cell, corrected (post hoc, descriptive; ANALYSES_tmlr_addendum2.md)", "",
         f"4-decimal values in the main paper's tables: {len(vals)}; matched by at least one cell: {len(used)}; matched by none: "
         + (", ".join(f"{v:.4f}" for v in sorted(v for v in vals if v not in used)) or "none") + ".",
         f"Cells found: {len(found)}; entirely on RTX 4000 Ada: {pure}; on more than one PARTITION model: {sum(1 for f in found if len(f['gpus']) > 1)}; "
         f"with a run without a PARTITION record: {sum(1 for f in found if f['no_gpu'])}.",
         "Runs by PARTITION model: " + ", ".join(f"{g} {n}" for g, n in sorted(runs.items(), key=lambda x: -x[1])) + ".", "",
         f"## Values matched by more than one cell ({len(multi)})", "",
         "| value | table(s) | cells (task, arm, rank, rate, seeds: PARTITION models) | same PARTITION composition |", "|---|---|---|---|"]
    for v, fs in sorted(multi.items()):
        same = len({" + ".join(sorted(f["gpus"])) for f in fs}) == 1
        L.append(f"| {v:.4f} | {', '.join(fs[0]['tables'])} | " + "; ".join(f"{f['task']} {f['model']} {f['mode']} r{f['rank']} {f['lr']} {f['seeds']}: "
                 + ", ".join(f"{g} ({n})" for g, n in sorted(f["gpus"].items())) for f in fs) + f" | {'yes' if same else 'NO'} |")
    L += ["", "## Every cell", "", "| table(s) | task | model | arm | rank | rate | seeds | value | PARTITION models (runs) | matching run sets |", "|---|---|---|---|---|---|---|---|---|---|"]
    for f in sorted(found, key=lambda f: (f["tables"][0], str(f["task"]), str(f["mode"]), f["rank"] or 0, float(f["lr"] or 0))):
        L.append(f"| {', '.join(f['tables'])} | {f['task']} | {f['model']} | {f['mode']} | {f['rank']} | {f['lr']} | {f['seeds']} | {f['value']:.4f} | "
                 + ", ".join(f"{g} ({n})" for g, n in sorted(f["gpus"].items())) + f" | {f['run_sets']} |")
    open(os.path.join(HERE, "analyses_tmlr_a3b.md"), "w").write("\n".join(L) + "\n"); print("\n".join(L[:6]))


# ------------------------------------------------------------------ A3c (ANALYSES_tmlr_addendum3.md)
def a3c():
    """A3b's ambiguous values resolved by the table, row and column of each occurrence (analyses_inputs/a3c_map.json)."""
    d = json.load(open(os.path.join(HERE, "analyses_tmlr_a3b.json"))); mp = json.load(open(os.path.join(HERE, "analyses_inputs", "a3c_map.json")))["entries"]
    by_val = {}
    for c in d["cells"]:
        by_val.setdefault(c["value"], []).append(c)
    amb = {v for v, cs in by_val.items() if len(cs) > 1}
    mapped = {e["value"] for e in mp}
    final, problems = {}, []
    for v, cs in by_val.items():
        if v not in amb:
            final[tuple(sorted(cs[0]["runs"]))] = dict(cs[0], resolved_by="unique")
    for v in sorted(amb - mapped):
        problems.append(f"{v:.4f} : ambiguous and absent from the mapping")
    for e in mp:
        cs = by_val.get(e["value"], [])
        for want in e["cells"]:
            hit = [c for c in cs if c["task"] == want["task"] and c["model"] == want["model"] and c["mode"] == want["mode"]
                   and c["rank"] == want["rank"] and (want["seeds"] is None or c["seeds"] == want["seeds"])]
            if len(hit) != 1:
                problems.append(f"{e['value']:.4f} in {e['table']} : {len(hit)} candidate(s) for {want}")
                continue
            final.setdefault(tuple(sorted(hit[0]["runs"])), dict(hit[0], resolved_by=f"table, row and column ({e['table']})"))
    cells = list(final.values())
    runs = {}; comp = {}
    for c in cells:
        for g, n in c["gpus"].items():
            runs[g] = runs.get(g, 0) + n
        k = " + ".join(sorted(c["gpus"])); comp[k] = comp.get(k, 0) + 1
    pure = sum(1 for c in cells if set(c["gpus"]) == {"RTX 4000 Ada"}); mixed = sum(1 for c in cells if len(c["gpus"]) > 1)
    nog = [(c["value"], c["mode"], c["rank"], c["no_gpu"]) for c in cells if c["no_gpu"]]
    json.dump({"cells": cells, "problems": problems, "runs_by_model": runs, "compositions": comp}, open(os.path.join(HERE, "analyses_tmlr_a3c.json"), "w"), indent=1, default=str)
    L = ["# A3c — PARTITION model behind each reported cell, ambiguities resolved (post hoc, descriptive; ANALYSES_tmlr_addendum3.md)", "",
         f"Published values matched (A3b): {len(by_val)}; of which ambiguous: {len(amb)}, resolved by table, row and column: {len(amb & mapped)}.",
         f"Distinct reported cells: {len(cells)}; entirely on RTX 4000 Ada: {pure}; on more than one PARTITION model: {mixed}; on a single other model: {len(cells) - pure - mixed}.",
         "Runs by PARTITION model: " + ", ".join(f"{g} {n}" for g, n in sorted(runs.items(), key=lambda x: -x[1])) + ".",
         f"Cells with runs without a PARTITION record: {len(nog)}" + (": " + "; ".join(f"{v:.4f} ({m} r{r}: {', '.join(x)})" for v, m, r, x in nog) if nog else "."),
         f"Problems: {len(problems)}" + (":" if problems else ".")]
    L += [f"- {x}" for x in problems]
    L += ["", "| PARTITION composition | cells |", "|---|---|"] + [f"| {k} | {n} |" for k, n in sorted(comp.items(), key=lambda x: -x[1])]
    L += ["", "## Every cell", "", "| table(s) | task | model | arm | rank | rate | seeds | value | PARTITION models (runs) | resolved by |", "|---|---|---|---|---|---|---|---|---|---|"]
    for c in sorted(cells, key=lambda c: (c["tables"][0], str(c["task"]), str(c["mode"]), c["rank"] or 0)):
        L.append(f"| {', '.join(c['tables'])} | {c['task']} | {c['model']} | {c['mode']} | {c['rank']} | {c['lr']} | {c['seeds']} | {c['value']:.4f} | "
                 + ", ".join(f"{g} ({n})" for g, n in sorted(c["gpus"].items())) + f" | {c['resolved_by']} |")
    open(os.path.join(HERE, "analyses_tmlr_a3c.md"), "w").write("\n".join(L) + "\n"); print("\n".join(L[:8 + len(problems)]))


if __name__ == "__main__":
    done = False
    if "--a1" in sys.argv:
        a1(); done = True
    if "--a2" in sys.argv:
        a2(); done = True
    if "--a3" in sys.argv:
        a3(); done = True
    if "--a3b" in sys.argv:
        a3b(); done = True
    if "--a3c" in sys.argv:
        a3c(); done = True
    if not done:
        sys.exit(__doc__)
