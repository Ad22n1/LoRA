"""Point 6: why do 11 of 20 reloaded evaluations not reproduce their recorded score? No PARTITION is used.

    python scripts/diag_reload.py

1. For each of the 20 trained runs: the node and PARTITION it trained on (recorded by train.py), the node and PARTITION its reloaded
   evaluation ran on (Slurm), and the reproduction verdict. If exactly the runs that changed PARTITION model fail to reproduce,
   the cause is numerical (bf16 arithmetic differs between PARTITION models), not the reload.
2. Was the deviation committed before the first of the 77 retrained runs started?
3. Which other scripts reload trained factors, and could therefore be affected?
"""
import glob

import os
import re
import subprocess

import yaml

R = os.path.expanduser("~/lora-runs")
LR6 = {"top": 1e-2, "random": 1e-2, "random_ortho": 1e-2, "bottom": 5e-3}


def short(h):
    return str(h).split(".")[0] if h not in (None, "", "nan") else None


# host and PARTITION are written by train.py into each run's own results.csv (see train.py, _environment())
import csv  # noqa: E402


def env_of(d):
    try:
        with open(d + "/results.csv", newline="") as f:
            row = next(csv.DictReader(f))
    except (OSError, StopIteration):
        return None, None
    g = row.get("PARTITION") or None
    return short(row.get("host")), g


# --- the 20 trained runs, and a node -> PARTITION map from every run on disk
runs, node_gpu = {}, {}
for p in glob.glob(R + "/*/config.yaml"):
    d = os.path.dirname(p)
    c = yaml.safe_load(open(p)) or {}
    h, g = env_of(d)
    if h and g: node_gpu.setdefault(h, g)
    if (c.get("task") == "format" and c.get("rank") == 2 and c.get("seed") in range(105, 110) and c.get("mode") in LR6
            and c.get("update_norm_target") in (None, "") and abs(float(c.get("lr", 0)) - LR6[c["mode"]]) < 1e-12):
        runs[os.path.basename(d)] = (c["mode"], c["seed"], h, g)

# --- the reloaded evaluations: verdict per run, and the Slurm node of the task that wrote it
evals = {}
for log in glob.glob(os.path.expanduser("~/lora-grid/norm6_train_*/logs/*.out")):
    txt = open(log, errors="ignore").read()
    m = re.search(r"(\d+)_(\d+)\.out$", log)
    node = None
    if m:
        try:
            out = subprocess.run(["sacct", "-n", "-P", "-X", "-j", f"{m.group(1)}_{m.group(2)}", "--format=NodeList"],
                                 capture_output=True, text=True, timeout=20).stdout.split()
            node = out[0] if out else None
        except Exception:  # noqa: BLE001
            node = None
    node = short(node or (re.search(r"node: (\S+)", txt).group(1) if re.search(r"node: (\S+)", txt) else None))
    for line in txt.splitlines():
        v = re.match(r"\s*([0-9a-f]{12})\s.*->\s*(NON REPRO|REPRO)", line)
        if v:
            evals[v.group(1)] = (node, "REPRODUIT" if v.group(2) == "REPRO" else "NON")

print("=== 1. machine d'entrainement contre machine d'evaluation ===")
print(f"  {'run':14s} {'bras':13s} {'graine':6s} {'entrainement':34s} {'evaluation':34s} verdict")
same_ok = same_ko = diff_ok = diff_ko = unknown = 0
for rid, (mode, seed, h, g) in sorted(runs.items(), key=lambda x: (x[1][0], x[1][1])):
    pref = [k for k in evals if rid.startswith(k)]
    node, verdict = evals[pref[0]] if pref else (None, "?")
    ge = node_gpu.get(node, "?") if node else "?"
    same = (g not in (None, "?") and ge != "?" and g == ge)
    known = g not in (None, "?") and ge != "?"
    if not known or verdict == "?": unknown += 1
    elif same and verdict == "REPRODUIT": same_ok += 1
    elif same: same_ko += 1
    elif verdict == "REPRODUIT": diff_ok += 1
    else: diff_ko += 1
    print(f"  {rid[:12]:14s} {mode:13s} {seed:<6d} {str(h)[:12]:12s} {str(g)[:21]:21s} {str(node)[:12]:12s} {ge[:21]:21s} {verdict}")
print(f"\n  meme modele de PARTITION     : {same_ok} reproduits, {same_ko} non reproduits")
print(f"  modele de PARTITION different : {diff_ok} reproduits, {diff_ko} non reproduits")
print(f"  inconnus : {unknown}")
if unknown == len(runs) or unknown > len(runs) // 2:
    print("  -> IMPOSSIBLE DE CONCLURE : la machine ou la carte manque pour la plupart des runs.")
elif same_ko == 0 and diff_ok == 0 and unknown == 0:
    print("  -> SEPARATION PARFAITE : chaque run non reproduit a change de modele de PARTITION, et aucun run reproduit n'en a change.")
else:
    print("  -> pas de separation parfaite par le modele de PARTITION : la cause est a chercher ailleurs (ou en plus).")

print("\n=== 2. l'ecart au protocole, committe avant les runs reentraines ? ===")
try:
    first = subprocess.run(["git", "log", "--diff-filter=A", "--format=%ci %h", "--", "PROTOCOL_norm_control_deviation.md"],
                           capture_output=True, text=True).stdout.strip().splitlines()
    print("  premier commit de l'ecart :", first[-1] if first else "INTROUVABLE")
except Exception as e:  # noqa: BLE001
    print("  git indisponible :", e)
starts = []
for p in glob.glob(R + "/*/config.yaml"):
    c = yaml.safe_load(open(p)) or {}
    if c.get("seed") in range(105, 110) and c.get("update_norm_target") not in (None, "") and c.get("rank") == 2:
        starts.append(os.path.getmtime(p))
if starts:
    import datetime
    print("  premier run reentraine cree :", datetime.datetime.fromtimestamp(min(starts)).strftime("%Y-%m-%d %H:%M:%S"),
          f"({len(starts)} runs)")

print("\n=== 3. les autres scripts qui rechargent des facteurs ===")
for f in sorted(glob.glob("scripts/*.py") + glob.glob("src/lorasub/*.py")):
    txt = open(f).read()
    if "load_factors_into" in txt or "load_factors(" in txt:
        print("  ", f)
