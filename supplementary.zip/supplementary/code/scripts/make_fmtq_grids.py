"""Writes the four grids of PROTOCOL_format_qwen_rank.md from the server's current base (configs/grids/scale_qwen15.yaml).

    python scripts/make_fmtq_grids.py            # writes configs/grids/fmtq_*.yaml, prints the base it used

STOPS unless the base is the format task on Qwen/Qwen2.5-1.5B. The base's mode, rank, lr and seed are replaced by the grid; the
salt is on (it acts on random_ortho only); no factors are saved. 392 runs in all.
"""
import sys
from pathlib import Path

import yaml

SRC = Path("configs/grids/scale_qwen15.yaml")
if not SRC.exists():
    sys.exit(f"STOP : {SRC} introuvable")
raw = yaml.safe_load(open(SRC)) or {}
base = dict(raw.get("base") or {})
if base.get("task") != "format" or str(base.get("model")) != "Qwen/Qwen2.5-1.5B":
    sys.exit(f"STOP : la base n'est pas la tache de format sur Qwen2.5-1.5B (task={base.get('task')}, model={base.get('model')})")
for k in ("mode", "rank", "lr", "seed", "band_frac", "update_norm_target"):
    base.pop(k, None)
base["subspace_salted"] = True
base["save_factor_steps"] = []
SEL, REP = [20, 21], [22, 23, 24, 25, 26]
LR2 = [1e-4, 5e-4, 1e-3, 2e-3, 5e-3, 1e-2, 2e-2]
LR16 = [1e-4, 2e-4, 5e-4, 1e-3, 2e-3, 5e-3, 1e-2]
GRIDS = {
    "fmtq_r2": (["top", "bottom", "random_ortho"], 2, LR2),
    "fmtq_r2_free": (["free"], 1, LR2),
    "fmtq_r16": (["top", "bottom", "random_ortho"], 16, LR16),
    "fmtq_r16_free": (["free"], 7, LR16),
}
H = ("# PRE-ENREGISTRE (PROTOCOL_format_qwen_rank.md) : tache de format sur Qwen2.5-1.5B, le modele ou la tache ?\n"
     "# Genere par scripts/make_fmtq_grids.py depuis configs/grids/scale_qwen15.yaml. Graines neuves : 20-21 selection, 22-26 rapport.\n")
total = 0
for name, (modes, rank, lrs) in GRIDS.items():
    b = dict(base); b["rank"] = rank
    g = {"mode": modes, "lr": lrs, "seed": SEL + REP}
    n = len(modes) * len(lrs) * len(g["seed"]); total += n
    Path(f"configs/grids/{name}.yaml").write_text(H + f"# {n} runs.\n" + yaml.safe_dump({"base": b, "grid": g}, sort_keys=False))
    print(f"  {name:14s} : {'/'.join(modes)} rang {rank}, {len(lrs)} taux ({lrs[0]:g} a {lrs[-1]:g}), 7 graines -> {n} runs")
print(f"  total : {total} runs")
print("  base retenue : " + ", ".join(f"{k}={base.get(k)}" for k in ("model", "task", "target_tokens", "target_modules", "max_grad_norm", "alpha")))
if total != 392:
    sys.exit("STOP : le total n'est pas 392")
