#!/bin/bash
# Forgetting of `random` at the common rate 2e-3, the one empty cell of the forgetting table.
# Same script, same options as forget_common_lr.sh (which measured bottom, top, random_ortho and free),
# written to a SEPARATE file so the existing measurement is not touched. Salted draws, seeds 2-6.
#SBATCH --job-name=forgetrand
#SBATCH --partition=PARTITION
#SBATCH --cpus-per-task=4
#SBATCH --mem=32G
#SBATCH --time=01:59:00
#SBATCH --exclude=node
#SBATCH --output=~/lora-results/forgetrand-%j.out
source /tmp/lora-$USER/venv/bin/activate
export SHARED=$HOME/lora-shared
cd $HOME/repo
python -c "
import yaml
yaml.safe_dump({'selected': {'meta-llama/Llama-3.2-1B|format|random|2': 0.002}}, open('configs/lr_common_2e-3_random.yaml', 'w'))"
python scripts/forgetting_from_factors.py \
  --svd_cache "$SHARED/svd" \
  --lr_from configs/lr_common_2e-3_random.yaml \
  --modes random --salted true \
  --seeds 2,3,4,5,6 \
  --out "$HOME/lora-analysis/forgetting_common_lr_random.csv"
