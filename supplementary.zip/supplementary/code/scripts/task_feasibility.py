"""Is the task learnable at all?  Full fine-tuning upper bound, before spending any PARTITION on a grid.

    python scripts/task_feasibility.py --model allenai/OLMo-2-0425-1B --data_dir ~/lora-shared/data \
        [--n_entities 200] [--epochs 8] [--lr 2e-5] [--out ~/lora-results/feasibility]

Rationale.  Comparing adaptation *subspaces* on a task no method can learn measures nothing.  Full FT
is the upper bound: if it cannot make the facts extractable, the data are the problem, not the method
(Allen-Zhu & Li: memorising a corpus and being able to extract a fact from it are different things;
extraction needs many phrasings per fact).  Only once full FT is clearly above chance does a grid of
PEFT arms mean anything.

The script builds a *small* dedicated dataset (fewer entities, same generator) so that the check is
fast, runs full FT, and prints a verdict:

    MCQ >= 60 %  -> task learnable, launch the grid
    35-60 %      -> weak signal: raise epochs or template diversity, or use fewer entities
    <= 35 %      -> not learnable as built: fix the data before anything else

Chance level is 25 % (4 options).
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from lorasub.config import RunConfig  # noqa: E402
from lorasub.data.facts import generate_facts  # noqa: E402
from lorasub.train import run  # noqa: E402


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--data_dir", required=True, help="parent dir; a facts/ subset is written under --out")
    ap.add_argument("--out", default=None, help="where to write the subset and the run (default: <data_dir>/../feasibility)")
    ap.add_argument("--n_entities", type=int, default=200, help="fewer entities = easier; 200 is a reasonable probe")
    ap.add_argument("--epochs", type=float, default=8.0, help="MiCA used 8; extraction needs repetition")
    ap.add_argument("--lr", type=float, default=2e-5, help="full FT learning rate")
    ap.add_argument("--mode", default="full", choices=["full", "free", "top", "bottom", "random"])
    ap.add_argument("--rank", type=int, default=64)
    ap.add_argument("--batch_size", type=int, default=2)
    ap.add_argument("--grad_accum", type=int, default=16)
    ap.add_argument("--max_len", type=int, default=256)
    ap.add_argument("--svd_cache", default=None)
    ap.add_argument("--eval_limit", type=int, default=600)
    a = ap.parse_args()

    out = Path(a.out) if a.out else Path(a.data_dir).parent / "feasibility"
    out.mkdir(parents=True, exist_ok=True)
    data = out / "data"

    stats = generate_facts(data / "facts", n_entities=a.n_entities, seed=0,
                           n_test_mcq=min(a.eval_limit, a.n_entities * 6),
                           n_test_completion=min(a.eval_limit, a.n_entities * 6),
                           n_val_mcq=min(200, a.n_entities * 2))
    print(f"[feasibility] subset: {stats}")
    print(f"[feasibility] {stats['sentences_per_entity']} sentences per entity, "
          f"{stats['templates_per_attribute']} templates per attribute")

    cfg = RunConfig(model=a.model, task="facts", mode=a.mode, rank=(0 if a.mode == "full" else a.rank),
                    lr=a.lr, seed=0, epochs=a.epochs, batch_size=a.batch_size, grad_accum=a.grad_accum,
                    max_len=a.max_len, data_dir=str(data), out_dir=str(out / "runs"),
                    svd_cache=a.svd_cache or str(Path(a.data_dir).parent / "svd"),
                    save_factor_steps=[], eval_limit=a.eval_limit, eval_forgetting=False)
    row = run(cfg)
    acc = float(row.get("mcq_acc", 0.0))
    em = float(row.get("completion_em", 0.0))
    print(json.dumps({k: row[k] for k in ("run_id", "total_steps", "tokens_seen", "mcq_acc", "completion_em")
                      if k in row}, indent=2))

    print("\n" + "=" * 62)
    print(f"MCQ accuracy {acc:.1%}  (chance 25 %)   |   exact match {em:.1%}")
    if acc >= 0.60:
        print("VERDICT: task learnable. The PEFT grid will measure something. Launch it.")
    elif acc >= 0.35:
        print("VERDICT: weak signal. Before the grid, try: more epochs (--epochs 16), "
              "fewer entities (--n_entities 100), or more phrasings per attribute in the template pack.")
    else:
        print("VERDICT: NOT learnable as built. Do not launch the grid — it would compare arms on a task "
              "no method can solve. Fix the data first (phrasing diversity, entity count, epochs).")
    print("=" * 62)
    (out / "verdict.json").write_text(json.dumps(
        {"model": a.model, "mode": a.mode, "n_entities": a.n_entities, "epochs": a.epochs, "lr": a.lr,
         "mcq_acc": acc, "completion_em": em, "stats": stats}, indent=2))


if __name__ == "__main__":
    main()
