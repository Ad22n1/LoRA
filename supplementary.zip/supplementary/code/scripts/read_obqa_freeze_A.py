"""OpenBookQA at rank 2, Qwen2.5-1.5B: freezing A instead of B (PROTOCOL_obqa_freeze_A.md). No PARTITION.

    python scripts/read_obqa_freeze_A.py 2>&1 | grep -vE "FutureWarning|pd.concat"

GUARDS: the references must give their published scores (top frozen 5e-3: 0.4652, bottom frozen 2e-3: 0.4220, free r=1 2e-3:
0.5456) to 0.0001, without duplicates. Selection on seeds 0-1 (val_mcq_acc); reported seeds 2-6 at that rate only.
Tests: (1) dual_X - X frozen, t > 3.495, per band; (2) PRE-REGISTERED here: (dual_bottom - dual_top) - (bottom - top), t > 2.776;
(3) reported: against free and the unfrozen arms at rank 1, the spread among the three A-frozen arms, the rates, the PARTITION models
and the tests redone on the seeds whose compared runs share one PARTITION model.
"""
import glob
import json
import math
import os
import re
import statistics as st

import yaml

R = os.path.expanduser("~/lora-runs")
QWEN, FP = "Qwen/Qwen2.5-1.5B", "dc05f4d847f9"
S_SEL, S = (0, 1), [2, 3, 4, 5, 6]
LRS = [1e-4, 5e-4, 1e-3, 2e-3, 5e-3, 1e-2, 2e-2]
G_FIXED = {"top": 8.04, "bottom": 12.36}
FROZEN = {"top": 5e-3, "bottom": 2e-3}
T95, T90 = 2.776, 2.132


def ok(c):
    v = c.get("max_grad_norm", 1.0)
    return (c.get("task") == "commonsense" and str(c.get("data_fingerprint")) == FP and str(c.get("model")) == QWEN
            and v is not None and float(v) == 1.0 and c.get("update_norm_target") in (None, ""))


RUNS = []
for p in glob.glob(R + "/*/config.yaml"):
    c = yaml.safe_load(open(p)) or {}
    d = os.path.dirname(p)
    try:
        if ok(c) and open(d + "/status").read().startswith("DONE"):
            RUNS.append((c, json.load(open(d + "/metrics.json")), d))
    except OSError:
        continue


def cell(mode, rank, lr, seeds, key):
    by = {}
    for c, m, d in RUNS:
        if c.get("mode") == mode and c.get("rank") == rank and abs(float(c.get("lr") or 0) - lr) < 1e-12 and c.get("seed") in seeds and key in m:
            by.setdefault(c["seed"], []).append((m[key], d))
    dup = {s: len(v) for s, v in by.items() if len(v) > 1}
    return {s: v[0][0] for s, v in by.items()}, dup, {s: v[0][1] for s, v in by.items()}


def gpu_of(d):
    import csv as _csv
    try:
        with open(d + "/results.csv", newline="") as f:
            g = next(_csv.DictReader(f)).get("PARTITION") or "?"
    except (OSError, StopIteration):
        g = "?"
    return g.replace("NVIDIA ", "").replace("GeForce ", "").replace(" Generation", "")


def same_gpu_test(pairs, thresh_name):
    """pairs: {seed: [(value, dir), ...]} for the runs of one comparison; keeps seeds where every run has the same known PARTITION model."""
    keep = [s for s, runs in pairs.items() if len({gpu_of(d) for _, d in runs}) == 1 and gpu_of(runs[0][1]) != "?"]
    if len(keep) < 3:
        return f"controle a PARTITION egal : non calculable ({len(keep)} graine(s))"
    from statistics import mean, stdev
    diffs = [pairs[s][0][0] for s in keep]
    m = mean(x * 100 for x in diffs); se = stdev(x * 100 for x in diffs) / len(keep) ** 0.5
    return f"controle a PARTITION egal ({len(keep)} graines {sorted(keep)}) : {m:+.2f}, t = {m / se if se > 0 else float('inf'):+.2f} ({len(keep) - 1} d.l.)"


def stats(d):
    x = [d[s] * 100 for s in S]; m = st.mean(x); se = st.stdev(x) / len(x) ** 0.5
    return m, m - T95 * se, m + T95 * se, m - T90 * se, m + T90 * se, (m / se if se > 0 else float("inf"))


def select(mode, rank):
    full = {}
    for lr in LRS:
        v, dup, _ = cell(mode, rank, lr, S_SEL, "val_mcq_acc")
        if len(v) == 2 and not dup: full[lr] = st.mean(v.values())
    if len(full) < len(LRS):
        return None, f"INCOMPLET ({len(full)}/{len(LRS)} taux)"
    best = max(full, key=full.get)
    return best, "  ".join(f"{lr:g}:{full[lr]:.3f}" for lr in LRS) + f"  -> {best:g}" + ("  AU BORD" if best in (LRS[0], LRS[-1]) else "")


def angles(dirs):
    try:
        import torch
        from safetensors.torch import load_file
    except ImportError:
        return None
    out = []
    for d in dirs:
        steps = sorted(int(m.group(1)) for f in glob.glob(d + "/factors_*.safetensors") if (m := re.search(r"factors_(\d+)\.safetensors$", f)))
        if 0 not in steps or len(steps) < 2: return None
        t0, te = load_file(d + "/factors_0.safetensors"), load_file(d + f"/factors_{steps[-1]}.safetensors")
        worst = []
        for k in t0:
            if k.endswith(".B"):
                q0, _ = torch.linalg.qr(t0[k].double()); qe, _ = torch.linalg.qr(te[k].double())
                worst.append(math.degrees(math.acos(float(torch.linalg.svdvals(q0.T @ qe).clamp(-1, 1).min()))))
        out.append(st.mean(worst))
    return out


REF = {"top": (5e-3, 0.4652), "bottom": (2e-3, 0.4220)}
print("==================== OpenBookQA, rang 2, Qwen2.5-1.5B : geler A plutot que B (PROTOCOL_obqa_freeze_A.md) ====================")
free, fdup, freedirs = cell("free", 1, 2e-3, S, "mcq_acc")
ok_ref = len(free) == 5 and not fdup and abs(st.mean(free.values()) - 0.5456) < 1e-4
print(f"  free r=1 a 2e-3 : {st.mean(free.values()) if free else float('nan'):.4f} ({len(free)} graines)" + ("" if ok_ref else "  <- ARRET : reference inattendue"))
FR, DU, DD, FD = {}, {}, {}, {}
for arm, (lr_f, expect) in REF.items():
    fr, dup, frdirs = cell(arm, 2, lr_f, S, "mcq_acc")
    m_ = st.mean(fr.values()) if fr else float("nan")
    good = len(fr) == 5 and not dup and abs(m_ - expect) < 1e-4
    print(f"\n  --- {arm} gele (B) r=2 a {lr_f:g} : {m_:.4f} (attendu {expect:.4f})" + ("" if good else "  <- ARRET : reference inattendue ou doublons"))
    if not (good and ok_ref):
        continue
    FR[arm], FD[arm] = fr, frdirs
    best, txt = select(f"dual_{arm}", 2); print(f"    selection dual_{arm} : {txt}")
    if best is None:
        continue
    du, ddup, ddirs = cell(f"dual_{arm}", 2, best, S, "mcq_acc")
    if ddup or len(du) != 5:
        print(f"    ARRET : {len(du)} graines, doublons {ddup or 'aucun'}"); continue
    DU[arm], DD[arm] = du, ddirs
    D, lo, hi, _, _, t = stats({s: du[s] - fr[s] for s in S})
    est = abs(t) > 3.495
    print(f"    dual_{arm} (gel de A) a {best:g} : {st.mean(du.values()):.4f}")
    print(f"    (1) PRINCIPAL  dual_{arm} - {arm} = {D:+.2f}, IC95 [{lo:+.2f}, {hi:+.2f}], t = {t:+.2f} -> " + ("ETABLI" if est else "non etabli")
          + ("" if not est else (" (geler A coute MOINS)" if D > 0 else " (geler A coute PLUS)")))
    print("        " + same_gpu_test({s: [(du[s] - fr[s], ddirs[s]), (0, frdirs[s])] for s in S}, "(1)"))
    print("        PARTITION par graine : gele B " + " ".join(f"{s}:{gpu_of(frdirs[s])}" for s in S) + " | gele A " + " ".join(f"{s}:{gpu_of(ddirs[s])}" for s in S))
if len(DU) == 2:
    pos = [a for a in DU if abs(stats({s: DU[a][s] - FR[a][s] for s in S})[5]) > 3.495 and stats({s: DU[a][s] - FR[a][s] for s in S})[0] > 0]
    print("\n  -> issue " + ("1 : geler A coute moins que geler B aux deux bandes" if len(pos) == 2 else ("2 : a une seule bande (" + ", ".join(pos) + ")" if pos else "3 : a aucune bande")))
    print("     reserve : geler A a +26,8 % de parametres face au gel de B, +11,8 % face a free r=1")
    m, lo, hi, _, _, t = stats({s: (DU["bottom"][s] - DU["top"][s]) - (FR["bottom"][s] - FR["top"][s]) for s in S})
    mB, mA = stats({s: FR["bottom"][s] - FR["top"][s] for s in S})[0], stats({s: DU["bottom"][s] - DU["top"][s] for s in S})[0]
    print(f"  (2) PRE-ENREGISTRE : bottom - top : {mB:+.2f} gel de B, {mA:+.2f} gel de A ; difference = {m:+.2f}, IC95 [{lo:+.2f}, {hi:+.2f}], t = {t:+.2f} -> "
          + ("ETABLI" if abs(t) > 2.776 else "non etabli"))
    print("      " + same_gpu_test({s: [((DU["bottom"][s] - DU["top"][s]) - (FR["bottom"][s] - FR["top"][s]), DD["bottom"][s]), (0, DD["top"][s]), (0, FD["bottom"][s]), (0, FD["top"][s])] for s in S}, "(2)"))
    print("\n  (3) rapporte :")
    for a in ("top", "bottom"):
        un, udup, _ = cell(f"{a}_unfrozen", 1, 2e-3, S, "mcq_acc")
        print(f"      dual_{a} {st.mean(DU[a].values()):.4f} ; free r=1 {st.mean(free.values()):.4f} ; {a}_unfrozen r=1 {st.mean(un.values()) if len(un) == 5 else float('nan'):.4f}")
    ro_best, ro_txt = select("dual_random_ortho", 2); print(f"      selection dual_random_ortho : {ro_txt}")
    if ro_best is not None:
        ro, rdup, _ = cell("dual_random_ortho", 2, ro_best, S, "mcq_acc")
        if len(ro) == 5 and not rdup:
            ms = {"dual_top": st.mean(DU["top"].values()), "dual_bottom": st.mean(DU["bottom"].values()), "dual_random_ortho": st.mean(ro.values())}
            print(f"      etendue entre les trois bras qui gelent A : {(max(ms.values()) - min(ms.values())) * 100:.2f} pt ; " + ", ".join(f"{k} {v:.4f}" for k, v in ms.items()))
