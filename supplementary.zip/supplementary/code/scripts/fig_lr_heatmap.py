"""The learning-rate selection, arm by arm: validation score on the selection seeds, every rate.

    python scripts/fig_lr_heatmap.py [paper/figures/lr_heatmap.png]

Why it is back. The earlier heat map was refused by the figure audit of 15/09 because it averaged two
verifier versions and two evaluation sizes into the same cell. This one reads only the selection
population: Llama-3.2-1B, format task, seven modules, clipping 1.0, no norm rescaling, alpha = rank,
salted draws for the random arms, and the selection seeds (0 and 1, plus 30 to 32 where they exist,
which is bottom at rank 2). It keeps the aggregator's refusal to mix verifier or metric versions.
Only seeds 0 and 1 are drawn: the seeds 30-32 of bottom were evaluated at another size, and the
aggregator refuses to average them with the others. bottom's selection on five seeds is in the text.

A box marks each row's selected rate: the best validation mean, the rule the paper uses. The count of
runs is printed in every cell, since a cell with one run is not read like the others.
"""
import os
import sys

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

sys.path.insert(0, "src")
from lorasub.aggregate import _refuse_if_mixed, collect, effective_metric_version  # noqa: E402
# No conclusions inside the images (24/09): every title is dropped, only panel letters such as "(a)"
# are kept where a caption refers to them. What a figure shows is said in its caption, where it can
# be qualified -- a claim written in the image cannot.
import re as _re
import matplotlib.axes as _max
import matplotlib.figure as _mfig
_set_title = _max.Axes.set_title
def _letter_only(self, label="", *a, **k):
    m = _re.match(r"\s*\(([a-z])\)", str(label))
    return _set_title(self, f"({m.group(1)})" if m else "", loc="left", fontsize=10)
_max.Axes.set_title = _letter_only
_mfig.Figure.suptitle = lambda self, *a, **k: None

L = "meta-llama/Llama-3.2-1B"
ARMS = ["top", "random", "random_ortho", "bottom"]
RANKS = [1, 2, 4]
SEL = [0, 1]   # the selection seeds every arm shares; bottom r=2 also used 30-32 (section conf)

d = collect(os.path.expanduser("~/lora-runs"))
x = d[(d.task == "format") & (d.model.astype(str) == L) & d["mode"].isin(ARMS) & d["rank"].isin(RANKS)
      & (d.n_modules == 7) & (d.max_grad_norm == 1.0) & d.update_norm_target.isna()
      & d.band_frac.isna() & d.seed.isin(SEL) & ((d.alpha / d["rank"]).round(2) == 1.0)
      & d.val_format_parsed.notna()]
x = x[~(x["mode"].isin(["random", "random_ortho"]) & (x.subspace_salted != True))]  # noqa: E712
# The selection sweeps of the main arms were evaluated on 400 items; some of their runs were later
# re-evaluated on 614, and the aggregator refuses to average the two. Draw the population the
# selection used, and only it.
n0 = len(x)
x = x[x.format_n == 400]
n1 = len(x)
# One checker version per row, never two in a cell: each row keeps the version that carries its full
# sweep, which is the one its rate was selected on. Most sweeps predate the recording of the checker's
# version ("pre-field"); rescoring the eleven of them whose generations were kept with the current
# checker changes no score (scripts/checker_rescore.py).
x = x.assign(_v=effective_metric_version(x).astype(str))
keep = []
for (m, r), g in x.groupby(["mode", "rank"]):
    best = max(g._v.unique(), key=lambda v: g.loc[g._v == v, "lr"].nunique())
    keep.append(g[g._v == best])
    print(f"  {m:13s} r={r}  version {best[:12]:12s}  {g.loc[g._v == best, 'lr'].nunique()} taux")
x = pd.concat(keep).drop(columns="_v")
print(f"  runs : {n0} au depart, {n1} a 400 items, {len(x)} gardes")
_refuse_if_mixed(x, "fig_lr_heatmap")

per = x.groupby(["mode", "rank", "lr", "seed"]).val_format_parsed.mean().reset_index()
piv = per.pivot_table(index=["mode", "rank"], columns="lr", values="val_format_parsed", aggfunc="mean")
cnt = per.pivot_table(index=["mode", "rank"], columns="lr", values="val_format_parsed", aggfunc="count")
order = [(m, r) for r in RANKS for m in ARMS if (m, r) in piv.index]
piv, cnt = piv.loc[order], cnt.loc[order]

fig, ax = plt.subplots(figsize=(1.0 * len(piv.columns) + 2.6, 0.38 * len(piv) + 1.6))
im = ax.imshow(piv.values, aspect="auto", cmap="viridis", vmin=0, vmax=np.nanmax(piv.values))
ax.set_xticks(range(len(piv.columns)))
ax.set_xticklabels([f"{c:.0e}".replace("e-0", "e-") for c in piv.columns], fontsize=8)
ax.set_yticks(range(len(piv)))
ax.set_yticklabels([f"{m}, r={r}" for m, r in piv.index], fontsize=8.5)
for i in range(piv.shape[0]):
    row = piv.values[i]
    # a maximum is read on complete cells only: a cell with fewer runs than the row's fullest is not
    # compared with the others (bottom at rank 1 has one run at 5e-3 against two at 1e-2)
    full = cnt.values[i] == np.nanmax(cnt.values[i])
    cand = np.where(full & np.isfinite(row), row, -np.inf)
    best = int(np.argmax(cand)) if np.isfinite(cand).any() else None
    for j in range(piv.shape[1]):
        v, n = row[j], cnt.values[i, j]
        if np.isfinite(v):
            ax.text(j, i, f"{v:.2f}\n({int(n)})", ha="center", va="center", fontsize=6.5,
                    color="black" if v > 0.6 * np.nanmax(piv.values) else "white")
    if best is not None:
        ax.add_patch(plt.Rectangle((best - 0.5, i - 0.5), 1, 1, fill=False, ec="red", lw=1.8))
    if i < piv.shape[0] - 1 and piv.index[i][1] != piv.index[i + 1][1]:
        ax.axhline(i + 0.5, color="white", lw=2)
ax.set_xlabel("learning rate", fontsize=9)
ax.set_title("Validation score of the selection sweeps (seeds 0 and 1, 400-item evaluation), at every rate;\n"
             "the red box marks the best rate of each row (bottom at rank 2 was selected on three more seeds)", fontsize=9)
fig.colorbar(im, ax=ax, fraction=0.03, pad=0.02).set_label("valid-format accuracy (validation)", fontsize=8)
fig.tight_layout()
out = sys.argv[1] if len(sys.argv) > 1 else "paper/figures/lr_heatmap.png"
fig.savefig(out, dpi=200)
for (m, r) in piv.index:
    row, c = piv.loc[(m, r)], cnt.loc[(m, r)]
    row = row[c == c.max()]
    print(f"  {m:13s} r={r}  selected {row.idxmax():g}  ({row.max():.3f}, cases completes seulement)")
print("  ecrit ->", out)
