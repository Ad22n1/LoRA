#!/bin/bash
# One-time data + SVD setup on the shared filesystem. Run from the repo root on a PARTITION node.
set -euo pipefail
: "${SHARED:?set SHARED to the shared filesystem root}"
export HF_HOME="${HF_HOME:-$SHARED/hf}"
export PYTHONPATH="$(cd "$(dirname "$0")/.." && pwd)/src:${PYTHONPATH:-}"
mkdir -p "$HOME/lora-shared/data" "$SHARED/svd" "$HOME/lora-runs" "$SHARED/logs"
# 174 sentences per entity (24 declaratives/attribute + qa + pairs + bio): phrasing diversity is what
# makes a memorised fact extractable. With 1000 entities this is ~174k sentences (~3.5M tokens/epoch).
python -m lorasub.data.facts  "$HOME/lora-shared/data/facts" --n 1000 --seed 0 --lang en
# variant=transform (not a copy) and min_entities=3 (sorting/signature are trivial below that):
# with the easy settings a rank-16 free LoRA reached 99.6 % parsing and the task stopped discriminating.
python -m lorasub.data.format "$HOME/lora-shared/data/format" --variant transform --min_entities 3
# SVD caches: smoke + main models now; 7B caches (~15 GB each, fp16) only when the 1B table exists.
for M in Qwen/Qwen2.5-0.5B meta-llama/Llama-3.2-1B allenai/OLMo-2-0425-1B; do
  python -m lorasub.cache_svd --model "$M" --svd_cache "$SHARED/svd"
done

# Confirmation models (uncomment after the 1B crossed table is in):
# for M in Qwen/Qwen2.5-7B mistralai/Mistral-7B-v0.3; do
#   python -m lorasub.cache_svd --model "$M" --svd_cache "$SHARED/svd"
# done
