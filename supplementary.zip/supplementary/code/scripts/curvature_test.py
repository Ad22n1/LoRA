"""Paired test on curvature: is `bottom` stiffer than the others, seed by seed?

The medians differ by a factor 3.9, but bottom's inter-seed spread is half its median — 4.9e-4 to
2.1e-3 across five seeds. An unpaired comparison of two noisy quantities says little. The seeds are
shared across arms, though: seed 2 draws the same data order and the same initialisation for every
arm, so the comparison can be made WITHIN each seed, which removes whatever the seed itself
contributes to the level.

Reported on the log scale, because curvature spans a factor four across seeds within one arm and the
quantity of interest is a RATIO — the prediction is "five times stiffer", not "0.001 stiffer".
"""
import os, sys, math
import pandas as pd

p = os.path.expanduser(sys.argv[1] if len(sys.argv) > 1
                       else '~/lora-analysis/curvature_5seeds.csv')
d = pd.read_csv(p)
w = d.pivot_table(index='seed', columns='mode', values='curvature_median')
print("=== courbure par graine et par bras ===")
print(w.round(6).to_string())

def paired(a, b):
    """Paired t on log-ratios. Returns (geometric mean ratio, t, p, CI on the ratio)."""
    r = (w[a] / w[b]).dropna()
    l = r.apply(math.log)
    n = len(l); m = l.mean(); s = l.std(ddof=1)
    t = m / (s / math.sqrt(n))
    # two-sided p from the t distribution, 4 df — computed without scipy
    from statistics import NormalDist
    try:
        from scipy import stats
        pv = 2 * (1 - stats.t.cdf(abs(t), n - 1))
    except ImportError:
        pv = float('nan')
    h = 2.776 * s / math.sqrt(n)          # t_{.975,4}
    return math.exp(m), t, pv, (math.exp(m - h), math.exp(m + h)), n

print("\n=== rapport de courbure, apparié par graine (échelle log) ===")
print(f"{'paire':30s} {'rapport':>9s} {'t':>7s} {'p':>9s}   IC 95 % sur le rapport")
for a, b in (("bottom", "top"), ("bottom", "random"), ("bottom", "random_ortho"),
             ("bottom", "free"), ("random", "top"), ("random_ortho", "top"), ("free", "top")):
    if a not in w or b not in w:
        continue
    g, t, pv, ci, n = paired(a, b)
    star = "  <-- exclut 1" if ci[0] > 1 or ci[1] < 1 else ""
    print(f"{a + ' / ' + b:30s} {g:9.2f} {t:7.2f} {pv:9.4f}   [{ci[0]:.2f} ; {ci[1]:.2f}]{star}")

print("\n=== ce que la prédiction annonçait ===")
print("  bottom / top attendu ~5 (le rapport des taux optimaux : 1e-2 / 2e-3).")
print("  Un IC sur le rapport qui contient 5 ET exclut 1 soutient la lecture par la courbure.")
print("  Un IC qui exclut 1 mais aussi 5 dit que la courbure va dans le bon sens sans suffire.")
