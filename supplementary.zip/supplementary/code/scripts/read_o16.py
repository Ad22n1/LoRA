"""PROTOCOL_isolation_obqa16.md: freezing B isolated at rank 16 on OpenBookQA (Qwen2.5-1.5B). No PARTITION.

    python scripts/read_o16.py 2>&1 | grep -vE "FutureWarning|pd.concat"

References and G come from refs_o16.json, committed before any run; the reader checks the reference runs still give those values.
New arms top_unfrozen and bottom_unfrozen at ranks 7 and 16, selected on seeds 0-1 (validation), reported on 2-6; oracle = best on 2-6.
Tests: (1) U = unfrozen(7) - frozen(16) against 0.7 G / 0.3 G, only if G >= 2; (2) unfrozen(16) - frozen(16), t > 3.495;
(3) band-gap shrinkage at rank 16, t > 2.776, read only if the frozen gap is >= 2. Each against the original references and, as a control,
against the references re-trained on one PARTITION model (~/lora-runs-suivi).
"""
import csv
import glob
import json
import math
import os
import random
import re
import statistics as st

import yaml


def is_obqa(c):
    """OpenBookQA on Qwen2.5-1.5B: identified by its data directory; the rank-16 campaign predates the data fingerprint (empty)."""
    return (c.get("task") == "commonsense" and str(c.get("model")) == "Qwen/Qwen2.5-1.5B"
            and os.path.basename(str(c.get("data_dir") or "").rstrip("/")) == "openbookqa"
            and str(c.get("data_fingerprint") or "") in ("", "None", "dc05f4d847f9"))

R = os.path.expanduser("~/lora-runs")
LLAMA, QWEN = "meta-llama/Llama-3.2-1B", "Qwen/Qwen2.5-1.5B"
S_SEL, S_REP = (0, 1), [2, 3, 4, 5, 6]


def tokens(c):
    t = c.get("target_tokens")
    return t.get(c.get("task")) if isinstance(t, dict) else t


RUNS = []
for p in glob.glob(R + "/*/config.yaml"):
    c = yaml.safe_load(open(p)) or {}
    d = os.path.dirname(p)
    try:
        if not open(d + "/status").read().startswith("DONE"):
            continue
        RUNS.append((c, json.load(open(d + "/metrics.json")), d))
    except OSError:
        continue


def clipped(c):
    """Gradient clipping at 1.0, the paper's setting. A noclip grid reran the same cells without clipping (collect()'s
    docstring); mixing both put two runs per seed in the frozen cells and moved G from 12.41 to 13.53 (26/09)."""
    v = c.get("max_grad_norm", 1.0)
    return v is not None and float(v) == 1.0


def seven(c):
    tm = c.get("target_modules")
    return tm is None or len(tm) == 7


def cell(pred, mode, rank, lr, seeds, key):
    """{seed: value}; several runs of one seed are averaged and flagged."""
    by = {}
    for c, m, d in RUNS:
        if (pred(c) and clipped(c) and c.get("mode") == mode and c.get("rank") == rank and abs(float(c.get("lr") or 0) - lr) < 1e-12
                and c.get("seed") in seeds and key in m and c.get("update_norm_target") in (None, "")):
            by.setdefault(c["seed"], []).append((m[key], d))
    dup = {s: len(v) for s, v in by.items() if len(v) > 1}
    if dup:   # say what separates the duplicates, so that the next filter is written from evidence
        s0 = sorted(dup)[0]; cfgs = [yaml.safe_load(open(d + "/config.yaml")) or {} for _, d in by[s0]]
        keys = sorted(k for k in set().union(*cfgs) if k not in ("run_id", "out_dir") and len({str(c_.get(k)) for c_ in cfgs}) > 1)
        dup["differ"] = {k: [c_.get(k) for c_ in cfgs] for k in keys} or "configs identiques"
    return {s: st.mean(x for x, _ in v) for s, v in by.items()}, dup, {s: [d for _, d in v] for s, v in by.items()}


def select(pred, mode, rank, lrs, key):
    full = {}
    for lr in lrs:
        v, _, _ = cell(pred, mode, rank, lr, S_SEL, key)
        if len(v) == 2: full[lr] = st.mean(v.values())
    if len(full) < len(lrs):
        return None, f"INCOMPLET ({len(full)}/{len(lrs)} taux avec leurs deux graines)"
    best = max(full, key=full.get)
    edge = best in (lrs[0], lrs[-1])
    return best, "  ".join(f"{lr:g}:{full[lr]:.3f}" for lr in lrs) + f"  -> {best:g}" + ("  AU BORD" if edge else "")



import json as _json
LRS = [1e-4, 2e-4, 5e-4, 1e-3, 2e-3, 5e-3, 1e-2]
T4, BONF2 = 2.776, 3.495
obqa = is_obqa
PRE = _json.load(open("refs_o16.json"))
RATE = PRE["rates"]; RANK = {"top": 16, "bottom": 16, "free": 7}
FOLLOW = []
for p_ in glob.glob(os.path.expanduser("~/lora-runs-suivi") + "/*/config.yaml"):
    d_ = os.path.dirname(p_)
    try:
        if open(d_ + "/status").read().startswith("DONE"):
            FOLLOW.append((yaml.safe_load(open(p_)) or {}, _json.load(open(d_ + "/metrics.json")), d_))
    except (OSError, ValueError):
        pass


def cell_in(src, mode, rank, lr):
    by = {}
    for c, m, d in src:
        if (obqa(c) and c.get("mode") == mode and c.get("rank") == rank and abs(float(c.get("lr") or 0) - lr) < 1e-12 and c.get("seed") in S_REP and "mcq_acc" in m
                and float(c.get("max_grad_norm", 1.0) or 0) == 1.0 and c.get("update_norm_target") in (None, "")):
            by.setdefault(c["seed"], []).append((m["mcq_acc"], d))
    ok = sorted(by) == S_REP and all(len(v) == 1 for v in by.values())
    return ({s: v[0][0] for s, v in by.items()} if ok else None), {s: v[0][1] for s, v in by.items()}


def gpu_of(d):
    try:
        with open(d + "/results.csv", newline="") as f:
            return (next(csv.DictReader(f)).get("PARTITION") or "?").replace("NVIDIA ", "").replace(" Generation", "")
    except (OSError, StopIteration):
        return "?"


def pt(d):
    m = st.mean(d); se = st.stdev(d) / len(d) ** 0.5
    return m, m - T4 * se, m + T4 * se, (m / se if se > 0 else float("inf"))


col = lambda x, thr: f"{x[0]:+.2f} [{x[1]:+.2f}, {x[2]:+.2f}] t={x[3]:+.2f} -> " + ("ETABLI" if abs(x[3]) > thr else "non etabli")  # noqa: E731
print("==================== le gel de B isole au rang 16, OpenBookQA (Qwen2.5-1.5B) ====================")
R, stop = {}, []
for k in ("top", "bottom", "free"):
    v, dirs = cell_in(RUNS, k, RANK[k], RATE[k])
    pre = {int(s): x for s, x in PRE[k].items()}
    same = v is not None and all(abs(v[s] - pre[s]) < 1e-9 for s in S_REP)
    print(f"  reference {k:6s} (r={RANK[k]} a {RATE[k]:g}) : {st.mean(pre.values()):.4f} (committee) ; cartes {PRE[k + '_gpu']}" + ("" if same else "  <- LES RUNS ONT CHANGE"))
    if not same:
        stop.append(k)
    R[k] = pre
if stop:
    print("  ARRET : references modifiees depuis le commit : " + ", ".join(stop))
else:
    G = PRE["G"]
    N, O, gpus = {}, {}, set()
    for X in ("top", "bottom"):
        for rank in (7, 16):
            b, txt = select(obqa, X + "_unfrozen", rank, LRS, "val_mcq_acc")
            full = {lr: cell_in(RUNS, X + "_unfrozen", rank, lr) for lr in LRS}
            done = {lr: v for lr, (v, _) in full.items() if v is not None}
            o = max(done, key=lambda lr: st.mean(done[lr].values())) if done else None
            print(f"  selection {X}_unfrozen r={rank:2d} : {txt}  | oracle : {o if o is None else f'{o:g}'}")
            if b is None or b not in done:
                stop.append(f"{X}_unfrozen r={rank}"); continue
            N[(X, rank)], O[(X, rank)] = done[b], done[o]
            gpus |= {gpu_of(full[b][1][s]) for s in S_REP}
            print(f"    {X}_unfrozen r={rank} a {b:g} : {st.mean(done[b].values()):.4f}" + ("  AU BORD" if b in (LRS[0], LRS[-1]) else ""))
    if stop:
        print("  ARRET : cellules incompletes : " + ", ".join(stop))
    else:
        print(f"  cartes des nouveaux bras : {sorted(gpus)}")
        F = {}
        for k in ("top", "bottom", "free"):
            v, dirs = cell_in(FOLLOW, k, RANK[k], RATE[k])
            if v is not None:
                F[k] = v; print(f"  reference {k:6s} reentrainee sur une carte : {st.mean(v.values()):.4f} ({','.join(sorted({gpu_of(dirs[s]) for s in S_REP}))})")
        series = [("references d'origine", R, G)]
        if len(F) == 3:
            series.append(("controle a carte egale", F, {X: (st.mean(F["free"].values()) - st.mean(F[X].values())) * 100 for X in ("top", "bottom")}))
        else:
            print("  controle a carte egale : references reentrainees incompletes, non calcule")
        for lab, RR, GG in series:
            print(f"\n  ---- {lab} ----")
            for X in ("top", "bottom"):
                g = GG[X]
                for tag, Z in (("retenu", N), ("oracle", O)):
                    if g >= 2.0:
                        m, lo, hi, _ = pt([(Z[(X, 7)][s] - RR[X][s]) * 100 for s in S_REP])
                        v = ("le gel explique l'essentiel" if lo >= 0.7 * g else "partage (chevauche 0,7 G)") if m >= 0.7 * g else (("l'essentiel vient d'ailleurs" if hi <= 0.3 * g else "partage (chevauche 0,3 G)") if m <= 0.3 * g else "partage")
                        u = f"U = {m:+.2f} [{lo:+.2f}, {hi:+.2f}] contre 0,7 G = {0.7 * g:.2f} -> {v}"
                    else:
                        u = f"G = {g:+.2f} < 2 points : test U NON APPLICABLE"
                    print(f"    {X:6s} {tag} : (1) {u}")
                    print(f"    {X:6s} {tag} : (2) gel seul r=16 {col(pt([(Z[(X, 16)][s] - RR[X][s]) * 100 for s in S_REP]), BONF2)}")
            fz = [(RR["bottom"][s] - RR["top"][s]) * 100 for s in S_REP]; floor = abs(st.mean(fz)) >= 2.0
            for tag, Z in (("retenu", N), ("oracle", O)):
                d = [((Z[("bottom", 16)][s] - Z[("top", 16)][s]) - (RR["bottom"][s] - RR["top"][s])) * 100 for s in S_REP]
                print(f"    (3) {tag} : ecart gele {st.mean(fz):+.2f} ; plancher " + ("atteint" if floor else "NON atteint (pas lu)") + f" ; retrecissement {col(pt(d), T4)}")
