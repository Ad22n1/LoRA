"""Analyse A6 (PROTOCOL_analyse_A6.md) : soumet les deux jobs qui recalculent le gradient initial de `grad` (memes 64 sequences, graine 1000,
modele de base, sans mise a jour) en gardant ses 32 premiers vecteurs singuliers a gauche. Pas d'entrainement. Dans la fenetre PARTITION seulement.

    python scripts/submit_grad32.py
"""
import os
import sys

sys.argv = ["x"]; ns = {"__name__": "x"}
exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "v2camp.py")).read().split('if __name__ == "__main__":')[0], ns)
runs = ns["load_runs"]("~/lora-runs")
for k, src, out in (("g32a", "g2a", "~/repo/bases/gradk32_obqa_r32.safetensors"),
                    ("g32b", "g2b", "~/repo/bases/gradk32_format_llama_r32.safetensors")):
    if os.path.exists(os.path.expanduser(out)):
        print(f"  {k} : {out} existe deja ; rien a soumettre"); continue
    C = dict(ns["CAMPS"][src]); C.update(basis=out, grad_rank=32, n=64, _k=k)
    ns["_grad_submit"](k, C, runs)
print("  quand les deux jobs sont finis : python scripts/analyses_v5.py --energy")
