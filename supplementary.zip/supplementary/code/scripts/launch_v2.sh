#!/bin/bash
# Lanceur des experiences v2 : bash scripts/launch_v2.sh <campagne> <prefixe> [--dry]
# Soumet les grilles configs/grids/v2_<campagne>_<prefixe>_*.yaml, epinglees (RTX 4000 Ada, ou machines eprouvees pour le 7B), apres avoir
# verifie qu'elles sont committees et que le disque suffit pour les facteurs. Refuse une relance tant que des runs tournent (doublons).
set -u
cd "$HOME/repo" || exit 1
PY="/tmp/lora-$USER/venv/bin/python"; [ -x "$PY" ] || PY=python3
K="${1:?campagne}"; P="${2:?prefixe}"; DRY=0; [ "${3:-}" = "--dry" ] && DRY=1
GRIDS=$(ls configs/grids/v2_${K}_${P}_*.yaml 2>/dev/null | xargs -n1 basename 2>/dev/null | sed 's/\.yaml$//')
[ -n "$GRIDS" ] || { echo "  REFUS : aucune grille v2_${K}_${P}_*"; exit 1; }
echo "=== 1. tout est committe et a jour ==="
bad=0; for f in scripts/v2camp.py scripts/launch_v2.sh $(for g in $GRIDS; do echo configs/grids/$g.yaml; done); do
  git ls-files --error-unmatch "$f" >/dev/null 2>&1 && git diff --quiet HEAD -- "$f" || { echo "  NON COMMITTE : $f"; bad=1; }; done
[ $bad -eq 0 ] && echo "  ok" || { echo "  REFUS : committer d'abord ; rien n'est lance"; exit 1; }
echo "=== 2. quota disque (runs sans facteurs ; ~3 Mo par run, estimation prudente) ==="
NRUNS=$("$PY" - $GRIDS <<'PYEOF'
import sys, yaml
print(sum(len(y["grid"]["lr"]) * len(y["grid"]["seed"]) for y in (yaml.safe_load(open(f"configs/grids/{g}.yaml")) for g in sys.argv[1:])))
PYEOF
)
NEED=$((NRUNS * 3))
Q=$(quota -w -s 2>/dev/null | awk 'NF >= 3 && $1 ~ /[0-9]M$/ {gsub("M","",$1); gsub("M","",$2); print $2 - $1; exit} NF >= 4 && $2 ~ /[0-9]M$/ {gsub("M","",$2); gsub("M","",$3); print $3 - $2; exit}')
DF=$(df -Pm "$HOME" | awk 'NR==2 {print $4}')
AVAIL=${Q:-$DF}; [ -n "$Q" ] && [ "$DF" -lt "$Q" ] && AVAIL=$DF
echo "  $NRUNS runs, ~${NEED} Mo ; libre sous le quota : ${Q:-inconnu} Mo ; disque : ${DF} Mo -> ${AVAIL} Mo retenus"
[ "$AVAIL" -gt $((NEED + 500)) ] || { echo "  REFUS : place insuffisante sous le quota (marge de 500 Mo) ; rien n'est lance"; exit 1; }
echo "=== 3. epinglage ==="
case "$K" in budget7|r16_7b) NODES="scripts/nodes_for_7b.py"; EXCL=$("$PY" $NODES 2>&1 | tail -1); "$PY" $NODES --report 2>&1 | head -1 ;;
  *) NODES="scripts/nodes_for_gpu.py"; EXCL=$("$PY" $NODES "RTX 4000 Ada" 2>&1 | tail -1); "$PY" $NODES "RTX 4000 Ada" --report 2>&1 | head -1 ;; esac
case "$EXCL" in STOP*|"") echo "  $EXCL"; echo "  REFUS : epinglage impossible ; rien n'est lance"; exit 1;; esac
BUSY=$(squeue -h -u "$USER" -o "%o" 2>/dev/null | grep -c "/lora-grid/v2_${K}_")      # jobs de CETTE campagne seulement
# Couvre-feu du cluster partage : plus aucun run apres 8 h. Echeance = le prochain 8 h ; duree maximale realiste par modele.
case "$K" in budget7|r16_7b) TLIM="01:15:00" ;; *) TLIM="00:30:00" ;; esac
NOW=$(date +%s); D8=$(date -d "08:00" +%s); [ "$NOW" -ge "$D8" ] && D8=$(date -d "tomorrow 08:00" +%s)
DEADLINE=$(date -d "@$D8" +%Y-%m-%dT%H:%M:%S)
echo "=== 4. lancement (duree maximale $TLIM, echeance Slurm $DEADLINE : une tache qui ne peut pas finir avant n'est pas demarree) ==="
for g in $GRIDS; do
  dir="$HOME/lora-grid/$g"; [ $DRY -eq 1 ] && dir="$(mktemp -d)/$g"
  out=$("$PY" -m lorasub.launch_grid "configs/grids/$g.yaml" --grid_dir "$dir" --partition PARTITION --time "$TLIM" --max_par 8 --venv "/tmp/lora-$USER/venv" 2>&1)
  n=$(echo "$out" | grep -oE "[0-9]+ already done; [0-9]+ to run")
  [ -n "$n" ] || { echo "  ERREUR  $g : $(echo "$out" | tail -1)"; continue; }
  done_=$(echo "$n" | grep -oE "^[0-9]+"); torun=$(echo "$n" | grep -oE "[0-9]+ to run" | grep -oE "[0-9]+")
  if [ "$torun" -eq 0 ]; then echo "  RIEN    $g : complet ($done_)"; continue; fi
  if [ "$done_" -gt 0 ] && [ "$BUSY" -gt 0 ]; then echo "  ATTENTE $g : $done_ termines, $torun a relancer, mais des runs tournent encore (doublons possibles) ; relancer file vide"; continue; fi
  [ "$done_" -gt 0 ] && echo "  REPRISE $g : $done_ runs termines conserves"
  if [ $DRY -eq 1 ]; then echo "  pret    $g : $torun runs"; continue; fi
  echo "  soumis  $g ($torun runs) : job $(sbatch --parsable --deadline="$DEADLINE" --exclude="node,$EXCL" "$HOME/lora-grid/$g/slurm_array.sh")"
done
echo "=== file ==="; squeue -u "$USER" 2>/dev/null | head -6
