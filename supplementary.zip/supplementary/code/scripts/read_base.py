"""EVAL_base_models.md: scores of the un-adapted models, seeds 150 and 151, pinned to one PARTITION model. No PARTITION.

    python scripts/read_base.py
"""
import csv
import glob
import json
import os

import yaml

CELLS = [("format", "meta-llama/Llama-3.2-1B", None, "format_parsed"), ("format", "Qwen/Qwen2.5-1.5B", None, "format_parsed"),
         ("commonsense", "Qwen/Qwen2.5-7B", "dc05f4d847f9", "mcq_acc"), ("commonsense", "mistralai/Mistral-7B-v0.3", "dc05f4d847f9", "mcq_acc")]
runs = []
for p in glob.glob(os.path.expanduser("~/lora-runs/*/config.yaml")):
    c = yaml.safe_load(open(p)) or {}; d = os.path.dirname(p)
    if c.get("mode") != "baseline":
        continue
    try:
        if not open(d + "/status").read().startswith("DONE"):
            continue
        m = json.load(open(d + "/metrics.json"))
        g = (next(csv.DictReader(open(d + "/results.csv"))).get("PARTITION") or "?").replace("NVIDIA ", "").replace(" Generation", "")
    except (OSError, ValueError, StopIteration):
        continue
    runs.append((c, m, g))
print("==================== le modele de base, sans entrainement ====================")
for task, model, fp, key in CELLS:
    sel = [(c, m, g) for c, m, g in runs if c.get("task") == task and str(c.get("model")) == model and (fp is None or str(c.get("data_fingerprint")) == fp) and key in m]
    new = {c.get("seed"): (m[key], g) for c, m, g in sel if c.get("seed") in (150, 151)}
    old = [(c.get("seed"), m[key], g) for c, m, g in sel if c.get("seed") not in (150, 151)]
    label = f"{'format' if task == 'format' else 'OpenBookQA'}, {model}"
    if sorted(new) != [150, 151]:
        print(f"  {label:44s} : INCOMPLET ({sorted(new)})"); continue
    (a, ga), (b, gb) = new[150], new[151]
    print(f"  {label:44s} : {a:.4f} ; graine 151 {b:.4f} (ecart {abs(a - b) * 100:.2f} point) ; cartes {sorted({ga, gb})}")
    for s, v, g in old:
        print(f"    evaluation plus ancienne : graine {s}, {v:.4f} ({g})")
