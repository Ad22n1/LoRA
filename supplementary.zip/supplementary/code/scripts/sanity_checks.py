"""Step 3 sanity checks on an un-adapted model: MCQ ~ 25 %, alien parsing < 10 %.

    python scripts/sanity_checks.py --model meta-llama/Llama-3.2-1B --data_dir $SHARED/data
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from lorasub.eval import format_metrics, mcq_accuracy  # noqa: E402
from lorasub.modeling import load_model, load_tokenizer  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--model", required=True)
ap.add_argument("--data_dir", required=True)
ap.add_argument("--n", type=int, default=200)
a = ap.parse_args()
tok = load_tokenizer(a.model)
model = load_model(a.model)
model.eval()
d = Path(a.data_dir)
m = mcq_accuracy(model, tok, d / "facts" / "mcq_test.jsonl", a.n)
f = format_metrics(model, tok, d / "format" / "test.jsonl", a.n)
print(m, f)
print("facts sanity  (MCQ at chance) :", "OK" if 0.18 <= m["mcq_acc"] <= 0.32 else "FAIL -> an attribute has priors, rebalance")
print("format sanity (parsed < 10%)  :", "OK" if f["format_parsed"] < 0.10 else "FAIL -> format already known, change keys/tags")
