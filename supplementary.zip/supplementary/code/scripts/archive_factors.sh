#!/usr/bin/env bash
# Move the saved factors of FINISHED runs from the home quota to node's local disk /Data (kept, per USER).
#
#     bash scripts/archive_factors.sh --dry     # counts files and size, moves nothing
#     bash scripts/archive_factors.sh           # moves, then leaves a symlink in place of each file
#
# /Data is LOCAL to node: compute nodes do not see it. So only files no PARTITION job reads are moved: the
# factors of runs whose status is DONE and that have not been touched for an hour. The analyses run on
# node read metrics, not factors; on node the symlinks make every moved file readable as before. A PARTITION
# job that needed one would hit a broken link and fail loudly, never silently.
# rsync copies and checks each file before removing the original; a manifest lists every move.
set -u
DRY=0; [ "${1:-}" = "--dry" ] && DRY=1
DATA="${DATA_ROOT:-/Data}"   # DATA_ROOT exists only for the tests
SRC="$HOME/lora-runs"; DEST="$DATA/$USER/lora-runs-factors"
case "$(hostname)" in node*) ;; *) echo "  REFUS : a lancer sur node (son /Data n'est pas celui des autres machines)"; exit 1;; esac
[ -d "$DATA" ] && [ -w "$DATA" ] || { echo "  REFUS : /Data absent ou non inscriptible"; exit 1; }

LIST=$(mktemp)
# the factors of runs that are DONE and whose directory has not changed for 60 minutes
for st in "$SRC"/*/status; do
    d=$(dirname "$st")
    head -1 "$st" 2>/dev/null | grep -q "^DONE" || continue
    [ -n "$(find "$d" -maxdepth 1 -newermt '-60 minutes' -print -quit)" ] && continue
    find "$d" -maxdepth 1 -type f -name 'factors_*' -printf '%P\n' | sed "s#^#$(basename "$d")/#"
done > "$LIST"
N=$(wc -l < "$LIST")
BYTES=$(cd "$SRC" && tr '\n' '\0' < "$LIST" | xargs -0 -r stat -c %s | awk '{s+=$1} END {print s+0}')
echo "$N $BYTES" | awk '{printf "  %d fichiers de facteurs, %.2f Go, dans des runs termines depuis plus d'"'"'une heure\n", $1, $2/1e9}'
quota -s 2>/dev/null | tail -1 | sed 's/^/  quota avant : /'
if [ "$DRY" -eq 1 ] || [ "$N" -eq 0 ]; then rm -f "$LIST"; exit 0; fi

mkdir -p "$DEST" && chmod 700 "$DATA/$USER"
MAN="$DEST/MANIFEST_$(date +%Y%m%d_%H%M%S).txt"; cp "$LIST" "$MAN"
# file by file: copy, compare byte for byte, and only then remove the original and leave a symlink.
# No rsync needed; a file whose copy does not match stays where it was.
ok=0; miss=0
while read -r rel; do
    src="$SRC/$rel"; dst="$DEST/$rel"
    mkdir -p "$(dirname "$dst")"
    if cp -p "$src" "$dst" && cmp -s "$src" "$dst"; then
        rm "$src" && ln -s "$dst" "$src" && ok=$((ok+1))
    else
        rm -f "$dst"; miss=$((miss+1)); echo "  ANOMALIE, laisse en place : $rel"
    fi
done < "$LIST"
echo "  deplaces et relies : $ok ; anomalies : $miss   (manifeste : $MAN)"
cp "$MAN" "$HOME/lora-results/$(basename "$MAN")"
quota -s 2>/dev/null | tail -1 | sed 's/^/  quota apres : /'
rm -f "$LIST"
