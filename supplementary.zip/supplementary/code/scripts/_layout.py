"""Layout helpers for the figure scripts (01/10): place a legend where it hides no point and no label, and pull apart
point labels that overlap. They move artists only; no plotted value is touched."""


def _boxes(ax, r, skip=()):
    import numpy as np
    pts = []
    for ln in ax.lines:
        xy = ln.get_xydata()
        if len(xy) and ln.get_marker() not in (None, "None", "", " "):
            pts.append(ax.transData.transform(np.asarray(xy, float)))
    for c in ax.collections:
        off = c.get_offsets()
        if len(off):
            pts.append(c.get_offset_transform().transform(np.asarray(off, float)))
    texts = [t.get_window_extent(r) for t in ax.texts if t.get_visible() and t.get_text() and t not in skip]
    return (np.vstack(pts) if pts else np.zeros((0, 2))), texts


def place_legend(ax, order=("upper center", "upper left", "upper right", "lower left", "lower right", "center left",
                            "center right", "lower center", "center"), pad=3.0, **kw):
    """Try each location; keep the first whose box covers no marker and no text of the axes. Else put it below the axes."""
    fig = ax.figure
    for loc in order:
        leg = ax.legend(loc=loc, **kw)
        fig.canvas.draw(); r = fig.canvas.get_renderer()
        bb = leg.get_window_extent(r).expanded(1.0, 1.0)
        pts, texts = _boxes(ax, r)
        hit_p = ((pts[:, 0] >= bb.x0 - pad) & (pts[:, 0] <= bb.x1 + pad) & (pts[:, 1] >= bb.y0 - pad) & (pts[:, 1] <= bb.y1 + pad)).any() if len(pts) else False
        hit_t = any(bb.overlaps(t) for t in texts)
        if not hit_p and not hit_t:
            print(f"  legend placed at {loc!r}: no marker or label under it")
            return leg, loc
        leg.remove()
    leg = ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.14), **kw)
    print("  legend placed below the axes: every location inside covered a marker or a label")
    return leg, "below"


def separate_labels(ax, labels, step=4.0, max_iter=80, margin_px=4.0):
    """Shift annotations sideways, in points, until no two overlap or come within margin_px of each other. Their anchors (the data
    points) do not move."""
    fig = ax.figure; moved = 0
    for _ in range(max_iter):
        fig.canvas.draw(); r = fig.canvas.get_renderer()
        bbs = [t.get_window_extent(r).padded(margin_px / 2) for t in labels]
        clash = [(i, j) for i in range(len(labels)) for j in range(i + 1, len(labels)) if bbs[i].overlaps(bbs[j])]
        if not clash:
            break
        anchors = [ax.transData.transform(t.xy) for t in labels]      # the data points, in display units
        for i, j in clash:
            # the label of the point further left goes left: labels never cross over their points
            left, right = (i, j) if (anchors[i][0], i) <= (anchors[j][0], j) else (j, i)
            for k, d in ((left, -step), (right, step)):
                x, y = labels[k].xyann
                labels[k].xyann = (x + d, y); moved += 1
    fig.canvas.draw(); r = fig.canvas.get_renderer()
    bbs = [t.get_window_extent(r).padded(margin_px / 2) for t in labels]
    left_over = sum(bbs[i].overlaps(bbs[j]) for i in range(len(labels)) for j in range(i + 1, len(labels)))
    print(f"  point labels: {moved} shift(s) applied; overlapping pairs left: {left_over}")
    return left_over


def save_at_width(fig, path, width_px, pad_inches=0.05, **kw):
    """Export cropped to the drawn content (nothing is cut: tight bounding box) at a resolution that gives exactly width_px
    pixels, so that a figure keeps the width it has in the paper. The tight box shifts slightly with the resolution, so the
    resolution is searched in memory around the first estimate until the width is exact."""
    import io
    from PIL import Image
    fig.canvas.draw()
    bb = fig.get_tightbbox(fig.canvas.get_renderer())
    est = width_px / (bb.width + 2 * pad_inches)

    def width(dpi):
        buf = io.BytesIO(); fig.savefig(buf, format="png", dpi=dpi, bbox_inches="tight", pad_inches=pad_inches, **kw)
        return Image.open(io.BytesIO(buf.getvalue())).size[0]
    best = (abs(width(est) - width_px), est)
    for k in range(1, 400):
        for dpi in (est * (1 + k * 2.5e-4), est * (1 - k * 2.5e-4)):
            w = width(dpi)
            if abs(w - width_px) < best[0]:
                best = (abs(w - width_px), dpi)
            if w == width_px:
                break
        if best[0] == 0:
            break
    fig.savefig(path, dpi=best[1], bbox_inches="tight", pad_inches=pad_inches, **kw)
    print(f"  exported at {best[1]:.3f} dpi: {width_px - best[0]} to {width_px + best[0]} px of width (target {width_px})")
