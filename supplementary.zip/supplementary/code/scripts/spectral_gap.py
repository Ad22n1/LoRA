"""Spectral gap in the bands each arm freezes -- the Davis-Kahan mechanism, never measured.

WHY THIS EXISTS. The project's original theory axis (V1, 10 September) proposed that the bottom of
the spectrum is *malleable* because the singular subspace there is unstable: when consecutive
singular values are close, a small perturbation rotates the corresponding singular vectors a lot.
That is the Davis-Kahan / Wedin bound, and it was the candidate explanation for the plasticity MiCA
reports. Reference: Staats et al., NeurIPS 2025, "Small singular values matter" -- absent from the
current bibliography.

The axis was never run, and the argument was later confused with a different one. On 13 September a
claim that ``sigma_min / sigma_max ~ 3e-9`` was refuted: the worst real ratio is 1.86e-7 and the
numerical rank is full. That refutation killed "bottom-r adapts quantisation noise". **It does NOT
touch Davis-Kahan**, which depends on the GAP ``sigma_i - sigma_{i+1}``, not on ``sigma_min``. A
spectrum can be numerically healthy everywhere and still have vanishing gaps at the bottom.

So the gap has never been measured, it is free, and it is the best remaining mechanical candidate
for why the bottom band behaves differently.

WHAT IS REPORTED, and why each column is needed.

* ``rel_gap`` -- the gap between the band and its neighbour, divided by sigma_max. This is the
  quantity Davis-Kahan puts in the denominator: subspace rotation under a perturbation of norm eps
  is bounded by roughly ``eps / gap``. A band with a small relative gap is a band whose identity is
  fragile.
* ``within_spread`` -- ``(sigma_first - sigma_last) / sigma_first`` INSIDE the band. A band whose own
  singular values are nearly equal is not just fragile at its boundary: its internal basis is
  arbitrary, since any rotation within a degenerate eigenspace is equally valid. For r = 2 this is
  the more relevant number, and nobody reports it.
* ``sigma_mean`` -- the scale itself, to separate "small gap" from "small sigma". They are not the
  same thing and the project has already confused them once.

WHAT THIS CANNOT SHOW. A gap is a property of the frozen basis B, computed before any training. It
constrains how much the TRUE singular subspace of W0 would move under perturbation; it says nothing
directly about how well an adapter writing into that subspace can learn. The link is a hypothesis --
the same caveat that applies to reading the gradient-energy profile as a prediction about the arms.
Report the measurement, propose the mechanism, do not assert the implication.
"""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import torch  # noqa: E402

from lorasub.spectral import band_indices, list_cached, load_svd, numerical_rank, parse_module_name  # noqa: E402


def band_stats(S: torch.Tensor, idx: torch.Tensor) -> dict[str, float]:
    """Gap and internal spread for one band of singular values.

    ``idx`` need not be contiguous (the ``random`` arm draws scattered indices), so the neighbour is
    taken around the min and max index actually used.
    """
    S = S.float()
    smax = float(S[0])
    i0, i1 = int(idx.min()), int(idx.max())
    sig = S[idx]
    first, last = float(sig.max()), float(sig.min())

    # gap to the nearest singular value OUTSIDE the band, on either side
    below = float(S[i1 + 1]) if i1 + 1 < S.numel() else None   # smaller sigma, higher index
    above = float(S[i0 - 1]) if i0 - 1 >= 0 else None          # larger sigma, lower index
    gaps = [g for g in ((above - first) if above is not None else None,
                        (last - below) if below is not None else None) if g is not None]
    gap = min(gaps) if gaps else float("nan")

    return {
        "sigma_max": smax,
        "sigma_first": first,
        "sigma_last": last,
        "sigma_mean": float(sig.mean()),
        "abs_gap": gap,
        "rel_gap": gap / smax if smax > 0 else float("nan"),
        # (first - last) / first: 0 means the band is degenerate, so its internal basis is arbitrary
        "within_spread": (first - last) / first if first > 0 else float("nan"),
    }


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--svd_cache", required=True)
    ap.add_argument("--model", default="meta-llama/Llama-3.2-1B")
    ap.add_argument("--ranks", default="1,2,4,16")
    ap.add_argument("--out", default=None)
    ap.add_argument("--rel_tol", type=float, default=1e-6,
                    help="numerical-rank tolerance; bottom bands are taken inside the non-zero part")
    a = ap.parse_args()

    names = list_cached(a.svd_cache, a.model)
    if not names:
        raise SystemExit(f"no SVD cache for {a.model} under {a.svd_cache}")
    ranks = [int(x) for x in a.ranks.split(",")]

    rows = []
    for name in names:
        e = load_svd(a.svd_cache, a.model, name)
        layer, module = parse_module_name(name)
        nrank = numerical_rank(e.S, a.rel_tol)
        for r in ranks:
            if r > nrank:
                continue
            for arm in ("top", "bottom"):
                # bottom bands are taken INSIDE the numerically non-zero part: passing S and rel_tol
                # makes band_indices use the numerical rank rather than m. Without it, a bottom band
                # on a rank-deficient module would sit in the null space, where the singular vectors
                # are arbitrary and the gap meaningless.
                idx = band_indices(e.m, f"{arm}:{r}", S=e.S, rel_tol=a.rel_tol)
                st = band_stats(e.S, idx)
                rows.append({"model": a.model, "module": name, "layer": layer,
                             "module_type": module, "rank": r, "arm": arm,
                             "numerical_rank": nrank, **st})

    out = Path(a.out or Path.home() / "lora-analysis" / "spectral_gap.csv")
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"wrote {len(rows)} rows -> {out}")

    # --- summary, medians per (rank, arm): heavy-tailed quantities, never a mean ---
    try:
        import pandas as pd
    except ImportError:
        return
    d = pd.DataFrame(rows)
    print("\n=== relative gap to the neighbouring singular value, median over modules and layers ===")
    print(d.pivot_table(index="rank", columns="arm", values="rel_gap", aggfunc="median").to_string())
    print("\n=== spread INSIDE the band, (first-last)/first — 0 = degenerate, basis arbitrary ===")
    print(d.pivot_table(index="rank", columns="arm", values="within_spread",
                        aggfunc="median").round(4).to_string())
    print("\n=== scale, to separate 'small gap' from 'small sigma' ===")
    print(d.pivot_table(index="rank", columns="arm", values="sigma_mean",
                        aggfunc="median").round(4).to_string())

    r2 = d[d["rank"] == 2]
    if not r2.empty:
        print("\n=== rank 2, per module type: is the effect uniform? ===")
        print(r2.pivot_table(index="module_type", columns="arm",
                             values=["rel_gap", "within_spread"], aggfunc="median").round(5).to_string())
        piv = r2.pivot_table(index=["layer", "module_type"], columns="arm", values="within_spread")
        if {"top", "bottom"} <= set(piv.columns):
            diff = (piv["bottom"] - piv["top"]).dropna()
            n_lower = int((diff < 0).sum())
            print(f"\n=== paired over (layer, module), n={len(diff)} ===")
            print(f"  bottom more degenerate than top in {n_lower}/{len(diff)} cases")
            print(f"  median difference in within-spread (bottom - top): {diff.median():+.5f}")
            k, hi = len(diff), max(n_lower, len(diff) - n_lower)
            from math import comb
            p = min(1.0, 2 * sum(comb(k, i) for i in range(hi, k + 1)) / 2 ** k) if k else 1.0
            print(f"  sign test, two-sided: p = {p:.3g}")
            print("\n  If bottom bands are systematically more degenerate, Davis-Kahan says their")
            print("  singular basis is the less well-determined one — a mechanism for why writing")
            print("  there behaves differently, and one that survives the refutation of the 3e-9.")


if __name__ == "__main__":
    main()
