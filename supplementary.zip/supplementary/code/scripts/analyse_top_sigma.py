"""The top_sigma rate sweep, exactly as PROTOCOL_top_sigma.md fixed it before launch.

Selection: mean validation score over seeds 0 and 1, per rate. The selected rate must be interior;
on an edge, the grid is extended by one step in that direction and the selection redone. If the two
best rates are within one binomial standard error, the tie is reported and both go to seeds 2-6.
Conclusion, fixed in advance (top selects 1e-2, bottom 2e-3 or 5e-3):
  (A) rate <= 1e-3 -> keeping Sigma is enough to recover PiSSA's direction: Sigma reverses the shift
  (B) rate >= 1e-2 -> Sigma does not move the rate: the shift does not come from Sigma
  (C) otherwise    -> Sigma moves it part of the way: reported as such, no attribution
Writes configs/grids/top_sigma_seeds.yaml for seeds 2-6 at the retained rate(s), only if interior.

    python scripts/analyse_top_sigma.py
"""
import os
import sys

import yaml

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
from lorasub.aggregate import collect  # noqa: E402

GRID = [2e-5, 5e-5, 1e-4, 2e-4, 5e-4, 1e-3, 2e-3, 5e-3, 1e-2, 2e-2]
d = collect(os.path.expanduser("~/lora-runs"))
x = d[(d.task == "format") & (d.model.astype(str) == "meta-llama/Llama-3.2-1B") & (d["mode"] == "top_sigma")
      & (d["rank"] == 2) & (d.n_modules == 7) & (d.max_grad_norm == 1.0) & d.update_norm_target.isna()
      & d.seed.isin([0, 1])]
if x.empty:
    raise SystemExit("no top_sigma run found yet")
rows = []
for lr in GRID:
    c = x[(x.lr - lr).abs() < 1e-15]
    per = c.groupby("seed").val_format_parsed.mean()
    n = float(c.val_format_n.iloc[0]) if len(c) and "val_format_n" in c else float("nan")
    rows.append((lr, float(per.mean()) if len(per) else float("nan"), int(per.size), n))
print("  rate      val (seeds 0-1)   seeds")
for lr, v, k, _ in rows:
    print(f"  {lr:<8g}  {v:.4f}           {k}{'   INCOMPLETE' if k < 2 else ''}")
if any(k < 2 for _, _, k, _ in rows):
    raise SystemExit("\n  incomplete: wait for the jobs, or relaunch the missing runs identically, then rerun")
best = sorted(rows, key=lambda r: -r[1])
lr1, v1, _, n = best[0]
lr2, v2 = best[1][0], best[1][1]
se = (v1 * (1 - v1) / (2 * n)) ** 0.5
i = GRID.index(lr1)
print(f"\n  best {lr1:g} ({v1:.4f}), runner-up {lr2:g} ({v2:.4f}), gap {v1 - v2:.4f}, binomial SE {se:.4f}")
if i in (0, len(GRID) - 1):
    step = "lower" if i == 0 else "higher"
    raise SystemExit(f"\n  EDGE: the optimum is on the {step} edge. Protocol: extend the grid by one step"
                     f" {step} and redo the selection. Nothing is concluded.")
kept = [lr1] + ([lr2] if v1 - v2 < se else [])
print(f"  retained: {', '.join(f'{v:g}' for v in kept)}" + ("   (tie within one SE, both go to seeds 2-6)" if len(kept) > 1 else ""))


def verdict(lr):
    return "A: Sigma reverses the shift" if lr <= 1e-3 + 1e-15 else (
        "B: the shift does not come from Sigma" if lr >= 1e-2 - 1e-15 else "C: partial, no attribution")


verdicts = {verdict(v) for v in kept}
print(f"  CONCLUSION (protocol): {' / '.join(sorted(verdicts))}")
if len(verdicts) > 1:
    print("  the tied rates fall in different cases: the paper reports the tie and attributes nothing")
base = yaml.safe_load(open("configs/grids/top_sigma_sweep.yaml"))["base"]
head = ("# top_sigma, graines rapportees 2 a 6, au taux retenu par la regle du protocole (analyse_top_sigma.py).\n"
        "# Protocole : PROTOCOL_top_sigma.md. Lancer SANS --lr_from.\n")
open("configs/grids/top_sigma_seeds.yaml", "w").write(head + yaml.safe_dump(
    {"base": base, "grid": {"mode": ["top_sigma"], "lr": kept, "seed": [2, 3, 4, 5, 6]}}, sort_keys=False))
print(f"\n  wrote configs/grids/top_sigma_seeds.yaml : {5 * len(kept)} runs")
