"""PROTOCOL_7b_unfrozen_r1.md: B trained at the free reference's rank (1) on Qwen2.5-7B and Mistral-7B, OpenBookQA. No PARTITION.

    python scripts/read_u1.py 2>&1 | grep -vE "FutureWarning|pd.concat"

References: the frozen arms (rank 2) and free LoRA (rank 1) of the two 7B campaigns, seeds 2-6, which must give back their values to 1e-4.
New arms top_unfrozen and bottom_unfrozen at rank 1, selected on seeds 0-1 (validation), reported on 2-6.
Test: U = unfrozen (r=1) - frozen (r=2) against 0.7 G and 0.3 G, G fixed in advance.
"""
import csv
import glob
import json
import math
import os
import random
import re
import statistics as st

import yaml

R = os.path.expanduser("~/lora-runs")
LLAMA, QWEN = "meta-llama/Llama-3.2-1B", "Qwen/Qwen2.5-1.5B"
S_SEL, S_REP = (0, 1), [2, 3, 4, 5, 6]


def tokens(c):
    t = c.get("target_tokens")
    return t.get(c.get("task")) if isinstance(t, dict) else t


RUNS = []
for p in glob.glob(R + "/*/config.yaml"):
    c = yaml.safe_load(open(p)) or {}
    d = os.path.dirname(p)
    try:
        if not open(d + "/status").read().startswith("DONE"):
            continue
        RUNS.append((c, json.load(open(d + "/metrics.json")), d))
    except OSError:
        continue


def clipped(c):
    """Gradient clipping at 1.0, the paper's setting. A noclip grid reran the same cells without clipping (collect()'s
    docstring); mixing both put two runs per seed in the frozen cells and moved G from 12.41 to 13.53 (26/09)."""
    v = c.get("max_grad_norm", 1.0)
    return v is not None and float(v) == 1.0


def seven(c):
    tm = c.get("target_modules")
    return tm is None or len(tm) == 7


def cell(pred, mode, rank, lr, seeds, key):
    """{seed: value}; several runs of one seed are averaged and flagged."""
    by = {}
    for c, m, d in RUNS:
        if (pred(c) and clipped(c) and c.get("mode") == mode and c.get("rank") == rank and abs(float(c.get("lr") or 0) - lr) < 1e-12
                and c.get("seed") in seeds and key in m and c.get("update_norm_target") in (None, "")):
            by.setdefault(c["seed"], []).append((m[key], d))
    dup = {s: len(v) for s, v in by.items() if len(v) > 1}
    if dup:   # say what separates the duplicates, so that the next filter is written from evidence
        s0 = sorted(dup)[0]; cfgs = [yaml.safe_load(open(d + "/config.yaml")) or {} for _, d in by[s0]]
        keys = sorted(k for k in set().union(*cfgs) if k not in ("run_id", "out_dir") and len({str(c_.get(k)) for c_ in cfgs}) > 1)
        dup["differ"] = {k: [c_.get(k) for c_ in cfgs] for k in keys} or "configs identiques"
    return {s: st.mean(x for x, _ in v) for s, v in by.items()}, dup, {s: [d for _, d in v] for s, v in by.items()}


def select(pred, mode, rank, lrs, key):
    full = {}
    for lr in lrs:
        v, _, _ = cell(pred, mode, rank, lr, S_SEL, key)
        if len(v) == 2: full[lr] = st.mean(v.values())
    if len(full) < len(lrs):
        return None, f"INCOMPLET ({len(full)}/{len(lrs)} taux avec leurs deux graines)"
    best = max(full, key=full.get)
    edge = best in (lrs[0], lrs[-1])
    return best, "  ".join(f"{lr:g}:{full[lr]:.3f}" for lr in lrs) + f"  -> {best:g}" + ("  AU BORD" if edge else "")



LRS = [5e-4, 1e-3, 2e-3, 5e-3, 1e-2]
T4 = 2.776
MODELS = {"Qwen/Qwen2.5-7B": {"top": (5e-3, 0.5316), "bottom": (5e-4, 0.4840), "free": (2e-3, 0.6284), "G": {"top": 9.68, "bottom": 14.44}},
          "mistralai/Mistral-7B-v0.3": {"top": (1e-3, 0.4764), "bottom": (1e-3, 0.4776), "free": (1e-3, 0.6012), "G": {"top": 12.48, "bottom": 12.36}}}


def gpu_of(d):
    try:
        with open(d + "/results.csv", newline="") as f:
            return (next(csv.DictReader(f)).get("PARTITION") or "?").replace("NVIDIA ", "").replace(" Generation", "")
    except (OSError, StopIteration):
        return "?"


def pt(d):
    m = st.mean(d); se = st.stdev(d) / len(d) ** 0.5
    return m, m - T4 * se, m + T4 * se


for model, ref in MODELS.items():
    pred = lambda c, model=model: c.get("task") == "commonsense" and str(c.get("data_fingerprint")) == "dc05f4d847f9" and str(c.get("model")) == model  # noqa: E731
    print(f"\n==================== {model}, OpenBookQA : B entraine au rang 1 ====================")
    R, gpus, stop = {}, set(), []
    for X, rank in (("top", 2), ("bottom", 2), ("free", 1)):
        lr, exp = ref[X]
        v, dup, dirs = cell(pred, X, rank, lr, S_REP, "mcq_acc")
        m = st.mean(v.values()) if len(v) == 5 else float("nan")
        ok = len(v) == 5 and not dup and abs(m - exp) < 1e-4
        print(f"  reference {X:6s} (r={rank} a {lr:g}) : {m:.4f} (attendu {exp:.4f})" + ("" if ok else "  <- ECART"))
        if not ok:
            stop.append(X)
        else:
            R[X] = v; gpus |= {gpu_of(dirs[s][0]) for s in S_REP}
    if stop:
        print("  ARRET : references non retrouvees : " + ", ".join(stop)); continue
    for X in ("top", "bottom"):
        b, txt = select(pred, X + "_unfrozen", 1, LRS, "val_mcq_acc")
        print(f"  selection {X}_unfrozen r=1 : {txt}")
        if b is None:
            print("    ARRET : selection incomplete"); continue
        v, dup, dirs = cell(pred, X + "_unfrozen", 1, b, S_REP, "mcq_acc")
        if len(v) != 5 or dup:
            print(f"    ARRET : rapport incomplet ({len(v)} graines)"); continue
        gpus |= {gpu_of(dirs[s][0]) for s in S_REP}
        G = ref["G"][X]; m, lo, hi = pt([(v[s] - R[X][s]) * 100 for s in S_REP])
        verdict = ("le gel explique l'essentiel" if lo >= 0.7 * G else "partage (chevauche 0,7 G)") if m >= 0.7 * G else (("l'essentiel vient d'ailleurs" if hi <= 0.3 * G else "partage (chevauche 0,3 G)") if m <= 0.3 * G else "partage")
        print(f"    {X}_unfrozen r=1 a {b:g} : {st.mean(v.values()):.4f}" + ("  AU BORD" if b in (LRS[0], LRS[-1]) else "")
              + f" ; ecart au LoRA libre {(st.mean(v.values()) - st.mean(R['free'].values())) * 100:+.2f}")
        print(f"    U = {m:+.2f} [{lo:+.2f}, {hi:+.2f}] contre 0,7 G = {0.7 * G:.2f} (G = {G}) -> {verdict}")
    print(f"  modeles de carte : {sorted(gpus)}")
