"""Pre-registration audit, READ ONLY: was each protocol committed before the first run of its campaign?

    python scripts/audit_preenregistrement.py

For every grid in configs/grids/*.yaml:
  - the protocol(s) it cites (a PROTOCOL_*.md name in its header comments), and the time of their FIRST commit (git);
  - the time of the grid's first run: the oldest Slurm log in ~/lora-grid/<grid>/logs/ (else the oldest file of that directory);
  - the verdict: AVANT (committed before the first run), APRES (after), NON COMMITTE, or SANS PROTOCOLE CITE.
Protocols that no grid cites are listed at the end, with their first commit, for a manual mapping.
Nothing is modified.
"""
import datetime as dt
import glob
import os
import re
import subprocess

REPO = os.path.expanduser("~/repo")
GRID_DIR = os.path.expanduser("~/lora-grid")
os.chdir(REPO)


def first_commit(path):
    # no --follow: with it, git treats files of similar content as copies and returns an OLDER file's commit (found in testing)
    out = subprocess.run(["git", "log", "--diff-filter=A", "--format=%cI %h", "--", path], capture_output=True, text=True).stdout.split("\n")
    out = [l for l in out if l.strip()]
    if not out:
        return None, None
    iso, h = out[-1].split()
    return dt.datetime.fromisoformat(iso).replace(tzinfo=None), h


RUNS = os.path.expanduser("~/lora-runs")


def run_starts(grid):
    """Start of every run of the grid. The launcher writes <grid_dir>/configs/<run_id>.yaml for each run; the run's own
    directory ~/lora-runs/<run_id>/ is created when training starts, and its OLDEST file time is the start (no log bias)."""
    out = {}
    for c in glob.glob(os.path.join(GRID_DIR, grid, "configs", "*.yaml")):
        rid = os.path.basename(c)[:-5]
        d = os.path.join(RUNS, rid)
        files = [os.path.join(d, f) for f in os.listdir(d)] if os.path.isdir(d) else []
        if files:
            out[rid] = dt.datetime.fromtimestamp(min(os.path.getmtime(f) for f in files))
    return out


def first_run(grid):
    """Returns (first start, source, starts by run). Source 1: the run directories (exact start, per run).
    Source 2 (fallback, biased LATE): the oldest log time of the grid -- marked A VERIFIER."""
    starts = run_starts(grid)
    if starts:
        return min(starts.values()), "dossiers des runs", starts
    d = os.path.join(GRID_DIR, grid)
    files = glob.glob(os.path.join(d, "logs", "*")) or [f for f in glob.glob(os.path.join(d, "*")) if os.path.isfile(f)]
    if not files:
        return None, "aucun dossier de grille", {}
    return dt.datetime.fromtimestamp(min(os.path.getmtime(f) for f in files)), "journaux (borne haute)", {}


fmt = lambda t: t.strftime("%d/%m %H:%M") if t else "-"  # noqa: E731
rows, cited = [], set()
for g in sorted(glob.glob("configs/grids/*.yaml")):
    name = os.path.basename(g)[:-5]
    head = "".join(l for l in open(g).readlines()[:8] if l.lstrip().startswith("#"))
    protos = sorted(set(re.findall(r"PROTOCOL_[A-Za-z0-9_]+\.md", head)))
    cited.update(protos)
    run_t, src, starts = first_run(name)
    if not protos:
        rows.append((name, "-", None, None, run_t, "SANS PROTOCOLE CITE")); continue
    for p in protos:
        if not os.path.exists(p):
            rows.append((name, p, None, None, run_t, "PROTOCOLE ABSENT DU DEPOT")); continue
        c_t, h = first_commit(p)
        if c_t is None:
            v = "NON COMMITTE"
        elif run_t is None:
            v = "pas encore lance"
        elif starts:
            before = sorted(t for t in starts.values() if t < c_t)
            if not before:
                v = f"AVANT (verifie : {len(starts)} runs, tous demarres apres le commit)"
            else:
                v = (f"{len(before)}/{len(starts)} runs demarres AVANT le commit (le 1er le {fmt(before[0])}) : "
                     + ("references reutilisees ?" if len(before) < len(starts) else "TOUS -> protocole APRES le lancement"))
        else:
            v = ("AVANT ? A VERIFIER (date approximative, biaisee vers le tard)" if c_t < run_t
                 else "APRES (%s d'ecart)" % str(c_t - run_t).split(".")[0])
        rows.append((name, p, c_t, h, run_t, v + ("" if src == "dossiers des runs" else "  [source : " + src + "]")))

print(f"{'grille':26s} {'protocole cite':42s} {'1er commit':12s} {'hash':8s} {'1er run':12s} verdict")
for name, p, c_t, h, run_t, v in rows:
    print(f"{name:26s} {p:42s} {fmt(c_t):12s} {h or '-':8s} {fmt(run_t):12s} {v}")

print("\n=== protocoles cites par aucune grille (a rattacher a la main) ===")
for p in sorted(glob.glob("PROTOCOL_*.md")):
    if p not in cited:
        c_t, h = first_commit(p)
        print(f"  {p:48s} 1er commit {fmt(c_t)} {h or 'NON COMMITTE'}")

print("\n=== resume ===")
from collections import Counter
def cat(v):
    if v.startswith("AVANT (verifie"): return "AVANT, verifie"
    if v.startswith("AVANT ?"): return "A VERIFIER"
    if re.match(r"\d+/\d+ runs", v): return "TOUS APRES LE LANCEMENT" if "TOUS" in v else "runs anterieurs (references ?)"
    if v.startswith("APRES"): return "APRES"
    return {"SANS": "sans protocole cite", "pas": "grille jamais lancee sous ce nom", "NON": "NON COMMITTE"}.get(v.split(" ")[0], v.split(" ")[0])


cnt = Counter(cat(v) for *_, v in rows)
for k, n in cnt.most_common():
    print(f"  {k:36s} {n}")
print("\nRien n'a ete modifie. Debut d'un run : le plus ancien fichier de son dossier ~/lora-runs/<run_id>/ ; a defaut, journaux (A VERIFIER).")
