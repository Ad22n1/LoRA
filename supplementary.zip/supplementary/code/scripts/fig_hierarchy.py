"""The figure the title asks for: how much each of the three things moves the score, by rank.

  the learning rate  how far bottom's standing swings between the two common rates (2e-3, 1e-2):
                     its lead over the best other arm at 2e-3 plus its deficit to the best at 1e-2.
                     Measured at rank 2 only, and the figure says so.
  freezing           the budget-matched free reference minus the best frozen arm of that rank
                     (free r=1 against rank 2, free r=2 against rank 4), seeds 2-6.
  the position       the spread of the beta sweep, best minus worst position, seeds 2-8.

EVERYTHING IS COMPUTED FROM THE RUNS; every intermediate value is printed so that it can be checked
against the paper. Same populations as the tables: Llama-3.2-1B, format, seven modules, clipping at
1.0, no norm rescaling, 614 items, replicates averaged within a seed, salted random draws.

At rank 4 the best frozen arm depends on which of two honest rate selections is kept for `top` (2e-3
from its own sweep on 400 items, 5e-3 from the beta=0 sweep on 614): both are drawn, as a range.

    python scripts/fig_hierarchy.py paper/figures/hierarchy.png
"""
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import yaml

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
from lorasub.aggregate import collect  # noqa: E402
# No conclusions inside the images (24/09): every title is dropped, only panel letters such as "(a)"
# are kept where a caption refers to them. What a figure shows is said in its caption, where it can
# be qualified -- a claim written in the image cannot.
import re as _re
import matplotlib.axes as _max
import matplotlib.figure as _mfig
_set_title = _max.Axes.set_title
def _letter_only(self, label="", *a, **k):
    m = _re.match(r"\s*\(([a-z])\)", str(label))
    return _set_title(self, f"({m.group(1)})" if m else "", loc="left", fontsize=10)
_max.Axes.set_title = _letter_only
_mfig.Figure.suptitle = lambda self, *a, **k: None

MODEL = "meta-llama/Llama-3.2-1B"
SEL = (yaml.safe_load(open("configs/lr_selected.yaml")) or {})["selected"]
SEL4 = (yaml.safe_load(open("configs/lr_selected_r4.yaml")) or {})["selected"]
REPORTED_LR = {"bottom": 5e-3}          # the paper's reported rate for bottom (the rule picks 5e-3)
# the rates of the table's cells where lr_selected.yaml disagrees: random at rank 4 is reported at
# 1e-2 (the salted sweep's optimum); lr_selected says 5e-3 because it mixed salted and unsalted draws
TABLE_LR = {("bottom", 2): 5e-3, ("random", 4): 1e-2}

d = collect(os.path.expanduser("~/lora-runs"))
base = d[(d.task == "format") & (d.model.astype(str) == MODEL) & (d.n_modules == 7) & (d.max_grad_norm == 1.0)
         & d.update_norm_target.isna() & (d.format_n == 614)]
base = base[~base["mode"].isin(["random", "random_ortho"]) | (base.subspace_salted == True)]


def cell(mode, rank, lr, seeds, band_frac=None):
    x = base[(base["mode"] == mode) & (base["rank"] == rank) & ((base.lr - lr).abs() < 1e-12) & base.seed.isin(seeds)]
    if band_frac is not None:
        x = x[(x.band_frac - band_frac).abs() < 1e-9]
    per = x.groupby("seed").format_parsed.mean()
    se = float(per.std() / per.size ** 0.5) if per.size > 1 else float("nan")
    return (float(per.mean()), int(per.size), se, per) if per.size else (float("nan"), 0, float("nan"), per)


def boot(stat, arms, B=20000, seed=0):
    """Paired bootstrap over the seeds, the same resample for every arm, the statistic recomputed at
    each draw so that a maximum over noisy arms is not treated as if it were a fixed arm. This is the
    method of Table 4; the bars used to combine standard errors in quadrature, which ignores pairing."""
    import random
    idx = sorted(set.intersection(*[set(a.index) for a in arms.values()]))
    if len(idx) < 2:
        return float("nan")
    rng = random.Random(seed)
    reps = []
    for _ in range(B):
        pick = [idx[rng.randrange(len(idx))] for _ in idx]
        reps.append(stat({k: [a[i] for i in pick] for k, a in arms.items()}))
    m = sum(reps) / len(reps)
    return (sum((r - m) ** 2 for r in reps) / (len(reps) - 1)) ** 0.5


def arm_lr(mode, rank):
    """The rate of the table's cell. lr_selected.yaml disagrees for random at rank 4 (it mixed salted
    and unsalted draws): when its rate has no five-seed cell, take the one rate that has."""
    if (mode, rank) in TABLE_LR:
        return TABLE_LR[(mode, rank)]
    if mode == "random_ortho" and rank != 2:
        return None                      # run at rank 2 only in the paper; other cells are other experiments
    lr = SEL.get(f"{MODEL}|format|{mode}|{rank}")
    x = base[(base["mode"] == mode) & (base["rank"] == rank) & base.seed.isin(range(2, 7))]
    full = sorted(float(l) for l, g in x.groupby("lr") if g.seed.nunique() == 5)
    if lr is not None and any(abs(lr - f) < 1e-12 for f in full):
        return lr
    return full[0] if len(full) == 1 else lr


S26, S28 = range(2, 7), range(2, 9)
out, err = {}, {}
for r, tab in ((2, SEL), (4, SEL4)):
    # the position and the freeze bars are measured on the SAME seeds, 2-6, where the free reference
    # exists, so the two are paired (an outside reader: at rank 2 they are 9.0 and 9.1 on those seeds)
    pos = {bf: cell("band", r, tab[f"{MODEL}|format|band|{r}|b{bf:g}"], S26, bf)
           for bf in (0.0, 0.25, 0.5, 0.75, 1.0) if f"{MODEL}|format|band|{r}|b{bf:g}" in tab}
    means = {k: v[0] for k, v in pos.items() if v[1] == 5}
    out[("position", r)] = (max(means.values()) - min(means.values())) * 100 if len(means) == 5 else float("nan")
    hi_k, lo_k = max(means, key=means.get), min(means, key=means.get)
    err[("position", r)] = boot(lambda a: (max(sum(v) / len(v) for v in a.values())
                                           - min(sum(v) / len(v) for v in a.values())) * 100,
                                {k: v[3] for k, v in pos.items() if v[1] == 5})
    print(f"\n  rank {r} beta sweep, seeds 2-6: " + "  ".join(f"{k:g}:{v[0]:.4f}(n={v[1]})" for k, v in pos.items()))
    print(f"    -> position spread {out[('position', r)]:.1f} pt")

    frozen = {m: cell(m, r, arm_lr(m, r), S26) for m in ("top", "bottom", "random", "random_ortho") if arm_lr(m, r)}
    frozen = {m: v for m, v in frozen.items() if v[1] == 5}
    # every frozen arm of the rank counts, the beta sweep included: freezing is measured against the
    # best of them, whichever it is. Leaving the sweep out made freezing look costlier than choosing
    # at rank 2, where beta=0.75 is the best frozen arm.
    for bf, v in pos.items():
        if v[1] == 5:
            frozen[f"beta={bf:g}"] = v
    ref = cell("free", r // 2, SEL.get(f"{MODEL}|format|free|{r // 2}"), S26)
    print(f"  rank {r} frozen arms, seeds 2-6: " + "  ".join(f"{m}:{v[0]:.4f}(n={v[1]})" for m, v in frozen.items()))
    print(f"  free r={r // 2} reference: {ref[0]:.4f} (n={ref[1]})")
    best = max(frozen, key=lambda m: frozen[m][0])
    out[("freeze", r)] = ((ref[0] - frozen[best][0]) * 100,) * 2
    print(f"    best frozen arm: {best}")
    err[("freeze", r)] = boot(lambda a: (sum(a["__free__"]) / len(a["__free__"])
                                         - max(sum(v) / len(v) for k, v in a.items() if k != "__free__")) * 100,
                              {**{m: v[3] for m, v in frozen.items()}, "__free__": ref[3]})
    print(f"    -> freeze {out[('freeze', r)][0]:.1f} to {out[('freeze', r)][1]:.1f} pt")

# the rate effect, per rank, as PROTOCOL_rate_r4_qwen.md fixed it: bottom's lead over the best other
# arm at 2e-3 plus its deficit to the best other arm at 1e-2. Drawn only when every cell has its five
# seeds; otherwise the bar says "not measured".
# every arm measured at the rate counts: random at 2e-3 at rank 2 was completed on 21/09 (0.5443), and
# at rank 4 it was already counted, so leaving it out at rank 2 made bottom's lead 3.0 instead of 2.15
RATE_ARMS = {2: (("top", "random", "random_ortho"), ("top", "random", "random_ortho")), 4: (("top", "random"), ("top", "random"))}
for r, (o_lo, o_hi) in RATE_ARMS.items():
    loc = {m: cell(m, r, 2e-3, S26) for m in ("bottom",) + o_lo}
    hic = {m: cell(m, r, 1e-2, S26) for m in ("bottom",) + o_hi}
    if any(v[1] != 5 for v in list(loc.values()) + list(hic.values())):
        print(f"\n  rate, rank {r}: incomplete cells, not drawn " + str({k: v[1] for k, v in {**loc, **hic}.items()}))
        continue
    lo = {m: v[0] for m, v in loc.items()}; hi = {m: v[0] for m, v in hic.items()}
    lb = max(o_lo, key=lo.get); hb = max(o_hi, key=hi.get)
    lead = (lo["bottom"] - lo[lb]) * 100; last = (hi[hb] - hi["bottom"]) * 100
    out[("rate", r)] = lead + last
    err[("rate", r)] = boot(lambda a: ((sum(a["lo|bottom"]) / len(a["lo|bottom"])
                                        - max(sum(v) / len(v) for k, v in a.items() if k.startswith("lo|") and k != "lo|bottom"))
                                       + (max(sum(v) / len(v) for k, v in a.items() if k.startswith("hi|") and k != "hi|bottom")
                                          - sum(a["hi|bottom"]) / len(a["hi|bottom"]))) * 100,
                            {**{f"lo|{m}": v[3] for m, v in loc.items()}, **{f"hi|{m}": v[3] for m, v in hic.items()}})
    print(f"\n  rate, rank {r}: bottom leads by {lead:.1f} at 2e-3 and is last by {last:.1f} at 1e-2 -> swing {lead + last:.1f} pt")

fig, ax = plt.subplots(figsize=(7.0, 3.9))
C = {"rate": "#dd8452", "freeze": "#c44e52", "position": "#4c72b0"}
X = {2: 0.0, 4: 1.0}
W = 0.25
for i, (k, lab) in enumerate((("rate", "swing between two common rates"), ("freeze", "gap to a budget-matched free LoRA"), ("position", "spread across positions"))):
    for r in (2, 4):
        x = X[r] + (i - 1) * W
        v = out.get((k, r))
        if v is None:
            ax.text(x, 0.6, "not\nmeasured", ha="center", va="bottom", fontsize=7, color="0.55")
            continue
        if isinstance(v, tuple):
            ax.bar(x, max(v), W * 0.9, color=C[k], alpha=0.35, label=None)
            ax.bar(x, min(v), W * 0.9, color=C[k], label=lab if r == 2 else None)
            ax.errorbar(x, min(v), yerr=err.get((k, r), 0), fmt="none", ecolor="0.25", lw=1, capsize=3)
            ax.text(x, max(v) + 0.4 + err.get((k, r), 0), f"{min(v):.1f}–{max(v):.1f}" if abs(v[0] - v[1]) > 0.05 else f"{v[0]:.1f}",
                    ha="center", fontsize=8)
        else:
            ax.bar(x, v, W * 0.9, color=C[k], label=lab if r == 2 else None)
            ax.errorbar(x, v, yerr=err.get((k, r), 0), fmt="none", ecolor="0.25", lw=1, capsize=3)
            # the rate bars carry two decimals, as the text does (22.35 would otherwise print as 22.3)
            ax.text(x, v + 0.4 + err.get((k, r), 0), f"{v:.1f}", ha="center", fontsize=8)
ax.set_xticks([X[2], X[4]], ["rank 2", "rank 4"])
ax.set_ylabel("valid-format accuracy (points)")
ax.set_title("Three contrasts on Llama-3.2-1B, in points\n(different quantities on one scale, not a decomposition)", fontsize=10)
# below the axes, on one line: inside, it sat on the rank-4 bar and its interval
ax.legend(frameon=False, fontsize=8.5, loc="upper center", bbox_to_anchor=(0.5, -0.1), ncol=3)
for sp in ("top", "right"):
    ax.spines[sp].set_visible(False)
ax.grid(axis="y", color="0.93", lw=0.7)
ax.set_axisbelow(True)
fig.tight_layout(rect=(0, 0.06, 1, 1))
dst = sys.argv[1] if len(sys.argv) > 1 else "paper/figures/hierarchy.png"
os.makedirs(os.path.dirname(dst) or ".", exist_ok=True)
fig.savefig(dst, dpi=200, bbox_inches="tight", pad_inches=0.08)
print("  paired bootstrap SE (pt): " + "  ".join(f"{k[0]} r={k[1]}: {v:.2f}" for k, v in err.items()))
print(f"\n  written -> {dst}")
