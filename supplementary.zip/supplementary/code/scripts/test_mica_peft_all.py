"""Test d'equivalence numerique etendu, sans entrainement (post hoc, descriptif) : notre bras `bottom`, construit depuis le cache SVD fp16
des runs, contre PEFT 0.21.0 init_lora_weights="mica" (SVD fp32), sur TOUS les modules adaptes de Qwen2.5-1.5B (196) et de Llama-3.2-1B
(112), aux rangs 2 et 16. Prolonge le test du commit <commit>. Aucun resultat publie n'est modifie.

    python scripts/test_mica_peft_all.py            # ecrit VERIF_mica_peft_all.md et test_mica_peft_all.json

PEFT est importe depuis un dossier a part (PEFT_DIR), place APRES l'environnement des runs, qui n'est pas modifie.
"""
import json
import os
import statistics as st
import sys
import time

import torch
import yaml
from torch import nn

REPO = os.path.expanduser("~/repo")
sys.path.insert(0, f"{REPO}/src")
sys.path.append(os.environ.get("PEFT_DIR", f"/tmp/lora-{os.environ.get('USER', '')}/peft021"))
import peft  # noqa: E402
from peft import LoraConfig, inject_adapter_in_model  # noqa: E402

from lorasub.lora import LoRALinear  # noqa: E402
from lorasub.modeling import load_model  # noqa: E402
from lorasub.spectral import load_svd  # noqa: E402

if peft.__version__ != "0.21.0":
    sys.exit(f"ARRET : PEFT {peft.__version__} importe, 0.21.0 attendu")
MODELS = [m for m in os.environ.get("MICA_MODELS", "Qwen/Qwen2.5-1.5B,meta-llama/Llama-3.2-1B").split(",") if m]
RANKS, RMAX, FLAG = (2, 16), 16, 1e-2
TYPES = ("q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj")
SVDROOT = f"/tmp/lora-{os.environ.get('USER', '')}/svd"
ty = lambda n: n.rsplit(".", 1)[-1]  # noqa: E731
layer = lambda n: int(n.split(".layers.")[1].split(".")[0])  # noqa: E731


class Box(nn.Module):
    def __init__(self, lin):
        super().__init__(); self.lin = lin


def run_cfg(model_id):
    for d in sorted(os.listdir(os.path.expanduser("~/lora-runs"))):
        p = os.path.expanduser(f"~/lora-runs/{d}/config.yaml")
        if os.path.exists(p):
            c = yaml.safe_load(open(p)) or {}
            if c.get("model") == model_id and c.get("mode") == "bottom":
                return c
    sys.exit(f"ARRET : aucun run `bottom` de {model_id} pour lire la precision de chargement des runs")


rows, t0 = [], time.time()
for model_id in MODELS:
    c = run_cfg(model_id)
    model = load_model(model_id, c.get("dtype", "bfloat16"), c.get("attn_implementation", "eager"), device="cpu")
    names = [n for n, m in model.named_modules() if isinstance(m, nn.Linear) and ty(n) in TYPES and ".layers." in n]
    print(f"  {model_id} : charge en {c.get('dtype', 'bfloat16')} comme les runs ; {len(names)} modules adaptes", flush=True)
    for i, name in enumerate(names):
        lin = model.get_submodule(name)
        base = nn.Linear(lin.in_features, lin.out_features, bias=False)
        with torch.no_grad():
            base.weight.copy_(lin.weight.float())
        box = Box(base)                                   # PEFT 0.21.0, init "mica", au rang 16 : B = 16 dernieres colonnes de sa SVD fp32
        inject_adapter_in_model(LoraConfig(r=RMAX, lora_alpha=float(RMAX), lora_dropout=0.0, init_lora_weights="mica", target_modules=["lin"]), box)
        Bp16 = box.lin.lora_B["default"].weight.detach().double()
        trainable = sorted(tuple(p.shape) for p in box.lin.parameters() if p.requires_grad)
        S = torch.linalg.svdvals(base.weight.detach().float()).double()       # valeurs singulieres fp32, decroissantes
        m = S.numel(); cache = load_svd(SVDROOT, model_id, name)
        g = torch.Generator().manual_seed(1000 + i)
        x = torch.randn(2, 8, lin.in_features, generator=g, dtype=torch.float64)
        w = torch.randn(2, 8, lin.out_features, generator=g, dtype=torch.float64)
        M = torch.einsum("bto,bti->oi", w, x)             # dL/dA = (alpha/r) B^T M pour L = sum(w * y), alpha/r = 1
        for r in RANKS:
            Bp = Bp16[:, RMAX - r:]                       # le B de PEFT au rang r : les r dernieres colonnes de la meme SVD
            Bc = LoRALinear(nn.Linear(lin.in_features, lin.out_features, bias=False), r, "bottom", alpha=float(r), svd=cache).B.detach().double()
            s = torch.sign((Bc * Bp).sum(0)); s[s == 0] = 1; Bca = Bc * s
            # sous-espace : base orthonormale de l'espace engendre par le B du cache (arrondi en fp16, il n'est orthonormal qu'a ~1e-4 pres),
            # puis sin(theta_max) = || (I - Bp Bp^T) Q ||_2, forme stable pres de zero (sqrt(1 - cos^2) amplifierait une erreur de norme)
            Q = torch.linalg.qr(Bca)[0]; Q = Q * torch.sign(torch.diagonal(Q.T @ Bca))
            sin_max = float(torch.linalg.matrix_norm(Q - Bp @ (Bp.T @ Q), ord=2))
            A0 = torch.randn(r, lin.in_features, generator=g, dtype=torch.float64) * 0.02
            yp = x @ A0.T @ Bp.T; yc = x @ A0.T @ Bca.T
            gp = Bp.T @ M; gc = Bca.T @ M
            band = list(range(m - r, m))
            gap_b = float((S[m - r - 1] - S[m - r]) / S[m - r]) if m - r - 1 >= 0 else float("nan")
            gap_in = min(float((S[k] - S[k + 1]) / S[k + 1]) for k in band[:-1]) if r > 1 else float("nan")
            rows.append({"modele": model_id.split("/")[-1], "r": r, "module": name, "type": ty(name), "couche": layer(name),
                         "B_max": float((Bca - Bp).abs().max()), "sin_max": sin_max, "ecart_orthonormalite_cache": float((Bc.T @ Bc - torch.eye(r, dtype=Bc.dtype)).abs().max()),
                         "sorties_rel": float((yc - yp).abs().max() / yp.abs().max()), "gradients_rel": float((gc - gp).abs().max() / gp.abs().max()),
                         "signes_retournes": int((s < 0).sum()), "sigma_min_bande": float(S[m - r]), "sigma_voisin": float(S[m - r - 1]),
                         "ecart_frontiere_rel": gap_b, "ecart_interne_min_rel": gap_in,
                         "parametres_peft_ok": trainable == [(RMAX, lin.in_features)] and not box.lin.lora_B["default"].weight.requires_grad})
        if (i + 1) % 28 == 0:
            print(f"    ... {i + 1} / {len(names)} modules ({time.time() - t0:.0f} s)", flush=True)
    del model

json.dump(rows, open(f"{REPO}/test_mica_peft_all.json", "w"), indent=0)
med = lambda v: st.median(v) if v else float("nan")  # noqa: E731
L = ["# Équivalence numérique étendue : bras `bottom` (cache SVD fp16 des runs) contre PEFT 0.21.0 `init_lora_weights=\"mica\"` (SVD fp32)", "",
     "Statut : **post hoc, descriptif** ; sans entraînement ; aucun résultat publié modifié. Prolonge le test du commit `<commit>`.",
     "Tous les modules adaptés : " + ", ".join(f"{m.split('/')[-1]} ({sum(1 for x in rows if x['modele'] == m.split('/')[-1] and x['r'] == 2)})" for m in MODELS) + " ;"
     " rangs 2 et 16 ; α/r = 1 ; poids chargés dans la précision des runs, copiés en fp32. Valeurs par module : `test_mica_peft_all.json`.", "",
     "## Définitions", "",
     "- **B de PEFT** : `mica_init` de PEFT 0.21.0, appelé une fois par module au rang 16 (SVD fp32 sur le processeur) ; le B de rang 2 en est",
     "  les deux dernières colonnes, ce qui est exactement ce que `mica_init` produit au rang 2 (même SVD, mêmes colonnes).",
     "- **B du cache** : notre bras `bottom` construit comme dans les runs, depuis le cache SVD stocké en fp16 (colonnes m − r à m − 1 de U).",
     "- **Alignement des signes** : chaque colonne du B du cache est multipliée par ±1 pour que son produit scalaire avec la colonne",
     "  correspondante du B de PEFT soit positif ou nul. Les vecteurs singuliers ne sont définis qu'au signe près.",
     "- **Écart maximal sur B** : max_ij |B_cache,aligné − B_PEFT|_ij.",
     "- **Distance entre sous-espaces** : le sinus du plus grand angle principal θ_max entre les espaces engendrés par les deux B, calculé",
     "  comme sin θ_max = ‖(I − B_PEFT B_PEFTᵀ) Q_cache‖₂, où Q_cache est une base orthonormale (QR) de l'espace engendré par le B du cache.",
     "  Le B du cache, arrondi en fp16, n'est orthonormal qu'à ~10⁻⁴ près : on l'orthonormalise avant de mesurer l'angle, et l'on n'utilise",
     "  pas √(1 − cos²θ), qui transformerait une erreur de norme de 10⁻⁴ en un sinus apparent de 1,4·10⁻². Elle ne dépend ni des signes ni",
     "  d'une rotation à l'intérieur de la bande ; elle vaut 0 pour deux sous-espaces identiques et 1 si l'un contient une direction orthogonale à",
     "  l'autre. Comme le bras gèle B et entraîne A, seule cette distance change ce que le bras peut représenter.",
     "- **Écart relatif des sorties** : pour un même lot aléatoire x (2 × 8 positions) et une même matrice A non nulle (A_cache = signes ⊙ A_PEFT),",
     "  max |y_cache − y_PEFT| / max |y_PEFT|, où y = x Aᵀ Bᵀ est l'apport de l'adaptateur (α/r = 1).",
     "- **Écart relatif des gradients sur A**, à A = 0, pour la perte L = Σ w ⊙ y avec w aléatoire fixe : ∂L/∂A = Bᵀ M, M = Σ_positions wᵀ x ;",
     "  max |(∂L/∂A)_cache,aligné − (∂L/∂A)_PEFT| / max |(∂L/∂A)_PEFT|.",
     "- **Écarts de valeurs singulières** (σ décroissantes, en fp32, indices 0 à m − 1 ; la bande mineure de rang r est m − r … m − 1) :",
     "  écart à la frontière (σ_{m−r−1} − σ_{m−r}) / σ_{m−r} ; plus petit écart interne min_k (σ_k − σ_{k+1}) / σ_{k+1} sur la bande.",
     f"- **Signalement** : un module dont la distance entre sous-espaces dépasse {FLAG:g} ; le cache y sélectionnerait un autre sous-espace,",
     "  et non seulement un sous-espace moins précis.",
     "- Note : l'écart sur B, les sorties et les gradients se comparent colonne par colonne ; ils grandissent si les valeurs singulières",
     "  internes à la bande sont presque égales (rotation dans la bande), alors que la distance entre sous-espaces, elle, n'en dépend pas.", "",
     "## Résultats par modèle, rang et type de module (médiane / maximum sur les couches)", "",
     "| modèle | r | type | écart max sur B | distance sin θ_max | sorties (relatif) | gradients (relatif) | signes retournés |",
     "|---|---|---|---|---|---|---|---|"]
for mdl in [m.split("/")[-1] for m in MODELS]:
    for r in RANKS:
        for t in TYPES:
            R = [x for x in rows if x["modele"] == mdl and x["r"] == r and x["type"] == t]
            if not R:
                continue
            f = lambda k: f"{med([x[k] for x in R]):.1e} / {max(x[k] for x in R):.1e}"  # noqa: E731
            L.append(f"| {mdl} | {r} | {t.replace('_proj', '')} | {f('B_max')} | {f('sin_max')} | {f('sorties_rel')} | {f('gradients_rel')} | "
                     f"{sum(x['signes_retournes'] for x in R)} / {r * len(R)} |")
flag = [x for x in rows if x["sin_max"] > FLAG]
L += ["", f"## Modules signalés (distance entre sous-espaces > {FLAG:g}) : {len(flag)} sur {len(rows)} comparaisons", ""]
if flag:
    L += ["| modèle | r | module | sin θ_max | écart à la frontière | σ_{m−r} | σ_{m−r−1} |", "|---|---|---|---|---|---|---|"]
    L += [f"| {x['modele']} | {x['r']} | {x['module']} | {x['sin_max']:.2e} | {x['ecart_frontiere_rel']:.2e} | {x['sigma_min_bande']:.4e} | {x['sigma_voisin']:.4e} |"
          for x in sorted(flag, key=lambda x: -x["sin_max"])]
else:
    L += ["Aucun : à tous les modules et aux deux rangs, le cache sélectionne le même sous-espace que PEFT."]
L += ["", "## Llama-3.2-1B, modules q et o : écarts de valeurs singulières à la bande mineure, couche par couche", "",
      "| type | couche | r = 2 : écart frontière | r = 2 : écart interne | r = 2 : sin θ_max | r = 16 : écart frontière | r = 16 : écart interne min | r = 16 : sin θ_max |",
      "|---|---|---|---|---|---|---|---|"]
for t in ("q_proj", "o_proj"):
    for Lr in sorted({x["couche"] for x in rows if x["modele"] == "Llama-3.2-1B" and x["type"] == t}):
        a2 = next((x for x in rows if x["modele"] == "Llama-3.2-1B" and x["type"] == t and x["couche"] == Lr and x["r"] == 2), None)
        a16 = next((x for x in rows if x["modele"] == "Llama-3.2-1B" and x["type"] == t and x["couche"] == Lr and x["r"] == 16), None)
        if a2 and a16:
            L.append(f"| {t.replace('_proj', '')} | {Lr} | {a2['ecart_frontiere_rel']:.2e} | {a2['ecart_interne_min_rel']:.2e} | {a2['sin_max']:.1e} | "
                     f"{a16['ecart_frontiere_rel']:.2e} | {a16['ecart_interne_min_rel']:.2e} | {a16['sin_max']:.1e} |")
ok_peft = all(x["parametres_peft_ok"] for x in rows)
orth = max(x["ecart_orthonormalite_cache"] for x in rows)
L += ["", f"- Paramètres entraînables de PEFT : A seul, B gelé, à tous les modules : {'oui' if ok_peft else 'NON'}.",
      f"- Orthonormalité du B du cache (arrondi fp16) : max |BᵀB − I| = {orth:.1e} sur tous les modules.",
      f"- Durée : {time.time() - t0:.0f} s sur le processeur."]
open(f"{REPO}/VERIF_mica_peft_all.md", "w").write("\n".join(L) + "\n")
print("\n".join(L))
