"""PROTOCOL_format_qwen_rank.md: the format task on Qwen2.5-1.5B at ranks 2 and 16 -- the model or the task? No PARTITION.

    python scripts/read_fmtq.py 2>&1 | grep -vE "FutureWarning|pd.concat"

Selection on seeds 20-21 (val_format_parsed) per arm; reported seeds 22-26 at that rate only. Freezing = free - best frozen arm,
choosing = spread among top, bottom and random_ortho; freezing - choosing with a paired bootstrap 95 % interval (20 000 draws),
as for ARC. Every cell prints its seed count and its duplicates; nothing is concluded on incomplete data.
"""
import glob
import json
import os
import random
import statistics as st

import yaml

R = os.path.expanduser("~/lora-runs")
LLAMA, QWEN = "meta-llama/Llama-3.2-1B", "Qwen/Qwen2.5-1.5B"
S_SEL, S_REP = (20, 21), [22, 23, 24, 25, 26]      # fresh seeds (PROTOCOL_format_qwen_rank.md)


def tokens(c):
    t = c.get("target_tokens")
    return t.get(c.get("task")) if isinstance(t, dict) else t


RUNS = []
for p in glob.glob(R + "/*/config.yaml"):
    c = yaml.safe_load(open(p)) or {}
    d = os.path.dirname(p)
    try:
        if not open(d + "/status").read().startswith("DONE"):
            continue
        RUNS.append((c, json.load(open(d + "/metrics.json")), d))
    except OSError:
        continue


def clipped(c):
    """Gradient clipping at 1.0, the paper's setting. A noclip grid reran the same cells without clipping (collect()'s
    docstring); mixing both put two runs per seed in the frozen cells and moved G from 12.41 to 13.53 (26/09)."""
    v = c.get("max_grad_norm", 1.0)
    return v is not None and float(v) == 1.0


def seven(c):
    tm = c.get("target_modules")
    return tm is None or len(tm) == 7


def cell(pred, mode, rank, lr, seeds, key):
    """{seed: value}; several runs of one seed are averaged and flagged."""
    by = {}
    for c, m, d in RUNS:
        if (pred(c) and clipped(c) and c.get("mode") == mode and c.get("rank") == rank and abs(float(c.get("lr") or 0) - lr) < 1e-12
                and c.get("seed") in seeds and key in m and c.get("update_norm_target") in (None, "")):
            by.setdefault(c["seed"], []).append((m[key], d))
    dup = {s: len(v) for s, v in by.items() if len(v) > 1}
    if dup:   # say what separates the duplicates, so that the next filter is written from evidence
        s0 = sorted(dup)[0]; cfgs = [yaml.safe_load(open(d + "/config.yaml")) or {} for _, d in by[s0]]
        keys = sorted(k for k in set().union(*cfgs) if k not in ("run_id", "out_dir") and len({str(c_.get(k)) for c_ in cfgs}) > 1)
        dup["differ"] = {k: [c_.get(k) for c_ in cfgs] for k in keys} or "configs identiques"
    return {s: st.mean(x for x, _ in v) for s, v in by.items()}, dup, {s: [d for _, d in v] for s, v in by.items()}


def paired(a, b):
    k = sorted(set(a) & set(b)); dd = [(a[s] - b[s]) * 100 for s in k]
    if len(dd) < 2: return float("nan"), float("nan"), len(dd)
    sd = st.stdev(dd)
    return st.mean(dd), (st.mean(dd) / (sd / len(dd) ** 0.5) if sd > 0 else float("inf")), len(dd)


def show(lab, v, dup=None):
    extra = f"  DOUBLONS {dup}" if dup else ""
    print(f"    {lab:36s} " + (f"{st.mean(v.values()):.4f}  ({len(v)} graines){extra}" if v else "AUCUN RUN"))


def select(pred, mode, rank, lrs, key):
    full = {}
    for lr in lrs:
        v, _, _ = cell(pred, mode, rank, lr, S_SEL, key)
        if len(v) == 2: full[lr] = st.mean(v.values())
    if len(full) < len(lrs):
        return None, f"INCOMPLET ({len(full)}/{len(lrs)} taux avec leurs deux graines)"
    best = max(full, key=full.get)
    edge = best in (lrs[0], lrs[-1])
    return best, "  ".join(f"{lr:g}:{full[lr]:.3f}" for lr in lrs) + f"  -> {best:g}" + ("  AU BORD" if edge else "")


fq = lambda c: c.get("task") == "format" and str(c.get("model")) == QWEN and seven(c)  # noqa: E731


def read_fmt(rk, rk_free, lrs, issues):
    print(f"\n==================== tache de format, Qwen2.5-1.5B, rang {rk} (free au rang {rk_free}) ====================")
    sel, own = {}, {}
    for mode, rank in (("top", rk), ("bottom", rk), ("random_ortho", rk), ("free", rk_free)):
        best, txt = select(fq, mode, rank, lrs, "val_format_parsed"); print(f"    selection {mode:13s} : {txt}")
        if best is not None:
            sel[mode] = best; own[mode], dup, _ = cell(fq, mode, rank, best, S_REP, "format_parsed"); show(f"{mode} a {best:g}", own[mode], dup)
    fz = {k: v for k, v in own.items() if k != "free"}
    if len(own) == 4 and all(len(v) == 5 for v in own.values()):
        S = sorted(set(own["free"]).intersection(*[set(v) for v in fz.values()]))

        def fc(ix):
            m = {k: st.mean(v[s] for s in ix) for k, v in fz.items()}; ff = st.mean(own["free"][s] for s in ix)
            return (ff - max(m.values())) * 100, (max(m.values()) - min(m.values())) * 100
        g, c = fc(S); rng = random.Random(0); B = sorted(a - b for a, b in (fc([S[rng.randrange(len(S))] for _ in S]) for _ in range(20000)))
        lo, hi = B[500], B[19499]
        print(f"  PRINCIPAL  geler {g:.2f}, choisir {c:.2f} -> geler - choisir {g - c:+.2f}  IC95 [{lo:+.2f}, {hi:+.2f}] -> "
              + (issues["neg"] if hi < 0 else (issues["pos"] if lo > 0 else issues["zero"])))
        lower = [k for k in ("top", "random_ortho") if sel["bottom"] < sel[k]]
        print(f"  rapporte : bottom ({sel['bottom']:g}) plus bas que {lower or 'aucun'} (top {sel['top']:g}, random_ortho {sel['random_ortho']:g})")
        spec = max(("top", "bottom"), key=lambda k: st.mean(fz[k].values()))
        d, t_, n = paired(fz[spec], fz["random_ortho"]); print(f"  rapporte : meilleur bras spectral ({spec}) - random_ortho = {d:+.2f} pt (t = {t_:+.2f}, {n} graines)")
        return g - c, lo, hi
    print("  PRINCIPAL non calculable : cellules incompletes")
    return None


r2 = read_fmt(2, 1, [1e-4, 5e-4, 1e-3, 2e-3, 5e-3, 1e-2, 2e-2],
              {"pos": "geler coute plus au rang 2 : le resultat de Llama tient sur Qwen pour la meme tache",
               "zero": "non etabli au rang 2", "neg": "choisir coute plus au rang 2"})
r16 = read_fmt(16, 7, [1e-4, 2e-4, 5e-4, 1e-3, 2e-3, 5e-3, 1e-2],
               {"neg": "choisir coute plus au rang 16, comme sur ARC : le renversement suit le MODELE",
                "zero": "l'ordre s'efface au rang 16, comme sur la tache de format avec Llama : il suit la TACHE",
                "pos": "geler coute encore plus au rang 16, sur ce modele et cette tache"})
print("\n  rappel : format/Llama -> geler > choisir aux rangs 2 a 8, efface au rang 16 ; ARC/Qwen -> non etabli au rang 2, inverse aux rangs 16 et 32")
