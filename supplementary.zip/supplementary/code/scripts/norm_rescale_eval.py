"""Point 6, position or norm: evaluate ONE trained run at its own norm, then rescaled to each target norm.

    python scripts/norm_rescale_eval.py --config <config.yaml of the grid listing>     # inside the eval array
    python scripts/norm_rescale_eval.py --run ~/lora-runs/<run_id>                       # by hand, to test

Each (arm, seed) is trained ONCE, with no target (grids norm6_train_*). This script then reloads the run's
final factors and evaluates the same learned update:
  1. at its own norm, without rescaling. This MUST reproduce the score the run recorded at the end of
     training (tolerance: 3 items on the 614 test items, 3 on the 500 validation items). If it does not,
     the reload is wrong and nothing else is measured: the script stops with exit code 3.
  2. rescaled to each target mean ||dW||_F (1.5 to 4.5), with the same `rescale_update_` as training uses.
One CSV per run, in ~/lora-analysis/norm_control/<run_id>.csv, so array tasks never write the same file.
What this compares, and what it does not: the directions each arm learned, at equal amplitude; it does
not test a training run constrained to a norm.
"""
from __future__ import annotations

import argparse
import csv
import glob
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import torch  # noqa: E402
import yaml  # noqa: E402

from lorasub.eval import run_all  # noqa: E402
from lorasub.lora import inject_lora, load_factors_into, rescale_update_, update_norms  # noqa: E402
from lorasub.modeling import load_model, load_tokenizer  # noqa: E402

TARGETS = [1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5]
TOL_TEST, TOL_VAL = 3 / 614, 3 / 500
KEYS = ("mode", "rank", "lr", "seed", "task", "model", "update_norm_target", "subspace_salted")


def last_factors(d: Path):
    """Final factors, never the initialisation (A = 0 would evaluate the base model)."""
    best, key_best = None, None
    for f in d.glob("factors_*.safetensors"):
        stem = f.stem[len("factors_"):]
        if stem in ("0", "rescaled"):
            continue
        key = (1, 0) if stem == "end" else ((0, int(stem)) if stem.isdigit() else None)
        if key is not None and (key_best is None or key > key_best):
            best, key_best = f, key
    return best


def tokens(c: dict):
    """The token budget of the run's task. Run configs store it resolved (600000); grid configs may keep the
    per-task dict ({facts: ..., format: ...}). Compare the two forms as one number."""
    t = c.get("target_tokens")
    return t.get(c.get("task")) if isinstance(t, dict) else t


def find_run(cfg_path: str) -> Path:
    """The run directory whose config matches the grid config on every identifying field."""
    want = yaml.safe_load(open(cfg_path)) or {}
    hits = []
    for p in glob.glob(os.path.expanduser("~/lora-runs/*/config.yaml")):
        c = yaml.safe_load(open(p)) or {}
        if all(str(c.get(k)) == str(want.get(k)) for k in KEYS) and tokens(c) == tokens(want):
            hits.append(Path(p).parent)
    if len(hits) != 1:
        sys.exit(f"  {len(hits)} runs match {cfg_path}; expected exactly one")
    return hits[0]


def evaluate(model, tok, c):
    kw = dict(max_new_tokens=int(c.get("max_new_tokens") or 128), do_forgetting=False)
    data_dir = os.path.expandvars(os.path.expanduser(str(c["data_dir"])))
    limit = int(c.get("eval_limit") or 1000)
    m = run_all(model, tok, c["task"], data_dir, limit=limit, split="test", **kw)
    v = run_all(model, tok, c["task"], data_dir, limit=min(limit, 500), split="val", **kw)
    return m, v


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config"); ap.add_argument("--run")
    ap.add_argument("--svd_cache", default=os.path.expanduser("~/lora-shared/svd"))
    a = ap.parse_args()
    d = Path(os.path.expanduser(a.run)) if a.run else find_run(a.config)
    c = yaml.safe_load(open(d / "config.yaml"))
    if not open(d / "status").read().startswith("DONE"):
        sys.exit(f"  {d.name} is not DONE")
    rec = json.load(open(d / "metrics.json"))
    f = last_factors(d)
    if f is None:
        sys.exit(f"  {d.name}: no trained factors (only the initialisation?)")
    out = Path(os.path.expanduser("~/lora-analysis/norm_control")); out.mkdir(parents=True, exist_ok=True)

    tok = load_tokenizer(c["model"]); model = load_model(c["model"])
    mods = inject_lora(model, r=int(c["rank"]), mode=c["mode"], cache_dir=a.svd_cache, model_id=c["model"],
                       seed=int(c.get("seed", 0)), subspace_salted=bool(c.get("subspace_salted", False)))
    model.eval()
    if hasattr(model.config, "use_cache"):
        model.config.use_cache = True

    rows = []
    load_factors_into(model, f)
    norm0 = sum(update_norms(mods).values()) / len(mods)
    m, v = evaluate(model, tok, c)
    dt, dv = abs(m["format_parsed"] - rec["format_parsed"]), abs(v["format_parsed"] - rec["val_format_parsed"])
    ok = dt <= TOL_TEST and dv <= TOL_VAL
    print(f"  {d.name} {c['mode']} seed {c['seed']} <- {f.name} : norme propre {norm0:.3f} ; score {m['format_parsed']:.4f} "
          f"(enregistre {rec['format_parsed']:.4f}), validation {v['format_parsed']:.4f} (enregistre {rec['val_format_parsed']:.4f})"
          f" -> {'REPRODUIT' if ok else 'NON REPRODUIT'}", flush=True)
    rows.append(dict(run=d.name, mode=c["mode"], seed=c["seed"], lr=c["lr"], target="own", norm=norm0, factor=1.0,
                     format_parsed=m["format_parsed"], val_format_parsed=v["format_parsed"], reproduced=ok))
    if not ok:
        _write(out / f"{d.name}.csv", rows)
        sys.exit(3)
    for t in TARGETS:
        load_factors_into(model, f)                    # back to the learned update before every rescale
        fac = rescale_update_(mods, t)
        m, v = evaluate(model, tok, c)
        rows.append(dict(run=d.name, mode=c["mode"], seed=c["seed"], lr=c["lr"], target=t, norm=t, factor=fac,
                         format_parsed=m["format_parsed"], val_format_parsed=v["format_parsed"], reproduced=True))
        print(f"    cible {t:.1f} (facteur {fac:.3f}) : score {m['format_parsed']:.4f}", flush=True)
        _write(out / f"{d.name}.csv", rows)            # written after every target: a killed task keeps what it did
    del model; torch.cuda.empty_cache()


def _write(path: Path, rows):
    with path.open("w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)


if __name__ == "__main__":
    main()
