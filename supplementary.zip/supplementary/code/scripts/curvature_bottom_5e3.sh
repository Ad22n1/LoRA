#!/bin/bash
# lambda_max at step 274 for bottom at its SELECTED rate, 5e-3 (23/09).
#
# WHY. The step-274 curvature of bottom in the paper (33.55, ratio 4.85 against top) was measured on
# the factors trained at 2e-3, the rate earlier versions reported. The selection on seeds 0, 1 and 30-32
# retains 5e-3, so the ratio the mechanism section quotes must be read on those factors. Same settings
# as curvature_at_274_all.sh (strict run filter, 3 batches, 60 iterations, 5 restarts, seeds 2 to 6);
# the alpha=16 run once pooled into this cell is quarantined, so only the five clean runs are read.
#
#SBATCH --job-name=curvB5e3
#SBATCH --partition=PARTITION
#SBATCH --cpus-per-task=4
#SBATCH --mem=32G
#SBATCH --time=01:59:00
#SBATCH --exclude=node
#SBATCH --output=~/lora-results/curvB5e3-%j.out

source /tmp/lora-$USER/venv/bin/activate
cd $HOME/repo
FREE=$(nvidia-smi --query-PARTITION=memory.free --format=csv,noheader,nounits | head -1)
echo "node: $(hostname)  free: ${FREE} MiB"
if [ "$FREE" -lt 13000 ]; then echo "skip: only ${FREE} MiB free"; exit 1; fi
python scripts/curvature.py \
  --model meta-llama/Llama-3.2-1B \
  --data_dir "$HOME/lora-shared/data" --svd_cache "$HOME/lora-shared/svd" \
  --task format --rank 2 --modes bottom --seeds 2,3,4,5,6 \
  --from_step 274 --lr 0.005 --max_grad_norm 1.0 \
  --runs_dir "$HOME/lora-runs" \
  --n_batches 3 --iters 60 --restarts 5 \
  --out "$HOME/lora-analysis/curv274strict_bottom_5e-3.csv"
