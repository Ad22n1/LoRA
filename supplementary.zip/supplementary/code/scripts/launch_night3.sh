#!/usr/bin/env bash
# The night of 26/09: point 5 (second budget) and point 6 (position or norm), in one command.
#
#     bash scripts/launch_night3.sh --dry     # checks and counts only (any time); logs are never touched
#     bash scripts/launch_night3.sh           # submits; refuses between 09:00 and 17:00
#
# Point 6 is two steps: the 20 trainings (norm6_train_*), then one evaluation task per trained run
# (scripts/norm_rescale_eval.py), built from the training job by scripts/make_eval_array.sh and chained with
# --dependency=afterany, so it starts only once every training task has ended (a failed training is caught
# by the evaluation, which refuses a run that is not DONE).
set -u
cd "$HOME/repo" || exit 1
PY="/tmp/lora-$USER/venv/bin/python"; [ -x "$PY" ] || { echo "  venv introuvable : $PY"; exit 1; }
DRY=0; [ "${1:-}" = "--dry" ] && DRY=1
H=$(date +%H)
if [ $DRY -eq 0 ] && [ "$H" -ge 9 ] && [ "$H" -lt 17 ]; then echo "  REFUS : il est $(date +%H:%M), pas de PARTITION entre 9 h et 17 h"; exit 1; fi

G5="budget2x_common budget2x_own_bottom budget2x_own_free budget2x_sel_frozen budget2x_sel_bottom budget2x_sel_free"
G6="norm6_train_frozen norm6_train_bottom"
FILES="PROTOCOL_budget2x.md PROTOCOL_norm_control.md scripts/norm_rescale_eval.py scripts/make_eval_array.sh $(for g in $G5 $G6; do echo configs/grids/$g.yaml; done)"

echo "=== 1. tout est committe et a jour ==="
bad=0
for f in $FILES; do
    if [ ! -f "$f" ]; then echo "  ABSENT       $f"; bad=1
    elif ! git ls-files --error-unmatch "$f" >/dev/null 2>&1; then echo "  NON COMMITTE $f"; bad=1
    elif ! git diff --quiet HEAD -- "$f"; then echo "  MODIFIE      $f"; bad=1; fi
done
for old in configs/grids/norm6_frozen.yaml configs/grids/norm6_bottom.yaml PROTOCOL_budget2x_addendum.md; do
    [ -e "$old" ] && { echo "  A RETIRER    $old (ancienne version, remplacee)"; bad=1; }
done
[ $bad -eq 0 ] && echo "  ok" || { echo "  REFUS : envoyer, retirer les anciennes versions et committer d'abord"; exit 1; }

TMP=$(mktemp -d)
count() {   # "done torun" for grid $1, or ACTIVE if jobs of this grid still run; the grid dir is never deleted
    local dir="$HOME/lora-grid/$1"; [ $DRY -eq 1 ] && dir="$TMP/$1"
    local out; out=$("$PY" -m lorasub.launch_grid "configs/grids/$1.yaml" --grid_dir "$dir" --partition PARTITION \
        --time 01:59:00 --max_par 8 --venv "/tmp/lora-$USER/venv" 2>&1)
    if echo "$out" | grep -q "refusing to generate"; then echo "ACTIVE"; return; fi
    echo "$out" | grep -oE "[0-9]+ already done; [0-9]+ to run" | grep -oE "[0-9]+" | tr '\n' ' '
}
submit() {   # prints the job id on stdout (last line) when it submits
    local g=$1 res done torun
    res="$(count "$g")"
    if [ "$res" = "ACTIVE" ]; then echo "  EN COURS $g : des jobs tournent encore, rien n'est soumis en double" >&2; return; fi
    read -r done torun <<< "$res"
    if [ -z "${done:-}" ]; then echo "  ERREUR  $g : comptage impossible" >&2; return; fi
    if [ "$done" -gt 0 ]; then echo "  SAUTE   $g : $done runs existent deja (collision)" >&2; return; fi
    if [ $DRY -eq 1 ]; then echo "  pret    $g : $torun runs" >&2; return; fi
    local jid; jid=$(sbatch --parsable --exclude=node "$HOME/lora-grid/$g/slurm_array.sh")
    echo "  soumis  $g ($torun runs) : job $jid" >&2; echo "$jid"
}

echo "=== 2. point 5 : second budget (six grilles) ==="
for g in $G5; do submit "$g" >/dev/null; done

echo "=== 3. point 6 : les 20 entrainements, puis leur evaluation enchainee ==="
for g in $G6; do
    jid=$(submit "$g" | tail -1)
    [ $DRY -eq 1 ] && { echo "  (evaluation de $g : sera construite et enchainee au vrai lancement)"; continue; }
    [ -z "${jid:-}" ] && { echo "  evaluation de $g NON soumise (son entrainement n'est pas parti)"; continue; }
    bash scripts/make_eval_array.sh "$g" || continue
    ejid=$(sbatch --parsable --exclude=node --dependency=afterany:"$jid" "$HOME/lora-grid/$g/eval_array.sh")
    echo "  evaluation de $g : job $ejid, demarre apres la fin du job $jid"
done
rm -rf "$TMP"
echo "=== file ==="; squeue -u "$USER" | head -8
