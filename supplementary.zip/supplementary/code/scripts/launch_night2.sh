#!/usr/bin/env bash
# The second night's launches (24/09), in priority order, after checks that refuse rather than guess.
#
#     bash scripts/launch_night2.sh --dry     # checks and counts only (any time); logs are NEVER touched
#     bash scripts/launch_night2.sh           # submits; refuses between 09:00 and 17:00
#
# Refuses when: in the daytime; a protocol, grid or code file is not committed or differs from its commit;
# a grid already has runs, unless it is in RESUME (a partial grid resumed on purpose). Campaign B runs
# only if the bottom_sigma test passes on this server.
set -u
cd "$HOME/repo" || exit 1
PY="/tmp/lora-$USER/venv/bin/python"; [ -x "$PY" ] || { echo "  venv introuvable : $PY"; exit 1; }
DRY=0; [ "${1:-}" = "--dry" ] && DRY=1
H=$(date +%H)
if [ $DRY -eq 0 ] && [ "$H" -ge 9 ] && [ "$H" -lt 17 ]; then echo "  REFUS : il est $(date +%H:%M), pas de PARTITION entre 9 h et 17 h"; exit 1; fi

G_C="sigma_residual"
G_D="obqa_r2_sweep obqa_r2_free_sweep"
G_B="bottom_sigma_sweep_7mod bottom_sigma_sweep_5mod top_sigma_sweep_5mod"
G_ARC="arce_common arce_own_free"
RESUME="random_r4_5e3_seeds facts_r64_bottom_edge"          # partial on purpose: only their missing runs go
FILES="PROTOCOL_sigma_residual.md PROTOCOL_bottom_sigma.md PROTOCOL_obqa_rank2.md src/lorasub/lora.py src/lorasub/config.py \
src/lorasub/aggregate.py tests/test_lora.py $(for g in $G_C $G_D $G_B $G_ARC $RESUME; do echo configs/grids/$g.yaml; done)"

echo "=== 1. tout est committe et a jour ==="
bad=0
for f in $FILES; do
    if [ ! -f "$f" ]; then echo "  ABSENT       $f"; bad=1
    elif ! git ls-files --error-unmatch "$f" >/dev/null 2>&1; then echo "  NON COMMITTE $f"; bad=1
    elif ! git diff --quiet HEAD -- "$f"; then echo "  MODIFIE      $f"; bad=1; fi
done
[ $bad -eq 0 ] && echo "  ok" || { echo "  REFUS : envoyer et committer d'abord"; exit 1; }

echo "=== 2. le test de bottom_sigma, sur ce serveur ==="
# all of test_lora.py, plus the test that every mode is in ARMS and correctly salted (a new mode missing from
# ARMS would make its runs vanish from every table without an error)
"$PY" -m pytest -q tests/test_lora.py "tests/test_additions.py::test_the_salted_modes_list_has_no_second_copy" 2>&1 | tail -3 > /tmp/bsig_test.txt
if grep -qE "passed" /tmp/bsig_test.txt && ! grep -qE "failed|error" /tmp/bsig_test.txt; then
    echo "  ok : le test passe, B peut partir"; B_OK=1
else
    echo "  ECHEC : B ne partira pas ce soir"; cat /tmp/bsig_test.txt; B_OK=0
fi

TMP=$(mktemp -d)
count() {   # "done torun" for grid $1, or ACTIVE if jobs of this grid still run. The grid dir is NEVER deleted:
            # the launcher detects running jobs through its logs, and deleting them would blind that guard.
    local dir="$HOME/lora-grid/$1"; [ $DRY -eq 1 ] && dir="$TMP/$1"
    local out; out=$("$PY" -m lorasub.launch_grid "configs/grids/$1.yaml" --grid_dir "$dir" --partition PARTITION \
        --time 01:59:00 --max_par 8 --venv "/tmp/lora-$USER/venv" 2>&1)
    if echo "$out" | grep -q "refusing to generate"; then echo "ACTIVE"; return; fi
    echo "$out" | grep -oE "[0-9]+ already done; [0-9]+ to run" | grep -oE "[0-9]+" | tr '\n' ' '
}
submit() {
    for g in $1; do
        res="$(count "$g")"
        if [ "$res" = "ACTIVE" ]; then echo "  EN COURS $g : des jobs de cette grille tournent encore, rien n'est soumis en double"; continue; fi
        read -r done torun <<< "$res"
        if [ -z "${done:-}" ]; then echo "  ERREUR  $g : comptage impossible"; continue; fi
        if [ "$torun" -eq 0 ]; then echo "  RIEN    $g : deja complet ($done)"; continue; fi
        if [ "$done" -gt 0 ] && ! echo " $RESUME " | grep -q " $g "; then echo "  SAUTE   $g : $done runs existent deja (collision)"; continue; fi
        if [ $DRY -eq 1 ]; then echo "  pret    $g : $torun runs ($done deja faits)"; continue; fi
        sbatch --exclude=node "$HOME/lora-grid/$g/slurm_array.sh" | sed "s/^/  soumis  $g ($torun runs) : /"
    done
}
echo "=== 3. les runs a reprendre ===";                    submit "$RESUME"
echo "=== 4. ARC-Easy, seconde etape ===";                   submit "$G_ARC"
echo "=== 5. C : top_sigma contre top_scalar ===";          submit "$G_C"
echo "=== 6. D : OpenBookQA au rang 2, selection ===";      submit "$G_D"
echo "=== 7. B : bottom_sigma ==="
[ $B_OK -eq 1 ] && submit "$G_B" || echo "  B non lance (test)"
rm -rf "$TMP"
echo "=== file ==="; squeue -u "$USER" | head -6
