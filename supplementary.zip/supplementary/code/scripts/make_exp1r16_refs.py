"""The pre-registered follow-up of PROTOCOL_exp1_rank16.md: the four frozen references retrained, pinned to one PARTITION model, in a separate
directory (~/lora-runs-suivi), so that every compared evaluation runs on one PARTITION model. Written now, launched only if the reading says so.

    python scripts/make_exp1r16_refs.py      # writes configs/grids/e1r16_ref_*.yaml (4 grids, 20 runs)

Same bases and checks as scripts/make_exp1r16_grids.py; each reference at its selected rate, seeds 2-6.
"""
import sys
from pathlib import Path

import yaml

REFS = {  # grid: (base, check, mode, rate)
    "e1r16_ref_fmt_top": ("configs/grids/sigma_residual_C2.yaml", "fmt", "top", 2e-3),
    "e1r16_ref_fmt_bot": ("configs/grids/sigma_residual_C2.yaml", "fmt", "bottom", 5e-4),
    "e1r16_ref_arc_top": ("configs/grids/arcc_own_top.yaml", "arc", "top", 5e-4),
    "e1r16_ref_arc_bot": ("configs/grids/arcc_own_top.yaml", "arc", "bottom", 1e-3),
}
CHECK = {
    "fmt": lambda b: b.get("task") == "format" and str(b.get("model")) == "meta-llama/Llama-3.2-1B",
    "arc": lambda b: b.get("task") == "commonsense" and str(b.get("data_fingerprint")) == "0755bcdbdce3" and str(b.get("model")) == "Qwen/Qwen2.5-1.5B",
}
H = "# SUIVI PRE-ENREGISTRE (PROTOCOL_exp1_rank16.md) : reference gelee reentrainee, epinglee, hors population principale. 5 runs.\n"
for name, (src, chk, mode, lr) in REFS.items():
    base = dict((yaml.safe_load(open(src)) or {}).get("base") or {})
    if not CHECK[chk](base):
        sys.exit(f"STOP : {src} n'est pas la base attendue")
    for k in ("mode", "rank", "lr", "seed", "band_frac", "update_norm_target"):
        base.pop(k, None)
    base.update(rank=16, save_factor_steps=[], out_dir="$HOME/lora-runs-suivi")
    Path(f"configs/grids/{name}.yaml").write_text(H + yaml.safe_dump({"base": base, "grid": {"mode": [mode], "lr": [lr], "seed": [2, 3, 4, 5, 6]}}, sort_keys=False))
    print(f"  {name:18s} : {mode} r=16 a {lr:g}, graines 2-6, dans ~/lora-runs-suivi")
