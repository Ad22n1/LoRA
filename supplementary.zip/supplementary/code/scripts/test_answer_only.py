"""Test de la perte sur la reponse seule (PROTOCOL_answer_only.md), EXIGE AVANT TOUT RUN. Sans PARTITION, vraies donnees, vrai tokenizer.

    python scripts/test_answer_only.py
"""
import glob
import os
import sys

import torch
import yaml

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
from lorasub.answer_only import AnswerOnly  # noqa: E402
from lorasub.config import RunConfig  # noqa: E402
from lorasub.data.loaders import build_dataset  # noqa: E402
from lorasub.modeling import load_tokenizer  # noqa: E402

ok = True


def check(label, cond, detail=""):
    global ok
    ok &= bool(cond); print(f"  {'ok    ' if cond else 'ECHEC '} {label}" + (f" ({detail})" if detail else ""))


ref = None
for p in glob.glob(os.path.expanduser("~/lora-runs/*/config.yaml")):
    c = yaml.safe_load(open(p)) or {}
    if ("openbookqa" in str(c.get("data_dir")) and str(c.get("model")).endswith("Qwen2.5-1.5B") and c.get("mode") == "free" and c.get("rank") == 1
            and c.get("seed") == 2 and not c.get("answer_only")):
        ref = c; break
if ref is None:
    sys.exit("ARRET : aucune configuration de reference (OpenBookQA, Qwen2.5-1.5B, libre r=1, graine 2)")
cfg = RunConfig(**ref); tok = load_tokenizer(cfg.model)
print("=== 1. memes blocs, seules les etiquettes changent ===")
d1 = build_dataset(cfg.task, cfg.data_dir, tok, cfg.max_len, split="train", seed=cfg.seed)
d2 = build_dataset(cfg.task, cfg.data_dir, tok, cfg.max_len, split="train", seed=cfg.seed)
a = AnswerOnly(d2, tok)
check("blocs identiques a la reference, dans le meme ordre", torch.equal(a.blocks, d1.blocks), f"{len(a)} blocs de {a.blocks.shape[1]} tokens")
bad = 0
for i in range(len(a)):
    x = a[i]; lab = x["labels"]; bad += int(((lab != -100) & (lab != x["input_ids"])).sum())
check("chaque etiquette est masquee ou egale a son token", bad == 0)
frac = a.n_tokens / d1.n_tokens
check("part des tokens supervises plausible (entre 2 % et 50 %)", 0.02 < frac < 0.5, f"{a.n_tokens:,} sur {d1.n_tokens:,}, soit {100 * frac:.1f} %")
print("=== 2. chaque « Answer: » ouvre une reponse supervisee ===")
flat = a.blocks.reshape(-1).tolist(); m = a.mask.reshape(-1).tolist()
text_marks = tok.decode(flat).count("Answer:")
check("autant de reponses que de marques « Answer: » dans le texte", a.n_answers == text_marks, f"{a.n_answers} / {text_marks}")
spans, cur = [], []
for t, s in zip(flat, m):
    if s:
        cur.append(t)
    elif cur:
        spans.append(cur); cur = []
check("chaque reponse a au moins un token supervise", len(spans) >= a.n_answers - 1, f"{len(spans)} plages supervisees")
print("  cinq reponses supervisees, en clair :")
for sp in spans[:5]:
    print(f"      {tok.decode(sp)!r}")
print("=== 3. configuration et identifiants ===")
try:
    RunConfig(**dict(ref, task="format", answer_only=True)); check("answer_only refuse hors d'OpenBookQA / ARC", False)
except (ValueError, TypeError):
    check("answer_only refuse hors d'OpenBookQA / ARC", True)
c0 = RunConfig(**ref); c1 = RunConfig(**dict(ref, answer_only=True))
check("answer_only absent de l'identifiant quand faux", "answer_only" not in c0.id_dict())
check("answer_only change l'identifiant quand vrai", c0.run_id != c1.run_id, f"{c0.run_id} / {c1.run_id}")
runs = sorted(glob.glob(os.path.expanduser("~/lora-runs/*/config.yaml")))[:300]
same = sum(RunConfig(**(yaml.safe_load(open(p)) or {})).run_id == os.path.basename(os.path.dirname(p)) for p in runs)
print(f"  (runs existants : {same} / {len(runs)} identifiants retrouves ; 292 / 300 attendus, les 8 autres datent des 11-12/09)")
print("  TEST DE LA PERTE SUR LA REPONSE SEULE : " + ("REUSSI" if ok else "ECHOUE -- aucun run answer_only ne doit partir"))
sys.exit(0 if ok else 1)
