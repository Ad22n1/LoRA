#!/bin/bash
# `top` is the arm we resolve least well, and it is the denominator of the ratio we quote.
#
# With five restarts its within-cell spread is 1.68, against 0.15 to 0.47 for every other arm, and
# one seed reads 74 where the other four read 32.5. The ratio bottom/top therefore carries more
# uncertainty than the number suggests, and the paper currently says so as a reservation.
#
# This removes the reservation instead of writing it: twenty restarts and five batches on `top`
# alone. If the spread drops to the level of the other arms, the ratio is as solid as they are; if
# it stays at 1.68, the reservation is a real property of that subspace and belongs in the paper
# with this measurement behind it.
#
#SBATCH --job-name=curvtop
#SBATCH --partition=PARTITION
#SBATCH --cpus-per-task=4
#SBATCH --mem=32G
#SBATCH --exclusive
#SBATCH --time=01:59:00
#SBATCH --output=~/lora-results/curvtop-%j.out

source /tmp/lora-$USER/venv/bin/activate
export SHARED=$HOME/lora-shared
cd $HOME/repo

FREE=$(nvidia-smi --query-PARTITION=memory.free --format=csv,noheader,nounits | head -1)
echo "node: $(hostname)  free: ${FREE} MiB"
if [ "$FREE" -lt 13000 ]; then echo "skip: only ${FREE} MiB free"; exit 1; fi

python scripts/curvature.py \
  --model meta-llama/Llama-3.2-1B \
  --data_dir "$SHARED/data" --svd_cache "$SHARED/svd" \
  --task format --rank 2 --modes top --seeds 2,3,4,5,6 \
  --n_batches 5 --batch 1 --max_len 384 --iters 60 --restarts 20 \
  --out "$HOME/lora-analysis/curvature_top_deep.csv"

python - <<'PY'
import os
import pandas as pd
d = pd.read_csv(os.path.expanduser("~/lora-analysis/curvature_top_deep.csv"))
d["spread"] = (d.curvature_max - d.curvature_min) / d.curvature_median
print("\n=== top, twenty restarts ===")
print(d[["seed", "curvature_median", "curvature_min", "curvature_max", "spread"]].round(3).to_string(index=False))
print(f"\n  median lambda = {d.curvature_median.median():.2f}   (five restarts gave 32.58)")
print(f"  median spread = {d.spread.median():.2f}   (five restarts gave 1.68; other arms 0.15-0.47)")
print(f"  ratio bottom/top = {333.0 / d.curvature_median.median():.2f}   (five restarts gave 10.22)")
PY
