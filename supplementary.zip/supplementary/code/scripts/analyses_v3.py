"""Analyses sans entrainement, troisieme serie (demandees par la relecture le 28/09).

    python scripts/analyses_v3.py --decomp     # decomposition facteur x bande a tous les rangs, intervalles de t apparies (t a 4 ddl)
    python scripts/analyses_v3.py --angles     # angles principaux : directions apprises, directions du gradient, bandes spectrales de W0
    python scripts/analyses_v3.py --mineur     # le bras bottom d'OpenBookQA au rang 2 (0,4220 = le modele de base) : inventaire

Chaque cellule est retrouvee par sa valeur publiee (a 1e-4 pres) ou, pour les campagnes v2, par le taux retenu de leur selection ; arret si
elle est absente, incomplete ou en doublon.
"""
import glob
import json
import os
import statistics as st
import sys

import yaml

REPO = os.path.expanduser("~/repo")
S26, S120 = (2, 3, 4, 5, 6), (120, 121, 122, 123, 124)
T4 = 2.776
dd = lambda c: os.path.basename(str(c.get("data_dir") or "").rstrip("/"))  # noqa: E731


def _tok(c):
    tt = c.get("target_tokens")
    return tt.get("format") if isinstance(tt, dict) else tt


def clean(c):
    mods = c.get("target_modules")
    return (mods is None or len(mods) == 7) and float(c.get("max_grad_norm", 1.0) or 0) == 1.0 and c.get("update_norm_target") in (None, "")


POPS = {"format/Llama": (lambda c: c.get("task") == "format" and str(c.get("model")).endswith("Llama-3.2-1B") and _tok(c) == 600000, "format_parsed"),
        "OBQA/Qwen1.5B": (lambda c: dd(c) == "openbookqa" and str(c.get("model")).endswith("Qwen2.5-1.5B") and not c.get("answer_only"), "mcq_acc"),
        "OBQA/Qwen7B": (lambda c: dd(c) == "openbookqa" and str(c.get("model")).endswith("Qwen2.5-7B"), "mcq_acc"),
        "OBQA/Mistral7B": (lambda c: dd(c) == "openbookqa" and str(c.get("model")).endswith("Mistral-7B-v0.3"), "mcq_acc"),
        "ARC-C/Qwen1.5B": (lambda c: dd(c) == "arc_challenge" and str(c.get("model")).endswith("Qwen2.5-1.5B"), "mcq_acc")}
RUNS = []
for p in glob.glob(os.path.expanduser("~/lora-runs/*/config.yaml")):
    d = os.path.dirname(p)
    try:
        if open(d + "/status").read().startswith("DONE"):
            RUNS.append((yaml.safe_load(open(p)) or {}, json.load(open(d + "/metrics.json")), d, os.path.getmtime(p)))
    except (OSError, ValueError):
        pass


def _at(pop, mode, rank, lr, seeds, since=None):
    pred, key = POPS[pop]; by = {}
    for c, m, d, t in RUNS:
        if (pred(c) and clean(c) and c.get("mode") == mode and c.get("rank") == rank and abs(float(c.get("lr") or 0) - lr) < 1e-12
                and c.get("seed") in seeds and key in m and (since is None or t >= since)):
            by.setdefault(c["seed"], []).append(m[key])
    return {s: by[s][0] for s in seeds} if sorted(by) == list(seeds) and all(len(v) == 1 for v in by.values()) else None


def cell(pop, mode, rank, seeds, value=None, lr=None, since=None):
    tag = f"{pop} {mode} r={rank}"
    if lr is not None:
        v = _at(pop, mode, rank, lr, seeds, since)
        if v is None:
            sys.exit(f"ARRET : {tag} a {lr:g} : cellule incomplete ou en doublon")
        return v
    pred, _ = POPS[pop]
    rates = sorted({float(c["lr"]) for c, m, d, t in RUNS if pred(c) and clean(c) and c.get("mode") == mode and c.get("rank") == rank and c.get("seed") in seeds})
    hits = [(r, v) for r in rates for v in [_at(pop, mode, rank, r, seeds)] if v is not None and abs(st.mean(v.values()) - value) <= 1e-4]
    if len(hits) > 1:
        # plusieurs taux redonnent la valeur publiee : on garde celui que la selection a retenu, le meilleur en validation (graines 0 et 1)
        vkey = "val_" + POPS[pop][1]; vals = []
        for r, v in hits:
            by = {}
            for c, m, d, t in RUNS:
                if (POPS[pop][0](c) and clean(c) and c.get("mode") == mode and c.get("rank") == rank and abs(float(c.get("lr") or 0) - r) < 1e-12
                        and c.get("seed") in (0, 1) and vkey in m):
                    by.setdefault(c["seed"], []).append(m[vkey])
            vals.append((st.mean(x[0] for x in by.values()) if sorted(by) == [0, 1] else None, r, v))
        ok = [x for x in vals if x[0] is not None]
        best = sorted(ok, key=lambda x: -x[0])
        if not best or (len(best) > 1 and best[0][0] == best[1][0]):
            sys.exit(f"ARRET : {tag} : valeur publiee {value:.4f} retrouvee a {len(hits)} taux, que la validation ne departage pas")
        print(f"  ({tag} : {value:.4f} retrouvee a {len(hits)} taux (" + ", ".join(f"{r:g}" for r, v in hits) + f") ; retenu {best[0][1]:g}, "
              f"le meilleur en validation, comme la selection : " + ", ".join(f"{r:g} -> {x:.4f}" for x, r, v in ok) + ")")
        return best[0][2]
    if len(hits) != 1:
        sys.exit(f"ARRET : {tag} : valeur publiee {value:.4f} retrouvee a {len(hits)} taux")
    return hits[0][1]


def tci(x):
    m = st.mean(x); h = T4 * st.stdev(x) / len(x) ** 0.5
    return m, m - h, m + h


def do_decomp():
    print("==================== decomposition facteur x bande a tous les rangs (post hoc ; intervalles de t apparies, t a 4 ddl) ====================")
    print("  facteur = moyenne(A gele) - moyenne(B gele) ; bande = moyenne(bottom) - moyenne(top) ; interaction = (A : bottom - top) - (B : bottom - top)")
    POP = []
    # rang 2 : les valeurs publiees du tableau central
    for pop, S, v in (("format/Llama", S26, (0.6443, 0.5922, 0.7739, 0.7818)), ("format/Llama", S120, (0.6593, 0.5954, 0.7772, 0.7818)),
                      ("OBQA/Qwen1.5B", S26, (0.4652, 0.4220, 0.5308, 0.5248)), ("OBQA/Qwen7B", S26, (0.5316, 0.4840, 0.6364, 0.6148)),
                      ("OBQA/Mistral7B", S26, (0.4764, 0.4776, 0.6076, 0.5860))):
        POP.append((2, pop, S, [cell(pop, m, 2, S, value=x) for m, x in zip(("top", "bottom", "dual_top", "dual_bottom"), v)]))
    # rangs 4 et 8 : la tendance (selection v2 ; les bras B geles au rang 4 sont ceux du budget, identiques)
    sel = json.load(open(f"{REPO}/v2_trend_selection.json")); t0 = os.path.getmtime(f"{REPO}/v2_budget15_check.json")
    for r in (4, 8):
        POP.append((r, "OBQA/Qwen1.5B", S26, [cell("OBQA/Qwen1.5B", m, r, S26, lr=sel[f"{m}_r{r}"], since=t0) for m in ("top", "bottom", "dual_top", "dual_bottom")]))
    # rang 16 : ARC-Challenge et OpenBookQA (valeurs publiees ; A gele = B gele + l'ecart publie), et le 7B (selection v2)
    for pop, v in (("ARC-C/Qwen1.5B", (0.4970, 0.4452, 0.4922, 0.4982)), ("OBQA/Qwen1.5B", (0.5408, 0.4984, 0.5544, 0.5364))):
        POP.append((16, pop, S26, [cell(pop, m, 16, S26, value=x) for m, x in zip(("top", "bottom", "dual_top", "dual_bottom"), v)]))
    s7 = json.load(open(f"{REPO}/v2_r16_7b_selection.json")); t7 = os.path.getmtime(f"{REPO}/v2_r16_7b_check.json")
    POP.append((16, "OBQA/Qwen7B", S26, [cell("OBQA/Qwen7B", m, 16, S26, lr=s7[f"{m}_r16"], since=t7) for m in ("top", "bottom", "dual_top", "dual_bottom")]))
    for r, pop, S, (t, b, dt, db) in POP:
        f = [((dt[s] + db[s]) - (t[s] + b[s])) / 2 * 100 for s in S]; bd = [((b[s] + db[s]) - (t[s] + dt[s])) / 2 * 100 for s in S]
        it = [((db[s] - dt[s]) - (b[s] - t[s])) * 100 for s in S]
        (fm, fl, fh), (bm, bl, bh), (im, il, ih) = tci(f), tci(bd), tci(it)
        ratio = abs(fm) / abs(bm) if abs(bm) > 1e-9 else float("inf")
        print(f"  r={r:<2d} {pop:15s} graines {S[0]}-{S[-1]} : facteur {fm:+6.2f} [{fl:+6.2f}, {fh:+6.2f}] ; bande {bm:+6.2f} [{bl:+6.2f}, {bh:+6.2f}] ; "
              f"interaction {im:+6.2f} [{il:+6.2f}, {ih:+6.2f}] ; |facteur| / |bande| {ratio:5.1f}")


def do_angles():
    print("==================== angles principaux entre sous-espaces de rang 2 (cote sortie), par type de module ====================")
    import torch
    from safetensors.torch import load_file
    sys.path.insert(0, f"{REPO}/src")
    from lorasub.spectral import load_svd
    B = {k: f"{REPO}/bases/{f}" for k, f in (("appris, graine 0", "learned_obqa_r2_s0.safetensors"), ("appris, graine 7", "learned_obqa_r2_s7.safetensors"),
                                               ("gradient", "learned_grad_obqa_r2.safetensors"), ("appris (format)", "learned_format_llama_r2_s0.safetensors"),
                                               ("gradient (format)", "learned_grad_format_llama_r2.safetensors"))}
    have = {k: load_file(v) for k, v in B.items() if os.path.exists(v)}
    print("  bases presentes : " + ", ".join(have) + ("" if len(have) == len(B) else "  (manquantes : " + ", ".join(k for k in B if k not in have) + ")"))
    svdroot = f"/tmp/lora-{os.environ['USER']}/svd"

    def spectral(model, name, band):
        e = load_svd(svdroot, model, name); U = e.U.float()
        return U[:, :2] if band == "top" else U[:, e.S.numel() - 2:e.S.numel()]

    def overlap(Q1, Q2):   # moyenne des cos^2 des angles principaux = ||Q1^T Q2||_F^2 / 2 ; hasard : 2 / d
        return float((Q1.float().T @ Q2.float()).pow(2).sum() / 2)
    PAIRS = [("OBQA", "Qwen/Qwen2.5-1.5B", "appris, graine 0", "appris, graine 7"), ("OBQA", "Qwen/Qwen2.5-1.5B", "appris, graine 0", "gradient"),
             ("OBQA", "Qwen/Qwen2.5-1.5B", "appris, graine 7", "gradient"), ("OBQA", "Qwen/Qwen2.5-1.5B", "appris, graine 0", "top"),
             ("OBQA", "Qwen/Qwen2.5-1.5B", "appris, graine 0", "bottom"), ("OBQA", "Qwen/Qwen2.5-1.5B", "gradient", "top"),
             ("OBQA", "Qwen/Qwen2.5-1.5B", "gradient", "bottom"), ("format", "meta-llama/Llama-3.2-1B", "appris (format)", "gradient (format)"),
             ("format", "meta-llama/Llama-3.2-1B", "appris (format)", "top"), ("format", "meta-llama/Llama-3.2-1B", "gradient (format)", "top")]
    TYPES = ("q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj")
    print("  chiffre = moyenne des cos^2 des deux angles principaux (1 = meme sous-espace, 0 = orthogonaux), mediane sur les couches ; "
          "entre parentheses, le hasard (2 / d_out)")
    for task, model, a, b in PAIRS:
        if a not in have or (b not in ("top", "bottom") and b not in have):
            print(f"  {task:6s} {a} / {b} : bases absentes, non calcule"); continue
        per = {t: [] for t in TYPES}; dims = {}
        for name, Qa in have[a].items():
            Qb = spectral(model, name, b) if b in ("top", "bottom") else have[b][name]
            ty = name.rsplit(".", 1)[-1]; per[ty].append(overlap(Qa, Qb)); dims[ty] = Qa.shape[0]
        row = "  ".join(f"{t.replace('_proj', '')} {st.median(v):.3f} ({2 / dims[t]:.4f})" for t, v in per.items() if v)
        print(f"  {task:6s} {a:18s} / {b:18s} : {row}")


def do_mineur():
    print("==================== le bras bottom d'OpenBookQA au rang 2 (0,4220 = le modele de base) : inventaire ====================")
    pred, key = POPS["OBQA/Qwen1.5B"]
    for mode, lr in (("bottom", 2e-3), ("top", 5e-3)):
        rs = [(c, m, d) for c, m, d, t in RUNS if pred(c) and clean(c) and c.get("mode") == mode and c.get("rank") == 2 and abs(float(c["lr"]) - lr) < 1e-12 and c.get("seed") in S26]
        if not rs:
            print(f"  {mode} : aucun run"); continue
        c, m, d = sorted(rs, key=lambda x: x[0]["seed"])[0]
        print(f"  {mode} r=2 a {lr:g}, graine {c['seed']} : fichiers {sorted(os.listdir(d))}")
        print(f"    metriques : { {k: (round(v, 4) if isinstance(v, float) else v) for k, v in m.items() if not isinstance(v, (list, dict))} }")
        un = os.path.join(d, "update_norms.json")
        if os.path.exists(un):
            u = json.load(open(un)); vals = [v for v in (u.values() if isinstance(u, dict) else u) if isinstance(v, (int, float))]
            print(f"    normes des mises a jour : {len(vals)} valeurs, mediane {st.median(vals):.3g}" if vals else f"    update_norms.json : {str(u)[:160]}")
        for f in ("generations_test.jsonl", "predictions.jsonl", "mcq_preds.jsonl"):
            if os.path.exists(os.path.join(d, f)):
                print(f"    {f} : premiere ligne {open(os.path.join(d, f)).readline()[:220]}")
    base = [(c, m, d) for c, m, d, t in RUNS if pred(c) and c.get("mode") == "baseline"]
    print(f"  modele de base : {len(base)} run(s)" + (f" ; fichiers {sorted(os.listdir(base[0][2]))}" if base else ""))


if __name__ == "__main__":
    acts = {"--decomp": do_decomp, "--angles": do_angles, "--mineur": do_mineur}
    todo = [a for a in sys.argv[1:] if a in acts]
    if not todo:
        sys.exit(__doc__)
    for a in todo:
        acts[a](); print()
