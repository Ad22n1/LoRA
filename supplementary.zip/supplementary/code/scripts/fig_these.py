"""Gap to free LoRA against the cost of choosing, population by population (the dot-and-arrow chart).

    python scripts/fig_these.py paper/figures        # writes thesis.png (main text) and thesis_full.png (appendix)

Nothing is typed twice. Each population is given by the SCORES of its arms (means over the reported seeds, each arm at its
selected rate, as printed by the reading scripts named next to them); the two costs are computed here:
    freezing = free - best frozen arm ;  choosing = best frozen arm - worst frozen arm   (points)
Whether freezing - choosing is established is read from the results map (scripts/fig_summary.py, column "freezing costs more
than choosing": E or R established, N not); a population absent from the map has no such test and is drawn as not established.
Rows are grouped by task; within a group, by increasing rank. Rows that carry no claim go to the full version only.
Filled markers: freezing - choosing established; open: not established (the convention of the dependence-on-rank figure).
No title, no ratio, no note inside the image: what the figure shows is said in its caption.
"""
import ast
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else "."
if OUT.endswith(".png"):          # the deploy script passes paper/figures/thesis.png: write both images next to it
    OUT = str(Path(OUT).parent)
HERE = Path(__file__).resolve().parent

# ---------------------------------------------------------------- the populations: (group, label, map row or None, free, frozen arms)
# format, Llama-3.2-1B: scripts/table_values.py (21/09, after the 15 re-runs), read_caption_values.py (25/09), read_points56.py (26/09)
POP = [
    ("format (Llama-3.2-1B)", "r=2", "format, rank 2", 0.7684, {"random_ortho": 0.6534, "random": 0.6521, "top": 0.6443, "bottom": 0.5922}),
    ("format (Llama-3.2-1B)", "r=2, 2\u00d7 budget", "format, rank 2, 2x budget", 0.7984, {"top": 0.6967, "random": 0.6935, "random_ortho": 0.6896, "bottom": 0.6313}),
    ("format (Llama-3.2-1B)", "r=2, 5 modules", None, 0.7941, {"random": 0.6094, "top": 0.5910, "bottom": 0.5326}),
    ("format (Llama-3.2-1B)", "r=2, along the spectrum", None, 0.7684, {"beta=0": 0.6508, "beta=0.25": 0.6332, "beta=0.5": 0.6612, "beta=0.75": 0.6782, "beta=1": 0.5873}),
    ("format (Llama-3.2-1B)", "r=4", "format, rank 4", 0.8033, {"random": 0.7023, "bottom": 0.6958, "top": 0.6599}),
    ("format (Llama-3.2-1B)", "r=4, top at 5e-3", None, 0.8033, {"top": 0.7189, "random": 0.7023, "bottom": 0.6958}),
    ("format (Llama-3.2-1B)", "r=8", "format, rank 8", 0.8293, {"random": 0.7550, "random_ortho": 0.7505, "top": 0.7450, "bottom": 0.7450}),
    ("format (Llama-3.2-1B)", "r=16", "format, rank 16", 0.8205, {"random_ortho": 0.7795, "top": 0.7756, "random": 0.7700, "bottom": 0.7554}),
    # format, Qwen2.5-1.5B: scripts/read_fmtq.py (26/09), seeds 22-26
    ("format (Qwen2.5-1.5B)", "r=2", "format, rank 2, Qwen2.5-1.5B", 0.7879, {"top": 0.6257, "bottom": 0.6391, "random_ortho": 0.6238}),
    ("format (Qwen2.5-1.5B)", "r=16", "format, rank 16, Qwen2.5-1.5B", 0.8078, {"top": 0.7430, "bottom": 0.7524, "random_ortho": 0.7521}),
    # OpenBookQA, Qwen2.5-1.5B: read_night3.py (25/09) and the rank-16 campaign
    ("OpenBookQA", "r=2", "OpenBookQA, rank 2", 0.5456, {"top": 0.4652, "random": 0.4652, "random_ortho": 0.4592, "bottom": 0.4220}),
    ("OpenBookQA", "r=16", "OpenBookQA, rank 16", 0.5616, {"top": 0.5408, "random_ortho": 0.5060, "bottom": 0.4984}),
    # ARC, Qwen2.5-1.5B: the second stage (26/09) and read_night4.py (26/09)
    ("ARC-Easy", "r=16", "ARC-Easy, rank 16", 0.7940, {"top": 0.7948, "random_ortho": 0.7970, "bottom": 0.7792}),
    ("ARC-Challenge", "r=2", "ARC-Challenge, rank 2", 0.5044, {"top": 0.4842, "random_ortho": 0.4692, "bottom": 0.4668}),
    ("ARC-Challenge", "r=16", "ARC-Challenge, rank 16", 0.4952, {"top": 0.4970, "random_ortho": 0.4860, "bottom": 0.4452}),
    ("ARC-Challenge", "r=32", "ARC-Challenge, rank 32", 0.4888, {"top": 0.4824, "random_ortho": 0.4960, "bottom": 0.4758}),
]
# rows that carry no claim: shown in the appendix version only (budget not matched, or a degenerate exact match)
NO_CLAIM = [
    ("no claim", "r=1 (2.15\u00d7)", 0.7684, {"random": 0.5288, "top": 0.5107, "bottom": 0.4547}),
    ("no claim", "r=64, knowledge (2.15\u00d7)", 0.5480, {"top": 0.3400, "random": 0.3065, "bottom": 0.2825}),
]
NO_CLAIM_FREEZE_ONLY = [("no claim", "2 modules (exact)", 42.5)]   # the degenerate q,o pair: no choosing cost
GROUPS = ["format (Llama-3.2-1B)", "format (Qwen2.5-1.5B)", "OpenBookQA", "ARC-Easy", "ARC-Challenge"]


def map_status():
    """row label -> outcome code of the map's third column, read from scripts/fig_summary.py without running it"""
    tree = ast.parse((HERE / "fig_summary.py").read_text())
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(getattr(t, "id", None) == "ROWS" for t in node.targets):
            return {lab: cells[2][0] for lab, cells in ast.literal_eval(node.value)}
    raise SystemExit("STOP : ROWS introuvable dans fig_summary.py")


def cost(free, arms):
    best, worst = max(arms.values()), min(arms.values())
    return (free - best) * 100, (best - worst) * 100


def rows(full):
    st = map_status(); out = []
    for g in GROUPS:
        out.append(("head", g))
        for _, lab, key, free, arms in [p for p in POP if p[0] == g]:
            if key is not None and key not in st:
                raise SystemExit(f"STOP : {key!r} absent de la carte")
            f, c = cost(free, arms)
            out.append(("row", lab, f, c, key is not None and st[key] in ("E", "R"), 1.0))
    if full:
        out.append(("head", NO_CLAIM[0][0]))
        for _, lab, free, arms in NO_CLAIM:
            f, c = cost(free, arms); out.append(("row", lab, f, c, False, 0.45))
        for _, lab, v in NO_CLAIM_FREEZE_ONLY:
            out.append(("row", lab, v, None, False, 0.45))
    return out


FREEZE, CHOOSE, FS = "#c44e52", "#4c72b0", 11.5


def draw(full, path):
    R = rows(full); n = len(R)
    vals = [v for r in R if r[0] == "row" for v in (r[2], r[3]) if v is not None]
    near = 0.085 * (max(vals) - min(vals))               # "close" scales with the axis range: 1.6 points here, 3.7 with the no-claim rows
    fig, ax = plt.subplots(figsize=(8.0, 0.30 * n + 0.9))
    ytick, ylab, ystyle = [], [], []
    for y, r in enumerate(R):
        ytick.append(y); ylab.append(r[1]); ystyle.append(r[0])
        if r[0] == "head":
            continue
        _, lab, f, c, est, al = r
        close = True   # every value beside its marker, outward: a label above a marker can hit the row above
        def label(x, v, col, side):
            if close:
                ax.text(x + (-1 if side == "left" else 1) * near * 0.22, y, f"{v:.1f}", ha="right" if side == "left" else "left", va="center",
                        fontsize=FS - 1, color=col, alpha=al)
            else:
                ax.text(x, y - 0.33, f"{v:.1f}", ha="center", va="bottom", fontsize=FS - 1, color=col, alpha=al)
        if c is not None:
            ax.plot([c, f], [y, y], color="0.6", lw=1.1, zorder=1, alpha=al)
            ax.plot(c, y, "s", ms=7, mec=CHOOSE, mfc=CHOOSE if est else "white", mew=1.6, zorder=3, alpha=al)
            label(c, c, CHOOSE, "left" if c <= f else "right")
        ax.plot(f, y, "o", ms=7.5, mec=FREEZE, mfc=FREEZE if est else "white", mew=1.6, zorder=3, alpha=al)
        label(f, f, FREEZE, "right" if (c is None or f >= c) else "left")
    ax.set_yticks(ytick); ax.set_yticklabels(ylab, fontsize=FS)
    for t, sty in zip(ax.get_yticklabels(), ystyle):
        if sty == "head":
            t.set_fontweight("bold")
    ax.set_ylim(n - 0.4, -0.7)
    ax.set_xlim(min(vals) - 1.1 * near, max(vals) + 0.5 * near)   # room for the labels set beside the leftmost points
    ax.axvline(0, color="0.75", lw=0.8, zorder=0)
    ax.set_xlabel("points of accuracy (the metric of each row is given in the caption)", fontsize=FS)
    ax.tick_params(axis="x", labelsize=FS); ax.tick_params(axis="y", length=0)
    for sp in ("top", "right", "left"):
        ax.spines[sp].set_visible(False)
    ax.grid(axis="x", color="0.92", lw=0.8); ax.set_axisbelow(True)
    handles = [Line2D([], [], marker="o", ls="", ms=7.5, mfc=FREEZE, mec=FREEZE, label="gap to a budget-matched free LoRA (freezing)"),
               Line2D([], [], marker="s", ls="", ms=7, mfc=CHOOSE, mec=CHOOSE, label="spread among the frozen arms"),
               Line2D([], [], marker="o", ls="", ms=7.5, mfc="0.35", mec="0.35", label="filled: gap minus spread established"),
               Line2D([], [], marker="o", ls="", ms=7.5, mfc="white", mec="0.35", mew=1.6, label="open: not established")]
    ax.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.42, -0.085 * 18 / n), ncol=2, fontsize=FS - 0.5, frameon=False,
              handletextpad=0.3, columnspacing=1.4, borderaxespad=0.0)
    fig.savefig(path, dpi=200, bbox_inches="tight", pad_inches=0.05); plt.close(fig)


draw(False, f"{OUT}/thesis.png")
draw(True, f"{OUT}/thesis_full.png")
print(f"  ecrit -> {OUT}/thesis.png, thesis_full.png")
for r in rows(True):
    if r[0] == "row":
        print(f"    {r[1]:34s} geler {r[2]:6.2f}  choisir " + (f"{r[3]:5.2f}" if r[3] is not None else "  -  ") + ("  plein" if r[4] else "  vide"))
