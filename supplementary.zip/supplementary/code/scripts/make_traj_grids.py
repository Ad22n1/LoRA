"""Grids of PROTOCOL_lrscale_trajectory.md, from configs/grids/sigma_residual_C2.yaml (checked as the original campaign's configuration).

    python scripts/make_traj_grids.py          # 6 grids, 11 runs
"""
import sys
from pathlib import Path

import yaml

SRC = Path("configs/grids/sigma_residual_C2.yaml")
base = dict((yaml.safe_load(open(SRC)) or {}).get("base") or {}) if SRC.exists() else sys.exit(f"STOP : {SRC} introuvable")
tok = base.get("target_tokens"); tok = tok.get("format") if isinstance(tok, dict) else tok
mods = base.get("target_modules")
checks = {"tache format": base.get("task") == "format", "Llama-3.2-1B": str(base.get("model")) == "meta-llama/Llama-3.2-1B", "600 000 tokens": tok == 600000,
          "longueur 384": base.get("max_len") == 384, "lot 2": base.get("batch_size") == 2, "accumulation 16": base.get("grad_accum") == 16,
          "sept modules": mods is None or len(mods) == 7}
bad = [k for k, ok in checks.items() if not ok]
if bad:
    sys.exit(f"STOP : la base differe de la campagne d'origine sur : {', '.join(bad)}")
for k in ("mode", "rank", "lr", "seed", "band_frac", "update_norm_target", "max_grad_norm", "adam_eps", "dtype"):
    base.pop(k, None)
base.update(rank=2, save_factor_steps=list(range(1, 17)) + list(range(20, 401, 4)))
C = {"traj_c0": (1e6, 1e-20, "float32"), "traj_c1": (1.0, 1e-20, "float32"), "traj_c2": (1e6, 1e-8, "float32"),
     "traj_c3": (1e6, 1e-20, "bfloat16"), "traj_c4": (1.0, 1e-8, "bfloat16")}
H = "# PRE-ENREGISTRE (PROTOCOL_lrscale_trajectory.md). Genere par scripts/make_traj_grids.py.\n"
total = 0
for name, (clip, eps, dt) in C.items():
    b = dict(base); b.update(max_grad_norm=clip, adam_eps=eps, dtype=dt, out_dir="$HOME/lora-runs-traj")
    Path(f"configs/grids/{name}.yaml").write_text(H + yaml.safe_dump({"base": b, "grid": {"mode": ["top_scalar", "top_lrscale"], "lr": [5e-3], "seed": [200]}}, sort_keys=False))
    total += 2; print(f"  {name} : ecretage {clip:g}, eps {eps:g}, {dt} ; top_scalar et top_lrscale")
b = dict(base); b.update(max_grad_norm=1e6, adam_eps=1e-20, dtype="float32", out_dir="$HOME/lora-runs-traj-ctrl")
Path("configs/grids/traj_ctrl.yaml").write_text(H + "# TEMOIN : top_scalar en C0, second run, dossier separe.\n"
                                               + yaml.safe_dump({"base": b, "grid": {"mode": ["top_scalar"], "lr": [5e-3], "seed": [200]}}, sort_keys=False))
total += 1; print("  traj_ctrl : temoin, top_scalar en C0 relance")
print(f"  total : {total} runs"); total == 11 or sys.exit("STOP : le total n'est pas 11")
