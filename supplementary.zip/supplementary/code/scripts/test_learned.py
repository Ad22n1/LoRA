"""Test du mode `learned` (phase 2, ANALYSE_writes_additif.md), EXIGE AVANT TOUT RUN. CPU, quelques secondes.

    python scripts/test_learned.py
"""
import glob
import os
import shutil
import sys
import tempfile

import torch
import yaml
from safetensors.torch import save_file
from torch import nn

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
from lorasub.config import RunConfig  # noqa: E402
from lorasub.lora import count_trainable, expected_trainable, inject_lora, lora_modules  # noqa: E402

ok = True


def check(label, cond, detail=""):
    global ok
    ok &= bool(cond)
    print(f"  {'ok    ' if cond else 'ECHEC '} {label}" + (f" ({detail})" if detail else ""))


class Toy(nn.Module):
    def __init__(self):
        super().__init__()
        self.layers = nn.ModuleList([nn.ModuleDict({"q_proj": nn.Linear(32, 24, bias=False), "up_proj": nn.Linear(32, 48, bias=False)}) for _ in range(2)])

    def forward(self, x):
        for L in self.layers:
            x = torch.tanh(L["q_proj"](x)).repeat(1, 2)[:, :32] + L["up_proj"](x)[:, :32]
        return x


torch.manual_seed(0); tmp = tempfile.mkdtemp(); r = 2; suf = ("q_proj", "up_proj")
model = Toy(); names = [n for n, m in model.named_modules() if n.split(".")[-1] in suf]
bases = {n: torch.linalg.qr(torch.randn(model.get_submodule(n).out_features, r))[0].contiguous() for n in names}
f = os.path.join(tmp, "bases.safetensors"); save_file(bases, f)
x = torch.randn(8, 32); y0 = model(x).detach()

print("=== 1. B charge = fichier, gele ; A entrainable ===")
mods = inject_lora(model, r=r, mode="learned", target_suffixes=suf, learned_basis=f)
check("tous les modules cibles recoivent un adaptateur", sorted(mods) == sorted(names), f"{len(mods)} modules")
check("B identique au fichier", all(torch.equal(m.B.detach().cpu(), bases[n]) for n, m in mods.items()),
      f"ecart max {max(float((m.B.detach().cpu() - bases[n]).abs().max()) for n, m in mods.items()):.1e}")
check("B gele, A entrainable", all((not m.B.requires_grad) and m.A.requires_grad for m in mods.values()))
print("=== 2. dW = 0 a l'initialisation ===")
check("dW = B A nul", all(float(m.delta_w().abs().max()) == 0.0 for m in mods.values()))
check("sortie identique au modele de base", torch.equal(model(x).detach(), y0))
print("=== 3. budget : r * d_in par module ===")
exp_manual = sum(r * model.get_submodule(n).base.in_features for n in names)
check("expected_trainable = count_trainable = r * d_in", expected_trainable(model, r, "learned", suf) == count_trainable(model) == exp_manual,
      f"{expected_trainable(model, r, 'learned', suf)} / {count_trainable(model)} / {exp_manual}")
print("=== 4. B ne bouge pas pendant l'entrainement ; A bouge ===")
B0 = {n: m.B.detach().clone() for n, m in mods.items()}
opt = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=1e-2)
for _ in range(20):
    opt.zero_grad(); loss = ((model(x) - torch.randn(8, 32)) ** 2).mean(); loss.backward(); opt.step()
check("B inchange apres 20 pas", all(torch.equal(m.B.detach(), B0[n]) for n, m in lora_modules(model).items()))
check("A a bouge", all(float(m.A.detach().abs().max()) > 0 for m in lora_modules(model).values()))
print("=== 5. refus ===")
for lab, bad in (("base absente pour un module", {k: v for k, v in list(bases.items())[1:]}),
                 ("base non orthonormale", {k: (v * 2 if i == 0 else v) for i, (k, v) in enumerate(bases.items())}),
                 ("mauvaise forme", {k: (torch.linalg.qr(torch.randn(v.shape[0], 3))[0] if i == 0 else v) for i, (k, v) in enumerate(bases.items())})):
    fb = os.path.join(tmp, "bad.safetensors"); save_file({k: v.contiguous() for k, v in bad.items()}, fb)
    try:
        inject_lora(Toy(), r=r, mode="learned", target_suffixes=suf, learned_basis=fb); check(f"refuse : {lab}", False, "accepte a tort")
    except ValueError as e:
        check(f"refuse : {lab}", True, str(e)[:70])
print("=== 6. identifiant des runs ===")
base = dict(model="Qwen/Qwen2.5-1.5B", task="commonsense", rank=2, lr=2e-3, seed=2)
try:
    RunConfig(mode="learned", **base); check("learned sans fichier : refuse", False)
except ValueError:
    check("learned sans fichier : refuse", True)
c1 = RunConfig(mode="learned", learned_basis=f, **base)
f2 = os.path.join(tmp, "copie.safetensors"); shutil.copy(f, f2); c2 = RunConfig(mode="learned", learned_basis=f2, **base)
f3 = os.path.join(tmp, "autre.safetensors"); save_file({k: torch.linalg.qr(torch.randn(v.shape))[0].contiguous() for k, v in bases.items()}, f3)
c3 = RunConfig(mode="learned", learned_basis=f3, **base)
check("l'empreinte du fichier entre dans l'identifiant", "learned_basis_md5" in c1.id_dict() and "learned_basis" not in c1.id_dict())
check("meme contenu, autre chemin : meme identifiant", c1.run_id == c2.run_id, c1.run_id)
check("autres bases : autre identifiant", c1.run_id != c3.run_id, f"{c1.run_id} / {c3.run_id}")
for m in ("free", "top", "bottom", "random_ortho", "dual_top", "top_unfrozen"):
    d = RunConfig(mode=m, **base).id_dict()
    check(f"mode {m} : aucun champ learned_* dans l'identifiant", "learned_basis" not in d and "learned_basis_md5" not in d)
runs = sorted(glob.glob(os.path.expanduser("~/lora-runs/*/config.yaml")))[:300]
if runs:
    same = sum(RunConfig(**(yaml.safe_load(open(p)) or {})).run_id == os.path.basename(os.path.dirname(p)) for p in runs)
    print(f"  (runs existants : {same} / {len(runs)} identifiants retrouves a l'identique avec le code modifie)")
shutil.rmtree(tmp)
print("  TEST DU MODE learned : " + ("REUSSI" if ok else "ECHOUE -- aucun run learned ne doit partir"))
sys.exit(0 if ok else 1)
