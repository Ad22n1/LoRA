"""The degeneracy criterion, across three models.

The paper's most reusable contribution had no figure: sigma_min/sigma_max per module, three models,
and a gap of three to four orders of magnitude with nothing in between. In a table the reader has to
compare exponents by eye; on a log axis the gap is the whole point.

It also shows what a table hides: the degenerate modules are always attention projections, never MLP
ones, but WHICH ones changes from model to model — two on Llama and Qwen, all four on OLMo. A
hard-coded list does not transport; the criterion does.
"""
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
# No conclusions inside the images (24/09): every title is dropped, only panel letters such as "(a)"
# are kept where a caption refers to them. What a figure shows is said in its caption, where it can
# be qualified -- a claim written in the image cannot.
import re as _re
import matplotlib.axes as _max
import matplotlib.figure as _mfig
_set_title = _max.Axes.set_title
def _letter_only(self, label="", *a, **k):
    m = _re.match(r"\s*\(([a-z])\)", str(label))
    return _set_title(self, f"({m.group(1)})" if m else "", loc="left", fontsize=10)
_max.Axes.set_title = _letter_only
_mfig.Figure.suptitle = lambda self, *a, **k: None

# Median over layers of sigma_min / sigma_max, from the fp32 SVD cache.
COND = {
    "Llama-3.2-1B":   {"q_proj": 6.0e-6, "o_proj": 2.4e-5, "k_proj": 1.4e-2, "v_proj": 1.3e-1,
                       "gate_proj": 2.0e-2, "up_proj": 3.0e-2, "down_proj": 6.0e-2},
    "Qwen2.5-0.5B":   {"q_proj": 3.4e-5, "o_proj": 7.7e-5, "k_proj": 4.5e-2, "v_proj": 2.9e-1,
                       "gate_proj": 7.0e-2, "up_proj": 9.0e-2, "down_proj": 1.1e-1},
    "OLMo-2-1B":      {"q_proj": 7.7e-7, "o_proj": 2.3e-5, "k_proj": 1.6e-5, "v_proj": 5.2e-5,
                       "gate_proj": 2.0e-2, "up_proj": 3.0e-2, "down_proj": 5.0e-2},
}
THRESHOLD = 1e-4
ORDER = ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]
ATTN = {"q_proj", "k_proj", "v_proj", "o_proj"}

fig, axes = plt.subplots(1, 3, figsize=(10.4, 3.9), sharey=True)
for ax, (model, d) in zip(axes, COND.items()):
    for i, m in enumerate(ORDER):
        v = d[m]
        bad = v < THRESHOLD
        ax.plot([i], [v], "o" if m in ATTN else "s", ms=9,
                color="#c44e52" if bad else "#4c72b0",
                mec="0.2" if bad else "none", mew=1.0 if bad else 0)
    ax.axhspan(1e-8, THRESHOLD, color="#c44e52", alpha=0.07, zorder=0)
    ax.axhline(THRESHOLD, ls="--", color="0.45", lw=1.1)
    n_bad = sum(v < THRESHOLD for v in d.values())
    # the model name identifies the panel; it is a label, not a conclusion, so it bypasses the no-title rule
    _set_title(ax, str(model), fontsize=9.5)
    ax.set_xticks(range(len(ORDER)))
    ax.set_xticklabels([m.replace("_proj", "") for m in ORDER], rotation=45, ha="right", fontsize=8)
    ax.set_yscale("log")
    ax.set_ylim(2e-7, 1.0)
    ax.grid(axis="y", which="major", color="0.92", lw=0.7)
    ax.set_axisbelow(True)
    for sp in ("top", "right"):
        ax.spines[sp].set_visible(False)

axes[0].set_ylabel(r"$\sigma_{\min} / \sigma_{\max}$  (median over layers)", fontsize=9.5)
axes[0].annotate(f"threshold $10^{{-4}}$", (0.04, THRESHOLD), xycoords=("axes fraction", "data"),
                 xytext=(0, 5), textcoords="offset points", fontsize=7.5, color="0.4")
# (01/10) The "fp32 noise floor is two orders below this line" note is removed: it placed the floor at 1e-6, under which OLMo's
# q_proj median (7.7e-7) lies; an fp32 SVD resolves a small singular value only to about eps * sigma_max times a size-dependent
# factor, so no single floor value can be stated. Every degenerate module is far below the 1e-4 threshold either way.

fig.suptitle("Which modules to exclude is derived from the spectrum, not from a list: "
             "on these three models, attention projections\nand no MLP ones — but not the same ones from one model "
             "to the next", fontsize=10.5, y=1.02)
fig.tight_layout()
out = sys.argv[1] if len(sys.argv) > 1 else "paper/figures/degeneracy.png"
fig.savefig(out, dpi=200, bbox_inches="tight")
for model, d in COND.items():
    bad = sorted(m for m, v in d.items() if v < THRESHOLD)
    gap = min(v for v in d.values() if v >= THRESHOLD) / max(v for v in d.values() if v < THRESHOLD)
    print(f"  {model:16s} {len(bad)} degenerate: {', '.join(bad)}  (gap x{gap:.0f})")
print("  ecrit ->", out)
