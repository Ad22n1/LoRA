"""Main result: the four constrained arms at rank 2, with the free reference as a line.

The previous version of this figure labelled the dashed line "free r=1 (budget +7.5%)" while
plotting 0.802 — which is free at rank 2. free r=1 is 0.7919. The two differ by one point and the
budget claim only holds for r=1, so the label was wrong on both counts.
"""
import sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ARMS = [("bottom", 0.5645, 0.0177), ("top", 0.6443, 0.0122),
        ("random", 0.6521, 0.0099), ("random_ortho", 0.6534, 0.0091)]
FREE_R1, FREE_R2 = 0.7919, 0.8020
LOW, OTHER = "#c44e52", "#4c72b0"

fig, ax = plt.subplots(figsize=(6.4, 3.9))
xs = range(len(ARMS))
ax.bar(xs, [a[1] for a in ARMS], yerr=[a[2] for a in ARMS], capsize=4,
       color=[LOW] + [OTHER] * 3, alpha=0.9,
       error_kw=dict(lw=1.2, ecolor="0.25"))
for x, (_, v, e) in zip(xs, ARMS):
    ax.text(x, v + e + 0.018, f"{v:.3f}", ha="center", fontsize=9.5)

# The two reference lines sit one point apart, so their labels collide if both are placed at the
# line. Anchor them on opposite sides and offset the lower one downward.
ax.axhline(FREE_R1, ls="--", color="0.45", lw=1.2)
ax.axhline(FREE_R2, ls=":", color="0.45", lw=1.2)
ax.annotate(f"free r=1, +7.5 % budget: {FREE_R1:.3f}",
            xy=(-0.42, FREE_R1), xytext=(-0.42, FREE_R1 - 0.055),
            fontsize=8.2, color="0.3", ha="left",
            arrowprops=dict(arrowstyle="-", color="0.6", lw=0.7))
ax.annotate(f"free r=2, 2.15x budget: {FREE_R2:.3f}",
            xy=(len(ARMS) - 0.55, FREE_R2), xytext=(len(ARMS) - 0.55, FREE_R2 + 0.045),
            fontsize=8.2, color="0.3", ha="right",
            arrowprops=dict(arrowstyle="-", color="0.6", lw=0.7))

ax.set_xticks(list(xs))
ax.set_xticklabels([f"{a[0]}\n(n=5)" for a in ARMS], fontsize=9.5)
ax.set_ylabel("format_parsed", fontsize=10)
ax.set_ylim(0, 0.92)
ax.set_title("Rank 2, 614 items, per-arm selected learning rate\n"
             "error bars: s.d. over 5 paired seeds", fontsize=10)
ax.grid(axis="y", color="0.92", lw=0.7)
ax.set_axisbelow(True)
for sp in ("top", "right"):
    ax.spines[sp].set_visible(False)

fig.tight_layout()
out = sys.argv[1] if len(sys.argv) > 1 else "paper/figures/main_r2.png"
fig.savefig(out, dpi=200)
print("ecrit ->", out)
