#!/bin/bash
#SBATCH --partition=PARTITION
#SBATCH --time=00:30:00
#SBATCH --job-name=cache
#SBATCH --output=~/lora-results/cache-%j.out
source /tmp/lora-$USER/venv/bin/activate
cd $HOME/repo
python - <<'PY'
import sys, os, glob, yaml; sys.path.insert(0,'src')
try: from yaml import CSafeLoader as L
except ImportError: L = yaml.SafeLoader
from lorasub.aggregate import collect
d = collect(os.path.expanduser('~/lora-runs'))
m = {}
for p in glob.glob(os.path.expanduser('~/lora-runs/*/config.yaml')):
    m[os.path.basename(os.path.dirname(p))] = yaml.load(open(p), Loader=L) or {}
for c in ('seed','lr','mode','rank','update_norm_target','max_grad_norm','subspace_salted','band_frac'):
    d[c] = d.run_id.map(lambda r: (m.get(r) or {}).get(c))
d['nmod'] = d.run_id.map(lambda r: len((m.get(r) or {}).get('target_modules') or []))
d['mods'] = d.run_id.map(lambda r: tuple((m.get(r) or {}).get('target_modules') or []))
d.to_pickle(os.path.expanduser('~/lora-analysis/runs.pkl'))
print(f"{len(d)} runs en cache")
PY
