#!/bin/bash
# One-shot setup on a remote host, after scripts/cluster_probe.sh told you what the machine is.
# Idempotent: safe to re-run.  Installs nothing outside $SHARED.
#
#   export SHARED=/scratch/$USER/lora            # a writable path with ~100 GB
#   export CUDA_TAG=cu121                        # match the driver reported by nvidia-smi (cu118/cu121/cu124)
#   bash scripts/remote_setup.sh 2>&1 | tee $SHARED/setup.log
#
# Then, in a PARTITION session:  source $SHARED/venv/bin/activate && python scripts/preflight.py --model Qwen/Qwen2.5-0.5B

set -euo pipefail

: "${SHARED:?export SHARED=<writable path with ~100 GB> first (see scripts/cluster_probe.sh section 4)}"
CUDA_TAG="${CUDA_TAG:-cu121}"
REPO="$(cd "$(dirname "$0")/.." && pwd)"

echo "repo   : $REPO"
echo "SHARED : $SHARED"
echo "cuda   : $CUDA_TAG"

mkdir -p "$SHARED"/{hf,data,svd,runs,logs,analysis}
export HF_HOME="$SHARED/hf"

if [ ! -d "$SHARED/venv" ]; then
  echo "--- creating venv"
  python3 -m venv "$SHARED/venv"
fi
# shellcheck disable=SC1091
source "$SHARED/venv/bin/activate"
python -m pip install -q --upgrade pip setuptools wheel

if ! python -c "import torch" 2>/dev/null; then
  echo "--- installing torch ($CUDA_TAG)"
  # --extra-index-url, not --index-url: the latter *replaces* the default index, so build
  # dependencies (flit_core, setuptools) become unreachable and the install fails on a fresh node.
  pip install -q torch --extra-index-url "https://download.pytorch.org/whl/$CUDA_TAG"
fi
echo "--- installing project requirements"
pip install -q -r "$REPO/requirements.txt"
pip install -q -e "$REPO"

echo
echo "--- versions"
python - <<'PY'
import torch, transformers, datasets
print("torch       ", torch.__version__, "| cuda available:", torch.cuda.is_available())
if torch.cuda.is_available():
    print("PARTITION         ", torch.cuda.get_device_name(0),
          "| bf16:", torch.cuda.is_bf16_supported(),
          "| mem GB:", round(torch.cuda.get_device_properties(0).total_memory / 1e9, 1))
else:
    print("PARTITION          none visible here (login node? ask for an interactive PARTITION session)")
print("transformers", transformers.__version__)
print("datasets    ", datasets.__version__, "(>=4 -> Parquet mirror is used for CoNLL)")
for opt in ("peft", "bitsandbytes", "lm_eval", "flash_attn"):
    try:
        m = __import__(opt); print(f"{opt:12}", getattr(m, "__version__", "yes"))
    except Exception:
        print(f"{opt:12} absent (optional)")
PY

echo
echo "--- tests (CPU, ~1 min)"
cd "$REPO" && python -m pytest -q | tail -3

cat <<EOF

Setup done.  Next, in a session that has a PARTITION:

  source $SHARED/venv/bin/activate
  export SHARED=$SHARED HF_HOME=$SHARED/hf
  huggingface-cli login            # once, for gated models (Llama)
  python scripts/preflight.py --model Qwen/Qwen2.5-0.5B 2>&1 | tee $SHARED/logs/preflight.log

If huggingface.co is unreachable from compute nodes, prefetch here and add
HF_HUB_OFFLINE=1 (and CONLL_DIR=<dir> for the format data) when running jobs.
EOF
