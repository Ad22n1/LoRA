"""Read the four campaigns in flight, in one pass, and say what each one decides.

Each has a criterion written before it was launched. This file reads them against those criteria
rather than against whatever the numbers suggest afterwards, and refuses to conclude on a campaign
that has not finished.
"""
import os
import sys

import pandas as pd
import yaml

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from lorasub.aggregate import collect  # noqa: E402

RUNS = os.path.expanduser("~/lora-runs")
ANA = os.path.expanduser("~/lora-analysis")


def head(t):
    print(f"\n{'=' * 78}\n {t}\n{'=' * 78}")


def curvature():
    head("1. CURVATURE with restarts — does the ratio of 12 survive?")
    p = os.path.join(ANA, "curvature_5seeds_restarts.csv")
    if not os.path.exists(p):
        print("  not written yet"); return
    d = pd.read_csv(p)
    d["spread"] = d.curvature_max / d.curvature_min.replace(0, float("nan"))
    g = d.groupby("mode").agg(lam=("curvature_median", "median"),
                              spread=("spread", "median"),
                              n=("curvature_median", "size"))
    print(g.round(3).to_string())
    if {"bottom", "top"} <= set(g.index):
        r = g.loc["bottom", "lam"] / g.loc["top", "lam"]
        print(f"\n  ratio bottom/top : {r:.2f}   (paper says 12.04; the unstable rerun said 8.98)")
        print(f"  lambda*lr bottom : {g.loc['bottom', 'lam'] * 2e-3:.3f}   (paper says 0.662)")
    bad = g[g.spread > 10]
    print(f"\n  arms whose batches still disagree by more than 10x: "
          f"{list(bad.index) if len(bad) else 'none — the restarts fixed it'}")


def qwen():
    head("2. QWEN at fifteen seeds — frozen protocol, one-sided, Bonferroni 0.0125")
    import statistics as st
    d = collect(RUNS)
    tab = (yaml.safe_load(open("configs/lr_selected.yaml")) or {})["selected"]
    q = d[(d["mode"] == "band") & d.model.astype(str).str.contains("Qwen")
          & d.seed.between(2, 16)]
    q = q[q.apply(lambda r: abs(float(r.lr) - tab.get(
        f"Qwen/Qwen2.5-0.5B|format|band|2|b{float(r.band_frac):g}", -1)) < 1e-12, axis=1)]
    p = q.pivot_table(index="seed", columns="band_frac", values="format_parsed")
    n = int(p.notna().all(axis=1).sum())
    print(f"  {len(q)} runs, {n} seeds complete on all five positions")
    if n < 15:
        print(f"  *** NOT FINISHED: the protocol fixed the population at fifteen seeds.")
        print(f"      Reading it now is what that protocol exists to forbid.")
        return
    p = p.dropna()
    m = p.mean()
    print("\n" + m.round(4).to_string())
    best = m.idxmax()
    print(f"\n  best position: beta = {best:g}" +
          ("  (same as Llama)" if abs(best - 0.75) < 1e-9 else "  *** NOT 0.75"))
    passed = []
    for o in sorted(c for c in p.columns if abs(c - best) > 1e-9):
        dif = (p[best] - p[o]).values
        k = len(dif)
        t = st.mean(dif) / (st.stdev(dif) / k ** 0.5)
        print(f"  vs beta={o:<5g} : {st.mean(dif) * 100:+6.2f} pt | t = {t:5.2f} | "
              f"{sum(v > 0 for v in dif)}/{k} seeds")
        # 2.510 is the ONE-SIDED critical value at 14 d.f. for 0.0125 (Bonferroni over four
        # comparisons). 2.98 is the TWO-SIDED one, and using it would have silently rejected
        # comparisons the frozen protocol counts as passing.
        if t > 2.510:
            passed.append(o)
    print(f"\n  pass Bonferroni (one-sided, 14 d.f., t > 2.510): "
          f"{[f'{b:g}' for b in passed] if passed else 'none'}")


def bracket():
    head("3. UNCLIPPED BRACKET — is there one threshold in lambda*lr?")
    LAM = {"bottom": 330.88, "top": 27.48, "random": 26.29, "random_ortho": 24.38}
    d = collect(RUNS)
    x = d[(d.task == "format") & (d["rank"] == 2) & (d.n_modules == 7)
          & d.model.astype(str).str.contains("Llama")
          & d.update_norm_target.isna() & (d.max_grad_norm > 100)
          & d["mode"].isin(LAM)]
    g = x.groupby(["mode", "lr"]).format_parsed.agg(["mean", "size"]).reset_index()
    rows = []
    for m, sub in g.groupby("mode"):
        alive, dead = sub[sub["mean"] > 0.05].lr, sub[sub["mean"] <= 0.05].lr
        rows.append(dict(mode=m, holds_to=LAM[m] * alive.max() if len(alive) else float("nan"),
                         dies_at=LAM[m] * dead.min() if len(dead) else float("nan"),
                         n_rates=len(sub)))
    out = pd.DataFrame(rows).set_index("mode")
    print(out.round(3).to_string())
    u = out.dropna()
    missing = list(out.index.difference(u.index))
    if missing:
        print(f"\n  *** NOT BRACKETED: {missing} — no survivor or no collapse measured")
    if len(u) >= 2:
        lo, hi = u.holds_to.max(), u.dies_at.min()
        print(f"\n  intersection over {list(u.index)}: ({lo:.2f} ; {hi:.2f})  "
              f"-> {'NON-EMPTY' if lo < hi else 'EMPTY'}")
        if lo >= hi:
            print(f"  `{u.holds_to.idxmax()}` still trains at {lo:.2f} where others are dead "
                  f"at {hi:.2f}: lambda*lr is not what bounds the step.")


def facts64():
    head("4. FACTS r=64 low rates — was bottom's optimum at the grid edge?")
    d = collect(RUNS)
    x = d[(d.task == "facts") & (d["rank"] == 64) & d.seed.isin([2, 3, 4, 5, 6])]
    t = x.pivot_table(index="lr", columns="mode", values="mcq_acc", aggfunc="mean")
    n = x.groupby(["mode", "lr"]).size().unstack(fill_value=0)
    print(t.round(4).to_string())
    low = [c for c in t.index if c < 1e-3]
    if not low:
        print("\n  the low rates have not landed yet"); return
    print(f"\n  runs per cell at the low rates:\n{n[low].to_string() if len(low) else ''}")
    for m in t.columns:
        if t[m].notna().sum() < 2:
            continue
        best = t[m].idxmax()
        edge = " *** STILL AT THE EDGE" if best == t[m].dropna().index.min() else ""
        print(f"  {m:8s} best at {best:g}{edge}")


if __name__ == "__main__":
    for f in (curvature, qwen, bracket, facts64):
        try:
            f()
        except Exception as e:
            print(f"\n  [{f.__name__}] failed: {type(e).__name__}: {e}")
