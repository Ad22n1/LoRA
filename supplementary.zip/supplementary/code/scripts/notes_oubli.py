"""Notes 1 and 5 of the paper: recompute the forgetting tests marked with a dagger, on the corrected re-measurement. No PARTITION.

    python scripts/notes_oubli.py

Sources: every ~/lora-analysis/forgetting*.csv; for each cell, the most recent file holding its five seeds (printed).
GUARD 1: the perplexity column is found by its values: it must give, at each arm's selected rate on seeds 2 to 6, the values the
re-measurement's files give (top 40.64, random 24.94, random_ortho 26.31 at 1e-2; free r=2 23.81 at 2e-3), to 0.02. Otherwise: stop.
GUARD 2: a test is computed only if both cells have the five seeds; a missing cell is reported, never filled.
The four dagger rows of the tests table:
  (a) common rate 2e-3, each arm against top;
  (b) selected rates, each arm against bottom at its former rate 2e-3 (random, free, random_ortho, top);
  (c) (b) on log-perplexity, top against bottom;
  (d) top against random at 1e-2, with its 95 % interval (note 1).
"""
import csv
import math
import os
import statistics as st

import glob
S = [2, 3, 4, 5, 6]
T4 = 2.776
# Every forgetting file of ~/lora-analysis (26/09): forgetting.csv is the FIRST measurement (17/09); the corrected re-measurement
# of 24/09 is in forgetting_recheck_*.csv. For each cell, the MOST RECENT file that holds its five seeds is used, and printed.
FILES = sorted((f for f in glob.glob(os.path.expanduser("~/lora-analysis/forgetting*.csv")) if os.path.getsize(f) > 0), key=os.path.getmtime)
print(f"  {len(FILES)} fichiers d'oubli, du plus ancien au plus recent : " + ", ".join(os.path.basename(f) for f in FILES))


def num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def cells(col):
    """(mode, rank, lr) -> ({seed: value}, file), from the most recent file holding the five seeds of that cell."""
    out = {}
    for f in FILES:                                   # oldest first: a later file overwrites an earlier one
        per = {}
        for r in csv.DictReader(open(f)):
            v, s = num(r.get(col)), num(r.get("seed"))
            if v is None or s is None or int(s) not in S or r.get("mode") in (None, "baseline"):
                continue
            per.setdefault((r["mode"], int(float(r["rank"])), float(r["lr"])), {}).setdefault(int(s), []).append(v)
        for k, d in per.items():
            if len(d) == 5:
                out[k] = ({s_: st.mean(v_) for s_, v_ in d.items()}, os.path.basename(f), {s_: len(v_) for s_, v_ in d.items() if len(v_) > 1})
    return out


# values of the re-measurement, READ FROM ITS FILES on 26/09 (not from our notes, which said 24.97 for random: a copying error)
EXPECT = {("top", 2, 1e-2): 40.64, ("random", 2, 1e-2): 24.94, ("random_ortho", 2, 1e-2): 26.31, ("free", 2, 2e-3): 23.81}


def key_of(c, mode, rank, lr):
    return next((k for k in c if k[0] == mode and k[1] == rank and abs(k[2] - lr) < 1e-12), None)


columns = sorted({k for f in FILES for k in (next(csv.DictReader(open(f)), None) or {})} - {"mode", "rank", "lr", "seed", "run"})
col = None
for cand in columns:
    c = cells(cand)
    if all((k := key_of(c, m, rk, lr)) is not None and abs(st.mean(c[k][0].values()) - val) <= 0.02 for (m, rk, lr), val in EXPECT.items()):
        col = cand; break
if col is None:
    raise SystemExit("  ARRET : aucune colonne ne redonne les valeurs remesurees (40,64 ; 24,94 ; 26,31 ; 23,81)")
C = cells(col)
print(f"  colonne de perplexite : {col}")
for k in sorted(C, key=str):
    if k[1] in (1, 2) and k[0] in ("top", "bottom", "random", "random_ortho", "free"):
        d, f, dup = C[k]
        print(f"    {k[0]:13s} r={k[1]} lr={k[2]:g} : {st.mean(d.values()):7.2f}   <- {f}" + (f"  DOUBLONS {dup}" if dup else ""))


def get(mode, rank, lr):
    k = key_of(C, mode, rank, lr)
    return None if k is None else C[k][0]


def paired(a, b, f=lambda x: x):
    d = [f(a[s]) - f(b[s]) for s in S]; m = st.mean(d); se = st.stdev(d) / 5 ** 0.5
    return m, (m / se if se > 0 else float("inf")), m - T4 * se, m + T4 * se


def line(lab, a, b, f=lambda x: x):
    if a is None or b is None:
        print(f"    {lab:44s} ABSENT de la remesure : non calcule"); return
    m, t, lo, hi = paired(a, b, f)
    print(f"    {lab:44s} {m:+7.2f}  t = {t:+6.2f}  IC95 [{lo:+.2f}, {hi:+.2f}]")


print("\n  (a) taux commun 2e-3, chaque bras contre top :")
top2 = get("top", 2, 2e-3)
for a, rk in (("random_ortho", 2), ("bottom", 2), ("free", 2), ("random", 2)):
    line(f"{a} - top", get(a, rk, 2e-3), top2)
print("\n  (b) taux retenus, chaque bras contre bottom a son ancien taux 2e-3 :")
bot = get("bottom", 2, 2e-3)
for a, rk, lr in (("random", 2, 1e-2), ("free", 2, 2e-3), ("random_ortho", 2, 1e-2), ("top", 2, 1e-2)):
    line(f"{a} ({lr:g}) - bottom (2e-3)", get(a, rk, lr), bot)
print("\n  (c) la meme chose en log-perplexite, top contre bottom :")
line("log top (1e-2) - log bottom (2e-3)", get("top", 2, 1e-2), bot, f=math.log)
print("\n  (d) top contre random a 1e-2 (note 1) :")
line("top - random, a 1e-2", get("top", 2, 1e-2), get("random", 2, 1e-2))
print("\n  seuils : (a) et (b), t > 4,31 (quatre comparaisons) ; (c) t > 4,31 ; (d) t > 2,776")
