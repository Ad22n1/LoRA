"""Is `bottom`'s collapse at 5e-3 a property of the configuration, or a single bad run?

Section `regimes` reports that one seed in five fails to converge when `bottom` runs at 5e-3 with
clipping at 1.0, and the tie-break in section `limits` overrides the selection rule because of it.
Both statements rest on runs that scored 0.000.

The beta sweep gives an independent test the paper never used: beta = 1 IS `bottom` by construction
(s = floor(band_frac * (m - r)), so beta = 1 takes U[:, m-r:m]), it runs at 5e-3, and it clips at
1.0. Seven seeds there are seven more draws from exactly the configuration said to fail one time in
five. If none of them collapses, the failure rate is not one in five.

A run that scored 0.000 and one that scored 0.55 in the same cell cannot both be the configuration
behaving as designed. This file counts them.
"""
import glob
import os
import sys

import pandas as pd
import yaml

RUNS = os.path.expanduser("~/lora-runs")
FAILED = []


def check(name, ok, detail=""):
    print(f"  [{'ok ' if ok else 'FAIL'}] {name}" + (f"\n         {detail}" if detail else ""))
    if not ok:
        FAILED.append(name)


def rows():
    for p in glob.glob(os.path.join(RUNS, "*", "config.yaml")):
        d = os.path.dirname(p)
        r = os.path.join(d, "results.csv")
        if not os.path.exists(r):
            continue
        y = yaml.safe_load(open(p)) or {}
        try:
            t = pd.read_csv(r)
            sc = float(t.format_parsed.iloc[0])
        except Exception:
            continue
        yield dict(run=os.path.basename(d), model=str(y.get("model")), mode=y.get("mode"),
                   band_frac=y.get("band_frac"), seed=y.get("seed"),
                   lr=float(y.get("lr") or 0), rank=y.get("rank"),
                   clip_at=float(y.get("max_grad_norm") or 0),
                   norm_target=y.get("update_norm_target"),
                   nmod=len(y.get("target_modules") or []),
                   evl=y.get("eval_limit") or 0, score=sc,
                   PARTITION=str(t.PARTITION.iloc[0]) if "PARTITION" in t else None)


def main():
    d = pd.DataFrame(rows())
    # the configuration the collapse is attributed to
    # WITHOUT the model filter this mixes Llama and Qwen: the beta sweep exists on both, and the
    # Qwen scores at beta = 1 (0.4723, 0.5212, ...) look like plausible Llama runs. They are not.
    cfg = d[d.model.str.contains("Llama") & (d["rank"] == 2) & (abs(d.lr - 5e-3) < 1e-12)
            & (d.clip_at == 1.0) & d.norm_target.isna() & (d.nmod == 7) & (d.evl >= 6000)]
    bot = cfg[cfg["mode"] == "bottom"]
    band = cfg[(cfg["mode"] == "band") & (cfg.band_frac.astype(float).round(6) == 1.0)]

    print("\n=== A. beta = 1 is `bottom`: same rate, same clipping, same subspace ===")
    check("the beta sweep clips at 1.0 like everything else",
          bool(len(band)) and set(band.clip_at) == {1.0},
          f"{len(band)} runs at clip={sorted(set(band.clip_at))}")
    check("no rescaled or reduced-module run contaminates either group",
          bool(cfg.norm_target.isna().all() and set(cfg.nmod) == {7}))

    print("\n=== B. how often does it actually collapse? ===")
    for lab, g in (("`bottom`", bot), ("beta = 1", band)):
        z = int((g.score <= 0.05).sum())
        print(f"         {lab:10s} {z} collapse(s) out of {len(g)}   "
              f"seeds {sorted(g.seed.tolist())}")
    tot_z = int((pd.concat([bot, band]).score <= 0.05).sum())
    tot_n = len(bot) + len(band)
    print(f"\n         pooled: {tot_z}/{tot_n} = {100 * tot_z / max(tot_n, 1):.0f}%, "
          f"against the 20% the paper reports")
    check("the collapse rate is well below one in five",
          tot_n >= 8 and tot_z / tot_n < 0.12,
          "if this holds, `one seed in five` describes an incident, not a failure rate")

    print("\n=== C. the same cell, run more than once ===")
    for s in sorted(set(bot.seed) | set(band.seed)):
        g = pd.concat([bot, band])
        g = g[g.seed == s]
        if len(g) < 2:
            continue
        print(f"         seed {s}: " + " | ".join(
            f"{r.score:.4f} ({r.PARTITION or 'card not recorded'})" for r in g.itertuples()))
    dup = pd.concat([bot, band]).groupby("seed").score.agg(["min", "max", "size"])
    split = dup[(dup["size"] >= 2) & (dup["min"] <= 0.05) & (dup["max"] > 0.4)]
    check("no seed both collapses AND converges in the same configuration",
          split.empty,
          "a seed that does both means the run, not the configuration, is what failed"
          if not split.empty else "")

    print("\n=== D. does the collapsed run predate the instrumentation? ===")
    z = pd.concat([bot, band])
    z = z[z.score <= 0.05]
    for r in z.itertuples():
        print(f"         {r.run}  seed={r.seed}  PARTITION={r.PARTITION or 'NOT RECORDED'}")
    check("every collapsed run is one we can attribute to a card",
          bool(z.empty or z.PARTITION.notna().all()),
          "a run with no card recorded predates the logging and cannot be diagnosed")

    print("\n" + "=" * 70)
    if FAILED:
        print(f"  {len(FAILED)} CHECK(S) FAILED -- read each one: a failure here is the finding.")
        for f in FAILED:
            print(f"    - {f}")
    else:
        print("  every check passed.")


if __name__ == "__main__":
    main()
