"""Three summary figures, every value copied from internal notes (source noted next to it).
Cells not read yet are drawn as PENDING, never guessed.

    python scripts/fig_summary.py paper/figures        # writes results_map.png, rank_dependence.png, sigma_rates.png

1. results_map     -- configurations x questions, coloured by outcome, marked when pre-registered
2. rank_dependence -- format task, ranks 2/4/8/16: the arm-by-rate interaction (inversion) and freezing minus choosing
3. sigma_rates     -- the rate each arm selects, log scale: the direction of the shift reverses with Sigma
"""
import sys

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.patches import Patch  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else "."

# ---------------------------------------------------------------------------------------------------- 1. the map
# outcome codes: E established, N not established, R reversed and established, T not testable, P pending
COL = {"E": "#4a8c5c", "C": "#8fc49d", "D": "#cfe6d4", "N": "#d9d9d9", "R": "#c0504d", "T": "#ffffff", "P": "#fff4cc"}
LAB = {"E": "established", "C": "prediction confirmed\n(selection, not a test)", "D": "observed, descriptive", "N": "not established", "R": "reversed, established", "T": "not testable or not computed", "P": "pending"}
QUESTIONS = ["rate shift\n(bottom selects\na lower rate)", "inversion at\na common rate", "gap to free LoRA\nexceeds the spread\namong frozen arms",
             "change in the gap\nbetween bands once\nB is trained"]
# (row label, [(outcome, pre-registered?, short note) per question])
ROWS = [
    ("format, rank 2",       [("C", True, "5 seeds: confirmed"), ("E", False, "t = 55.7"), ("E", False, "+5.4"), ("E", True, "+6.78,\nfresh seeds")]),   # journal: rank 2 ; shift5 ; exp. 1, pre-registered on fresh seeds 120-124
    ("format, rank 2, Qwen2.5-0.5B", [("D", False, "half the rate"), ("E", False, "t = 9.2"), ("T", False, "not computed"), ("T", False, "not tested")]),
    ("format, rank 2, Qwen2.5-1.5B", [("D", False, "lower (5e-3)"), ("E", False, "t = 9.0"), ("E", True, "+13.36"), ("T", True, "no frozen gap\n(+1.34, floor)")]),   # fmtq, 26/09 ; e1q 27/09, below the floor
    ("format, rank 4",       [("D", False, "partial"), ("E", False, "t = 9.7"), ("E", True, "+5.44"), ("T", False, "not tested")]),
    ("format, rank 8",       [("N", True, "partial"), ("T", True, "rates coincide"), ("E", True, "+6.42"), ("T", False, "not tested")]),
    ("format, rank 16",      [("C", True, "confirmed"), ("N", True, "t = 0.7-2.8"), ("N", True, "+1.69"), ("N", True, "sign flip")]),  # exp. 1 at rank 16
    ("format, rank 16, Qwen2.5-1.5B", [("D", False, "lower (1e-3)"), ("T", False, "not tested"), ("N", True, "+4.59"), ("T", False, "not tested")]),  # fmtq, 26/09
    ("format, rank 2, 2x budget", [("C", True, "confirmed"), ("N", True, "not reproduced"), ("E", True, "+3.62"), ("T", False, "not tested")]),
    ("OpenBookQA, rank 2",   [("D", True, "2 seeds: yes;\n5 seeds: partial"), ("N", True, "bottom behind"), ("E", True, "+3.72"), ("E", True, "+3.84")]),   # shift5 ; OBQA unfrozen
    ("OpenBookQA, rank 2, Qwen2.5-7B", [("D", False, "lower (5e-4, edge)"), ("T", False, "not tested"), ("D", False, "+4.92"), ("E", True, "+4.96")]),   # scale, 27/09
    ("format, rank 2, 4x training", [("D", False, "lower (5e-3)"), ("T", False, "not tested"), ("T", False, "not computed\n(two frozen arms)"), ("E", True, "+6.25")]),   # long, 27/09
    ("OpenBookQA, rank 2, Mistral-7B", [("D", False, "same rate (1e-3)"), ("T", False, "not tested"), ("D", False, "+12.24"), ("N", True, "+0.48 (no\nfrozen gap)")]),   # mscale, 27/09
    ("OpenBookQA, rank 16",  [("D", False, "lowest rate"), ("N", True, "bottom last"), ("N", True, "-2.16"), ("T", False, "not tested")]),
    ("ARC-Challenge, rank 2", [("D", False, "lower (2e-3)"), ("T", False, "not tested"), ("N", True, "+0.28"), ("T", False, "not tested")]),
    ("ARC-Easy, rank 16",    [("D", False, "higher than top"), ("N", True, "bottom behind"), ("R", True, "-2.08"), ("T", False, "not tested")]),
    ("ARC-Challenge, rank 16", [("D", False, "higher than top"), ("T", True, "one common rate"), ("R", True, "-5.36"), ("E", True, "+4.28")]),  # exp. 1 at rank 16
    ("ARC-Challenge, rank 32", [("D", False, "lower (2e-4)"), ("T", False, "not tested"), ("R", True, "-2.74"), ("T", False, "not tested")]),
]
fig, ax = plt.subplots(figsize=(11.6, 8.8))
# display order: the argument of the paper first (freezing against choosing, the gap between bands), then the rate questions.
# ROWS keeps its data order (fig_these.py reads the freezing column by position); only the drawing is permuted.
ORDER = [2, 3, 0, 1]
for i, (lab, cells) in enumerate(ROWS):
    for j, (o, pre, note) in enumerate(cells[k] for k in ORDER):
        ax.add_patch(plt.Rectangle((j, i), 1, 1, facecolor=COL[o], edgecolor="0.55", lw=0.8,
                                   hatch="///" if o == "P" else None))
        ax.text(j + 0.5, i + 0.5, note, ha="center", va="center", fontsize=12,
                color="white" if o in ("E", "R") else "0.2")
        if pre:
            ax.text(j + 0.95, i + 0.12, "\u25cf", ha="right", va="top", fontsize=10, color="white" if o in ("E", "R") else "0.35")
ax.set_xlim(0, 4); ax.set_ylim(len(ROWS), 0)
ax.set_xticks([0.5, 1.5, 2.5, 3.5]); ax.set_xticklabels([QUESTIONS[k] for k in ORDER], fontsize=12); ax.xaxis.tick_top()
ax.set_yticks([i + 0.5 for i in range(len(ROWS))]); ax.set_yticklabels([r[0] for r in ROWS], fontsize=12.5)
for s in ax.spines.values(): s.set_visible(False)
ax.tick_params(length=0)
present = {o for _, cells in ROWS for o, _, _ in cells}   # the legend lists only the outcomes that appear
handles = [Patch(facecolor=COL[k], edgecolor="0.55", hatch="///" if k == "P" else None, label=LAB[k]) for k in ("E", "C", "D", "N", "R", "T", "P") if k in present]
handles.append(plt.Line2D([], [], marker="o", color="w", markerfacecolor="0.35", markersize=5, label="pre-registered"))
fig.legend(handles=handles, loc="lower center", ncol=3, fontsize=12, frameon=False, bbox_to_anchor=(0.5, 0.0))
fig.tight_layout(rect=(0, 0.11, 1, 1))
fig.savefig(f"{OUT}/results_map.png", dpi=200, bbox_inches="tight", pad_inches=0.08); plt.close(fig)

# ---------------------------------------------------------------------------------------------------- 2. rank dependence
import matplotlib.transforms as mtrans  # noqa: E402
T4 = 2.776   # two-sided t quantile, 4 d.f.: an interval from a mean and its t is mean +/- T4 * mean / t
def ci_from_t(m, t): half = T4 * abs(m / t); return m - half, m + half
# (a) the arm-by-rate interaction against top, a fixed competitor: how far bottom's gap to top swings between the low
# and the high common rate, in points. (mean, t, established?, the two common rates as printed under the rank)
#   ranks 2 and 4: the rates of the original comparison, fixed before the rule existed; ranks 8 and 16: the pre-registered rule
INTER = {2: (18.50, 55.70, True, "2e-3 / 1e-2"), 4: (21.79, 9.74, True, "2e-3 / 1e-2"), 16: (0.85, 0.69, False, "5e-4 / 2e-3")}
NOT_TESTABLE = {8: "2e-3 only"}      # the rule yields a single common rate: no point is drawn, not even a descriptive one
# (b) freezing minus choosing at each arm's selected rate: (mean, low, high, established?)
FC = {2: (5.4, 2.3, 7.0, True), 4: (5.44, 2.98, 7.42, True), 8: (6.42, 3.09, 7.33, True), 16: (1.69, -0.81, 3.39, False)}
# ARC-Challenge, Qwen2.5-1.5B, pre-registered at every rank (26/09): another task and another model, not compared point by point
FC_ARC = {2: (0.28, -1.74, 2.34, False), 16: (-5.36, -7.48, -3.24, True), 32: (-2.74, -4.98, -0.60, True)}
# the format task on Qwen2.5-1.5B, pre-registered on fresh seeds (scripts/read_fmtq.py, 26/09): the model of ARC, the task of Llama
FC_QWEN = {2: (13.36, 11.30, 14.20, True), 16: (4.59, -0.52, 6.09, False)}
PURPLE, FS3 = "#8064a2", 11.8
GREEN = "#6a9a3c"
RED, BLUE = "#c0504d", "#4f81bd"
fig, (a1, a2) = plt.subplots(1, 2, figsize=(9.4, 4.0))
for r, (m, t, est, _) in INTER.items():
    lo, hi = ci_from_t(m, t)
    a1.errorbar([r], [m], yerr=[[m - lo], [hi - m]], fmt="o", color=RED, mfc=RED if est else "white", mew=1.8, capsize=4, ms=7)
a1.plot([2, 4], [INTER[2][0], INTER[4][0]], ":", color=RED, lw=1)     # never across rank 8, where nothing was tested
# a hatched band over the whole column, the cross and its label inside it: the column has no measurement. A cross
# floating among the values would read as one (on the zero line, a null effect; below it, a negative one).
trx = mtrans.blended_transform_factory(a1.transData, a1.transAxes)
for r in NOT_TESTABLE:
    a1.axvspan(r / 1.22, r * 1.22, color="0.93", hatch="///", edgecolor="0.8", lw=0, zorder=0)
    # no cross: a marker at mid-height would read as a value; the band and its label say that nothing was measured
    a1.text(r, 0.96, "not\ntestable", ha="center", va="top", fontsize=FS3, color="0.35", transform=trx)
a1.axhline(0, color="0.6", lw=0.8)
a1.set_ylabel("arm \u00d7 rate interaction (points)", fontsize=FS3 + 0.5); a1.set_title("(a)", loc="left", fontsize=FS3 + 0.5)
for r, (m, lo, hi, est) in FC.items():
    a2.errorbar([r], [m], yerr=[[m - lo], [hi - m]], fmt="s", color=BLUE, mfc=BLUE if est else "white", mew=1.8, capsize=4, ms=7)
a2.plot(sorted(FC), [FC[r][0] for r in sorted(FC)], ":", color=BLUE, lw=1)
for r, (m, lo, hi, est) in FC_ARC.items():         # shifted right by 8 % so that the two series never overlap
    a2.errorbar([r * 1.08], [m], yerr=[[m - lo], [hi - m]], fmt="^", color=GREEN, mfc=GREEN if est else "white", mew=1.8, capsize=4, ms=7)
# joined only between adjacent measured ranks (16 and 32): no line crosses ranks 4 and 8, where ARC was not run
a2.plot([16 * 1.08, 32 * 1.08], [FC_ARC[16][0], FC_ARC[32][0]], ":", color=GREEN, lw=1)
for r, (m, lo, hi, est) in FC_QWEN.items():        # shifted left by 8 %; ranks 2 and 16 are not adjacent measured ranks: no line
    a2.errorbar([r / 1.08], [m], yerr=[[m - lo], [hi - m]], fmt="D", color=PURPLE, mfc=PURPLE if est else "white", mew=1.8, capsize=4, ms=6.5)
a2.legend(handles=[plt.Line2D([], [], marker="s", color=BLUE, ls=":", label="format task, Llama-3.2-1B"),
                   plt.Line2D([], [], marker="D", color=PURPLE, ls="", label="format task, Qwen2.5-1.5B"),
                   plt.Line2D([], [], marker="^", color=GREEN, ls=":", label="ARC-Challenge, Qwen2.5-1.5B")],
          fontsize=FS3, frameon=False, loc="upper right")
a2.axhline(0, color="0.6", lw=0.8)
a2.set_ylabel("gap minus spread (points)", fontsize=FS3 + 0.5); a2.set_title("(b)", loc="left", fontsize=FS3 + 0.5)
for a, ranks in ((a1, [2, 4, 8, 16]), (a2, [2, 4, 8, 16, 32])):
    a.set_xscale("log", base=2); a.set_xticks(ranks); a.set_xticklabels([str(r) for r in ranks]); a.minorticks_off()
    a.set_xlim(1.6, 20 if a is a1 else 40); a.set_xlabel("rank", labelpad=18, fontsize=FS3 + 0.5); a.tick_params(labelsize=FS3)
    for sp in ("top", "right"): a.spines[sp].set_visible(False)
# the two common rates under each rank of panel (a), small: the rates behind each point, for transparency
tr = mtrans.blended_transform_factory(a1.transData, a1.transAxes)
for r, txt in list((k, v[3]) for k, v in INTER.items()) + list(NOT_TESTABLE.items()):
    a1.text(r, -0.13, txt, transform=tr, ha="center", va="top", fontsize=FS3 - 0.5, color="0.35")
fig.tight_layout()
fig.savefig(f"{OUT}/rank_dependence.png", dpi=200, bbox_inches="tight", pad_inches=0.08); plt.close(fig)

# ---------------------------------------------------------------------------------------------------- 3. Sigma
# selected rates, Llama-3.2-1B, rank 2, format task (seven modules; five for the second column)
RATES = [("top", 1e-2, 1e-2), ("bottom", 5e-3, None), ("top_scalar", 5e-3, None), ("top_sigma", 5e-3, 5e-3), ("bottom_sigma", 2e-2, 2e-2)]
fig, ax = plt.subplots(figsize=(6.4, 3.2))
colors = {"top": "#4f81bd", "bottom": "#c0504d", "top_scalar": "#8064a2", "top_sigma": "#4f81bd", "bottom_sigma": "#c0504d"}
for i, (arm, r7, r5) in enumerate(RATES):
    filled = arm.endswith("sigma") or arm == "top_scalar"
    ax.plot([r7], [i], "o", ms=9, color=colors[arm], mfc=colors[arm] if not filled else "white", mew=2)
    if r5 is not None and arm.endswith("sigma"):
        ax.plot([r5], [i + 0.22], "D", ms=5, color=colors[arm], alpha=0.7)
ax.annotate("", xy=(5e-3, 1), xytext=(1e-2, 1), arrowprops=dict(arrowstyle="-|>", color="0.4", lw=1.2))
ax.annotate("", xy=(2e-2, 4), xytext=(5e-3, 4), arrowprops=dict(arrowstyle="-|>", color="0.4", lw=1.2))
ax.set_xscale("log"); ax.set_xlim(2e-3, 5e-2)
ax.set_yticks(range(len(RATES))); ax.set_yticklabels([r[0] for r in RATES], fontsize=9, family="monospace"); ax.invert_yaxis()
ax.set_xlabel("selected learning rate (validation, selection seeds)")
ax.set_xticks([2e-3, 5e-3, 1e-2, 2e-2, 5e-2]); ax.set_xticklabels(["2e-3", "5e-3", "1e-2", "2e-2", "5e-2"], fontsize=8.5)
ax.minorticks_off()
ax.legend(handles=[plt.Line2D([], [], marker="o", color="0.3", mfc="0.3", ls="", label="no $\\Sigma$ in the frozen factor"),
                   plt.Line2D([], [], marker="o", color="0.3", mfc="white", mew=2, ls="", label="$\\Sigma$, or one scale per module"),
                   plt.Line2D([], [], marker="D", color="0.3", ls="", ms=5, label="five non-degenerate modules")],
          fontsize=7.5, frameon=False, loc="upper right")
ax.axhline(1.5, color="0.85", lw=0.8); ax.axhline(2.5, color="0.85", lw=0.8)
for s in ("top", "right"): ax.spines[s].set_visible(False)
fig.tight_layout()
fig.savefig(f"{OUT}/sigma_rates.png", dpi=200, bbox_inches="tight", pad_inches=0.08); plt.close(fig)
print(f"  ecrit -> {OUT}/results_map.png, rank_dependence.png, sigma_rates.png")
