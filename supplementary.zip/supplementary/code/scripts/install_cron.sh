#!/bin/bash
# Installe le pilote v2 dans la crontab (independant des sessions SSH) : une passe toutes les 10 minutes ; filet d'annulation a 7 h 58.
#   bash scripts/install_cron.sh            installer        bash scripts/install_cron.sh --retirer     retirer
set -u
TAG="# lora-v2"
command -v crontab >/dev/null || { echo "  STOP : crontab absent sur ce serveur"; exit 1; }
cur=$(crontab -l 2>/dev/null | grep -v "$TAG")
if [ "${1:-}" = "--retirer" ]; then printf "%s\n" "$cur" | sed '/^$/d' | crontab - && echo "  ok : pilote retire de la crontab"; exit 0; fi
for b in squeue sbatch scancel flock; do command -v $b >/dev/null || { echo "  STOP : $b introuvable"; exit 1; }; done
PATHS=$(for b in squeue sbatch scancel flock date; do dirname "$(command -v $b)"; done | sort -u | tr '\n' ':')"/usr/bin:/bin"
mkdir -p "$HOME/.v2_nuit"
P="PATH=$PATHS USER=$USER HOME=$HOME; cd $HOME/repo && flock -n $HOME/.v2_nuit/lock bash scripts/v2_nuit.sh --une-passe >> $HOME/v2_nuit.log 2>&1"
{ printf "%s\n" "$cur" | sed '/^$/d'; echo "*/10 * * * * $P $TAG"; echo "58 7 * * * $(command -v scancel) -u $USER -n lorasub >> $HOME/couvre_feu.log 2>&1 $TAG"; } | crontab - \
  || { echo "  STOP : la crontab a ete refusee"; exit 1; }
echo "  ok : pilote installe dans la crontab"; crontab -l | grep "$TAG" | sed 's/^/    /' | cut -c1-150
