"""Robustness bracket: every primary test at the rate SELECTED on seeds 0-1 (pre-registered) and at the ORACLE rate. No PARTITION.

    python scripts/oracle_bracket.py 2>&1 | grep -vE "FutureWarning|pd.concat"

ORACLE: for each arm of a campaign whose rates all ran on the reported seeds, the rate with the best mean TEST score on those same
seeds (2-6). It is optimistic by construction -- the rate is chosen on the data it is scored on -- so it BRACKETS the pre-registered
result, it does not replace it. If a conclusion holds at both rates, noise in the two-seed selection cannot explain it.
References that ran only at their selected rate on the reported seeds (the frozen-B arms and the free LoRA of experiment 1 and of
freezing A, OpenBookQA's frozen references) stay at that rate in both columns, and the script says so. On ARC every arm ran at
every rate: there the bracket is complete.
"""
import csv
import glob
import json
import math
import os
import random
import re
import statistics as st

import yaml

R = os.path.expanduser("~/lora-runs")
LLAMA, QWEN = "meta-llama/Llama-3.2-1B", "Qwen/Qwen2.5-1.5B"
S_SEL, S_REP = (0, 1), [2, 3, 4, 5, 6]


def tokens(c):
    t = c.get("target_tokens")
    return t.get(c.get("task")) if isinstance(t, dict) else t


RUNS = []
for p in glob.glob(R + "/*/config.yaml"):
    c = yaml.safe_load(open(p)) or {}
    d = os.path.dirname(p)
    try:
        if not open(d + "/status").read().startswith("DONE"):
            continue
        RUNS.append((c, json.load(open(d + "/metrics.json")), d))
    except OSError:
        continue


def clipped(c):
    """Gradient clipping at 1.0, the paper's setting. A noclip grid reran the same cells without clipping (collect()'s
    docstring); mixing both put two runs per seed in the frozen cells and moved G from 12.41 to 13.53 (26/09)."""
    v = c.get("max_grad_norm", 1.0)
    return v is not None and float(v) == 1.0


def seven(c):
    tm = c.get("target_modules")
    return tm is None or len(tm) == 7


def cell(pred, mode, rank, lr, seeds, key):
    """{seed: value}; several runs of one seed are averaged and flagged."""
    by = {}
    for c, m, d in RUNS:
        if (pred(c) and clipped(c) and c.get("mode") == mode and c.get("rank") == rank and abs(float(c.get("lr") or 0) - lr) < 1e-12
                and c.get("seed") in seeds and key in m and c.get("update_norm_target") in (None, "")):
            by.setdefault(c["seed"], []).append((m[key], d))
    dup = {s: len(v) for s, v in by.items() if len(v) > 1}
    if dup:   # say what separates the duplicates, so that the next filter is written from evidence
        s0 = sorted(dup)[0]; cfgs = [yaml.safe_load(open(d + "/config.yaml")) or {} for _, d in by[s0]]
        keys = sorted(k for k in set().union(*cfgs) if k not in ("run_id", "out_dir") and len({str(c_.get(k)) for c_ in cfgs}) > 1)
        dup["differ"] = {k: [c_.get(k) for c_ in cfgs] for k in keys} or "configs identiques"
    return {s: st.mean(x for x, _ in v) for s, v in by.items()}, dup, {s: [d for _, d in v] for s, v in by.items()}


def paired(a, b):
    k = sorted(set(a) & set(b)); dd = [(a[s] - b[s]) * 100 for s in k]
    if len(dd) < 2: return float("nan"), float("nan"), len(dd)
    sd = st.stdev(dd)
    return st.mean(dd), (st.mean(dd) / (sd / len(dd) ** 0.5) if sd > 0 else float("inf")), len(dd)


def show(lab, v, dup=None):
    extra = f"  DOUBLONS {dup}" if dup else ""
    print(f"    {lab:36s} " + (f"{st.mean(v.values()):.4f}  ({len(v)} graines){extra}" if v else "AUCUN RUN"))


def select(pred, mode, rank, lrs, key):
    full = {}
    for lr in lrs:
        v, _, _ = cell(pred, mode, rank, lr, S_SEL, key)
        if len(v) == 2: full[lr] = st.mean(v.values())
    if len(full) < len(lrs):
        return None, f"INCOMPLET ({len(full)}/{len(lrs)} taux avec leurs deux graines)"
    best = max(full, key=full.get)
    edge = best in (lrs[0], lrs[-1])
    return best, "  ".join(f"{lr:g}:{full[lr]:.3f}" for lr in lrs) + f"  -> {best:g}" + ("  AU BORD" if edge else "")


fmt = lambda c: (c.get("task") == "format" and str(c.get("model")) == LLAMA and tokens(c) == 600000 and seven(c)  # noqa: E731
                 and c.get("max_len") == 384 and c.get("batch_size") == 2 and c.get("grad_accum") == 16)
obqa = lambda c: c.get("task") == "commonsense" and str(c.get("data_fingerprint")) == "dc05f4d847f9" and str(c.get("model")) == QWEN and seven(c)  # noqa: E731
arc = lambda c: c.get("task") == "commonsense" and str(c.get("data_fingerprint")) == "0755bcdbdce3" and str(c.get("model")) == QWEN  # noqa: E731
T4, BONF2 = 2.776, 3.495


def at(pred, mode, rank, lr, key):
    v, dup, _ = cell(pred, mode, rank, lr, S_REP, key)
    return v if (len(v) == 5 and not dup) else None


def selected(pred, mode, rank, lrs, vkey, key):
    b, _ = select(pred, mode, rank, lrs, vkey)
    return (b, at(pred, mode, rank, b, key)) if b is not None else (None, None)


def oracle(pred, mode, rank, lrs, key):
    full = {lr: v for lr in lrs if (v := at(pred, mode, rank, lr, key)) is not None}
    if len(full) < len(lrs):
        return None, None, f"{len(full)}/{len(lrs)} taux complets sur 2-6"
    b = max(full, key=lambda lr: st.mean(full[lr].values()))
    return b, full[b], ""


def pt(a, b):
    """paired difference a - b in points, its 95 % interval (4 d.f.) and t"""
    d = [(a[s] - b[s]) * 100 for s in S_REP]; m = st.mean(d); se = st.stdev(d) / 5 ** 0.5
    return m, m - T4 * se, m + T4 * se, (m / se if se > 0 else float("inf"))


def line(label, sel, orc, thr, rule="t"):
    def fmt_(x):
        if x is None: return "non calculable"
        m, lo, hi, t = x
        ok = (abs(t) > thr) if rule == "t" else (lo > thr)
        return f"{m:+6.2f} [{lo:+6.2f}, {hi:+6.2f}] t={t:+6.2f} " + ("E " if ok else "NE")
    same = "" if sel is None or orc is None else ("   meme verdict" if ((abs(sel[3]) > thr) == (abs(orc[3]) > thr) if rule == "t" else (sel[1] > thr) == (orc[1] > thr)) else "   VERDICT DIFFERENT")
    print(f"    {label:34s} retenu : {fmt_(sel)}   |   oracle : {fmt_(orc)}{same}")


def unfrozen_block(title, pred, refs, lrs, vkey, key, band_label):
    print(f"\n==================== {title} ====================")
    free = at(pred, "free", 1, refs["free"], key)
    fz = {a: at(pred, a, 2, refs[a], key) for a in ("top", "bottom")}
    if free is None or None in fz.values():
        print("  references incompletes : bloc non calculable"); return
    print(f"  references a leur taux retenu dans les deux colonnes : free r=1 {refs['free']:g}, top {refs['top']:g}, bottom {refs['bottom']:g}")
    U2 = {}
    for arm in ("top", "bottom"):
        G = pt(free, fz[arm])[0]
        cols = {}
        for r in (1, 2):
            bs, vs = selected(pred, f"{arm}_unfrozen", r, lrs, vkey, key); bo, vo, why = oracle(pred, f"{arm}_unfrozen", r, lrs, key)
            cols[r] = (bs, vs, bo, vo, why)
        print(f"  --- {arm} (G = {G:.2f}, 0,7 G = {0.7 * G:.2f}) ; taux r=1 retenu/oracle {cols[1][0]}/{cols[1][2]} ; r=2 {cols[2][0]}/{cols[2][2]} {cols[1][4]} {cols[2][4]}")
        line("U = unfrozen r=1 - gele", pt(cols[1][1], fz[arm]) if cols[1][1] else None, pt(cols[1][3], fz[arm]) if cols[1][3] else None, 0.7 * G, rule="lo")
        line("gel seul = unfrozen r=2 - gele", pt(cols[2][1], fz[arm]) if cols[2][1] else None, pt(cols[2][3], fz[arm]) if cols[2][3] else None, BONF2)
        U2[arm] = (cols[2][1], cols[2][3])
    if all(U2[a][0] and U2[a][1] for a in U2):
        inter = lambda u: {s: (u["bottom"][s] - u["top"][s]) - (fz["bottom"][s] - fz["top"][s]) + 0 for s in S_REP}  # noqa: E731
        zero = {s: 0.0 for s in S_REP}
        line(band_label, pt(inter({a: U2[a][0] for a in U2}), zero), pt(inter({a: U2[a][1] for a in U2}), zero), T4)


def dual_block(title, pred, refs, lrs, vkey, key):
    print(f"\n==================== {title} ====================")
    fz = {a: at(pred, a, 2, refs[a], key) for a in ("top", "bottom")}
    if None in fz.values():
        print("  references incompletes : bloc non calculable"); return
    print(f"  references (B gele) a leur taux retenu dans les deux colonnes : top {refs['top']:g}, bottom {refs['bottom']:g}")
    D = {}
    for arm in ("top", "bottom"):
        bs, vs = selected(pred, f"dual_{arm}", 2, lrs, vkey, key); bo, vo, why = oracle(pred, f"dual_{arm}", 2, lrs, key)
        print(f"  --- dual_{arm} : taux retenu {bs} / oracle {bo} {why}")
        line(f"dual_{arm} - {arm}", pt(vs, fz[arm]) if vs else None, pt(vo, fz[arm]) if vo else None, BONF2)
        D[arm] = (vs, vo)
    if all(D[a][0] and D[a][1] for a in D):
        zero = {s: 0.0 for s in S_REP}
        inter = lambda u: {s: (u["bottom"][s] - u["top"][s]) - (fz["bottom"][s] - fz["top"][s]) for s in S_REP}  # noqa: E731
        line("ecart entre bandes, A contre B", pt(inter({a: D[a][0] for a in D}), zero), pt(inter({a: D[a][1] for a in D}), zero), T4)


def fc_block(title, pred, rk, rk_free, lrs, vkey, key):
    print(f"\n==================== {title} ====================")
    arms = (("top", rk), ("bottom", rk), ("random_ortho", rk), ("free", rk_free))
    res = {}
    for col, fn in (("retenu", lambda m, r: selected(pred, m, r, lrs, vkey, key)), ("oracle", lambda m, r: oracle(pred, m, r, lrs, key)[:2])):
        got = {m: fn(m, r) for m, r in arms}
        if any(v[1] is None for v in got.values()):
            print(f"  {col} : cellules incompletes"); continue
        fz = {m: v[1] for m, v in got.items() if m != "free"}; fr = got["free"][1]

        def fc(ix):
            mm = {k: st.mean(v[s] for s in ix) for k, v in fz.items()}; ff = st.mean(fr[s] for s in ix)
            return (ff - max(mm.values())) * 100, (max(mm.values()) - min(mm.values())) * 100
        g, c = fc(S_REP); rng = random.Random(0)
        B = sorted(a - b for a, b in (fc([S_REP[rng.randrange(5)] for _ in S_REP]) for _ in range(20000)))
        lo, hi = B[500], B[19499]
        res[col] = (g - c, lo, hi)
        print(f"  {col:7s} taux " + ", ".join(f"{m} {v[0]:g}" for m, v in got.items()) + f" -> geler {g:.2f}, choisir {c:.2f}, geler - choisir {g - c:+.2f} [{lo:+.2f}, {hi:+.2f}] -> "
              + ("> 0" if lo > 0 else ("< 0" if hi < 0 else "non etabli")))
    if len(res) == 2:
        sgn = lambda x: "pos" if x[1] > 0 else ("neg" if x[2] < 0 else "zero")  # noqa: E731
        print("  -> " + ("meme conclusion aux deux taux" if sgn(res["retenu"]) == sgn(res["oracle"]) else "CONCLUSION DIFFERENTE a l'oracle"))


print("ENCADREMENT : taux retenu (pre-enregistre, graines 0-1) contre taux ORACLE (meilleur en test sur les graines rapportees 2-6).")
print("L'oracle est optimiste par construction : il encadre le resultat, il ne le remplace pas.")
L7 = [1e-4, 5e-4, 1e-3, 2e-3, 5e-3, 1e-2, 2e-2]; LO = [2e-4, 5e-4, 1e-3, 2e-3, 5e-3, 1e-2, 2e-2]
unfrozen_block("experience 1 : le gel de B isole, tache de format, Llama", fmt, {"free": 1e-3, "top": 1e-2, "bottom": 5e-3}, L7, "val_format_parsed", "format_parsed",
               "ecart entre bandes (post hoc)")
unfrozen_block("OpenBookQA degele, Qwen2.5-1.5B", obqa, {"free": 2e-3, "top": 5e-3, "bottom": 2e-3}, LO, "val_mcq_acc", "mcq_acc", "ecart entre bandes (pre-enregistre)")
dual_block("geler A, tache de format, Llama", fmt, {"top": 1e-2, "bottom": 5e-3}, L7, "val_format_parsed", "format_parsed")
dual_block("geler A, OpenBookQA, Qwen2.5-1.5B", obqa, {"top": 5e-3, "bottom": 2e-3}, L7, "val_mcq_acc", "mcq_acc")
fc_block("ARC-Challenge, rang 2 (tous les bras a tous les taux)", arc, 2, 1, LO, "val_mcq_acc", "mcq_acc")
fc_block("ARC-Challenge, rang 32 (tous les bras a tous les taux)", arc, 32, 14, [5e-5, 1e-4, 2e-4, 5e-4, 1e-3, 2e-3, 5e-3], "val_mcq_acc", "mcq_acc")


# ------------------------------------------------------------------ the format task on Qwen (PROTOCOL_format_qwen_rank.md): fresh seeds
fq = lambda c: c.get("task") == "format" and str(c.get("model")) == QWEN and seven(c)  # noqa: E731
_sel, _rep = S_SEL, S_REP
S_SEL, S_REP = (20, 21), [22, 23, 24, 25, 26]
fc_block("tache de format, Qwen2.5-1.5B, rang 2 (graines 20-26)", fq, 2, 1, [1e-4, 5e-4, 1e-3, 2e-3, 5e-3, 1e-2, 2e-2], "val_format_parsed", "format_parsed")
fc_block("tache de format, Qwen2.5-1.5B, rang 16 (graines 20-26)", fq, 16, 7, [1e-4, 2e-4, 5e-4, 1e-3, 2e-3, 5e-3, 1e-2], "val_format_parsed", "format_parsed")
S_SEL, S_REP = _sel, _rep
