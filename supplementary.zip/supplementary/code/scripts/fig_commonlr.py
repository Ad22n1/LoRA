"""The inversion: which arm looks best depends entirely on the rate you impose.

This is contribution 6 and the refutation of H4, and it was the only major claim in the paper with
no figure. Three sentences asserted it; a reader had to take them on trust.

At 2e-3, `bottom` leads. At 1e-2, it is last. Both rates are defensible a priori;
only a per-arm sweep tells you which one each arm needs, and the comparisons this paper discusses
impose a single one.

`random` appears at 1e-2 only — it was never run at 2e-3 with 614-item evaluation — so it is drawn
but cannot enter the common-rate comparison. Saying so is the point: a figure that hid it would
invite exactly the question it is meant to answer.
"""
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# COMPUTED FROM THE RUNS, never typed in. The hard-coded table this replaces had drifted from the
# paper twice: bottom at 2e-3 kept a replicate the tables had since averaged (0.5646 against 0.5658),
# and bottom at 5e-3 was a mean over a collapsed seed that Table 19 leaves out. Same population as the
# main table: Llama-3.2-1B, format, r=2, seven modules, clipping at 1.0, no norm rescaling, 614 items,
# seeds 2-6, replicates averaged within a seed, salted draws for the random arms.
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
from lorasub.aggregate import collect  # noqa: E402
# No conclusions inside the images (24/09): every title is dropped, only panel letters such as "(a)"
# are kept where a caption refers to them. What a figure shows is said in its caption, where it can
# be qualified -- a claim written in the image cannot.
import re as _re
import matplotlib.axes as _max
import matplotlib.figure as _mfig
_set_title = _max.Axes.set_title
def _letter_only(self, label="", *a, **k):
    m = _re.match(r"\s*\(([a-z])\)", str(label))
    return _set_title(self, f"({m.group(1)})" if m else "", loc="left", fontsize=10)
_max.Axes.set_title = _letter_only
_mfig.Figure.suptitle = lambda self, *a, **k: None

_d = collect(os.path.expanduser("~/lora-runs"))
_x = _d[(_d.task == "format") & _d.model.astype(str).str.contains("Llama") & (_d["rank"] == 2)
        & (_d.n_modules == 7) & (_d.max_grad_norm == 1.0) & _d.update_norm_target.isna()
        & (_d.format_n == 614) & _d.seed.between(2, 6)
        & _d["mode"].isin(["bottom", "top", "random", "random_ortho"])]
_x = _x[~_x["mode"].isin(["random", "random_ortho"]) | (_x.subspace_salted == True)]
_per_seed = _x.groupby(["mode", "lr", "seed"]).format_parsed.mean().reset_index()
_cells = _per_seed.groupby(["mode", "lr"]).agg(mean=("format_parsed", "mean"), n=("seed", "nunique"))
S = {}
for (m, lr), row in _cells.iterrows():
    if row.n == 5:                      # a point is drawn only on the full five seeds
        S.setdefault(m, {})[float(lr)] = float(row["mean"])
S = {m: S[m] for m in ("bottom", "top", "random_ortho", "random") if m in S}
SELECTED = {"bottom": 5e-3,   # selected on seeds 0, 1, 30-32 (was 2e-3)
            "top": 1e-2, "random": 1e-2, "random_ortho": 1e-2}
COL = {"bottom": "#c44e52", "top": "#4c72b0", "random": "#55a868", "random_ortho": "#8172b2"}
MK = {"bottom": "o", "top": "s", "random": "^", "random_ortho": "D"}

fig, ax = plt.subplots(figsize=(7.2, 4.3))
for m, d in S.items():
    xs = sorted(d)
    ax.plot(xs, [d[x] for x in xs], "-" if len(xs) > 1 else "",
            marker=MK[m], color=COL[m], lw=1.8, ms=7,
            label=m + ("  (1e-2 only)" if len(xs) == 1 else ""))
    sel = SELECTED[m]
    if sel in d:
        # three arms select 1e-2 and their rings landed on top of each other: nudge them apart
        # along x, which a log axis makes harmless at this scale.
        nudge = 1.0 + 0.035 * (list(S).index(m) - 1.5) if sel == 1e-2 else 1.0
        ax.plot([sel * nudge], [d[sel]], marker=MK[m], color=COL[m], ms=15, mfc="none", mew=2.0)

for lr, lab in ((2e-3, "a common low rate"), (1e-2, "a common high rate")):
    # dashed and darker than the log grid, which also draws a line at 1e-2: otherwise the high-rate
    # line is lost in the grid and its label seems to float near 5e-3
    ax.axvline(lr, color="0.55", lw=1.0, ls="--", zorder=0)
    # inside the axes, low enough to clear both the curves and the three-line title
    ax.annotate(lab, xy=(lr, 0.03), xycoords=("data", "axes fraction"),
                xytext=(4, 0), textcoords="offset points",   # both labels start at their own line
                ha="left", va="bottom", fontsize=7.5, color="0.5",
                bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="none", alpha=0.8))

lo = {m: S[m][2e-3] for m in S if 2e-3 in S[m]}
hi = {m: S[m][1e-2] for m in S if 1e-2 in S[m]}
ax.set_xscale("log")
ax.set_xlabel("learning rate (log)", fontsize=10)
ax.set_ylabel("valid-format accuracy, mean over five seeds", fontsize=10)
# "\\n" inside an f-string written to a file becomes a literal backslash-n on the figure.
_lead = (lo["bottom"] - max(v for k, v in lo.items() if k != "bottom")) * 100
_last = (max(hi.values()) - hi["bottom"]) * 100
ax.set_title("Which arm looks best is decided by the rate you impose.\n"
             "Rings mark each arm's own selected rate.", fontsize=10.5, pad=10)
# lower right is where the 1e-2 label sits; centre-right clears both
ax.legend(fontsize=8.5, frameon=False, loc="center right", bbox_to_anchor=(1.0, 0.42))
ax.grid(color="0.93", lw=0.7)
ax.set_axisbelow(True)
for sp in ("top", "right"):
    ax.spines[sp].set_visible(False)

fig.tight_layout(rect=(0, 0, 1, 0.97))
out = sys.argv[1] if len(sys.argv) > 1 else "paper/figures/commonlr.png"
os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
fig.savefig(out, dpi=200)
print(f"  for the caption: bottom leads by {_lead:.1f} pt at 2e-3, is last by {_last:.1f} at 1e-2")
print(f"  at 2e-3 : {sorted(lo.items(), key=lambda kv: -kv[1])}")
print(f"  at 1e-2 : {sorted(hi.items(), key=lambda kv: -kv[1])}")
print(f"  bottom goes from rank {sorted(lo, key=lambda k: -lo[k]).index('bottom') + 1}/{len(lo)} "
      f"to rank {sorted(hi, key=lambda k: -hi[k]).index('bottom') + 1}/{len(hi)}")
print("  ecrit ->", out)
