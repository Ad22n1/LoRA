"""`top_unfrozen`, exactly as PROTOCOL_top_unfrozen.md fixed it before launch.

Selection: mean validation score over seeds 0 and 1, rank 1, six rates; the selected rate must be an
interior maximum, and the script says so when it is not. Then, on seeds 2 to 6:
    U = top_unfrozen(r=1) - top(r=2)     against     G = free(r=1) - top(r=2) = the reported 11.5
    U >= 0.7 G -> freezing accounts for most of the gap
    U <= 0.3 G -> initialisation, basis or rank account for most of it; contribution 3 is restated
    otherwise  -> shared, reported without attribution
Secondary, no claim: top_unfrozen - free at rank 1, and the three parameter counts.
Writes configs/grids/top_unfrozen_seeds.yaml for the reported seeds once the rate is selected.

    python scripts/analyse_top_unfrozen.py
"""
import os
import statistics as st
import sys

import yaml

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
from lorasub.aggregate import collect  # noqa: E402

GRID = [1e-4, 5e-4, 1e-3, 2e-3, 5e-3, 1e-2]
M = "meta-llama/Llama-3.2-1B"
d = collect(os.path.expanduser("~/lora-runs"))
B = d[(d.task == "format") & (d.model.astype(str) == M) & (d.n_modules == 7) & (d.max_grad_norm == 1.0)
      & d.update_norm_target.isna()]


def cell(mode, rank, lr, seeds, val=False):
    x = B[(B["mode"] == mode) & (B["rank"] == rank) & ((B.lr - lr).abs() < 1e-12) & B.seed.isin(seeds)]
    col = "val_format_parsed" if val else "format_parsed"
    if not val:
        x = x[x.format_n == 614]
    return x.groupby("seed")[col].mean()


print("  rate      val (seeds 0-1)   seeds")
rows = []
for lr in GRID:
    per = cell("top_unfrozen", 1, lr, [0, 1], val=True)
    rows.append((lr, float(per.mean()) if len(per) else float("nan"), int(per.size)))
    print(f"  {lr:<8g}  {rows[-1][1]:.4f}           {rows[-1][2]}")
if any(k < 2 for _, _, k in rows):
    raise SystemExit("\n  incomplete: wait for the sweep, or relaunch the missing runs identically")
best = max(rows, key=lambda r: r[1])
i = GRID.index(best[0])
edge = i in (0, len(GRID) - 1)
print(f"\n  selected {best[0]:g} ({best[1]:.4f})" + ("   ON THE GRID BOUNDARY" if edge else "   interior"))
if edge:
    raise SystemExit("  the protocol requires an interior maximum: extend the grid one step in that"
                     " direction, rerun the sweep, and redo the selection. Nothing is concluded.")

S = [2, 3, 4, 5, 6]
tu, top, free = cell("top_unfrozen", 1, best[0], S), cell("top", 2, 1e-2, S), cell("free", 1, 1e-3, S)
if len(tu) < 5:
    print(f"\n  reported seeds: {len(tu)}/5 present; run configs/grids/top_unfrozen_seeds.yaml first")
    base = yaml.safe_load(open("configs/grids/top_unfrozen_sweep.yaml"))["base"]
    head = ("# top_unfrozen, graines rapportees 2 a 6, au taux retenu (analyse_top_unfrozen.py).\n"
            "# Protocole : PROTOCOL_top_unfrozen.md. Lancer SANS --lr_from.\n")
    open("configs/grids/top_unfrozen_seeds.yaml", "w").write(head + yaml.safe_dump(
        {"base": base, "grid": {"mode": ["top_unfrozen"], "lr": [best[0]], "seed": S}}, sort_keys=False))
    print("  wrote configs/grids/top_unfrozen_seeds.yaml : 5 runs")
    raise SystemExit(0)


def paired(a, b, label):
    s = sorted(set(a.index) & set(b.index))
    dif = [(a[k] - b[k]) * 100 for k in s]
    t = st.mean(dif) / (st.stdev(dif) / len(dif) ** 0.5)
    print(f"  {label:34s} {st.mean(dif):+6.2f} pt  t={t:+5.2f}  {sum(x > 0 for x in dif)}/{len(dif)}")
    return st.mean(dif)


print()
U = paired(tu, top, "top_unfrozen(r=1) - top(r=2)")
G = paired(free, top, "free(r=1) - top(r=2)   [= G]")
paired(tu, free, "top_unfrozen(r=1) - free(r=1)")
paired(free, cell("random_ortho", 2, 1e-2, S), "free(r=1) - random_ortho(r=2)  [paper's 11.5]")
share = U / G if G else float("nan")
verdict = ("freezing accounts for most of the gap" if share >= 0.7 else
           "initialisation, basis or rank account for most of it: restate contribution 3" if share <= 0.3 else
           "shared between the two: report without attribution")
print(f"\n  U / G = {share:.2f}  ->  {verdict}")
