"""Regenerate figures from the same data and scripts, changing no plotted value (01/10).

    python scripts/regen_figures_0110.py            # run from the repository root, with PYTHONPATH=src

For each figure, the script as committed BEFORE this change (git HEAD) and the edited script run on the same data, through
scripts/fig_capture.py, each export redirected into a work folder (nothing existing is written over). Then:
  - every plotted value must be identical: line coordinates, collection offsets and paths, patch geometry, annotation anchors;
  - toy.png (a composite of two renders) must be pixel-identical outside the added title band and the two blanked letters;
  - the moved legend must cover no marker and no label, and no two point labels may overlap where they were pulled apart.
Only if every check passes are the new files copied into paper/figures (and zipped for the arXiv and TMLR versions).
"""
import json
import os
import shutil
import subprocess
import sys
import zipfile

import numpy as np
from PIL import Image

REPO = os.getcwd()
WORK = os.path.expanduser("~/fig_regen_0110")
PY = sys.executable
FIGS = [  # (file, script, arguments, request number, what changes)
    ("band_replication.png", "scripts/fig_band_replication.py", ["{o}/band_replication.png"], 6, "panel titles \"rank 2\" and \"rank 4, seeds 2 to 8\""),
    ("degeneracy.png", "scripts/fig_degeneracy.py", ["{o}/degeneracy.png"], 7, "\"Qwen2.5-0.5B\"; fp32-floor note removed"),
    ("toy.png", "scripts/fig_toy_merge.py", ["{o}/toy.png"], 8, "three panel titles in a band on top"),
    ("curvature_arms.png", "scripts/fig_curvature_arms.py", ["{o}/curvature_arms.png"], 10, "two decimals on every bar label"),
    ("curvature_vs_lr.png", "scripts/fig_curvature.py", [], 11, "legend of panel (a) placed where it hides nothing"),
    ("score_vs_norm.png", "scripts/score_vs_norm.py", [], 12, "overlapping rate labels pulled apart"),
]
TOY_LETTERS = [(141, 31, 174, 56), (941, 31, 974, 56)]
if os.environ.get("REGEN_ONLY"):                       # for testing: restrict to some files
    FIGS = [f for f in FIGS if f[0] in os.environ["REGEN_ONLY"].split(",")]


def run(tag, script, args):
    out = os.path.join(WORK, tag); dump = os.path.join(WORK, f"{tag}_{os.path.basename(script)}.json")
    env = dict(os.environ, PYTHONPATH=os.path.join(REPO, "src") + os.pathsep + os.path.join(REPO, "scripts"))
    p = subprocess.run([PY, os.path.join(REPO, "scripts/fig_capture.py"), out, dump, script] + [a.format(o=out) for a in args],
                       cwd=REPO, env=env, capture_output=True, text=True)
    if p.returncode != 0:
        sys.exit(f"STOP: {tag} {script} failed:\n{p.stderr[-2500:]}")
    return out, json.load(open(dump)), p.stdout


shutil.rmtree(WORK, ignore_errors=True); os.makedirs(os.path.join(WORK, "old_scripts"))
for f in ("fig_capture.py", "_layout.py", "regen_figures_0110.py"):
    if not os.path.exists(os.path.join(REPO, "scripts", f)):
        sys.exit(f"STOP: scripts/{f} missing")
ok_all, lines, made = True, [], []
for name, script, args, num, what in FIGS:
    old_src = subprocess.run(["git", "show", f"HEAD:{script}"], cwd=REPO, capture_output=True, text=True)
    if old_src.returncode != 0:
        sys.exit(f"STOP: {script} is not in git HEAD")
    old_path = os.path.join(WORK, "old_scripts", os.path.basename(script)); open(old_path, "w").write(old_src.stdout)
    o_dir, o_rec, _ = run("old", old_path, args)
    n_dir, n_rec, n_out = run("new", os.path.join(REPO, script), args)
    o_img, n_img = Image.open(os.path.join(o_dir, name)), Image.open(os.path.join(n_dir, name))
    note = []
    if name == "toy.png":
        a, b = np.asarray(o_img.convert("RGB")), np.asarray(n_img.convert("RGB")); band = b.shape[0] - a.shape[0]
        body = b[band:]; diff = (body != a).any(2) if body.shape == a.shape else np.ones((1, 1), bool)
        ys, xs = np.where(diff)
        inside = body.shape == a.shape and all(any(x0 <= x <= x1 and y0 <= y <= y1 for x0, y0, x1, y1 in TOY_LETTERS) for y, x in zip(ys, xs))
        blank = body.shape == a.shape and all((body[y0:y1 + 1, x0:x1 + 1] == 255).all() for x0, y0, x1, y1 in TOY_LETTERS)
        same = inside and blank and a.shape[1] == b.shape[1]
        note.append(f"pixels identical outside the {band}-px title band and the two blanked letters ({int(diff.sum())} letter pixels)")
    else:
        rec_o = {r["file"]: r for r in o_rec}; rec_n = {r["file"]: r for r in n_rec}
        r_o, r_n = rec_o.get(name), rec_n.get(name)
        same = r_o is not None and r_n is not None and len(r_o["axes"]) == len(r_n["axes"]) \
            and all(x["data"] == y["data"] for x, y in zip(r_o["axes"], r_n["axes"]))
        if r_o and r_n:
            n_items = sum(len(x["data"]["lines"]) + len(x["data"]["collections"]) + len(x["data"]["patches"]) + len(x["data"]["anchors"]) for x in r_n["axes"])
            note.append(f"{n_items} plotted artists compared")
            for i, (x, y) in enumerate(zip(r_o["axes"], r_n["axes"])):
                gone = sorted(set(x["texts"]) - set(y["texts"])); new = sorted(set(y["texts"]) - set(x["texts"]))
                if gone or new:
                    note.append(f"axes {i}: labels removed {gone[:6]}, added {new[:6]}")
                if x["title"] != y["title"]:
                    note.append(f"axes {i}: title {x['title']!r} -> {y['title']!r}")
                lo, ln = x["layout"], y["layout"]
                if name == "curvature_vs_lr.png" and i == 0:
                    note.append(f"legend covers {lo['legend_covers_markers']} marker(s) / {lo['legend_covers_labels']} label(s) before, "
                                f"{ln['legend_covers_markers']} / {ln['legend_covers_labels']} after")
                    same = same and ln["legend_covers_markers"] == 0 and ln["legend_covers_labels"] == 0
                if name == "score_vs_norm.png" and i == 0:
                    note.append(f"overlapping label pairs: {lo['overlapping_label_pairs']} before, {ln['overlapping_label_pairs']} after")
                    same = same and ln["overlapping_label_pairs"] == 0
    cur = os.path.join(REPO, "paper/figures", name)
    size_cur = Image.open(cur).size if os.path.exists(cur) else None
    lines.append(f"  {num:>2}. {name:22s} {'OK ' if same else 'ECHEC'} {what} ; size {o_img.size} -> {n_img.size}"
                 f" (paper/figures now {size_cur}) ; " + " ; ".join(note))
    ok_all &= bool(same); made.append((name, n_dir))
print("=== before / after (values from the same data and the same script, before and after the change)")
print("\n".join(lines))
if not ok_all:
    sys.exit("STOP: at least one check failed; nothing was copied into paper/figures")
os.makedirs(os.path.join(REPO, "paper/figures"), exist_ok=True)
copied = []
for name, d in made:
    shutil.copy(os.path.join(d, name), os.path.join(REPO, "paper/figures", name)); copied.append(name)
    pdf = name.replace(".png", ".pdf")
    if os.path.exists(os.path.join(d, pdf)) and os.path.exists(os.path.join(REPO, "paper/figures", pdf)):
        shutil.copy(os.path.join(d, pdf), os.path.join(REPO, "paper/figures", pdf)); copied.append(pdf)
loss = os.path.join(REPO, "fig_update_0110", "analyses_loss_curves.png")
if os.path.exists(loss):
    shutil.copy(loss, os.path.join(REPO, "paper/figures/analyses_loss_curves.png")); copied.append("analyses_loss_curves.png")
with zipfile.ZipFile(os.path.expanduser("~/figures_0110.zip"), "w") as z:
    for f in copied:
        z.write(os.path.join(REPO, "paper/figures", f), f"figures/{f}")
print(f"  copied into paper/figures and zipped in ~/figures_0110.zip: {', '.join(copied)}")
