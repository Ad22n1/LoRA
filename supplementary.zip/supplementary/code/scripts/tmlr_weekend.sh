#!/bin/bash
# Conducteur des experiences TMLR pour le week-end (pas de fenetre de nuit). Lance en arriere-plan par DEPLOY_tmlr.sh :
#   nohup bash scripts/tmlr_weekend.sh > ~/tmlr_weekend.log 2>&1 &
# Toutes les 5 minutes, pour chaque experience dans l'ordre e1 -> e5 : si aucun de ses runs n'est dans la file, execute son etape
# suivante (scripts/tmlr.py). Une etape qui attend des runs manquants alors que la file est vide les fait resoumettre (au plus deux
# fois), puis l'experience est bloquee et signalee. S'arrete quand tout est fini ou bloque, ou a l'echeance (~/.tmlr/arret).
set -u
USER="${USER:-$(whoami)}"
cd "$HOME/repo" || exit 1
PY="/tmp/lora-$USER/venv/bin/python"; S="$HOME/.tmlr"; mkdir -p "$S"
declare -A FIRST=([e1]=sel [e2]=rep [e3]=rep [e4]=sel [e5]=dir)
for k in e1 e2 e3 e4 e5; do [ -f "$S/$k.etape" ] || echo "${FIRST[$k]}" > "$S/$k.etape"; done
log() { echo "$(date '+%d/%m %H:%M')  $*"; }
END=$(date -d "$(cat "$S/arret" 2>/dev/null || date -d 'next monday 07:55' '+%Y-%m-%d %H:%M')" +%s 2>/dev/null || date -d 'next monday 07:55' +%s)
log "conducteur demarre ; echeance $(date -d "@$END" '+%d/%m %H:%M')"
while [ "$(date +%s)" -lt "$END" ]; do
  left=0
  for k in e1 e2 e3 e4 e5; do
    e=$(cat "$S/$k.etape"); case "$e" in fini|bloque) continue ;; esac; left=$((left + 1))
    busy=$(squeue -h -u "$USER" -o "%o" 2>/dev/null | grep -c "/lora-grid/v2_${k}_")
    [ "$busy" -gt 0 ] && continue
    out=$("$PY" scripts/tmlr.py "$k" "$e" 2>&1); code=$?
    echo "$out" | sed "s/^/    [$k $e] /"
    if echo "$out" | grep -q "^FINI"; then echo fini > "$S/$k.etape"; log "$k : FINI -> ~/tmlr_lecture_$k.txt"; continue; fi
    if echo "$out" | grep -qE "^STOP|Traceback" || [ $code -ne 0 ] && ! echo "$out" | grep -q "^ATTENTE"; then echo bloque > "$S/$k.etape"; log "$k : BLOQUE a l'etape « $e »"; continue; fi
    nx=$(echo "$out" | grep -oE "^ETAPE: [a-z]+" | cut -d' ' -f2)
    if [ -n "$nx" ]; then echo "$nx" > "$S/$k.etape"; rm -f "$S/$k.relances"; log "$k : « $e » faite -> « $nx »"; continue; fi
    if echo "$out" | grep -q "^ATTENTE"; then
      sleep ${TMLR_PAUSE:-60}; busy=$(squeue -h -u "$USER" -o "%o" 2>/dev/null | grep -c "/lora-grid/v2_${k}_"); [ "$busy" -gt 0 ] && continue
      n=$(cat "$S/$k.relances" 2>/dev/null || echo 0)
      if [ "$n" -lt 2 ]; then echo $((n + 1)) > "$S/$k.relances"; log "$k : runs manquants, file vide : relance $((n + 1))/2"; "$PY" scripts/tmlr.py "$k" relaunch 2>&1 | sed "s/^/    [$k relance] /"
      else echo bloque > "$S/$k.etape"; log "$k : BLOQUE (runs manquants apres deux relances)"; fi
    fi
  done
  [ "$left" -eq 0 ] && { log "toutes les experiences sont finies ou bloquees"; break; }
  sleep ${TMLR_SLEEP:-300}
done
log "conducteur arrete"
