"""Grids of PROTOCOL_rank2_fresh.md, from the server's base (configs/grids/sigma_residual_C2.yaml, checked). 55 runs, fresh seeds 120-124.

    python scripts/make_r2f_grids.py
"""
import sys
from pathlib import Path

import yaml

SRC = Path("configs/grids/sigma_residual_C2.yaml")
if not SRC.exists():
    sys.exit(f"STOP : {SRC} introuvable")
base = dict((yaml.safe_load(open(SRC)) or {}).get("base") or {})
tok = base.get("target_tokens"); tok = tok.get("format") if isinstance(tok, dict) else tok
mods = base.get("target_modules")   # None -> the model registry's modules: seven for Llama, as the readers accept (seven(c))
checks = {"tache format": base.get("task") == "format", "Llama-3.2-1B": str(base.get("model")) == "meta-llama/Llama-3.2-1B",
          "600 000 tokens": tok == 600000, "longueur 384": base.get("max_len") == 384, "lot 2": base.get("batch_size") == 2,
          "accumulation 16": base.get("grad_accum") == 16, "ecretage 1,0": base.get("max_grad_norm", 1.0) is not None and float(base.get("max_grad_norm", 1.0)) == 1.0,
          "sept modules": mods is None or len(mods) == 7}
bad = [k for k, ok in checks.items() if not ok]
if bad:
    sys.exit(f"STOP : la base differe de la campagne d'origine sur : {', '.join(bad)} ; rien n'est genere")
print("  base verifiee : " + ", ".join(checks))
for k in ("mode", "rank", "lr", "seed", "band_frac", "update_norm_target"):
    base.pop(k, None)
base["save_factor_steps"] = []
SEEDS = [120, 121, 122, 123, 124]
ARMS = {  # grid: (mode, rank, the rate already selected on the original selection seeds)
    "r2f_top": ("top", 2, 1e-2), "r2f_bottom": ("bottom", 2, 5e-3), "r2f_random": ("random", 2, 1e-2), "r2f_rortho": ("random_ortho", 2, 1e-2),
    "r2f_free": ("free", 1, 1e-3),
    "r2f_topu_r1": ("top_unfrozen", 1, 5e-3), "r2f_topu_r2": ("top_unfrozen", 2, 5e-3),
    "r2f_botu_r1": ("bottom_unfrozen", 1, 5e-3), "r2f_botu_r2": ("bottom_unfrozen", 2, 2e-3),
    "r2f_dual_top": ("dual_top", 2, 1e-2), "r2f_dual_bot": ("dual_bottom", 2, 1e-2),
}
H = "# PRE-ENREGISTRE (PROTOCOL_rank2_fresh.md). Genere par scripts/make_r2f_grids.py. Graines neuves 120-124, taux deja retenus. 5 runs.\n"
total = 0
for name, (mode, rank, lr) in ARMS.items():
    b = dict(base); b["rank"] = rank
    Path(f"configs/grids/{name}.yaml").write_text(H + yaml.safe_dump({"base": b, "grid": {"mode": [mode], "lr": [lr], "seed": SEEDS}}, sort_keys=False))
    total += len(SEEDS); print(f"  {name:12s} : {mode} rang {rank} a {lr:g}, graines 120-124")
print(f"  total : {total} runs")
if total != 55:
    sys.exit("STOP : le total n'est pas 55")
