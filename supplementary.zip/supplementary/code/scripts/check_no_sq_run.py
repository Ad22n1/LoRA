"""Guard for PROTOCOL_square_modules_addendum.md: STOPS if any run of the square-module campaign already exists (q_proj and o_proj only,
seeds 130-144). An addendum committed after a run would carry no weight."""
import glob
import os
import sys

import yaml

n = 0
for p in glob.glob(os.path.expanduser("~/lora-runs/*/config.yaml")):
    c = yaml.safe_load(open(p)) or {}
    if list(c.get("target_modules") or []) == ["q_proj", "o_proj"] and c.get("seed") in (130, 131, 140, 141, 142, 143, 144):
        n += 1
if n:
    sys.exit(f"STOP : {n} run(s) de la campagne des modules carres existent deja ; l'additif doit preceder tout run")
print("  aucun run de la campagne : l'additif peut etre committe")
