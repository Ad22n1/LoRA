"""Around patch_adam_eps.py: does the patch change any run identifier? Compares the identifier recomputed BEFORE the patch with the one
recomputed AFTER, run by run (a directory whose name already differed before the patch is reported, not blamed on the patch).

    PYTHONPATH=src python scripts/check_ids.py --before /tmp/ids_avant.json     # with the original code
    PYTHONPATH=src python scripts/check_ids.py --after  /tmp/ids_avant.json     # with the patched code: STOPS on any change
"""
import dataclasses
import glob
import json
import os
import sys

import yaml

from lorasub.config import RunConfig

names = {f.name for f in dataclasses.fields(RunConfig)}
ids, skipped = {}, 0
for root in ("~/lora-runs", "~/lora-runs-suivi", "~/lora-runs-probe"):
    for p in glob.glob(os.path.expanduser(root) + "/*/config.yaml"):
        d = yaml.safe_load(open(p)) or {}
        try:
            ids[os.path.dirname(p)] = RunConfig(**{k: v for k, v in d.items() if k in names}).run_id
        except Exception:  # noqa: BLE001
            skipped += 1
mode, path = sys.argv[1], sys.argv[2]
if mode == "--before":
    json.dump(ids, open(path, "w"))
    legacy = sum(1 for dd, i in ids.items() if os.path.basename(dd) != i)
    print(f"  releve avant correctif : {len(ids)} runs ({legacy} dont le dossier differe deja de l'identifiant recalcule ; {skipped} non chargeables)")
    sys.exit(0 if ids else "STOP : aucun run releve")
before = json.load(open(path))
changed = [dd for dd, i in before.items() if ids.get(dd) != i]
print(f"  apres correctif : {len(before) - len(changed)} identifiants inchanges, {len(changed)} changes")
for dd in changed[:3]:
    print(f"    CHANGE : {dd} : {before[dd]} -> {ids.get(dd)}")
if changed:
    sys.exit("STOP : le correctif change des identifiants")
if "adam_eps" in names:
    k = next(iter(before))
    d = yaml.safe_load(open(os.path.join(k, "config.yaml"))) or {}
    c = RunConfig(**{kk: v for kk, v in d.items() if kk in names})
    moved = dataclasses.replace(c, adam_eps=1e-20).run_id != c.run_id
    print("  adam_eps = 1e-20 entre dans l'identifiant : " + ("oui" if moved else "NON"))
    if not moved:
        sys.exit("STOP : adam_eps n'entre pas dans l'identifiant")
