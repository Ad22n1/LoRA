"""Writes the two grids of PROTOCOL_shift_5seeds.md from the server's current bases. 120 runs.

    python scripts/make_shift5_grids.py

STOPS unless configs/grids/sigma_residual_C2.yaml is the format task on Llama-3.2-1B and configs/grids/obqa_r2_common.yaml is OpenBookQA
(fingerprint dc05f4d847f9) on Qwen2.5-1.5B. mode, rank, lr and seed are replaced by the grid; the salt is on; no factors are saved.
"""
import sys
from pathlib import Path

import yaml

ARMS = ["top", "bottom", "random", "random_ortho"]
LRS = [1e-3, 2e-3, 5e-3, 1e-2, 2e-2]
SEEDS = [110, 111, 112]
CELLS = {
    "shift5_fmt": ("configs/grids/sigma_residual_C2.yaml", lambda b: b.get("task") == "format" and str(b.get("model")) == "meta-llama/Llama-3.2-1B"),
    "shift5_obqa": ("configs/grids/obqa_r2_common.yaml", lambda b: b.get("task") == "commonsense" and str(b.get("data_fingerprint")) == "dc05f4d847f9"
                    and str(b.get("model")) == "Qwen/Qwen2.5-1.5B"),
}
H = ("# PRE-ENREGISTRE (PROTOCOL_shift_5seeds.md) : le deplacement du taux, selectionne sur cinq graines (0, 1 + 110-112 neuves).\n"
     "# Genere par scripts/make_shift5_grids.py. Validation seulement. 60 runs.\n")
total = 0
for name, (src, ok) in CELLS.items():
    if not Path(src).exists():
        sys.exit(f"STOP : {src} introuvable")
    base = dict((yaml.safe_load(open(src)) or {}).get("base") or {})
    if not ok(base):
        sys.exit(f"STOP : {src} n'est pas la base attendue (task={base.get('task')}, model={base.get('model')}, empreinte={base.get('data_fingerprint')})")
    for k in ("mode", "rank", "lr", "seed", "band_frac", "update_norm_target"):
        base.pop(k, None)
    base.update(rank=2, subspace_salted=True, save_factor_steps=[])
    n = len(ARMS) * len(LRS) * len(SEEDS); total += n
    Path(f"configs/grids/{name}.yaml").write_text(H + yaml.safe_dump({"base": base, "grid": {"mode": ARMS, "lr": LRS, "seed": SEEDS}}, sort_keys=False))
    print(f"  {name:12s} : {src} -> {base.get('model')}, {base.get('task')}, rang 2, {n} runs")
print(f"  total : {total} runs")
if total != 120:
    sys.exit("STOP : le total n'est pas 120")
