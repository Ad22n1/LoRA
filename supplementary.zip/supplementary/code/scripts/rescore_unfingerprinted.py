"""Re-score, with TODAY's verifier, every format run that recorded no verifier fingerprint.

WHY. Runs before the repository (first commit 16/09 10:37) recorded no verifier fingerprint, and
eval.py says the format checker "was redefined three times". Runs that saved generations_test.jsonl
can be re-scored at no PARTITION cost; the rest can only be settled by a re-run.

THIS VERSION WALKS THE RUN DIRECTORIES. The first version built paths from the `run_id` column of
`collect`, which reads an all-digit identifier as an integer and drops its leading zero: such runs
were reported as "no generations saved" when their file simply could not be found.

Changes nothing on disk unless --write.

    python scripts/rescore_unfingerprinted.py
    python scripts/rescore_unfingerprinted.py --write     # writes ~/lora-analysis/rescored_format.csv
"""
import datetime
import glob
import json
import os
import sys

import pandas as pd
import yaml

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from lorasub.data.format import check_alien  # noqa: E402

RUNS = os.path.expanduser("~/lora-runs")
SEL = (yaml.safe_load(open("configs/lr_selected.yaml")) or {})["selected"]


def rescore(path):
    parsed = n = 0
    with open(path) as f:
        for line in f:
            r = json.loads(line)
            parsed += int(check_alien(r["gen"], r["gold"])["parsed"])
            n += 1
    return parsed / max(1, n), n


def reported(y, fmt_n):
    """The cells the paper's main tables read: selected rate, seeds 2-6, the reported population."""
    k = f"{y.get('model')}|format|{y.get('mode')}|{int(y.get('rank', -1))}"
    lr = SEL.get(k)
    return (lr is not None and abs(float(y.get("lr", 0)) - lr) < 1e-12 and 2 <= int(y.get("seed", -1)) <= 6
            and len(y.get("target_modules") or []) == 7 and y.get("update_norm_target") is None
            and abs(float(y.get("max_grad_norm") or 0) - 1.0) < 1e-6 and fmt_n == 614)


def main():
    rows = []
    for rdir in sorted(glob.glob(os.path.join(RUNS, "*"))):
        res, cfg = os.path.join(rdir, "results.csv"), os.path.join(rdir, "config.yaml")
        if not (os.path.exists(res) and os.path.exists(cfg)):
            continue
        y = yaml.safe_load(open(cfg)) or {}
        if y.get("task") != "format":
            continue
        t = pd.read_csv(res, dtype=str)
        mv = next((t[c].iloc[0] for c in ("metric_version", "_metric_version") if c in t.columns), None)
        if mv not in (None, "", "nan") and not pd.isna(mv):
            continue                                      # fingerprinted: not our concern here
        rec = float(t["format_parsed"].iloc[0])
        fmt_n = int(float(t["format_n"].iloc[0])) if "format_n" in t.columns else -1
        g = os.path.join(rdir, "generations_test.jsonl")
        new, n = rescore(g) if os.path.exists(g) else (None, None)
        rows.append({"dir": os.path.basename(rdir), "model": str(y.get("model")).split("/")[-1],
                     "mode": y.get("mode"), "rank": y.get("rank"), "seed": y.get("seed"), "lr": y.get("lr"),
                     "date": datetime.datetime.fromtimestamp(os.path.getmtime(res)),
                     "reported": reported(y, fmt_n), "gens": new is not None, "n_items": n, "format_n": fmt_n,
                     "recorded": rec, "rescored": new, "diff": None if new is None else new - rec})
    x = pd.DataFrame(rows)
    v, m = x[x.gens], x[~x.gens]
    print(f"\n=== {len(x)} format runs without a fingerprint | generations saved: {len(v)} | none: {len(m)} ===")
    if len(v):
        same = v["diff"].abs() < 1e-9
        print(f"  identical to the recorded score : {int(same.sum())} of {len(v)} | largest difference "
              f"{v['diff'].abs().max() * 100:.2f} pt | item counts off format_n: {int((v.n_items != v.format_n).sum())}")
        print(f"  verified runs date from {v.date.min():%d/%m %H:%M} to {v.date.max():%d/%m %H:%M}")
        if (~same).any():
            print(v[~same].groupby(["mode", "rank"]).agg(n=("diff", "size"),
                  mean_pt=("diff", lambda s: round(s.mean() * 100, 2))).to_string())
    if len(m):
        print(f"  runs WITHOUT generations date from {m.date.min():%d/%m %H:%M} to {m.date.max():%d/%m %H:%M}; "
              f"older than the first verified run: {int((m.date < v.date.min()).sum()) if len(v) else len(m)}")
        mr = m[m.reported]
        print(f"\n  of those, in a REPORTED cell (selected rate, seeds 2-6): {len(mr)}")
        if len(mr):
            print(mr.groupby(["mode", "rank"]).agg(n=("seed", "size"), first=("date", "min"),
                                                   last=("date", "max")).to_string())
    if "--write" in sys.argv:
        x.to_csv(os.path.expanduser("~/lora-analysis/rescored_format.csv"), index=False)
        print("\n  written ~/lora-analysis/rescored_format.csv")


if __name__ == "__main__":
    main()
