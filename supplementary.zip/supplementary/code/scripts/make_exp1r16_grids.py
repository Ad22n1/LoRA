"""Writes the four grids of PROTOCOL_exp1_rank16.md from the server's current bases. 392 runs.

    python scripts/make_exp1r16_grids.py

STOPS unless configs/grids/sigma_residual_C2.yaml is the format task on Llama-3.2-1B and configs/grids/arcc_own_top.yaml is ARC-Challenge
(fingerprint 0755bcdbdce3) on Qwen2.5-1.5B. mode, rank, lr and seed are replaced by the grid; no factors are saved.
"""
import sys
from pathlib import Path

import yaml

ARMS = ["top_unfrozen", "bottom_unfrozen"]
SEEDS = list(range(7))
CELLS = {  # grid: (base file, check, rank, rates)
    "e1r16_fmt_lo": ("configs/grids/sigma_residual_C2.yaml", "fmt", 8, [1e-4, 2e-4, 5e-4, 1e-3, 2e-3, 5e-3, 1e-2]),
    "e1r16_fmt_hi": ("configs/grids/sigma_residual_C2.yaml", "fmt", 16, [1e-4, 2e-4, 5e-4, 1e-3, 2e-3, 5e-3, 1e-2]),
    "e1r16_arc_lo": ("configs/grids/arcc_own_top.yaml", "arc", 7, [5e-5, 1e-4, 2e-4, 5e-4, 1e-3, 2e-3, 5e-3]),
    "e1r16_arc_hi": ("configs/grids/arcc_own_top.yaml", "arc", 16, [5e-5, 1e-4, 2e-4, 5e-4, 1e-3, 2e-3, 5e-3]),
}
CHECK = {
    "fmt": lambda b: b.get("task") == "format" and str(b.get("model")) == "meta-llama/Llama-3.2-1B",
    "arc": lambda b: b.get("task") == "commonsense" and str(b.get("data_fingerprint")) == "0755bcdbdce3" and str(b.get("model")) == "Qwen/Qwen2.5-1.5B",
}
H = ("# PRE-ENREGISTRE (PROTOCOL_exp1_rank16.md) : le gel de B isole au rang 16. Genere par scripts/make_exp1r16_grids.py.\n"
     "# Graines 0-6 ; taux choisi sur 0-1 (validation) ; seuls les runs 2-6 a ce taux sont lus. 98 runs.\n")
total = 0
for name, (src, chk, rank, lrs) in CELLS.items():
    if not Path(src).exists():
        sys.exit(f"STOP : {src} introuvable")
    base = dict((yaml.safe_load(open(src)) or {}).get("base") or {})
    if not CHECK[chk](base):
        sys.exit(f"STOP : {src} n'est pas la base attendue (task={base.get('task')}, model={base.get('model')}, empreinte={base.get('data_fingerprint')})")
    for k in ("mode", "rank", "lr", "seed", "band_frac", "update_norm_target"):
        base.pop(k, None)
    base.update(rank=rank, save_factor_steps=[])
    n = len(ARMS) * len(lrs) * len(SEEDS); total += n
    Path(f"configs/grids/{name}.yaml").write_text(H + yaml.safe_dump({"base": base, "grid": {"mode": ARMS, "lr": lrs, "seed": SEEDS}}, sort_keys=False))
    print(f"  {name:13s} : {src} -> {base.get('model')}, {base.get('task')}, rang {rank}, {n} runs")
print(f"  total : {total} runs")
if total != 392:
    sys.exit("STOP : le total n'est pas 392")
